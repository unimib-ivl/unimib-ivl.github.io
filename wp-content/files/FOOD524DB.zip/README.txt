﻿These MATLAB files contain the information about the composition of the Food524DB Dataset and the split used in training the classifier as found in the paper:

“Learning CNN-based Features for Retrieval of Food Image” Gianluigi Ciocca, Paolo Napoletano, and Raimondo Schettini, Proceedings of MADiMa2017 Conference, 2017 (to be published).

The Food524DB dataset if a composite dataset with images taken from the four food datasets: UECFOOD256 [1], VIREO [2], Food-101 [3], and Food-50 [4].

Each file contains three variables structured as follows:

name : cell array of strings containing the unique name of the foods (e.g. "Almond jelly")

id : cell array of strings containing the unique id of the foods (e.g. "almondjelly")

images: container Map  where each entry, indexed by id, is a cell array of strings with the file names of the food images belonging to the id class

The filenames of the food images, with the exception of UECFOOD256, follow the structure of the original datasets (e.g. VIREO/2/1_0.jpg, Food-101/images/apple_pie/134.jpg, food50/Arepas/20_arepas_001.jpg). For the dataset UECFOOD256, crops of the single food instances are used instead. These are extracted from the given bounding boxes (see the paper for more details). For convenience, this modified dataset is also provided in the UECFOOD256crop.zip archive. The filename structure is as UECFOOD256/1/1.jpg. 


[1] Kawano, Y., Yanai, K.: Automatic expansion of a food image dataset leverag-ing existing categories with domain adaptation. In: Proc. of ECCV Workshop on
Transferring and Adapting Source Knowledge in Computer Vision (2014)

[2] Chen, J., Ngo, C.W.: Deep-based ingredient recognition for cooking recipe retrieval.
In: Proc. of the 2016 ACM on Multimedia Conference. pp. 32{41. ACM (2016)

[3] Bossard, L., Guillaumin, M., Van Gool, L.: Food-101{mining discriminative compo-nents with random forests. In: Computer Vision{ECCV 2014, pp. 446{461 (2014)

[4] Chen, M. Y., Yang, Y. H., Ho, C. J., Wang, S. H., Liu, S. M., Chang, E., Ouhyoung, M. (2012, November). Automatic chinese food identification and quantity estimation. In SIGGRAPH Asia 2012 Technical Briefs (p. 29). ACM.
