clear

% Dimensions guide:
% 1. number of images
% 2. number of subwindows: 1 to 5
% 3. number of scales: 0.5 to 0.9
% 4. number of algorithms

%% BCC

load('BCC_spatial_stability_measures.mat');
winsizes = 50:10:90;
for ii = 1:numel(winsizes)
    fprintf('BCC %d STD\n', winsizes(ii))
    squeeze(mean(squeeze(std(:,ii,:)),1, 'omitnan'))

    fprintf('BCC %d err_rec\n', winsizes(ii))
    squeeze(mean(mean(squeeze(err_rec(:,:,ii,:)),1, 'omitnan'),2))'

    fprintf('BCC %d err_rep\n', winsizes(ii))
    squeeze(mean(mean(squeeze(err_rep(:,:,ii,:)),1, 'omitnan'),2))'
end

awb_names

%% Gray Ball

load('GB_spatial_stability_measures.mat');
winsizes = 50:10:90;
for ii = 1:numel(winsizes)
    fprintf('GB %d STD\n', winsizes(ii))
    squeeze(mean(squeeze(std(:,ii,:)),1, 'omitnan'))

    fprintf('GB %d err_rec\n', winsizes(ii))
    squeeze(mean(mean(squeeze(err_rec(:,:,ii,:)),1, 'omitnan'),2))'

    fprintf('GB %d err_rep\n', winsizes(ii))
    squeeze(mean(mean(squeeze(err_rep(:,:,ii,:)),1, 'omitnan'),2))'
end

awb_names
