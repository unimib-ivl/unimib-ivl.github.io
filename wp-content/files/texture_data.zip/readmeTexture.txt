IMAGING AND VISON LABORATORY 
Department of Informatics, Systems and Communication (DISCo)
UNIVERSITY OF MILANO BICOCCA



� Copyright 2015 Imaging and Vision Laboratory.
All rights reserved


Permission is hereby granted, without written agreement and without license or royalty fees, to use, copy, modify, and distribute the data for any purposes provided that the copyright notice in its entirety appear in all copies of the data. You may also publish  these data in scholarly journals to report research results without any further permission from IVL, citing in the bibliography our papers:

Corchs, Silvia Elena, Gianluigi Ciocca, Emanuela Bricolo, and Francesca Gasparini. "Predicting complexity perception of real world images." PloS one 11, no. 6 (2016): e0157986.

Ciocca, Gianluigi, Silvia Corchs, and Francesca Gasparini. "Genetic programming approach to evaluate complexity of texture images." Journal of Electronic Imaging 25, no. 6 (2016): 061408-061408.



Please contact FRANCESCA GASPARINI (gasparini@disco.unimib.it) or silvia.corchs@disco.unimib.it if you have any questions.

Provided material

TXT1-file.xls --> corresponding to texture images in TXT1 database (54 images one for each class of the VisTex database)
TXT2-file.xls --> corresponding to images of the texture TXT2 database  (58 images of the RawFooT acquired under the D65 lighting condition and frontal direction)


In each of the xls file the filename of the image, the values of the objective measures and the subjective scores are reported.


legend: 

objective measures: 

M1 = contrast
M2 = Correlation
M3 = Energy
M4 = Homogeneity
M5 = Frequency Factor
M6 = Edge Density
M7 = compression Ratio
M8 = number of regions
M9 = Colorfulness
M10 = number of colors
M11 = color Harmony
FC = feature congestion
SE = subband entropy


