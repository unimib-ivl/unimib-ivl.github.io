#-------------------------------------------------
#
# Project created by QtCreator 2014-12-27T15:50:08
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = ImageAnnotationStage
TEMPLATE = app


SOURCES += main.cpp\
        mainwindow.cpp\
	displayimage.cpp\
	projectwizard.cpp\
	options.cpp\
	listtool.cpp

HEADERS  += mainwindow.h\
	displayimage.h\
	projectwizard.h\
	options.h\
	listtool.h

FORMS    += mainwindow.ui\
	options.ui\
	listtool.ui
