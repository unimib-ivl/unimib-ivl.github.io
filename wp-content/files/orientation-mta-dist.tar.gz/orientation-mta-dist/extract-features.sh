#!/bin/bash


function lbp {
    LST=$1
    LBLS=$2

    paste \
	$LBLS \
 	<(./lbphistogram -r "300>" -l $LST -i -t 4 -b 4x1 -N -U -M 16 -R 2) | \
 	./sparsify
}


function lbp2 {
    LST=$1
    LBLS=$2

    paste \
	$LBLS \
	<(./lbphistogram -r "300>" -l $LST -i -t 4 -b 6x1 -N -U -M 16 -R 2) \
	<(./lbphistogram -r "300>" -l $LST -i -t 4 -b 1x6 -N -U -M 16 -R 2) | \
	./sparsify

#     paste \
# 	$LBLS \
# 	<(./lbphistogram -r "300>" -l $LST -i -t 4 -b 4x1 -N -U -M 16 -R 2) \
# 	<(./lbphistogram -r "150>" -l $LST -i -t 4 -b 4x1 -N -U -M 16 -R 2) \
# 	<(./lbphistogram -r "75>" -l $LST -i -t 4 -b 4x1 -N -U -M 16 -R 2) | \
# 	./sparsify
}


function yuv {
    LST=$1
    LBLS=$2

    paste \
	$LBLS \
	<(./yuvmoments -r "300>" -l $LST -i -t 4 -b 6x1 -N) \
	<(./yuvmoments -r "300>" -l $LST -i -t 4 -b 1x6 -N) | \
	./sparsify
}


function lbp_yuv {
    RES=300
    LST=$1
    LABELS=$2

    TEMP=$(mktemp)
    TEMP2=$(mktemp)

    ./yuvmoments -r "${RES}>" -l $LST -i -t 4 -b 6x1 -N > $TEMP
    ./yuvmoments -r "${RES}>" -l $LST -i -t 4 -b 1x6 -N | \
	paste $TEMP - > $TEMP2
    ./lbphistogram -r "${RES}>" -l $LST -i -t 4 -b 6x1 -N -U -M 16 -R 2  | \
	paste $TEMP2 - | paste $LABELS - | ./sparsify

    rm -f $TEMP $TEMP2
}


function features_paper {
    LST=$1
    LBLS=$2


    T1=$(mktemp)
    T2=$(mktemp)
    T3=$(mktemp)
    T4=$(mktemp)

    T1=t1
    T2=t2
    T3=t3
    T4=t4

    ./lbphistogram -r "300>" -l $LST -i -t 4 -b 6x1 -N -U -M 16 -R 2 > $T1
    ./lbphistogram -r "300>" -l $LST -i -t 4 -b 1x6 -N -U -M 16 -R 2 > $T2
    ./yuvmoments -r "300>" -l $LST -i -t 4 -b 6x1 -N > $T3
    ./yuvmoments -r "300>" -l $LST -i -t 4 -b 1x6 -N > $T4

    paste $LBLS $T1 $T2 $T3 $T4 | ./sparsify
    # rm -f $T1 $T2 $T3 $T4
}


function rgb {
    LST=$1
    LBLS=$2

    ./rgbhistogram -r "300>" -l $LST -i -t 4 -b 4x4 -N -M -Q 16 | \
	paste $LBLS - | ./sparsify
}


function sch {
    LST=$1
    LBLS=$2

    ./sch -r "300>" -l $LST -i -t 4 -Q 11 | \
	paste $LBLS - | ./sparsify
}


function tiny {
    LST=$1
    LBLS=$2

    ./tinyimages -r "300>" -l $LST -i -t 4 -D 64 -N | \
	paste $LBLS - | ./sparsify
}


function features {
    features_paper $@
    # lbp_yuv $@
}


C=1e0
TEMP3=t5

T=train
LST=real${T}-list.txt
LABELS=real${T}-labels.txt
OUT=real${T}.svmdata
features $LST $LABELS > $TEMP3
svm-scale -s scaling.dat -l 0 -u 1 $TEMP3 > $OUT
liblinear-train -s 0 -c $C -q $OUT model.svm

T=test
LST=real${T}-list.txt
LABELS=real${T}-labels.txt
OUT=real${T}.svmdata
features $LST $LABELS > $TEMP3
svm-scale -r scaling.dat $TEMP3 > $OUT
ACC=$(liblinear-predict -b 0 $OUT model.svm out.txt | tr '%' '=' | cut -d= -f 2)
    printf "%d\t%g\n" $RES $ACC

rm -f $TEMP3
