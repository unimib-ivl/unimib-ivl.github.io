/**
 * \file    ivl_vector.h
 * \brief   Vector class definition
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivllib_vector_h
#define ivllib_vector_h

//--- Headers --------------------------------------------------------
#include <cstddef>   // size_t
#include <stdexcept> // domain_error
#include <algorithm> // swap,copy,fill,distance,swap
#include <cassert>   // assert

namespace ivllib
{
  /** \cond detail */
  namespace detail
  {
    // the following types are used to disambiguate
    // the constructors.
    
    namespace vec
    {
      struct true_type { };
      struct false_type { };

      template <typename T>
      struct is_integer
      {
	typedef false_type type;
      };

      template <> struct is_integer<bool> { typedef true_type type; };
      template <> struct is_integer<char> { typedef true_type type; };
      template <> struct is_integer<signed char> { typedef true_type type; };
      template <> struct is_integer<unsigned char> { typedef true_type type; };
      template <> struct is_integer<wchar_t> { typedef true_type type; };
      template <> struct is_integer<short> { typedef true_type type; };
      template <> struct is_integer<int> { typedef true_type type; };
      template <> struct is_integer<long> { typedef true_type type; };
      template <> struct is_integer<unsigned short> { typedef true_type type; };
      template <> struct is_integer<unsigned int> { typedef true_type type; };
      template <> struct is_integer<unsigned long> { typedef true_type type; };
      // long long int ???

    } // namespace vec
  } // namespace detail
  /** \endcond */

  /** \addtogroup basic */
  /*@{*/

  //--- Classes --------------------------------------------------------
  /**
   * Generic vector class
   *
   * Vector is a generic class that implements a monodimensional
   * array of generic elements.
   */
  template <typename T>
  class Vector
  {
  public:
    //--- Type definitions ----
    typedef T element_type;         ///< type of the elements
    typedef std::size_t size_type;  ///< type of dimensions and indices

    /**
     * STL-like random access iterator type
     *
     * Random access iterator. If <tt> *it </tt> refers to the element
     * <tt> (i) </tt>, then <tt> *(it+1) </tt> points to:
     * - the element <tt> (i+1) </tt> if <tt> i! = size()-1 </tt>
     *
     * Iterators are invalidated by the methods:
     * - swap()
     * - resize()
     * - operator=()
     * - ~Vector()
     */
    typedef T* iterator;

    /**
     * STL-like const random access iterator type.
     *
     * \see iterator
     */
    typedef const T* const_iterator;

    //--- Constructors --------
    Vector();
    Vector(const Vector& pOther);
    explicit Vector(size_type pSize);
    Vector(size_type pSize,const T& pValue);
    template <typename ForwardIterator>
    Vector(ForwardIterator first,
	   ForwardIterator last);

    //--- Destructor ----------
    ~Vector(); ///< destructor

    //--- Methods -------------
    void swap(Vector& pOther);
    void resize(size_type pNewSize);
    void resize(size_type pNewSize,const T& pValue);
    void assign(const T& value);
    template <typename ForwardIterator>
    void assign(ForwardIterator first,ForwardIterator last);
    void clear();

    size_type size() const;
    element_type& elementAt(size_type pIndex);
    const element_type& elementAt(size_type pIndex) const;

    iterator begin();
    iterator end();
    const_iterator begin() const;
    const_iterator end() const;

    //--- Operators -----------
    element_type& operator[](size_type pIndex);
    const element_type& operator[](size_type pIndex) const;
    Vector& operator=(const Vector& pOther);

  private:
    //--- Methods -------------

    /** \cond detail */
    template <typename U>
    void dispatched_constructor(U first,
				U second,
				detail::vec::true_type);

    template <typename U>
    void dispatched_constructor(U first,
				U second,
				detail::vec::false_type);
    /** \endcond */

    //--- Attributes ----------
    size_type mSize;         ///< size of the vector
    element_type* mElements; ///< elements

  }; // Vector

  //--------------------------------------------------------------------

  /**
   * Swaps the content of two vectors.
   *
   * \param a first vector
   * \param b second vector
   */
  template <typename T>
  void swap(Vector<T>& a,Vector<T>& b)
  {
    a.swap(b);
  }

  //--- Vector - public - ---------------------------------------
  /**
   * Creates an empty vector
   *
   * \post size() == 0
   */
  template <typename T>
  Vector<T>::Vector()
    : mSize(0),
      mElements(0)
  {
  }

  /**
   * Creates a vector with the given dimension.
   *
   * \param pSize the size of the vector
   *
   * \post size() == pSize
   */
  template <typename T>
  Vector<T>::Vector(size_type pSize)
    : mSize(pSize>0 ? pSize : 0),
      mElements(pSize>0 ? new element_type[pSize] : 0)
  {
  }

  /**
   * Creates a vector with the given dimension.
   *
   * \param pSize the size of the vector
   * \param pValue initialization value of the elements
   *
   * \post size() == pSize
   */
  template <typename T>
  Vector<T>::Vector(size_type pSize,const T& pValue)
    : mSize(pSize>0 ? pSize : 0),
      mElements(pSize>0 ? new element_type[pSize] : 0)
  {
    std::fill(begin(),end(),pValue);
  }

  /**
   * Copy constructor
   * Make a deep copy of \p pOther
   *
   * \param pOther the vector to be copied
   *
   * \post size() == pOther.size()
   * \post elementAt(i) == pOther.elementAt(i)
   */
  template <typename T>
  Vector<T>::Vector(const Vector& pOther)
    : mSize(pOther.mSize),
      mElements(0)
  {
    if (mSize<1)
      return;

    mElements = new element_type[mSize];

    try {
      std::copy(pOther.begin(),pOther.end(),mElements);
    } catch (...) {
      delete[] mElements;
      throw;
    }
  }

  /**
   * Creates a vector given an input sequence.
   *
   * \param first iterator to the first element of the sequence
   * \param last  past-the-end iterator of the sequence
   *
   * \post size() == std::distance(first,last)
   *
   * \note The last parameter is defaulted. It is needed to disambiguate
   *       constructors and it may be ignored.
   */
  template <typename T> template <typename ForwardIterator>
  Vector<T>::Vector(ForwardIterator first,
		    ForwardIterator last)
    : mSize(0), mElements(0)
  {
    typedef typename detail::vec::is_integer<ForwardIterator>::type is_int;
    dispatched_constructor(first,
			   last,
			   is_int());
  }
  
  //--- Vector - public - Destructor ----------------------------------
  template <typename T>
  Vector<T>::~Vector()
  {
    delete[] mElements;
  }

  //--- Vector - public - Methods -------------------------------------
  /**
   * \return the number of elements in the vector
   */
  template <typename T>
  inline typename Vector<T>::size_type Vector<T>::size() const
  {
    return mSize;
  }

  /**
   * Swaps the content of two vectors
   * \param pOther the vector with wich the content is swapped
   */
  template <typename T>
  void Vector<T>::swap(Vector& pOther)
  {
    std::swap(mSize,pOther.mSize);
    std::swap(mElements,pOther.mElements);
  }

  /**
   * Resize th vector with the given size.
   *
   * \param pNewSize the new vector size
   *
   * \post size() == pNewSize
   */
  template <typename T>
  void Vector<T>::resize(size_type pNewSize)
  {
    Vector temp(pNewSize);
    swap(temp);
  }

  /**
   * Resize th vector with the given size.
   *
   * \param pNewSize the new vector size
   * \param pValue initialization value of the elements
   *
   * \post size() == pNewSize
   */
  template <typename T>
  void Vector<T>::resize(size_type pNewSize,const T& pValue)
  {
    Vector temp(pNewSize,pValue);
    swap(temp);
  }

  /**
   * \return the iterator pointing to the first element of the vector
   */
  template <typename T>
  inline typename Vector<T>::iterator
  Vector<T>::begin()
  {
    return mElements;
  }

  /**
   * \return the iterator pointing to the first element past the last element of the vector
   */
  template <typename T>
  inline typename Vector<T>::iterator
  Vector<T>::end()
  {
    return mElements+mSize;
  }

  /**
   * \return the const iterator pointing to the first element of the vector
   */
  template <typename T>
  inline typename Vector<T>::const_iterator
  Vector<T>::begin() const
  {
    return mElements;
  }

  /**
   * \return the const iterator pointing to the first element past the last element of the vector
   */
  template <typename T>
  inline typename Vector<T>::const_iterator
  Vector<T>::end() const
  {
    return mElements+mSize;
  }

  /**
   * Assign a @p value to each element of the vector.
   *
   * \param value value to be assigned
   */
  template <typename T>
  void Vector<T>::assign(const T& value)
  {
    std::fill(begin(),end(),value);
  }

  /**
   * Assign the values of an input sequence to the vector.
   *
   * \param first iterator to the first element of the sequence
   * \param last  past-the-end iterator of the sequence
   *
   * The former elements of the vector are lost.
   *
   * \post size() == std::distance(first,last)
   */
  template <typename T> template <typename ForwardIterator>
  void Vector<T>::assign(ForwardIterator first,ForwardIterator last)
  {
    // check if ForwardIterator is really an iterator
    // typedef typename std::iterator_traits<ForwardIterator>
    //   ::iterator_category iterator_category;

    Vector<T> tmp(first,last);
    swap(tmp);
  }

  /**
   * Empty the vector.
   *
   * \post size() == 0
   */
  template <typename T>
  void Vector<T>::clear()
  {
    Vector<T> tmp;
    swap(tmp);
  }

  //--- Vector - public - Operators -----------------------------------

  /**
   * if pIndex is 0 then the first element is returned
   * (if the vector is not empty).
   * if pIndex is size()-1 then the last element is returned
   * (if the vector is not empty).
   * the behaviour is undefined when pIndex<0 or pIndex>= size().
   */
  template <typename T>
  inline typename Vector<T>::element_type&
  Vector<T>::operator[](size_type pIndex)
  {
    return mElements[pIndex];
  }

  /**
   * if pIndex is 0 then the first element is returned
   * (if the vector is not empty).
   * if pIndex is Size()-1 then the last element is returned
   * (if the vector is not empty).
   * the behaviour is undefined when pIndex<0 or pIndex>= Size().
   */
  template <typename T>
  inline const typename Vector<T>::element_type&
  Vector<T>::operator[](size_type pIndex) const
  {
    return mElements[pIndex];
  }

  /**
   * Assignement of a vector
   *
   * The content of \p pOther is (deep) copied in the destination vector.
   * The elements formerly contained are destroyed.
   *
   * \param pOther the vector to be copied
   *
   * \post size() == pOther.size()
   * \post elementAt(i) == pOther.elementAt(i)
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  Vector<T>& Vector<T>::operator=(const Vector& pOther)
  {
    Vector temp(pOther);
    swap(temp);
    return *this;
  }

  /**
   * Access to an element of the vector.
   *
   * The index is checked against the vector size.
   *
   * \param pIndex the index of the element to retrieve
   *
   * \return a reference to the element of position (pIndex)
   *
   * \pre 0 <= pIndex < size()
   *
   * \exception std::out_of_range
   */
  template <typename T>
  typename Vector<T>::element_type&
  Vector<T>::elementAt(size_type pIndex)
  {
    if (pIndex<0)
      throw std::out_of_range("Subscript index must be positive integer.");
    if (pIndex>=mSize)
      throw std::out_of_range("Index exceed vector size.");

    return mElements[pIndex];
  }

  /**
   * Read-only access to an element of the vector.
   *
   * The index is checked against the vector size.
   *
   * \param pIndex the index of the element to retrieve
   *
   * \return a reference to the element of position (pIndex)
   *
   * \pre 0 <= pIndex < size()
   *
   * \exception std::out_of_range
   */
  template <typename T>
  const typename Vector<T>::element_type&
  Vector<T>::elementAt(size_type pIndex) const
  {
    if (pIndex<0)
      throw std::out_of_range("Subscript index must be positive integer.");
    if (pIndex>=mSize)
      throw std::out_of_range("Index exceed vector size.");

    return mElements[pIndex];
  }
  
  /*@}*/  

  /** \cond detail  */

  // construction using a (size, value) pair
  template <typename T> template <typename U>
  void Vector<T>::dispatched_constructor(U first,
					 U second,
					 detail::vec::true_type /* ignored */)
  {
    assert( first >= 0 );
    mSize = first; 
    mElements = (mSize > 0 ? new element_type[mSize] : 0);
    std::fill(begin(),end(),second);
  }

  // construction using a pair of iterators
  template <typename T> template <typename U>
  void Vector<T>::dispatched_constructor(U first,
					 U second,
					 detail::vec::false_type /* ignored */)
  {
    mSize = static_cast<size_type>(std::distance(first,second));
    mElements = (mSize > 0 ? new element_type[mSize] : 0);
    try {
      std::copy(first, second, mElements);
    } catch (...) {
      delete[] mElements;
      throw;
    }
  }

  /** \endcond */

} // namespace ivllib

#endif // ivllib_vector_h
