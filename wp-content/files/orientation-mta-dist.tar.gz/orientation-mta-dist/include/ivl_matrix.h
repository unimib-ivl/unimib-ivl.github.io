/**
 * \file    ivl_matrix.h
 * \brief   definition of the matrix class
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivllib_matrix_h
#define ivllib_matrix_h

/**
 * \example matrix_iterators.cpp
 *
 * Example on how to use matrix iterators.
 */

//--- Headers --------------------------------------------------------
#include <cstddef>   // size_t
#include <stdexcept> // out_of_range
#include <cassert>   // assert
#include <algorithm> // swap,copy,fill
#include "stride_iterator.h"

//--- Classes --------------------------------------------------------

namespace ivllib
{
  /** \cond detail */
  namespace detail
  {
    // the following types are used to disambiguate
    // the constructors.
    
    namespace mat
    {
      struct true_type { };
      struct false_type { };

      template <typename T>
      struct is_integer
      {
	typedef false_type type;
      };

      template <> struct is_integer<bool> { typedef true_type type; };
      template <> struct is_integer<char> { typedef true_type type; };
      template <> struct is_integer<signed char> { typedef true_type type; };
      template <> struct is_integer<unsigned char> { typedef true_type type; };
      template <> struct is_integer<wchar_t> { typedef true_type type; };
      template <> struct is_integer<short> { typedef true_type type; };
      template <> struct is_integer<int> { typedef true_type type; };
      template <> struct is_integer<long> { typedef true_type type; };
      template <> struct is_integer<unsigned short> { typedef true_type type; };
      template <> struct is_integer<unsigned int> { typedef true_type type; };
      template <> struct is_integer<unsigned long> { typedef true_type type; };
      // long long int ???

    } // namespace mat
  } // namespace detail
  /** \endcond */

  /** \addtogroup basic */
  /*@{*/

  /**
   * Generic matrix class
   *
   * Matrix is a generic class that implements a bidimensional
   * array of generic elements.
   *
   */
  template <typename T>
  class Matrix
  {
  public:
    //--- Type definitions ----
    typedef T element_type;          ///< type of the elements
    typedef std::size_t size_type;   ///< type of dimensions and indices

    /**
     * STL-like random access iterator type
     *
     * Random access iterator. If <tt> *it </tt> refers to the element
     * <tt> (i,j) </tt>, then <tt> *(it+1) </tt> points to:
     * - the element <tt> (i,j+1) </tt> if <tt> j != columns()-1 </tt>
     * - the element <tt> (i+1,0) </tt> if <tt> j == columns()-1 </tt>
     *   and <tt> i != rows()-1 </tt>
     * - end() if <tt> j == columns()-1 </tt> and <tt> i == rows()-1 </tt>
     *
     * Iterators are invalidated by the methods:
     * - swap()
     * - resize()
     * - operator=()
     * - ~Matrix()
     */
    typedef T* iterator;

    /**
     * STL-like const random access iterator type.
     *
     * \see iterator
     */
    typedef const T* const_iterator;

    /// type of the iterator which iterates over the elements of a single row
    typedef iterator row_iterator;
    /// type of the iterator which iterates over the elements of a single row
    typedef const_iterator const_row_iterator;

    /// type of the iterator which iterates over the elements of a single column
    typedef StrideIterator<iterator> column_iterator;
    /// type of the iterator which iterates over the elements of a single column
    typedef StrideIterator<const_iterator> const_column_iterator;

    /// type of the iterator which iterates over the elements of a single diagonal (form top-left to bottom-right)
    typedef StrideIterator<iterator> diagonal_iterator;
    /// type of the iterator which iterates over the elements of a single diagonal (form top-left to bottom-right)
    typedef StrideIterator<const_iterator> const_diagonal_iterator;

    /// type of the iterator which iterates over the elements of a single counter-diagonal (form top-right to bottom-left)
    typedef StrideIterator<iterator> counter_diagonal_iterator;
    /// type of the iterator which iterates over the elements of a single counter-diagonal (form top-right to bottom-left)
    typedef StrideIterator<const_iterator> const_counter_diagonal_iterator;

    /// type used for the indices of the diagonals
    typedef typename diagonal_iterator::difference_type diagonal_index_type;

    //--- Constructors --------
    Matrix();
    Matrix(size_type pRows,size_type pColumns);
    Matrix(size_type pRows,size_type pColumns,const T& value);
    Matrix(const Matrix& pOther);
    template <typename ForwardIterator,typename S>
    Matrix(ForwardIterator first,
	   ForwardIterator last,
	   S ncolumns);

    template <typename U>
    Matrix(const Matrix<U>& pOther);
      
    
    //--- Destructor ----------
    ~Matrix();

    //--- Methods -------------
    size_type rows() const;
    size_type columns() const;
    element_type& elementAt(size_type pRow,size_type pColumn);
    const element_type& elementAt(size_type pRow,size_type pColumn) const;
    void resize(size_type pRows,size_type pColumns);
    void resize(size_type pRows,size_type pColumns,const T& value);
    void swap(Matrix& pOther);
    void clear();
    void assign(const T& value);
    template <typename ForwardIterator>
    void assign(ForwardIterator first,
		ForwardIterator last,
		size_type ncolumns);
    
    iterator begin();
    iterator end();
    const_iterator begin() const;
    const_iterator end() const;

    row_iterator row_begin(size_type i);
    row_iterator row_end(size_type i);
    const_row_iterator row_begin(size_type i) const;
    const_row_iterator row_end(size_type i) const;

    column_iterator column_begin(size_type j);
    column_iterator column_end(size_type j);
    const_column_iterator column_begin(size_type j) const;
    const_column_iterator column_end(size_type j) const;

    diagonal_iterator diagonal_begin(diagonal_index_type i = 0);
    diagonal_iterator diagonal_end(diagonal_index_type i = 0);
    const_diagonal_iterator diagonal_begin(diagonal_index_type i = 0) const;
    const_diagonal_iterator diagonal_end(diagonal_index_type i = 0) const;

    counter_diagonal_iterator counter_diagonal_begin(diagonal_index_type i = 0);
    counter_diagonal_iterator counter_diagonal_end(diagonal_index_type i = 0);
    const_counter_diagonal_iterator counter_diagonal_begin(diagonal_index_type i = 0) const;
    const_counter_diagonal_iterator counter_diagonal_end(diagonal_index_type i = 0) const;

    //--- Operators -----------
    Matrix& operator=(const Matrix& pOther);
    template <typename U>
    Matrix& operator=(const Matrix<U>& pOther);
    row_iterator operator[](size_type pRow);
    const_row_iterator operator[](size_type pRow) const;

  private:
    //--- Methods -------------

    /** \cond detail */
    template <typename U, typename S>
    void dispatched_constructor(U first,
				U second,
				S third,
				detail::mat::true_type);

    template <typename U, typename S>
    void dispatched_constructor(U first,
				U second,
				S third,
				detail::mat::false_type);
    /** \endcond */
    
    //--- Attributes ----------
    size_type mRows;         ///< number of rows
    size_type mColumns;      ///< number of columns
    element_type* mElements; ///< pointer to the buffer that contains the elements
    element_type** mRowsPtr;

  }; // Matrix

  //--------------------------------------------------------------------

  /**
   * Swaps the content of two matrices.
   *
   * \param a first matrix
   * \param b second matrix
   */
  template <typename T>
  void swap(Matrix<T>& a,Matrix<T>& b)
  {
    a.swap(b);
  }

  //--- Matrix - public - Inline ---------------------------------------

  /**
   * Creates an empty matrix.
   *
   * \post rows() == 0
   * \post columns() == 0
   */
  template <typename T>
  inline Matrix<T>::Matrix()
    : mRows(0),mColumns(0),mElements(0),mRowsPtr(0)
  {
  }

  /**
   * Creates a matrix with the given dimension.
   *
   * The new matrix will have \p pRows rows and \p pColumns columns.
   * All the elements in the matrix are default-initialized.
   *
   * \param pRows number of rows
   * \param pColumns number of columns
   *
   * \pre pRows >= 0
   * \pre pColumns >= 0
   *
   * \post rows() == pRows
   * \post columns() == pColumns
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  Matrix<T>::Matrix(size_type pRows,size_type pColumns)
    : mRows(pRows),mColumns(pColumns),
      mElements(pRows*pColumns>0 ? new element_type[pRows*pColumns] : 0),
      mRowsPtr(0)
  {
    try {
      mRowsPtr = new element_type*[pRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= pRows; i++)
      mRowsPtr[i] = mElements + i*pColumns;
  }

  /**
   * Creates a matrix with the given dimension.
   *
   * The new matrix will have \p pRows rows and \p pColumns columns.
   * All the elements in the matrix are initialized to \p value.
   *
   * \param pRows number of rows
   * \param pColumns number of columns
   * \param value value of the elements
   *
   * \pre pRows >= 0
   * \pre pColumns >= 0
   *
   * \post rows() == pRows
   * \post columns() == pColumns
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  Matrix<T>::  Matrix(size_type pRows,size_type pColumns,const T& value)
    : mRows(pRows),
      mColumns(pColumns),
      mElements(pRows*pColumns>0 ? new element_type[pRows*pColumns] : 0),
      mRowsPtr(0)
  {
    try {
      std::fill(begin(),end(),value);
      mRowsPtr = new element_type*[pRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= pRows; i++)
      mRowsPtr[i] = mElements + i*pColumns;
  }

  /**
   * Copy constructor.
   *
   * Make a deep copy of \p pOther.
   *
   * \param pOther the matrix to be copied
   *
   * \post rows() == pOther.rows()
   * \post columns() == pOther.columns()
   * \post elementAt(i,j) == pOther.elementAt(i,j)
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  Matrix<T>::Matrix(const Matrix& pOther)
    : mRows(pOther.mRows),
      mColumns(pOther.mColumns),
      mElements(pOther.mRows*pOther.mColumns>0
		? new element_type[pOther.mRows*pOther.mColumns]
		: 0),
      mRowsPtr(0)
  {
    try {
      std::copy(pOther.begin(),pOther.end(),begin());
      mRowsPtr = new element_type*[mRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= mRows; i++)
      mRowsPtr[i] = mElements + i*mColumns;
  }


  /**
   * Conversion constructor
   *
   * create a new matrix converting the elements of \p pOther
   *
   * \post rows() == pOther.rows()
   * \post columns() == pOther.columns()
   * \post elementAt(i,j) is the conversion of pOther.elementAt(i,j)
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  template <typename U>
  Matrix<T>::Matrix(const Matrix<U>& pOther) : 
    mRows(pOther.rows()),
    mColumns(pOther.columns()),
    mElements(pOther.rows()*pOther.columns()>0
	      ? new element_type[pOther.rows()*pOther.columns()]
	      : 0),
    mRowsPtr(0)
  {
    try {
      
      std::copy(pOther.begin(),pOther.end(),begin());
      
      mRowsPtr = new element_type*[mRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= mRows; i++)
      mRowsPtr[i] = mElements + i*mColumns;
  }

  /**
   * Creates a matrix given an input sequence.
   *
   * \param first iterator to the first element of the sequence
   * \param last  past-the-end iterator of the sequence
   * \param ncolumns number of columns of the new matrix
   *
   * The number of elements of the sequence must be a multiple
   * of @p ncolumns. If @p ncolumns is 0 the sequence must be
   * empty.
   *
   * \pre std::distance(first,last) == 0 || 
   *      (ncolumns > 0 && std::distance(first,last) % ncolumns == 0)
   *
   * \post rows() == (std::distance(first,last) == 0 ? 0 
   *                 : std::distance(first,last) / ncolumns)
   * \post columns() == (std::distance(first,last) == 0 ? 0 : ncolumns)
   *
   * \note The last parameter is defaulted. It is needed to disambiguate
   *       constructors and it may be ignored.
   */
  template <typename T> template <typename ForwardIterator,typename S>
  Matrix<T>::Matrix(ForwardIterator first,
		    ForwardIterator last,
		    S ncolumns)
    : mRows(0),
      mColumns(0),
      mElements(0),
      mRowsPtr(0)
  {
    typedef typename detail::mat::is_integer<ForwardIterator>::type is_int;
    dispatched_constructor(first,
			   last,
			   ncolumns,
			   is_int());
  }
  
  /**
   * Destructor.
   */
  template <typename T>
  Matrix<T>::~Matrix()
  {
    delete[] mElements;
    delete[] mRowsPtr;
  }

  /**
   * Returns the number of rows of the matrix.
   *
   * \return the number of rows of the matrix
   */
  template <typename T>
  typename Matrix<T>::size_type Matrix<T>::rows() const
  {
    return mRows;
  }

  /**
   * Returns the number of columns of the matrix.
   *
   * \return the number of columns of the matrix
   */
  template <typename T>
  typename Matrix<T>::size_type Matrix<T>::columns() const
  {
    return mColumns;
  }

  /**
   * Access to an element of the matrix.
   *
   * The parameters are checked against the matrix dimensions.
   *
   * \param pRow the row that contains the element to retrieve
   * \param pColumn the column that contains the element to retrieve
   *
   * \return a reference to the element of position (pRow,pColumn)
   *
   * \pre 0 <= pRow < rows()
   * \pre 0 <= pColumn < columns()
   *
   * \exception std::out_of_range
   */
  template <typename T>
  typename Matrix<T>::element_type&
  Matrix<T>::elementAt(size_type pRow,size_type pColumn)
  {
    if (pRow<0 || pColumn<0)
      throw std::out_of_range("Subscript indices must be positive integers.");
    if (pRow>=mRows || pColumn>=mColumns)
      throw std::out_of_range("Indices exceed matrix dimensions.");

    return mRowsPtr[pRow][pColumn];
  }

  /**
   * Read-only access to an element of the matrix.
   *
   * The parameters are checked against the matrix dimensions.
   *
   * \param pRow the row that contains the element to retrieve
   * \param pColumn the column that contains the element to retrieve
   *
   * \return a const reference to the element of position (pRow,pColumn)
   *
   * \pre 0 <= pRow < rows()
   * \pre 0 <= pColumn < columns()
   *
   * \exception std::out_of_range
   */
  template <typename T>
  const typename Matrix<T>::element_type&
  Matrix<T>::elementAt(size_type pRow,size_type pColumn) const
  {
    if (pRow<0 || pColumn<0)
      throw std::out_of_range("Subscript indices must be positive integers.");
    if (pRow>=mRows || pColumn>=mColumns)
      throw std::out_of_range("Indices exceed matrix dimensions.");

    return mRowsPtr[pRow][pColumn];
  }

  /**
   * Resize the matrix.
   *
   * The matrix will have \p pRows rows and \p pColumns columns.
   * All the elements in the matrix are default-initialized
   * (the values of previous elements are lost).
   *
   * \param pRows number of rows
   * \param pColumns number of columns
   *
   * \pre pRows >= 0
   * \pre pColumns >= 0
   *
   * \post rows() == pRows
   * \post columns() == pColumns
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  void Matrix<T>::resize(size_type pRows,size_type pColumns)
  {
    Matrix tmp(pRows,pColumns);
    swap(tmp);
  }

  /**
   * Resize the matrix.
   *
   * The matrix will have \p pRows rows and \p pColumns columns.
   * All the elements in the matrix are initialized to \p value.
   * (the values of previous elements are lost).
   *
   * \param pRows number of rows
   * \param pColumns number of columns
   * \param value value of the elements
   *
   * \pre pRows >= 0
   * \pre pColumns >= 0
   *
   * \post rows() == pRows
   * \post columns() == pColumns
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  void Matrix<T>::resize(size_type pRows,size_type pColumns,const T& value)
  {
    Matrix tmp(pRows,pColumns,value);
    swap(tmp);
  }

  /**
   * Swaps the content of two matrices.
   *
   * \param pOther the matrix with which the content is swapped
   */
  template <typename T>
  void Matrix<T>::swap(Matrix& pOther)
  {
    std::swap(mElements,pOther.mElements);
    std::swap(mRows,pOther.mRows);
    std::swap(mColumns,pOther.mColumns);
    std::swap(mRowsPtr,pOther.mRowsPtr);
  }

  /**
   * Clear the content of the matrix.
   *
   * \post rows() == 0
   * \post columns() == 0
   */
  template <typename T>
  void Matrix<T>::clear()
  {
    Matrix tmp;
    swap(tmp);
  }

  /**
   * Assign a @p value to each element of the matrix.
   *
   * \param value value to be assigned
   */
  template <typename T>
  void Matrix<T>::assign(const T& value)
  {
    std::fill(begin(), end(), value);
  }

  /**
   * Assign an input sequence to the matrix.
   *
   * \param first iterator to the first element of the sequence
   * \param last  past-the-end iterator of the sequence
   * \param ncolumns number of columns of the new matrix
   *
   * The number of elements of the sequence must be a multiple of @p
   * ncolumns. If @p ncolumns is 0 the sequence must be
   * empty. Previous elements are deleted.
   *
   * \pre std::distance(first,last) == 0 || 
   *      (ncolumns > 0 && std::distance(first,last) % ncolumns == 0)
   *
   * \post rows() == (std::distance(first,last) == 0 ? 0 
   *                 : std::distance(first,last) / ncolumns)
   * \post columns() == (std::distance(first,last) == 0 ? 0 : ncolumns)
   */
  template <typename T> template <typename ForwardIterator>
  void Matrix<T>::assign(ForwardIterator first,
			 ForwardIterator last,
			 size_type ncolumns)
  {
    // check if ForwardIterator is really an iterator
    // typedef typename std::iterator_traits<ForwardIterator>
    //   ::iterator_category iterator_category;

    Matrix tmp(first,last,ncolumns);
    swap(tmp);
  }
  
  /**
   * Access to the begin of the matrix.
   *
   * Returns a random access iterator to the first element of the matrix.
   *
   * \return an iterator to the first element.
   */
  template <typename T>
  typename Matrix<T>::iterator Matrix<T>::begin()
  {
    return mElements;
  }

  /**
   * const version
   *
   * \see begin()
   */
  template <typename T>
  typename Matrix<T>::const_iterator Matrix<T>::begin() const
  {
    return mElements;
  }

  /**
   * Access to the end of the matrix.
   *
   * Returns a random access iterator pointing to past the last element
   * of the matrix.
   *
   * \return past the end iterator.
   */
  template <typename T>
  typename Matrix<T>::iterator Matrix<T>::end()
  {
    return mElements+mRows*mColumns;
  }

  /**
   * const version
   *
   * \see end()
   */
  template <typename T>
  typename Matrix<T>::const_iterator Matrix<T>::end() const
  {
    return mElements+mRows*mColumns;
  }

  /**
   * Access to the begin of a row of the matrix.
   *
   * Returns a random access iterator pointing to the first
   * element of the row of index <tt>i</tt>
   *
   * \pre 0 <= i < rows()
   *
   * \param i index of the row
   * \return iterator to the first element of the row.
   */
  template <typename T>
  typename Matrix<T>::row_iterator
  Matrix<T>::row_begin(size_type i)
  {
    if (i>=rows())
	throw std::runtime_error("i>=rows");
    assert(i<rows());
    return mRowsPtr[i];
  }

  /**
   * Access to the end of a row of the matrix
   *
   * \pre 0 <= i < rows()
   *
   * \param i index of the row
   * \return iterator to past the last the element of the row
   *
   * \see row_begin()
   */
  template <typename T>
  typename Matrix<T>::row_iterator
  Matrix<T>::row_end(size_type i)
  {
    assert(i<rows());
    return mRowsPtr[i+1];
  }

  /**
   * const version
   *
   * \see row_begin()
   */
  template <typename T>
  typename Matrix<T>::const_row_iterator
  Matrix<T>::row_begin(size_type i) const
  {
    assert(i<rows());
    return mRowsPtr[i];
  }

  /**
   * const version
   *
   * \see row_end()
   */
  template <typename T>
  typename Matrix<T>::const_row_iterator
  Matrix<T>::row_end(size_type i) const
  {
    assert(i<rows());
    return mRowsPtr[i+1];
  }

  /**
   * Access to the begin of a column of the matrix.
   *
   * Returns a random access iterator pointing to the first
   * element of the column of index <tt>j</tt>
   *
   * \pre 0 <= j < columns()
   *
   * \param j index of the column
   * \return iterator to the first element of the column.
   */
  template <typename T>
  typename Matrix<T>::column_iterator
  Matrix<T>::column_begin(size_type j)
  {
    assert(j < columns());
    return column_iterator(mElements+j,mColumns);
  }

  /**
   * Access to the end of a column of the matrix
   *
   * \pre 0 <= j < columns()
   *
   * \param j index of the column
   * \return iterator to past the last the element of the column
   *
   * \see column_begin()
   */
  template <typename T>
  typename Matrix<T>::column_iterator
  Matrix<T>::column_end(size_type j)
  {
    assert(j < columns());
    return column_begin(j) + mRows;
  }

  /**
   * const version
   *
   * \see column_begin()
   */
  template <typename T>
  typename Matrix<T>::const_column_iterator
  Matrix<T>::column_begin(size_type j) const
  {
    assert(j < columns());
    return const_column_iterator(mElements+j,mColumns);
  }


  /**
   * const version
   *
   * \see column_end()
   */
  template <typename T>
  typename Matrix<T>::const_column_iterator
  Matrix<T>::column_end(size_type j) const
  {
    assert(j < columns());
    return column_begin(j) + mRows;
  }

  /**
   * Access to the begin of a diagonal of the matrix.
   *
   * Returns a random access iterator pointing to first
   * element of the diagonal of index <tt>i</tt>.
   *
   * The index <tt>i</tt> can be positive or negative
   * - a positive index <tt>i</tt>  corresponds to the diagonal starting at row 0, column <tt>i</tt>
   * - a negative index corresponds to the diagonal starting at row <tt>-i</tt>, column 0
   * - a null index (default) corresponds to the principal diagonal
   *
   * Diagonals are traversed from top-left to bottom-right.
   *
   * \pre i < columns()
   * \pre -i < rows()
   *
   * \param i index of the column
   * \return iterator to the first element of the diagonal
   */
  template <typename T>
  typename Matrix<T>::diagonal_iterator
  Matrix<T>::diagonal_begin(diagonal_index_type i)
  {
    assert(i < diagonal_index_type(columns()));
    assert(-i < diagonal_index_type(rows()));
    return diagonal_iterator(mElements + (i >= 0 ? i : -i*mColumns),
			     mColumns+1);
  }

  /**
   * Access to the end of a diagonal of the matrix.
   *
   * \pre i < columns()
   * \pre -i < rows()
   *
   * \param i index of the diagonal
   * \return iterator to past the last the element of the diagonal
   *
   * \see diagonal_begin()
   */
  template <typename T>
  typename Matrix<T>::diagonal_iterator
  Matrix<T>::diagonal_end(diagonal_index_type i)
  {
    assert(i < diagonal_index_type(columns()));
    assert(-i < diagonal_index_type(rows()));
    return diagonal_begin(i) + (i >= 0
				? std::min(mRows, mColumns-i)
				: std::min(mRows+i, mColumns));
  }

  /**
   * const version
   *
   * \see diagonal_begin()
   */
  template <typename T>
  typename Matrix<T>::const_diagonal_iterator
  Matrix<T>::diagonal_begin(diagonal_index_type i) const
  {
    assert(i < diagonal_index_type(columns()));
    assert(-i < diagonal_index_type(rows()));
    return diagonal_iterator(mElements + (i >= 0 ? i : -i*mColumns),
			     mColumns+1);
  }

  /**
   * const version
   *
   * \see diagonal_end()
   */
  template <typename T>
  typename Matrix<T>::const_diagonal_iterator
  Matrix<T>::diagonal_end(diagonal_index_type i) const
  {
    assert(i < diagonal_index_type(columns()));
    assert(-i < diagonal_index_type(rows()));
    return diagonal_begin(i) + (i >= 0
				? std::min(mRows, mColumns-i)
				: std::min(mRows+i, mColumns));
  }

  /**
   * Access to the begin of a counter-diagonal of the matrix.
   *
   * Returns a random access iterator pointing to first
   * element of the counter-diagonal of index <tt>i</tt>.
   *
   * The index <tt>i</tt> can be positive or negative
   * - a positive index <tt>i</tt>  corresponds to the diagonal starting at row i, column <tt>columns()-1</tt>
   * - a negative index corresponds to the diagonal starting at row <tt>0</tt>, column <tt>columns() + i - 1</tt>
   * - a null index (default) corresponds to the principal counter-diagonal
   *
   * Diagonals are traversed from top-right to bottom-left
   *
   * \pre i < rows()
   * \pre -i < columns()
   *
   * \param i index of the counter-diagonal
   * \return iterator to the first element of the counter-diagonal
   */
  template <typename T>
  typename Matrix<T>::counter_diagonal_iterator
  Matrix<T>::counter_diagonal_begin(diagonal_index_type i)
  {
    assert(i < diagonal_index_type(rows()));
    assert(-i < diagonal_index_type(columns()));
    return counter_diagonal_iterator(mElements + (i >= 0 ? mColumns*(i+1) - 1 : mColumns + i - 1),
				     mColumns-1);
  }

  /**
   * Access to the end of a counter_diagonal of the matrix.
   *
   * \pre i < rows()
   * \pre -i < columns()
   *
   * \param i index of the diagonal
   * \return iterator to past the last the element of the diagonal
   *
   * \see counter_diagonal_begin()
   */
  template <typename T>
  typename Matrix<T>::counter_diagonal_iterator
  Matrix<T>::counter_diagonal_end(diagonal_index_type i)
  {
    assert(i < diagonal_index_type(rows()));
    assert(-i < diagonal_index_type(columns()));
    return counter_diagonal_begin(i) + (i >= 0
					? std::min(mRows - i, mColumns)
					: std::min(mRows, mColumns + i));
  }

  /**
   * const version
   *
   * \see counter_diagonal_begin()
   */
  template <typename T>
  typename Matrix<T>::const_counter_diagonal_iterator
  Matrix<T>::counter_diagonal_begin(diagonal_index_type i) const
  {
    assert(i < diagonal_index_type(rows()));
    assert(-i < diagonal_index_type(columns()));
    return const_counter_diagonal_iterator(mElements + (i >= 0 ? mColumns*(i+1) - 1 : mColumns + i - 1),
					   mColumns-1);
  }

  /**
   * const version
   *
   * \see counter_diagonal_end()
   */
  template <typename T>
  typename Matrix<T>::const_counter_diagonal_iterator
  Matrix<T>::counter_diagonal_end(diagonal_index_type i) const
  {
    assert(i < diagonal_index_type(rows()));
    assert(-i < diagonal_index_type(columns()));
    return counter_diagonal_begin(i) + (i >= 0
					? std::min(mRows - i, mColumns)
					: std::min(mRows, mColumns + i));
  }

  /**
   * Assignement of a matrix.
   *
   * The content of \p pOther is (deep) copied in the destination matrix.
   * The elements formerly contained are destroyed.
   *
   * \param pOther the matrix to be copied
   *
   * \post rows() == pOther.rows()
   * \post columns() == pOther.columns()
   * \post elementAt(i,j) == pOther.elementAt(i,j)
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  Matrix<T>& Matrix<T>::operator=(const Matrix& pOther)
  {
    Matrix tmp(pOther);
    swap(tmp);
    return *this;
  }

  /**
   * Assignment of a matrix (template version) 
   *
   * The content of \p pOther is (deep) converted in the destination
   * matrix.  The elements formerly contained are destroyed.
   *
   * \param pOther the matrix to be copied
   *
   * \post rows() == pOther.rows()
   * \post columns() == pOther.columns()
   * \post elementAt(i,j) is the conversion of pOther.elementAt(i,j)
   *
   * \exception std::bad_alloc
   */
  template <typename T>
  template <typename U>
  Matrix<T>& Matrix<T>::operator=(const Matrix<U>& pOther)
  {
    Matrix<T> tmp(pOther);
    swap(tmp);
    return *this;
  }


  /**
   * Access to a row of the matrix.
   *
   * \param pRow the index of the row.
   *
   * \return an iterator to the first element of the row \p pRow
   *
   * \warning The row index is not checked.
   */
  template <typename T>
  typename Matrix<T>::row_iterator
  Matrix<T>::operator[](size_type pRow)
  {
    return row_begin(pRow);
  }

  /**
   * Access to a row of the matrix.
   *
   * \param pRow the index of the row.
   *
   * \return a const iterator to the first element of the row \p pRow
   *
   * \warning The row index is not checked.
   */
  template <typename T>
  typename Matrix<T>::const_row_iterator
  Matrix<T>::operator[](size_type pRow) const
  {
    return row_begin(pRow);
  }
  
  /*@}*/

  /** \cond detail  */

  // construction using a (rows, columns, value) triplet
  template <typename T> template <typename U, typename S>
  void Matrix<T>::dispatched_constructor(U first,
					 U second,
					 S third,
					 detail::mat::true_type /* ignored */)
  {
    assert( first >= 0 );
    assert( second >= 0 );

    mRows = first;
    mColumns = second;
    mElements = (mRows*mColumns>0 ? new element_type[mRows*mColumns] : 0);
    mRowsPtr = 0;

    try {
      std::fill(begin(), end(), third);
      mRowsPtr = new element_type*[mRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= mRows; i++)
      mRowsPtr[i] = mElements + i*mColumns;
  }

  // construction using a pair of iterators and the number of columns
  template <typename T> template <typename U, typename S>
  void Matrix<T>::dispatched_constructor(U first,
					 U second,
					 S third,
					 detail::mat::false_type /* ignored */)
  {
    // third == number of columns
    size_type ncols = third;
    size_type sz = static_cast<size_type>(std::distance(first,second));
    assert( sz == 0 || (ncols > 0 && sz % ncols == 0) );
    if (sz == 0)
      return;
    
    mRows = sz / ncols;
    mColumns = ncols;
    
    mElements = new element_type[sz];
    try {
      std::copy(first,second,mElements);
      mRowsPtr = new element_type*[mRows+1];
    } catch (...) {
      delete[] mElements;
      throw;
    }
    for (size_type i = 0; i <= mRows; i++)
      mRowsPtr[i] = mElements + i*mColumns;
  }

  /** \endcond */

} // namespace ivllib

//--------------------------------------------------------------------
#endif // ivllib_matrix_h
