/**
 * \file config_parser.h
 * A configuration file parser.
 *
 * \author Claudio Cusano
 *
 * Minimal framework for parsing configuration files.
 *
 * The parser accepts configuration files respecting the grammar
 * defined here below.
 *
 *
 * CONFIGURATION FILE GRAMMAR
 *
 * The file is composed of text lines. Lines are terminated by
 * newlines characters, and may end with a comment which starts with
 * the character ';' or '#', and continues till the end of the line.
 * Lines can be (i) empty; (ii) section headers; (iii) property
 * definitions.
 *
 * <FILE> ::= <LINE>*
 * <LINE> ::= <space>* [<CONTENT>] <space>* [<COMMENT>] <newline>
 * <COMMENT> ::= (';' | '#') <anychar>*
 * <CONTENT> ::= (<SECTION_HEADER> | <DEFINITION>)
 * <SECTION_HEADER> ::= '[' <space>* <SECTION_NAME> <space>* ']'
 * <SECTION_NAME> := <section_header_chars>+
 * <DEFINITION> ::= <KEY> <space>* (':' | '=') <space>* <VALUE>
 * <KEY> ::= <key_chars>+
 * <VALUE> ::= <SIMPLE> | <STRING>
 * <SIMPLE> ::= <simple_chars>*
 * <STRING> ::= '"' <string_chars> '"'
 *
 * See the documentation of the functions is_section_valid and
 * is_property_valid for more details. 
 */
#ifndef config_parser_h
#define config_parser_h

#include <string>
#include <vector>
#include <istream>
#include <ostream>
#include <stdexcept>


/// the cc library
namespace cc
{
  /**
   * Parser of configuration files.
   *
   * \invariant sections().size() >= 1
   *
   * \invariant sections()[0] == ""
   */
  class ConfigParser
  {
  public:

    /**
     * Build an empty parser.
     *
     * Only the (empty) main section will be present.
     *
     * \post sections().size() == 1
     */
    ConfigParser();

    /**
     * Copy constructor.
     */
    ConfigParser(const ConfigParser& other);

    /**
     * Parse the file in \a fname.
     *
     * \param fname path to the configuration file
     *
     * \throw ConfigParserError in case of an ill-formed file
     *
     * \throw std::runtime_error in case of errors while opening or
     *        reading the file
     */
    ConfigParser(const std::string& fname);

    /**
     * Parse the content from a stream.
     *
     * \param input the input stream
     *
     * \throw ConfigParserError in case of an ill-formed file
     *
     * \throw std::runtime_error in case of errors while reading the
     *        stream
     */
    ConfigParser(std::istream& input);

    /**
     * Destructor.
     */
    ~ConfigParser();

    /**
     * Assignement.
     */
    ConfigParser& operator=(const ConfigParser& other);

    /**
     * Parse the file in \a fname.
     *
     * The old content is lost.
     *
     * \param fname path to the configuration file
     *
     * \throw ConfigParserError in case of an ill-formed file
     *
     * \throw std::runtime_error in case of errors while opening or
     *        reading the file
     */
    void parse_file(const std::string& fname);

    /**
     * Parse the content from a stream.
     *
     * The old content is lost.  In case of errors while reading from
     * the stream, no exception will be thrown, and only the
     * appropriate bits of the stream will be set.
     *
     * \param input the input stream
     *
     * \throw ConfigParserError in case of an ill-formed file
     */
    void parse_stream(std::istream& input);

    /**
     * Remove all the content from the parser.
     *
     * Only the (empty) main section will be left.
     *
     * \post sections().size() == 1
     */
    void clear();

    /**
     * Dump the configuration to \a os.
     *
     * \param os the output stream
     */
    void write(std::ostream& os) const;

    /**
     * Dump the configuration to the file \a filename.
     *
     * \param filename path to the output file
     *
     * \throw std::runtime_error in case of errors while opening or
     *        writing the file
     */
    void write(const std::string& filename) const;

    /**
     * Return the sections of the configuration.
     *
     * The returned vector contains the ordered names of sections of
     * the configuration.  The first element will always be the empty
     * string (representing the main section). Sections are listed in
     * the same order encountered in the original file or stream. The
     * returned reference is invalidated by any non-const operation on
     * the ConfigParser object.
     *
     * \return a vector containing the names of sections
     */
    const std::vector<std::string>&
    sections() const;

    /**
     * Return names of the properties in the given section.
     *
     * The returned vector contains the ordered names of the
     * properties in the section named \a section.  Names are listed
     * in the same order encountered while reading the section in the
     * original file or stream. In case of multiple definitions of the
     * property in the same section, the first occurrence determine
     * the order. The returned reference is invalidated by any
     * non-const operation on the ConfigParser object.
     *
     * \return a vector containing the names of the properties
     *
     * \throw std::runtime_error when \a section is not present in the
     *        configuration.
     */
    const std::vector<std::string>&
    properties(const std::string& section) const;

    /**
     * Check the presence of a property in a section.
     *
     * Check if the section is in the configuration, and if the
     * property is contained in the section.
     *
     * \param section the name of the section
     * \param name the name of the property
     */
    bool has_property(const std::string& section,
		      const std::string& name) const;

    /**
     * Return a value of a property.
     *
     * Return a value of the given property in the specified section.
     * If the section is not in the configuration, or if the property
     * is not contained in the section, the \a default_value is
     * returned.
     *
     * \param section the name of the section
     * \param name the name of the property
     * \param default_value the default value
     *
     * \return the value of the property, or default_value.
     */
    std::string property(const std::string& section,
			 const std::string& name,
			 const std::string& default_value="") const;
    /**
     * Return a value of a property.
     *
     * Return a value of the given property in the specified section.
     * If the section is not in the configuration, or if the property
     * is not contained in the section, the \a default_value is
     * returned. The property value is converted to an integer: if the
     * conversion is not possible, \a std::runtime_error exception is
     * thrown.
     *
     * \param section the name of the section
     * \param name the name of the property
     * \param default_value the default value
     *
     * \return the value of the property, or default_value.
     *
     * \throw std::runtime_error if the conversion is not possible
     */
    int int_property(const std::string& section,
		     const std::string& name,
		     int default_value=0) const;

    /**
     * Return a value of a property.
     *
     * Return a value of the given property in the specified section.
     * If the section is not in the configuration, or if the property
     * is not contained in the section, the \a default_value is
     * returned. The property value is converted to a double: if the
     * conversion is not possible, \a std::runtime_error exception is
     * thrown.
     *
     * \param section the name of the section
     * \param name the name of the property
     * \param default_value the default value
     *
     * \return the value of the property, or default_value.
     *
     * \throw std::runtime_error if the conversion is not possible
     */
    double double_property(const std::string& section,
			   const std::string& name,
			   double default_value=0.0) const;

    /**
     * Return a value of a property.
     *
     * Return a value of the given property in the specified section.
     * If the section is not in the configuration, or if the property
     * is not contained in the section, the \a default_value is
     * returned. The property value is converted to a boolean: the
     * allowed strings are:
     *
     * - "1", "y", "yes", "true", "on";
     *
     * - "0", "n", "no", "false", "off;
     *
     * for true and false, respectively.  Any case variation of the
     * above values is also allowed.
     *
     * \param section the name of the section
     * \param name the name of the property
     * \param default_value the default value
     *
     * \return the value of the property, or default_value.
     *
     * \throw std::runtime_error if the conversion is not possible
     */
    bool bool_property(const std::string& section,
		       const std::string& name,
		       bool default_value=false) const;

    /**
     * Add a section to the configuration object.
     *
     * The section is added only if there is not another section with
     * the same name. Note that the section name is not validated.
     *
     * \param section the section name
     *
     * \return true if the section has been actually added
     */
    bool add_section(const std::string& section);

    /**
     * Set the value of a property.
     *
     * If a property with the given name does not exist in the given
     * section, the property is added to the configuration.  If the
     * section is not in the configuration, a new section is added.
     * Note that the section and property names are not validated.
     *
     * \param section the section name
     * \param name the name of the property
     * \param value the new value of the property
     *
     * \return true if the property has been created
     */
    bool set_property(const std::string& section,
		      const std::string& name,
		      const std::string& value);

    /**
     * Swap the content with another \a ConfigParser object.
     */
    void swap(ConfigParser& other);

    /**
     * Insert escape sequences in the string.
     *
     * The input string is modified by the insertion of escape
     * sequences, where appropriate. The string may also be surrounded
     * by quotes. Quotes are always added when \a force is true, or
     * when escape sequences are required (they may also be added when
     * the string contain spaces, or some punctuation characters).
     *
     * \param s original string
     * \param force determine if quotes added also for simple values
     *
     * \return the modified string
     */
    static std::string escape_value(const std::string& s, bool force=false);

    /**
     * Tell if a string is a valid section name.
     *
     * Note that the empty string (which denote the main section) is
     * not considered valid.
     *
     * \param s the name of the section
     * 
     * \return true if the name is valid
     */
    static bool is_section_valid(const std::string& s);

    /**
     * Tell if a string is a valid property name.
     *
     * \param s the name of the property
     * 
     * \return true if the name is valid
     */
    static bool is_property_valid(const std::string& s);

  private:

    struct Impl;  ///< pimpl idiom (type)
    Impl* pimpl;  ///< pimpl idiom

    /// Called by the query functions.
    const std::string*
    find_property_(const std::string& section,
		   const std::string& name) const;

    /// Called only by the constructors.
    void process_stream_(const std::string& filename,
			 std::istream& input);

  };  // class ConfigParser



  /// Exception raised when parsing ill-formed files.
  class ConfigParserError
    : public std::runtime_error
  {
  public:
    /**
     * Constructor.
     *
     * \param filename name of the file (or "" when parsing a stream)
     * \param line number
     * \param message error message
     *
     * \pre lineno >= 1
     */
    ConfigParserError(const std::string& filename,
		      int lineno,
		      const std::string& message);

    virtual ~ConfigParserError() throw();

    /// Return the filename.
    const std::string& filename() const;

    /// Return the line number.
    int lineno() const;

    /// Return the error message.
    const std::string& message() const;

  private:
    static std::string make_message_(const std::string& filename,
				     int lineno,
				     const std::string& message);

    std::string filename_;  ///< the filename
    int lineno_;            ///< the line number
    std::string message_;   ///< the error message

  };  // ConfigParserError

}  // namespace cc

#endif  // config_parser_h
