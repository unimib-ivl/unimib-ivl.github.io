/**
 * \file option_parser.h
 * A command line parser.
 * \author Claudio Cusano
 *
 * Minimal framework for parsing command line arguments.
 *
 * The class @c Option defines allowed options.
 * The class @c OptionParser implements the parser.
 * The class @c ParsedOptions contains the result of the parser.
 */
#ifndef option_parser_h
#define option_parser_h

#include <string>

/// the cc library
namespace cc
{

  /** A command line option */
  class Option
  {
  public:
    /// type for options whitout parameter
    struct noparam_t {};
    static const noparam_t noparam;  ///< constant which means "no parameter"
    static const char noshort = ' '; ///< constant which means "no short name"

    // constructors

    /**
     * build a new option
     *
     * \post this->name() == name
     * \post this->short_name() == short_name
     * \post this->require_option() == false
     * \post this->metavar() == ""
     * \post this->group() == ""
     * \post this->description() == ""
     */
    Option(const std::string& name,
	   char short_name);

    /**
     * build a new option
     *
     * \post this->name() == name
     * \post this->short_name() == short_name
     * \post this->require_option() == false
     * \post this->metavar() == ""
     * \post this->group() == group
     * \post this->description() == description
     */
    Option(const std::string& name,
	   char short_name,
	   noparam_t,
	   const std::string& group="",
	   const std::string& description="");

    /**
     * build a new option
     *
     * \post this->name() == name
     * \post this->short_name() == short_name
     * \post this->require_option() == true
     * \post this->metavar() == metavar
     * \post this->group() == group
     * \post this->description() == description
     */
    Option(const std::string& name,
	   char short_name,
	   const std::string& metavar,
	   const std::string& group="",
	   const std::string& description="");

    // default copy, assignement, destructor

    // observers

    /// return the name
    std::string name() const;

    /// return the short_name
    char short_name() const;

    /// return true if the option requires a parameter
    bool require_parameter() const;

    /// name of the meta variable (affects only help message)
    std::string metavar() const;

    /// name of the group (affects only help message)
    std::string group() const;

    /// description of the option (affects only help message)
    std::string description() const;

    // modifiers

    /**
     * set the name
     *
     * \post name() == name
     */
    void set_name(const std::string& name);

    /**
     * set the short_name
     *
     * \post short_name() == short_name
     */
    void set_short_name(char short_name);

    /**
     * set the meta variable
     *
     * \post metavar() == ""
     * \post require_parameter() == false
     */
    void set_metavar(noparam_t);

    /**
     * set the meta variable
     *
     * \post metavar() == metavar
     * \post require_parameter() == true
     */
    void set_metavar(const std::string& metavar);

    /**
     * set the name of the group (affects only help message)
     *
     * \post group() == group
     */
    void set_group(const std::string& group);

    /**
     * set the description (affects only help message)
     *
     * \post description() == description
     */
    void set_description(const std::string& description);

  private:
    std::string name_;
    char short_name_;
    bool require_param_;
    std::string metavar_;
    std::string group_;
    std::string description_;
  };

  /**
   * Result of the parser
   */
  class ParsedOptions
  {
  public:
    /// constructor
    ParsedOptions();

    /// copy constructor
    ParsedOptions(const ParsedOptions& other);

    /// destructor
    ~ParsedOptions();

    /// assignement
    ParsedOptions& operator=(const ParsedOptions& other);

    /// swap
    void swap(ParsedOptions& other);

    /// number of the positional arguments
    int argc() const;

    /// return the positional argument of position \p i
    std::string argv(int i) const;

    /// return true if the option named \p name has been specified
    bool contains_option(const std::string& name) const;

    /**
     * return the paramater of the option named \p name.
     *
     * If the option has not been specified \p default_value is returned
     */
    std::string parameter_value(const std::string& name,
				const std::string& default_value = "") const;

    /**
     * return the paramater of the option named \p name converted to int.
     *
     * In case of a conversion error, a runtime_error is thrown.
     *
     * If the option has not been specified \p default_value is returned
     */
    long int_parameter_value(const std::string& name,
			     long default_value=0) const;

    /**
     * return the paramater of the option named \p name converted to double.
     *
     * In case of a conversion error, a runtime_error is thrown.
     *
     * If the option has not been specified \p default_value is returned
     */
    double double_parameter_value(const std::string& name,
				  double default_value=0.0) const;

    /// type of the iterator over the positional arguments
    typedef const std::string* args_iterator;

    /// iterator to the first positional argument
    args_iterator begin_args() const;

    /// iterator past the last positional argument
    args_iterator end_args() const;

  private:
    // use pimpl idiom
    struct impl;
    impl* pimpl_;

    friend class OptionParser;
  };

  /**
   * Command line parser
   */
  class OptionParser
  {
  public:
    /**
     * constructor
     *
     * \post this->usage() == usage
     */
    explicit OptionParser(const std::string& usage = "");

    /// copy constructor
    OptionParser(const OptionParser& other);

    /// destructor
    ~OptionParser();

    /// assignement
    OptionParser& operator=(const OptionParser& other);

    /// swap
    void swap(OptionParser& other);

    /**
     * Register an option
     *
     * the long and the short names of the option
     * must be unique. Multiple options
     * with the same long or short name are
     * not allowed. However, multiple options may
     * have Option::noshort as short_name
     */
    void add_option(const Option& opt);

    /**
     * Parse the command line
     *
     * the result of the parsing is returned
     */
    ParsedOptions parse_cmd_line(int argc,char* argv[]) const;

    /**
     * Print the descriptions of the options to stdout
     *
     * \p usage is printed as header and \p comment as trailer
     */
    void print_help(const std::string& comment = "") const;

    /**
     * Terminate the program
     *
     * Print the error message \p msg to stdout
     * and terminate the program.
     */
    void error(const std::string& msg = "") const;

    /// Return usage information
    std::string usage() const;

    /**
     * set usage information
     *
     * \post usage() == usage
     */
    void set_usage(const std::string& usage);

  private:
    struct impl;
    impl* pimpl_;
  };

} // opt_parser

#endif
