#ifndef stringop_h
#define stringop_h

#include <sstream>
#include <iterator>
#include <cstddef>
#include <tr1/tuple>

/**
 * \file stringop.h
 *
 * Simple string operations.
 *
 * Inspired by the interface of python str objects.
 *
 * Missing functions:
 * - find:       use std::string::find
 * - format:     use std::ostringstream
 * - rfind:      use std::string::rfind
 * - rsplit:     without support of the maxsplit argument,
 *               rsplit is identical to split
 * - splitlines: use split (no way to implement the keepends=true option);
 * - translate:  too complex
 *
 * Differences with respect to python:
 * - startswith, endswith: no optional parameters, they are too confusing.
 * - startswith, endswith: no support for tuples of prefixes and suffixes,
 *                         they would require a complex signature.
 * - split:                Imaplemented as an iterator class, instead of a
 *                         function returning a list. No support for the
 *                         maxsplit argument. Splitting an empty string
 *                         with a specified separator doe not return a
 *                         range containing the empty string.
 *
 * Additional functions:
 * - fromlong
 * - tolong
 * - fromdouble
 * - todouble
 */


#include <string>

namespace cc
{

namespace str
{

/**
 * Return a copy of the string with its first character capitalized
 * and the rest lowercased.
 */
std::string capitalize(std::string s);


/**
 * Return centered in a string of length width. Padding is done using
 * the specified fillchar (default is a space).
 */
std::string center(const std::string& s,
		   std::string::size_type width,
		   char fillchar=' ');


/**
 * Return the number of non-overlapping occurrences of substring sub
 * in the range [start, end).
 */
std::string::size_type count(const std::string& s,
			     const std::string& sub,
			     std::string::size_type start=0,
			     std::string::size_type end=std::string::npos);


/**
 * Return the number of non-overlapping occurrences of char c in the
 * range [start, end).
 */
std::string::size_type count(const std::string& s,
			     char c,
			     std::string::size_type start=0,
			     std::string::size_type end=std::string::npos);


/**
 * Return True if the string ends with the specified suffix, otherwise
 * return False.
 */
bool endswith(const std::string& s,
	      const std::string& suffix);


/**
 * Return a copy of the string where all tab characters are replaced
 * by one or more spaces, depending on the current column and the
 * given tab size. The column number is reset to zero after each
 * newline occurring in the string. If tabsize is not given, a tab
 * size of 8 characters is assumed. This doesn’t understand other
 * non-printing characters or escape sequences.
 */
std::string expandtabs(const std::string& s,
		       std::string::size_type tabsize=8);


/**
 * Convert a value to a string representation.
 */
std::string fromdouble(double x);


/**
 * Convert a value to a string representation.
 */
std::string fromlong(long n);


/**
 * Return a string which is the concatenation of the strings in the
 * iterator range. The separator between elements is s.
 */
template <typename InIter>
std::string join(const std::string& s,
		 InIter from,
		 InIter to);


/**
 * Return the string left justified in a string of length
 * width. Padding is done using the specified fillchar (default is a
 * space). The original string is returned if width is less than
 * s.size().
 */
std::string ljust(const std::string& s,
		  std::string::size_type width,
		  char fillchar=' ');


/**
 * Return a copy of the string converted to lowercase.
 */
std::string lower(std::string s);


/**
 * Return a copy of the string with leading characters removed. The
 * chars argument is a string specifying the set of characters to be
 * removed. If empty, the chars argument defaults to removing
 * whitespace. The chars argument is not a prefix; rather, all
 * combinations of its values are stripped:
 */
std::string lstrip(const std::string& s,
		   const std::string& chars="");


/**
 * Split the string at the first occurrence of sep, and return a
 * 3-tuple containing the part before the separator, the separator
 * itself, and the part after the separator. If the separator is not
 * found, return a 3-tuple containing the string itself, followed by
 * two empty strings.
 */
std::tr1::tuple<std::string, std::string, std::string>
partition(const std::string& s, const std::string& sep);


/**
 * Return a copy of the string with all occurrences of substring old
 * replaced by news. If the optional argument count is given, only the
 * first count occurrences are replaced.
 */
std::string replace(const std::string& s,
		    const std::string& old,
		    const std::string& news,
		    std::string::size_type count=std::string::npos);


/**
 * Return a copy of the string with all occurrences of the character
 * old replaced by news. If the optional argument count is given, only
 * the first count occurrences are replaced.
 */
std::string replace(std::string s,
		    char old,
		    char news,
		    std::string::size_type count=std::string::npos);


/**
 * Return the string right justified in a string of length
 * width. Padding is done using the specified fillchar (default is a
 * space). The original string is returned if width is less than
 * len(s).
 */
std::string rjust(const std::string& s,
		  std::string::size_type width,
		  char fillchar=' ');


/**
 * Split the string at the last occurrence of sep, and return a
 * 3-tuple containing the part before the separator, the separator
 * itself, and the part after the separator. If the separator is not
 * found, return a 3-tuple containing two empty strings, followed by
 * the string itself.
 */
std::tr1::tuple<std::string, std::string, std::string>
rpartition(const std::string& s, const std::string& sep);


/**
 * Return a copy of the string with trailing characters removed. The
 * chars argument is a string specifying the set of characters to be
 * removed. If omitted or None, the chars argument defaults to
 * removing whitespace. The chars argument is not a suffix; rather,
 * all combinations of its values are stripped:
 */
std::string rstrip(const std::string& s,
		   const std::string& chars="");


/**
 * Iterator over the splits of a string, according to a separator.
 *
 * If the separator is given, consecutive delimiters are not grouped
 * together and are deemed to delimit empty strings. Splitting an
 * empty string with a specified separator returns an empty range.
 *
 * If the separator is not specified or is the empty string, a
 * different splitting algorithm is applied: runs of consecutive
 * whitespace are regarded as a single separator, and the result will
 * contain no empty strings at the start or end if the string has
 * leading or trailing whitespace. Splitting an empty string or a
 * string consisting of just whitespace returns an empty range.
 *
 * Example: <tt>
 * int main()
 * {
 *   std::vector<std::string> v(cc::str::split("1, 2, 3, 4", ","),
 *                              cc::str::split());
 *   // v == {"1", " 2", " 3", " 4"};
 * }
 * </tt>
 */
class split
{
public:
  /// Category.
  typedef std::forward_iterator_tag iterator_category;

  // Value.
  typedef const std::string value_type;

  /// Difference.
  typedef std::ptrdiff_t difference_type;

  /// Pointer.
  typedef const std::string* pointer;

  /// Reference.
  typedef const std::string& reference;

  /**
   * Default constructor.
   *
   * Builds an iterator which can be used as the past-the-end
   * iterator.
   */
  split()
    : current_(""),
      base_(""),
      sep_(""),
      next_(std::string::npos)
  {
  }

  /**
   * Constructor.
   *
   * Builds an iterator which iterates over the splits of s, according
   * to the separator sep.
   */
  explicit split(const std::string& s,
			  const std::string& sep="");

  // Default copy, destructor, assignment.

  /// Return the pointed element.
  reference operator*() const { return current_; }

  /// Return a pointer to the element.
  pointer operator->() const { return &current_; }

  /// Pre-increment.
  split& operator++();

  /// Post-increment.
  split operator++(int)
  {
    split temp(*this);
    operator++();
    return temp;
  }

  /// Comparison.
  bool operator==(const split& iter) const
  {
    return (next_ == iter.next_ &&
	    base_ == iter.base_ &&
	    sep_ == iter.sep_);
  }

  /// Comparison.
  bool operator!=(const split& iter) const
  {
    return !(operator==(iter));
  }

private:

  std::string current_;
  std::string base_;
  std::string sep_;
  std::string::size_type next_;

};  // class split


/**
 * Return True if the string starts with the specified suffix,
 * otherwise return False.
 */
bool startswith(const std::string& s,
		const std::string& prefix);


/**
 * Return a copy of the string with the leading and trailing
 * characters removed. The chars argument is a string specifying the
 * set of characters to be removed. If omitted or None, the chars
 * argument defaults to removing whitespace. The chars argument is not
 * a prefix or suffix; rather, all combinations of its values are
 * stripped.
 */
std::string strip(const std::string& s,
		  const std::string& chars="");


/**
 * Return a copy of the string with uppercase characters converted to
 * lowercase and vice versa.
 */
std::string swapcase(std::string s);


/**
 * Return a titlecased version of the string where words start with an
 * uppercase character and the remaining characters are lowercase.
 *
 *  The algorithm uses a simple language-independent definition of a
 *  word as groups of consecutive letters. The definition works in
 *  many contexts but it means that apostrophes in contractions and
 *  possessives form word boundaries, which may not be the desired
 *  result.
 */
std::string title(std::string s);


/**
 * Convert a string to a number. If the string cannot be converted a
 * std::invalid_argument exception is thrown.
 */
double todouble(const std::string& s);


/**
 * Convert a string to a number. If the string cannot be converted def
 * is returned.
 */
double todouble(const std::string& s, double def);


/**
 * Convert a string to a number. If the string cannot be converted a
 * std::invalid_argument exception is thrown.
 */
long tolong(const std::string& s);


/**
 * Convert a string to a number. If the string cannot be converted def
 * is returned.
 */
long tolong(const std::string& s, long def);


/**
 * Return a copy of the string converted to uppercase.
 */
std::string upper(std::string s);


/**
 * Return the numeric string left filled with zeros in a string of
 * length width. A sign prefix is handled correctly. The original
 * string is returned if width is less than s.size().
 */
std::string zfill(const std::string& s,
		  std::string::size_type width);


//----------------------------------------------------------------------


}  // namespace str
}  // namespace cc


//----------------------------------------------------------------------
// Template implementations


namespace cc
{

namespace str
{

template <typename InIter>
std::string join(const std::string& s,
		 InIter from,
		 InIter to)
{
  if (from == to)
    return "";

  std::ostringstream os;
  os << (*from);
  ++from;
  while (from != to) {
    os << s << (*from);
    ++from;
  }
  return os.str();
}

}  // namespace str
}  // namespace cc


#endif  // stringop_h
