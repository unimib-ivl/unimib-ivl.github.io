/**
 * \file vector3_op.h
 * \brief Vector3 template class operations definition file
 * \author $LastChangedBy$
 * \date $Date: 2007-01-19 18:20:48 +0100 (ven, 19 gen 2007) $
 * \version $Revision$
 */

#ifndef IVLLIB_VECTOR3_OP_H
#define IVLLIB_VECTOR3_OP_H

//--- Headers ----------------------------------------------------------------------
#include "numerical/vector3.h"
#include <iostream>
#include <cmath>
#include <cassert>


namespace ivllib {
  
  /** \addtogroup numerical */
  /*@{*/

  /**
   * normalize the input vector so that length()=1.
   */
  template<typename T> 
    inline bool normalize(Vector3<T>& v);
  /**
   * computes the length (euclidean distance) of the current vector
   */
  template<typename T>
    inline T length(const Vector3<T>& v);
  
  /**
   * computes the squared length (euclidean distance) of the current
   * vector
   */
  template<typename T>
    inline T lengthsq(const Vector3<T>& v);

  /**
   * Compute the cosine of the angle between the current vector and
   * the vector passed as argument.
   */
  template<typename T>
    inline bool cos(const Vector3<T>&, const Vector3<T>&, T&);

  /**
   * Computes the sum (component by component) of the vectors passed as arguments.
   * @ return the resulting vector
   */
  template<typename A, typename B, typename C>
    inline void add(const Vector3<A>&, const Vector3<B>&, Vector3<C>& out);

  /**
   * Computes the subtraction (component by component) of the vectors passed as arguments.
   * @ return the resulting vector
   */
  template<typename A, typename B, typename C>
    inline void sub(const Vector3<A>&, const Vector3<B>&, Vector3<C>& out);
  
  /**
   * Computes the cross product of the vectors passed as arguments.  
   * @return the resulting vector
   */
  template<typename A, typename B, typename C>
    inline void cross(const Vector3<A>&, const Vector3<B>&, Vector3<C>& out);
  /**
   * vector by scalar multiplication
   */
  template<typename A, typename B, typename C>
    inline void mul_scalar(const Vector3<A>&, B, Vector3<C>& out);
  
  /**
   * vector by scalar division
   */
  template<typename A, typename B, typename C>
    inline void div_scalar(const Vector3<A>&, B, Vector3<C>& out);
  
  /**
   * Computes the inner product (or dot product) of the current vector
   * and the vector passed as argument
   */
  template<typename A, typename B, typename C>
    inline C inner_product(const Vector3<A>& v1, const Vector3<B>& v2, C scalar_base);

  //-----------------------------------------------------------------------
  template<typename T> 
    bool normalize(Vector3<T>& v)
    {
      T length = std::sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
	
      if (length == 0.0f)
	return false;
	
      v.x/=length;
      v.y/=length;
      v.z/=length;

      return true;
    }

  //----------------------------------------------------------------------
  template<typename T>
    T length(const Vector3<T>& v)
    {
      return std::sqrt(lengthsq(v));
    }

  //----------------------------------------------------------------------
  template<typename T>
    T lengthsq(const Vector3<T>& v)
    {
      return v.x*v.x + v.y*v.y + v.z*v.z;
    }

  //----------------------------------------------------------------------
  template<typename T>
    bool cos(const Vector3<T>& v1, 
	     const Vector3<T>& v2, 
	     T& res)
    {
      T temp;
	
      temp = length(v1) * length(v2);
	
      if (temp == 0.0f) 
	return false;
	
      res = inner_product(v1,v2,0.0) / temp;
      return true;
    }

  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    void cross(const Vector3<A>& a, 
	       const Vector3<B>& b, 
	       Vector3<C>& out)
  {
    C x = a.y*b.z-a.z*b.y;
    C y = a.z*b.x-a.x*b.z;
    C z = a.x*b.y-a.y*b.x;
    out.set(x,y,z);
  }

  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    void add(const Vector3<A>& a, 
	     const Vector3<B>& b, 
	     Vector3<C>& out)
  {
    out.x = a.x + b.x;
    out.y = a.y + b.y;
    out.z = a.z + b.z;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    void sub(const Vector3<A>& a, 
	     const Vector3<B>& b, 
	     Vector3<C>& out)
  {
    out.x = a.x - b.x;
    out.y = a.y - b.y;
    out.z = a.z - b.z;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    void mul_scalar(const Vector3<A>& a, 
		    B k, 
		    Vector3<C>& out)
  {
    out.x = a.x * k;
    out.y = a.y * k;
    out.z = a.z * k;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    void div_scalar(const Vector3<A>& a, 
		    B k, 
		    Vector3<C>& out)
  {
    out.x = a.x / k;
    out.y = a.y / k;
    out.z = a.z / k;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline C inner_product(const Vector3<A>& v1, const Vector3<B>& v2, C scalar_base)

  {
    return scalar_base + v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
  }
  
} //namespace ivllib

//----------------------------------------------------------------------
/**
 * output utility operator
 */
template<typename T>
std::ostream& operator<<(std::ostream& os, 
			 const ivllib::Vector3<T>& v);

//----------------------------------------------------------------------
template<typename T>
std::ostream& operator<<(std::ostream& os, 
			 const ivllib::Vector3<T>& v)
{
  os << v.x << " " << v.y << " " << v.z;
  return os;
}
//----------------------------------------------------------------------

/*@}*/

#endif //IVLLIB_VECTOR3_OP_H
