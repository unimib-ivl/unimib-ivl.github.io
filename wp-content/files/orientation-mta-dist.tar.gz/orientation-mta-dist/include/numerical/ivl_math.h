#ifndef IVL_MATH_H
#define IVL_MATH_H

#include <cmath>  // log


namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  
  //--- constants ----------------------------------------------

  /// \f$ \pi \f$
  const double PI = 3.14159265358979323846;


  //--- Functions ----------------------------------------------
  
  /**
   * converts the input argument from radians to degrees
   * @param rad the angle in radians to convert
   * @return the value of x expressed in degrees
   */
  inline float RAD2DEG(float rad)
  {
    return (rad*180.0f) / PI;
  }

  /**
   * converts the input argument from radians to degrees
   * @param rad the angle in radians to convert
   * @return the value of x expressed in degrees
   */
  inline double RAD2DEG(double rad)
  {
    return (rad*180.0) / PI;
  }


  /**
   * converts the input argument from degrees to radians
   * @param deg the angle in degrees to convert
   * @return the value of x expressed in radians
   */
  inline float DEG2RAD(float deg)
  {
    return (deg*PI) / 180.0f;
  }  

  /**
   * converts the input argument from degrees to radians
   * @param deg the angle in degrees to convert
   * @return the value of x expressed in radians
   */
  inline double DEG2RAD(double deg)
  {
    return (deg*PI) / 180.0;
  }

  /**
   * Computes the square of the given argument.
   */
  template <typename T>
  inline T sqr(const T& param)
  {
    return param*param;
  }


  /**
   * computes the logarithm of b in base a.
   */
  template <typename T,
    typename U>
    inline double log_a_b(const T& a,
			  const U& b)
    {
      return std::log(static_cast<double>(b)) / std::log(static_cast<double>(a));
    }
  
  /*@}*/
}

#endif //IVL_MATH_H
