/**
 * \file    wavelets.h
 * \brief   direct and inverse wavelet transorm
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef wavelets_h
#define wavelets_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <iterator>  // iterator_traits
#include <algorithm> // copy
#include <cstddef>   // size_t

namespace ivllib
{
  /** \cond detail */
  namespace detail
  {
    // functions for the retrieval of the pre-computed coefficients
    // for the direct and inverse wavelet transform
    const double* get_wavelet_coeff_low(unsigned int order);
    const double* get_wavelet_coeff_high(unsigned int order);
    const double* get_wavelet_coeff_inverse1(unsigned int order);
    const double* get_wavelet_coeff_inverse2(unsigned int order);
    
    /* 
     * compute a single step of the discrete wavelet transform
     * the input range [src,scr+n) and the output range [dst,dst+n)
     * must not overlap.
     * The number of elements n must be even and grater than the
     * order of the tranform.
     */
    template <typename RaIter1,typename RaIter2>
    void wavelet_step(RaIter1 src,
		      typename std::iterator_traits<RaIter1>::difference_type n,
		      RaIter2 dst,
		      unsigned int order)
    {
      assert( static_cast<unsigned int>(n) >= order );
      assert( n % 2 == 0 );

      const double* lo_c = get_wavelet_coeff_low(order);
      const double* hi_c = get_wavelet_coeff_high(order);
  
      // destination range is split in low-frequency [low,low + (n/2))
      // and high-frequency [low+(n/2),low+n)
      RaIter2 high = dst + (n / 2);
            
      // compute:
      // - dst[j/2]  = sum_{k=0}^{order} lo_c[k] * src[j+k]
      // - high[j/2] = sum_{k=0}^{order} hi_c[k] * src[j+k]
      for (unsigned j = 0; j <= n - order; j += 2) {
	RaIter1 it = src + j;
	*dst = 0;
	*high = 0;
	for (std::size_t k = 0; k < order; k++) {
	  *dst  += lo_c[k] * (*it);
	  *high += hi_c[k] * (*it);
	  ++it;
	}
	++dst;
	++high;
      }

      // to compute the last (order-2) coefficients wrap 
      // around the boundaries of the input vector
      // equivalent to:
      // - dst[j/2]  = sum_{k=0}^{order} lo_c[k] * src[(j+k) % n]
      // - high[j/2] = sum_{k=0}^{order} hi_c[k] * src[(j+k) % n]
      for (unsigned int i = 2; i < order; i += 2) {
	RaIter1 it = src + (n - order + i);
	*dst = 0;
	*high = 0;
	for (std::size_t k = 0; k < order-i; k++) {
	  *dst  += lo_c[k] * (*it);
	  *high += hi_c[k] * (*it);
	  ++it;
	}
	it = src;
	for (std::size_t k = order-i; k < order; k++) {
	  *dst  += lo_c[k] * (*it);
	  *high += hi_c[k] * (*it);
	  ++it;
	}
	++dst;
	++high;	
      }      
    }

    /* 
     * compute a single step of the inverse wavelet transform
     * the input range [src,scr+n) and the output range [dst,dst+n)
     * must not overlap.
     * The number of elements n must be even and grater than the
     * order of the tranform.
     */
    template <typename RaIter1,typename RaIter2>
    void iwavelet_step(RaIter1 src,
		       typename std::iterator_traits<RaIter1>::difference_type n,
		       RaIter2 dst,
		       unsigned int order)
    {
      assert( static_cast<unsigned int>(n) >= order );
      assert( n % 2 == 0 );

      const double* i1_c = get_wavelet_coeff_inverse1(order);
      const double* i2_c = get_wavelet_coeff_inverse2(order);

      RaIter1 high = src + (n / 2);
      
      // to compute the first order-2 coefficients wrap 
      // around the boundaries of the input vector
      for (unsigned int i = 2; i < order; i += 2) {
	*dst = 0;
	*(dst+1) = 0;
	RaIter1 it1 = src + (n - order + i)/2;
	RaIter1 it2 = high + (n - order + i)/2;
	for (std::size_t k = 0; k < order-i; k += 2) {
	  *dst += i1_c[k] * (*it1) + i1_c[k+1] * (*it2);
	  *(dst+1) += i2_c[k] * (*it1) + i2_c[k+1] * (*it2);
	  ++it1;
	  ++it2;
	}
	it1 = src;
	it2 = high;
	for (std::size_t k = order-i; k < order; k += 2) {
	  *dst += i1_c[k] * (*it1) + i1_c[k+1] * (*it2);
	  *(dst + 1) += i2_c[k] * (*it1) + i2_c[k+1] * (*it2);
	  ++it1;
	  ++it2;
	}
	dst += 2;
      }
      
      // regular elements (not across the boundaries)
      // - dst[2*i]   = sum_{2*k=0}^{order} i1_c[2*k]*src[i+2*k] + i1_c[2*k+1]*src[(n/2)+i+2*k+1]
      // - dst[2*i+1] = sum_{2*k=0}^{order} i2_c[2*k]*src[i+2*k] + i2_c[2*k+1]*src[(n/2)+i+2*k+1]
      RaIter1 stop = src + ((n-order)/2) + 1;
      while (src != stop) {
	*dst = 0;
	*(dst + 1) = 0;
	RaIter1 it1 = src;
	RaIter1 it2 = high;
	for (std::size_t k = 0; k < order; k += 2) {
	  *dst += i1_c[k] * (*it1) + i1_c[k+1] * (*it2);
	  *(dst + 1) += i2_c[k] * (*it1) + i2_c[k+1] * (*it2);
	  ++it1;
	  ++it2;
	}
	dst += 2;
	++src;
	++high;
      }
    }

    /*
     * Compute the discrete wavelet transform of the sequence [from,to)
     * and put the result in [out,out+(to-from).
     * The range [buffer,buffer+(to-from)) must be valid.
     * (to-from) must be a power of two and must be grater than order.
     */
    template <typename RaIter1,typename RaIter2,typename RaIter3>
    void wavelet_transform_1_aux(RaIter1 from,
				 RaIter1 to,
				 RaIter2 out,
				 RaIter3 buffer,
				 unsigned int order)
    {
      assert(static_cast<unsigned int>(to - from) >= order);
      assert(from != to && ((to-from)&((to-from)-1)) == 0); // check if is a power of 2

      typename std::iterator_traits<RaIter1>::difference_type n = to - from;
  
      wavelet_step(from,n,out,order);
      n /= 2;
      while (static_cast<unsigned int>(n) >= order) {
	std::copy(out,out+n,buffer);
	wavelet_step(buffer,n,out,order);
	n /= 2;
      }
    }

    /*
     * Compute the discrete wavelet transform of the sequence [from,to)
     * and put the result in [out,out+(to-from).
     * The range [buffer,buffer+(to-from)) must be valid.
     * (to-from) must be a power of two and must be grater than order.
     */
    template <typename RaIter1,typename RaIter2,typename RaIter3>
    void iwavelet_transform_1_aux(RaIter1 from,
				  RaIter1 to,
				  RaIter2 out,
				  RaIter3 buffer,
				  unsigned int order)
    {
      assert(static_cast<unsigned int>(to - from) >= order);
      assert(from != to && ((to-from)&((to-from)-1)) == 0); // check if is a power of 2

      typedef typename std::iterator_traits<RaIter1>::difference_type diff_type;
      diff_type n = to - from;
  
      std::copy(from,to,buffer);
      
      diff_type m = 2;
      // find the smallest power of 2 which is greater than order
      while (static_cast<unsigned int>(m) <= order)
	m *= 2;
      iwavelet_step(buffer,m,out,order);
      while (m < n) {
	std::copy(out,out+m,buffer);
	m *= 2;
	iwavelet_step(buffer,m,out,order);
      }
    }

  } // detail
  /** \endcond */

  /** \addtogroup numerical */
  /*@{*/
  
  /**
   * Discrete wavelet transform
   *
   * Compute the discrete wavelet transform of the matrix in
   * and put the result in the matrix out.
   * The parameter order specifies the number of coefficients
   * in the wavelet basis. Currently, are supported
   * Daubechies wavelets of order 2,4,6,8,10,12,14,16,18,20.
   * The dimensions of the input matrix must be powers of 2
   * and must be greater than, or equal to the order.
   * The type \p T must support multiplication whit \p double
   * values and the result must be convertible to double.
   * The type \p T must support multiplication whit \p double
   * values and the result must be convertible to double. Values
   * of type \p double must also be assignable to variables of
   * type \p U.
   *
   * \param in input matrix
   * \param out output matrix
   * \param order order of the wavelet basis
   *
   * \pre in.rows() >= order
   * \pre in.columns() >= order
   * \pre in.rows() must be a power of 2
   * \pre in.columns() must be a power of 2
   * \pre order >= 2 
   * \pre order <= 20
   * \pre order % 2 == 0
   */
  template <typename T,typename U>
  void wavelet_transform(const Matrix<T>& in,
			 Matrix<U>& out,
			 unsigned int order)
  {
    assert( in.rows() >= order );
    assert( in.columns() >= order );
    assert( in.rows() != 0 && ((in.rows() & (in.rows()-1))) == 0 ); // power of 2 check
    assert( in.columns() != 0 && ((in.columns() & (in.columns()-1))) == 0 ); // power of 2 check
    assert( order >= 2 );
    assert( order <= 20 );
    assert( order % 2 == 0 );

    typedef typename Matrix<T>::size_type size_type;
  
    size_type n = in.rows();
    size_type m = in.columns();
  
    Matrix<U> temp(n,m);
    Vector<U> buffer(n > m ? n : m);
    for (size_type i = 0; i < n; i++)
      detail::wavelet_transform_1_aux(in.row_begin(i),
				      in.row_end(i),
				      temp.row_begin(i),
				      buffer.begin(),
				      order);
  
    Matrix<U> result(n,m);

    for (size_type i = 0; i < m; i++)
      detail::wavelet_transform_1_aux(temp.column_begin(i),
				      temp.column_end(i),
				      result.column_begin(i),
				      buffer.begin(),
				      order);
    out.swap(result);
  }

  /**
   * Inverse discrete wavelet transform
   *
   * Compute the inverse discrete wavelet transform of the
   * matrix in and put the result in the matrix out.
   * The parameter order specifies the number of coefficients
   * in the wavelet basis. Currently, are supported
   * Daubechies wavelets of order 2,4,6,8,10,12,14,16,18,20.
   * The dimensions of the input matrix must be powers of 2
   * and must be greater than, or equal to the order.
   * The type \p T must support multiplication whit \p double
   * values and the result must be convertible to double.
   * The type \p T must support multiplication whit \p double
   * values and the result must be convertible to double. Values
   * of type \p double must also be assignable to variables of
   * type \p U.
   *
   * \param in input matrix
   * \param out output matrix
   * \param order order of the wavelet basis
   *
   * \pre in.rows() >= order
   * \pre in.columns() >= order
   * \pre in.rows() must be a power of 2
   * \pre in.columns() must be a power of 2
   * \pre order >= 2 
   * \pre order <= 20
   * \pre order % 2 == 0
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U>
  void iwavelet_transform(const Matrix<T>& in,
			  Matrix<U>& out,
			  unsigned int order)
  {
    assert( in.rows() >= order );
    assert( in.columns() >= order );
    assert( in.rows() != 0 && ((in.rows() & (in.rows()-1))) == 0 ); // power of 2 check
    assert( in.columns() != 0 && ((in.columns() & (in.columns()-1))) == 0 ); // power of 2 check
    assert( order >= 2 );
    assert( order <= 20 );
    assert( order % 2 == 0 );

    typedef typename Matrix<T>::size_type size_type;
  
    size_type n = in.rows();
    size_type m = in.columns();
  
    Matrix<U> temp(n,m);
    Vector<U> buffer(n > m ? n : m);
  
    for (size_type i = 0; i < n; i++)
      detail::iwavelet_transform_1_aux(in.row_begin(i),
				       in.row_end(i),
				       temp.row_begin(i),
				       buffer.begin(),
				       order);
  
    Matrix<U> result(n,m);
  
    for (size_type i = 0; i < m; i++)
      detail::iwavelet_transform_1_aux(temp.column_begin(i),
				       temp.column_end(i),
				       result.column_begin(i),
				       buffer.begin(),
				       order);

    out.swap(result);
  }
  
  /*@}*/  

} // ivllib

#endif
