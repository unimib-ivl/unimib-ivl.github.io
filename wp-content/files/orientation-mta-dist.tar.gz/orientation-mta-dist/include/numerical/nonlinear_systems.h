/**
 * \file    nonlinear_systems.h
 * \brief   nonlinear systems algorithms
 */

#ifndef IVLLIB_NONLINEAR_SYSTEMS_H
#define IVLLIB_NONLINEAR_SYSTEMS_H

//--- Headers ---------------------------------------------------------
#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <numerical/matrix_op.h>
#include <numerical/linear_systems.h>
#include <cassert>
#include <cmath>
#include <algorithm>

namespace ivllib
{
  //--- Function declarations -----------------------------------------
  
  /** \addtogroup numerical */
  /*@{*/

  /**
   * Abstract instance of an optimization problem.
   *
   * Abstract class used to describe an instance of the problem to be
   * optimized using the Levenberg-Marquardt algorithm.
   *
   * FloatType must be a floating point type.
   */
  template <typename FloatType>
  class LevMarProblem
  {
  public:
    /// scalar type 
    typedef FloatType value_type;

    /// vector type
    typedef Vector<FloatType> vector_type;

    /// matrix type
    typedef Matrix<FloatType> matrix_type;

    /// virtual destructor
    virtual ~LevMarProblem() { }

    /**
     * Evaluate the objective function.
     *
     * Evaluate the objective function at \c solution and place the
     * result in \c value.
     *
     * \param solution point in which the function must be evaluated
     * \param value output value
     */
    virtual void eval_function(const vector_type& solution,
			       vector_type& value) const = 0;
    
    /**
     * Evaluate the jacobian of the objective.
     *
     * Evaluate the jacobian at \c solution and place the result in \c
     * jacobian.
     *
     * \param solution point in which the function must be evaluated
     * \param value value of the objective function at solution
     * \param jacobian output value
     *
     * \post jacobian.rows() == value.size()
     * \post jacobian.columns() == solution.size()
     */
    virtual void eval_jacobian(const vector_type& solution,
			       const vector_type& value,
			       matrix_type& jacobian) const = 0;

    /**
     * Method called after Levenberg-Marquardt iterations.
     *
     * \param iteration number of iterations completed
     * \param error current error (square of the norm of the objective function)
     * \param solution current solution
     * \param dumping current dumping factor
     *
     * \return true if the algorithm should continue, false if the
     * algorithm must be stopped
     *
     * The default implementation does nothing and always return true
     */
    virtual bool callback(unsigned int iteration,
			  double error,
			  const vector_type& solution,
			  double dumping) const;
    
  protected:

    /**
     * Finite difference estimation of the jacobian.
     *
     * 
    * Evaluate the jacobian at \c solution and place the result in \c
     * jacobian.
     *
     * \param solution point in which the function must be evaluated
     * \param value value of the objective function at solution
     * \param step increment used to approximate the jacobian
     * \param jacobian output value
     *
     * \post jacobian.rows() == value.size()
     * \post jacobian.columns() == solution.size()
     */
    void estimate_jacobian(const vector_type& solution,
			   const vector_type& value,
			   value_type step,
			   matrix_type& jacobian) const;
  }; // class LevMarProblem

  /**
   * Levenberg-Marquardt algorithm.
   *
   * Numerically solve the problem:
   * \f[
   min_x \| F(x) \|^2, \;\;\;F:R^n \rightarrow R^m.
   * \f]
   *
   * The problem is described by an instance of the class
   * LevMarProblem. The termination of the algorithm can be determined
   * by the parameters \c max_iters, \c target_error, \c and
   * min_update. The callback method of LevMarProblem may be used to
   * monitor the algorithm and to terminate the computation.
   *
   * FloatType must be a floating point type.
   *
   * \param init initial estimate of the solution
   * \param problem description of the optimization problem
   * \param max_iters maximum number of iterations
   * \param target_error threshold on the current error which
   * terminates the algorithm
   * \param min_update minimum update required from each iteration
   * (norm of the difference in solution)
   * \param dumping_init initial dumping factor (tipically in the range
   * [1e-6,1])
   * \param solution best solution found (output)
   *
   * \post solution.size() == init.size()
   */
  template <typename FloatType>
  void solve_lev_mar(const Vector<FloatType>& init,
		     const LevMarProblem<FloatType>& problem,
		     unsigned int max_iters,
		     double target_error,
		     double min_update,
		     double dumping_init,
		     Vector<FloatType>& solution);

  /*@}*/  
  
  // --- implementation --------------------------------------------------

  template <typename FloatType>
  void solve_lev_mar(const Vector<FloatType>& init,
		     const LevMarProblem<FloatType>& problem,
		     unsigned int max_iters,
		     double target_error,
		     double min_update,
		     double dumping_init,
		     Vector<FloatType>& solution)
  {
    /*
     * sketch of the algorithm:
     *
     * given an initial solution x = x0:
     *
     * compute the jacobian J = J(x)
     * A = J'*J
     * determine the initial dumping factor l = tau*max(diag(A)) (given tau)
     *
     * i = 0
     * while i < max_iters and |f(x)| < threshold1
     *   
     *   B = A + l*diag(A)
     *   d = -inv(B)*J'*f(x)
     *
     *   if |d| < threshold2 then exit
     *   
     *   if |f(x+d)| < |f(x)|
     *     x = x + d
     *     J = J(x)
     *     A = J'*J
     *     l = l / 10
     *     i = i + 1
     *   else
     *     l = l * 10
     *
     * endwhile
     */

    // multiplier used to update of the dumping factor
    const double lev_mar_dump_update = 10;
    
    typedef Vector<FloatType> vec_type;
    typedef Matrix<FloatType> mat_type;
    typedef typename vec_type::size_type size_type;
    
    vec_type sol = init; // current solution
    size_type k = sol.size();
    
    vec_type val;
    problem.eval_function(sol, val); // current value
    double err = inner_product(val, val, 0.0); // current error
    
    mat_type j;
    problem.eval_jacobian(sol, val, j); // current jacobian
    assert( j.rows() == val.size() );
    assert( j.columns() == k );
    
    mat_type a;
    transposed_mul(j, j, a); // a = j'j

    bool stop = err < target_error;

    // dump = dumping_init * max(diag(a))
    double dump = *std::max_element(a.diagonal_begin(),
				    a.diagonal_end()) * dumping_init;

    if (!problem.callback(0, err, sol, dump))
      stop = true;

    for (unsigned int it = 0; !stop && it < max_iters; ++it) {
      vec_type g;
      transposed_mul(j, val, g);
      mul_to(g, -1); // g = -j'*f

      bool improved = false;
      // look for an improvement, varying the dumping factor dump
      while (!stop && !improved) {
	mat_type b = a; // b = a + dump*diag(a)
	for (size_type i = 0; i < k; i++)
	  b[i][i] += a[i][i]*dump;
	
	vec_type d; // update to the current solution
	mat_type unused;
	solve_gauss(b, g, unused, d); // d ~= inv(b)*g

	double update_size = std::sqrt(inner_product(d, d, 0.0));

	if (update_size < min_update) {
	  // the step is too small -> terminate the algorithm
	  stop = true;
	} else {
	  vec_type new_sol;
	  add(sol, d, new_sol); // new_sol = sol + d

	  vec_type new_val; // updated value
	  problem.eval_function(new_sol, new_val);
	  assert( new_val.size() == val.size() );
	  double new_err = inner_product(new_val, new_val, 0.0); // updated error
	  
	  if (new_err < err) {
	    // the new solution is an improvement...
	    improved = true;
	    dump /= lev_mar_dump_update; // reduce the dumping factor
	    val.swap(new_val); // update the value ...
	    err = new_err; // ... the error ...
	    sol.swap(new_sol); // ... the solution ...
	    
	    problem.eval_jacobian(sol, val, j); // ... the jacobian ...
	    assert( j.rows() == val.size() );
	    assert( j.columns() == k );
	    transposed_mul(j, j, a); // ... and the matrix a

	    if (!problem.callback(it+1, err, sol, dump)) // call the callback
	      stop = true;
	    if (err < target_error)
	      stop = true; // reached the target error -> terminate the algorithm
	  } else {
	    // the new solution is not an improvement:
	    // change the dumping factor and retry
	    dump *= lev_mar_dump_update;
	  }
	}
      }
    }

    // commit
    solution.swap(sol);
  }
  
  //------------------------------------------------------------

  /** \cond detail */

  template <typename FloatType>
  void
  LevMarProblem<FloatType>::estimate_jacobian(const typename LevMarProblem<FloatType>::vector_type& solution,
					      const typename LevMarProblem<FloatType>::vector_type& value,
					      typename LevMarProblem<FloatType>::value_type step,
					      typename LevMarProblem<FloatType>::matrix_type& jacobian) const
  {
    typedef typename vector_type::size_type size_type;
    
    size_type n = value.size();
    size_type k = solution.size();

    matrix_type ret(n,k);

    value_type inv_step = 1.0/step;

    for (size_type j = 0; j < k; j++) {
      vector_type sol1 = solution;
      sol1[j] += step;
      
      vector_type val1;
      eval_function(sol1, val1);
      assert( val1.size() == n );
      
      for (size_type i = 0; i < n; ++i)
	ret[i][j] = (val1[i] - value[i]) * inv_step;
    }
    
    jacobian.swap(ret);
  }

  
  template <typename FloatType>
  inline bool
  LevMarProblem<FloatType>::callback(unsigned int iteration,
				     double error,
				     const typename LevMarProblem<FloatType>::vector_type& solution,
				     double dumping) const
  {
    return true;
  }

  /** \endcond */
  
} // namespace ivllib

#endif //IVLLIB_NONLINEAR_SYSTEMS_H
