/**
 * \file numerical_exceptions.h
 * \brief exceptions thrown by numerical algorithms
 * \author $LastChangedBy$
 * \date $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_NUMERICAL_EXCEPTIONS
#define IVLLIB_NUMERICAL_EXCEPTIONS

#include <stdexcept>

namespace ivllib {

  /** @addtogroup numerical */
  /**@{*/
   
  class VectorNormalizationError 
    : public std::runtime_error

    {
    public:
      explicit VectorNormalizationError(const std::string& message)
	: std::runtime_error(message)
	{
	}
    };


  class SingularMatrixError
    : public std::runtime_error

    {
    public:
      explicit SingularMatrixError(const std::string& message)
	: std::runtime_error(message)
	{
	}
    };

  /**@}*/
}
#endif //IVLLIB_NUMERICAL_EXCEPTIONS
