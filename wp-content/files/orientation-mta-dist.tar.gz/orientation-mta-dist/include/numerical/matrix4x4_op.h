#ifndef IVLLIB_MATRIX4X4_OP_H
#define IVLLIB_MATRIX4X4_OP_H

//--- Headers ---------------------------------------------------
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>

#include "numerical/matrix4x4.h"
#include "numerical/matrix3x3.h"
#include "numerical/vector3.h"
#include "numerical/vector3_op.h"
#include "numerical/vector4.h"
#include "numerical/numerical_exceptions.h"
#include "numerical/ivl_math.h"

namespace ivllib {

  /** \addtogroup numerical */
  /*@{*/

  //--- types ------------------------------------------------------
  
  /**
   * This functor computes an rt_mul between a Matrix4x4 and a Vector3
   * Useful for transforming a set of vectors (e.g. an Image3D or a
   * Trimesh3D)
   */
  template<typename T>
    struct transform_Vector3 : public std::binary_function< ivllib::Vector3<T>, ivllib::Matrix4x4<T>, ivllib::Vector3<T> >
    {  
      /**
       * @param p the input vector
       * @param m the transformation matrix
       * @return rt_mul(p,m)
       */
      inline ivllib::Vector3<T> operator() (const ivllib::Vector3<T>& p, 
					    const ivllib::Matrix4x4<T>& m) const
      {
	ivllib::Vector3<T> ret(p);
	rt_mul(m, p, ret);
	return ret;      
      }  
    };
  
  /**
   * Sets the translational components ot the matrix 
   *
   * @note only the translational components of the matrix are changed.
   * 
   */
  template<typename T>
    inline void setTranslationVector (Matrix4x4<T>& m, 
				      const Vector3<T>& v);
  
  /**
   * This function performs an axis/angle rotation. For greater speed, 
   * always use a unit vector (length = 1). In these versions, we will assume 
   * an arbitrary length and normalize.
   * @note NOT only the rotational components of the matrix are changed, 
   * but all the matrix, setting translation components to (0,0,0).
   *
   * @param m the output matrix
   * @param v the 3D vector used as rotation axis
   * @param theta the angle of rotation in radians
   * @throw VectorNormalizationError
   */
  template<typename T>
    void buildRotationMatrix (Matrix4x4<T>& m, 
			      const Vector3<T>& v, 
			      T theta);

  /**
   * @return the rotational components of the current matrix
   */
  template<typename T>
    inline void getRotationMatrix (const Matrix4x4<T>& m, 
				   Matrix3x3<T>& out);

  /**
   * sets the rotational components of the current matrix
   */
  template<typename T>
    inline void setRotationMatrix (Matrix4x4<T>& m,
				   const Matrix3x3<T>& in);

  /**
   * returns the translation component of the current matrix
   */
  template<typename T>
    inline void getTranslationVector (const Matrix4x4<T>& m, 
				      Vector3<T>& out);

  /**
   * Sets  the matrix to a translation matrix
   *
   * @note not only the translational components of the matrix are changed. 
   * the rotational part is set to identity
   *
   */
  template<typename T>
    inline void buildTranslationMatrix (Matrix4x4<T>& m, 
					const Vector3<T>& v);


  /**
   * computes the transpose of the current matrix and returns the
   * result in the matrix passed as argument
   *
   */
  template<typename T>
    inline void transpose (const Matrix4x4<T>& m, 
			   Matrix4x4<T>& out);
  

  /**
   * \brief computes the inverse of the current matrix.
   *
   * Computes the inverse of a 3D affine matrix; i.e. a matrix with a
   * dimensionality of 4 where the bottom row has the entries (0, 0,
   * 0, 1).
   *
   * This procedure treats the 4 by 4 matrix as a block matrix and
   * calculates the inverse of one submatrix for a significant perform
   * ance improvement over a general procedure that can invert any non
   * singular matrix:
   *
   * @pre the current matrix represents an affine transformation matrix.
   * @throw SingularMatrixError
   */
  template<typename T>
    void affineInverse(const Matrix4x4<T>& m, 
		       Matrix4x4<T>& out);

  /**
   * \brief computes the inverse of the current matrix.
   *
   * calculate the inverse of a 4x4 matrix in this way:
   *     
   *     inv(A) = 1/det(A)*adjoint(A)
   *
   * @throw SingularMatrixError
   */
  template<typename T>
    void inverse(const Matrix4x4<T>& m, 
		 Matrix4x4<T>& out);

  /**
   * \brief calculate the adjoint(conjugate transpose) of the current 4x4 matrix
   *
   */
  template<typename T>
    void adjoint(const Matrix4x4<T>& m, 
		 Matrix4x4<T>& out);

  /**
   * computes the determinat of the current matrix
   * @return the the determinant of the current matrix
   */
  template<typename T>
    T determinant(const Matrix4x4<T>& m);

  /**
   * Matrix4x4 multiplication
   * @param mat1 first matrix
   * @param mat2 second matrix
   * @param out result matrix (mat1 * mat2)
   * @return mat1 * mat2
   */
  template <typename T>
    inline void mul(const Matrix4x4<T>& mat1, 
		    const Matrix4x4<T>& mat2, 
		    Matrix4x4<T>& out);

  /**
   * Matrix4x4 addiction
   * @param mat1 first matrix
   * @param mat2 second matrix
   * @param out result matrix (mat1 + mat2)
   * @return mat1 + mat2
   */
  template <typename T>
    inline void add(const Matrix4x4<T>& mat1, 
		    const Matrix4x4<T>& mat2, 
		    Matrix4x4<T>& out);

  /**
   * Matrix4x4 / Vector3 multiplication. This mul operation multiplies
   * only the rotation and tanslation components of the matrix.
   * 
   * @param mat transformation matrix
   * @param vec the vector to be transformed. 
   * @param out result vector (mat * vec)

  */
  template <typename T>
    inline void rt_mul(const Matrix4x4<T>& mat, 
		       const Vector3<T>& vec, 
		       Vector3<T>& out);

  /**
   * Matrix4x4 / Vector4 multiplication
   * @param mat transformation matrix
   * @param vec the vector to be transformed
   * @param out result vector (mat * vec)
   * @return mat * vec
   */
  template <typename T>
    inline void mul(const Matrix4x4<T>& mat, 
		    const Vector4<T>& vec, 
		    Vector4<T>& out);


  /**
   * Set the input matrix to identity
   */
  template <typename T>
    void Identity(Matrix4x4<T>& m);

  /**
   * streaming
   */ 
  template <typename T>
    std::ostream& operator<<(std::ostream& os, 
			     const Matrix4x4<T>& m);

  //----------------------------------------------------------
  // Implementation
  //----------------------------------------------------------
  namespace impl
    {
      template <typename T>
	T determinant3x3( T a00, T a01, T a02, 
			  T a10, T a11, T a12, 
			  T a20, T a21, T a22 )
	{
	  T ans;

	  ans = a00 * determinant2x2( a11, a12, a21, a22 )
	    - a10 * determinant2x2( a01, a02, a21, a22 )
	    + a20 * determinant2x2( a01, a02, a11, a12 );
  
	  return ans;
	}

      template <typename T>
	T determinant2x2( T a00, T a01, 
			  T a10, T a11)
	{
	  return a00 * a11 - a01 * a10;
	}
    }

  //---------------------------------------------------------------
  template <typename T>
    void Identity(Matrix4x4<T>& m)
    {
      m.set(1,0,0,0,
	    0,1,0,0,
	    0,0,1,0,
	    0,0,0,1);
    }

  //---------------------------------------------------------------
  template<typename T>
    inline void setTranslationVector (Matrix4x4<T>& m, 
				      const Vector3<T>& v)
    {
      m[0][3] = v.x;
      m[1][3] = v.y;
      m[2][3] = v.z;
    }

  //---------------------------------------------------------------
  template<typename T>
    void buildRotationMatrix (Matrix4x4<T>& m, 
			      const Vector3<T>& v, 
			      T theta)
    {
      Vector3<T> _v=v;
  
      double c,s,t;
  
      // normalize
      if (!normalize(_v))
	throw VectorNormalizationError("Cannot normalize rotation axis vector.");
  
      // do the trig
      c = std::cos(theta);
      s = std::sin(theta);
      t = 1-c;

      // build the rotation matrix
      m[0][0] = t*_v.x*_v.x + c;
      m[0][1] = t*_v.x*_v.y - s*_v.z;
      m[0][2] = t*_v.x*_v.z + s*_v.y;
      m[0][3] = 0;

      m[1][0] = t*_v.x*_v.y + s*_v.z;
      m[1][1] = t*_v.y*_v.y + c;
      m[1][2] = t*_v.y*_v.z - s*_v.x;
      m[1][3] = 0;

      m[2][0] = t*_v.x*_v.z - s*_v.y;
      m[2][1] = t*_v.y*_v.z + s*_v.x;
      m[2][2] = t*_v.z*_v.z + c;
      m[2][3] = 0;

      m[3][0] = 0;
      m[3][1] = 0;
      m[3][2] = 0;
      m[3][3] = 1;
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void getRotationMatrix(const Matrix4x4<T>& m, 
				  Matrix3x3<T>& out)
    {
      out.set(   m[0][0], m[0][1], m[0][2],
		 m[1][0], m[1][1], m[1][2],
		 m[2][0], m[2][1], m[2][2] );	
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void setRotationMatrix(Matrix4x4<T>& m,
				  const Matrix3x3<T>& in)
    {
      m[0][0] = in[0][0];
      m[0][1] = in[0][1];
      m[0][2] = in[0][2];
      m[1][0] = in[1][0];
      m[1][1] = in[1][1];
      m[1][2] = in[1][2];
      m[2][0] = in[2][0];
      m[2][1] = in[2][1];
      m[2][2] = in[2][2]; 
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void getTranslationVector(const Matrix4x4<T>& m, 
				     Vector3<T>& out)
    {
      out.x = m[0][3];
      out.y = m[1][3];
      out.z = m[2][3];
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void buildTranslationMatrix (Matrix4x4<T>& m, 
					const Vector3<T>& v)
    {
      m[0][0] = 1;
      m[0][1] = 0;
      m[0][2] = 0;
      m[0][3] = v.x;

      m[1][0] = 0;
      m[1][1] = 1;
      m[1][2] = 0;
      m[1][3] = v.y;

      m[2][0] = 0;
      m[2][1] = 0;
      m[2][2] = 1;
      m[2][3] = v.z;

      m[3][0] = 0;
      m[3][1] = 0;
      m[3][2] = 0;
      m[3][3] = 1;
    }

  //---------------------------------------------------------------
  template<typename T>
    inline void transpose (const Matrix4x4<T>& m, 
			   Matrix4x4<T>& out)
    {
      out[0][0] = m[0][0];
      out[0][1] = m[1][0];
      out[0][2] = m[2][0];
      out[0][3] = m[3][0];
      out[1][0] = m[0][1];
      out[1][1] = m[1][1];
      out[1][2] = m[2][1];
      out[1][3] = m[3][1];
      out[2][0] = m[0][2];
      out[2][1] = m[1][2];
      out[2][2] = m[2][2];
      out[2][3] = m[3][2];
      out[3][0] = m[0][3];
      out[3][1] = m[1][3];
      out[3][2] = m[2][3];
      out[3][3] = m[3][3];
    }

  //---------------------------------------------------------------
  template<typename T>
    void affineInverse(const Matrix4x4<T>& m, 
		       Matrix4x4<T>& out)
    {
      Matrix4x4<T> temp;
      register  double    det_1;
      double    pos, neg, dtemp;
  
#define ACCUMULATE    \
	if (dtemp >= 0.0)  \
		pos += dtemp;  \
	else              \
		neg += dtemp;
  
      /*
       * Calculate the determinant of submatrix A and determine if the
       * the matrix is singular as limited by the double precision
       * floating-point data representation.
       */
      pos = neg = 0.0;
      dtemp =  out[0][0] * out[1][1] * out[2][2];
      ACCUMULATE
	dtemp =  out[0][1] * out[1][2] * out[2][0];
      ACCUMULATE
	dtemp =  out[0][2] * out[1][0] * out[2][1];
      ACCUMULATE
	dtemp = -out[0][2] * out[1][1] * out[2][0];
      ACCUMULATE
	dtemp = -out[0][1] * out[1][0] * out[2][2];
      ACCUMULATE
	dtemp = -out[0][0] * out[1][2] * out[2][1];
      ACCUMULATE
	det_1 = pos + neg;
  
      /* Is the submatrix A singular? */
      if ((det_1 == 0.0) || 
	  (std::fabs(det_1 / (pos - neg)) < std::numeric_limits<T>::epsilon())) 
	{
	  /* Matrix M has no inverse */
	  throw SingularMatrixError("Cannot invert a singular matrix.");
	}
  
      else 
	{
      
	  /* Calculate inverse(A) = adj(A) / det(A) */
	  det_1 = 1.0 / det_1;
	  temp[0][0] =   ( out[1][1] * out[2][2] - out[1][2] * out[2][1] ) * det_1;
	  temp[1][0] = - ( out[1][0] * out[2][2] - out[1][2] * out[2][0] ) * det_1;
	  temp[2][0] =   ( out[1][0] * out[2][1] - out[1][1] * out[2][0] ) * det_1;
	  temp[0][1] = - ( out[0][1] * out[2][2] - out[0][2] * out[2][1] ) * det_1;
	  temp[1][1] =   ( out[0][0] * out[2][2] - out[0][2] * out[2][0] ) * det_1;
	  temp[2][1] = - ( out[0][0] * out[2][1] - out[0][1] * out[2][0] ) * det_1;
	  temp[0][2] =   ( out[0][1] * out[1][2] - out[0][2] * out[1][1] ) * det_1;
	  temp[1][2] = - ( out[0][0] * out[1][2] - out[0][2] * out[1][0] ) * det_1;
	  temp[2][2] =   ( out[0][0] * out[1][1] - out[0][1] * out[1][0] ) * det_1;

	  /* Compute -inverse(A) * C */
	  temp[0][3] = - (   temp[0][0] * out[0][3] + temp[0][1] * out[1][3] + temp[0][2] * out[2][3]);

	  temp[1][3] = - (   temp[1][0] * out[0][3] + temp[1][1] * out[1][3] + temp[1][2] * out[2][3] );

	  temp[2][3] = - (   temp[2][0] * out[0][3] + temp[2][1] * out[1][3] + temp[2][2] * out[2][3]);

	  /* Fill in last row */
	  temp[3][0] = temp[3][1] = temp[3][2] = 0.0;
	  temp[3][3] = 1.0;

	}

      out=temp;
    }

  //---------------------------------------------------------------
  template<typename T>
    void inverse(const Matrix4x4<T>& m, 
		 Matrix4x4<T>& out)
    {
      int i, j;
  
      Matrix4x4<T> temp;
  
      /* calculate the adjoint matrix */
      adjoint(m, temp);
  
      /*  calculate the 4x4 determinant
       *  if the determinant is zero,
       *  then the inverse matrix is not unique.
       */

      T det = determinant(m);

      if ( std::fabs( det ) < std::numeric_limits<T>::epsilon())
	throw SingularMatrixError("Cannot invert a singular matrix.");

      /* scale the adjoint matrix to get the inverse */
      for (i=0; i<4; i++)
	for(j=0; j<4; j++)
	  temp[i][j] = temp[i][j] / det;

      out=temp;
    }

  //---------------------------------------------------------------
  template<typename T>
    void adjoint(const Matrix4x4<T>& m, 
		 Matrix4x4<T>& out)
    {
      Matrix4x4<T> temp;
      T a1, a2, a3, a4, b1, b2, b3, b4;
      T c1, c2, c3, c4, d1, d2, d3, d4;

      /* assign to individual variable names to aid
       * selecting correct values  
       */

      a1 = m[0][0]; b1 = m[0][1];
      c1 = m[0][2]; d1 = m[0][3];

      a2 = m[1][0]; b2 = m[1][1];
      c2 = m[1][2]; d2 = m[1][3];

      a3 = m[2][0]; b3 = m[2][1];
      c3 = m[2][2]; d3 = m[2][3];

      a4 = m[3][0]; b4 = m[3][1];
      c4 = m[3][2]; d4 = m[3][3];


      /* row column labeling reversed since we transpose rows & columns */

      out[0][0]  =   impl::determinant3x3( b2, b3, b4, c2, c3, c4, d2, d3, d4);
      out[1][0]  = - impl::determinant3x3( a2, a3, a4, c2, c3, c4, d2, d3, d4);
      out[2][0]  =   impl::determinant3x3( a2, a3, a4, b2, b3, b4, d2, d3, d4);
      out[3][0]  = - impl::determinant3x3( a2, a3, a4, b2, b3, b4, c2, c3, c4);

      out[0][1]  = - impl::determinant3x3( b1, b3, b4, c1, c3, c4, d1, d3, d4);
      out[1][1]  =   impl::determinant3x3( a1, a3, a4, c1, c3, c4, d1, d3, d4);
      out[2][1]  = - impl::determinant3x3( a1, a3, a4, b1, b3, b4, d1, d3, d4);
      out[3][1]  =   impl::determinant3x3( a1, a3, a4, b1, b3, b4, c1, c3, c4);

      out[0][2]  =   impl::determinant3x3( b1, b2, b4, c1, c2, c4, d1, d2, d4);
      out[1][2]  = - impl::determinant3x3( a1, a2, a4, c1, c2, c4, d1, d2, d4);
      out[2][2]  =   impl::determinant3x3( a1, a2, a4, b1, b2, b4, d1, d2, d4);
      out[3][2]  = - impl::determinant3x3( a1, a2, a4, b1, b2, b4, c1, c2, c4);

      out[0][3]  = - impl::determinant3x3( b1, b2, b3, c1, c2, c3, d1, d2, d3);
      out[1][3]  =   impl::determinant3x3( a1, a2, a3, c1, c2, c3, d1, d2, d3);
      out[2][3]  = - impl::determinant3x3( a1, a2, a3, b1, b2, b3, d1, d2, d3);
      out[3][3]  =   impl::determinant3x3( a1, a2, a3, b1, b2, b3, c1, c2, c3);
    }

  //---------------------------------------------------------------
  template<typename T>
    T determinant(const Matrix4x4<T>& m)
    {
      T ans;
      T a1, a2, a3, a4, b1, b2, b3, b4, c1, c2, c3, c4, d1, d2, d3, d4;

      /* 
       * assign to individual variable names to aid selecting 
       * correct elements 
       */

      a1 = m[0][0]; b1 = m[0][1];
      c1 = m[0][2]; d1 = m[0][3];

      a2 = m[1][0]; b2 = m[1][1];
      c2 = m[1][2]; d2 = m[1][3];

      a3 = m[2][0]; b3 = m[2][1];
      c3 = m[2][2]; d3 = m[2][3];

      a4 = m[3][0]; b4 = m[3][1];
      c4 = m[3][2]; d4 = m[3][3];

      ans = 	
	a1 * impl::determinant3x3( b2, b3, b4, c2, c3, c4, d2, d3, d4)
	- b1 * impl::determinant3x3( a2, a3, a4, c2, c3, c4, d2, d3, d4)
	+ c1 * impl::determinant3x3( a2, a3, a4, b2, b3, b4, d2, d3, d4)
	- d1 * impl::determinant3x3( a2, a3, a4, b2, b3, b4, c2, c3, c4);

      return ans;
    }

  //---------------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix4x4<T>& mat1, 
		    const Matrix4x4<T>& mat2, 
		    Matrix4x4<T>& out)
    {
      assert(&mat1 != &out);
      assert(&mat2 != &out);

#define m4x4_compute(r,c) out[(r)][(c)] = mat1[(r)][0] * mat2[0][(c)] + \
				       mat1[(r)][1] * mat2[1][(c)] + \
				       mat1[(r)][2] * mat2[2][(c)] + \
				       mat1[(r)][3] * mat2[3][(c)];
  
      m4x4_compute(0,0);
      m4x4_compute(0,1);
      m4x4_compute(0,2);
      m4x4_compute(0,3);
      m4x4_compute(1,0);
      m4x4_compute(1,1);
      m4x4_compute(1,2);
      m4x4_compute(1,3);
      m4x4_compute(2,0);
      m4x4_compute(2,1);
      m4x4_compute(2,2);
      m4x4_compute(2,3);
      m4x4_compute(3,0);
      m4x4_compute(3,1);
      m4x4_compute(3,2);
      m4x4_compute(3,3);
  
#undef m4x4_compute
    }

  //---------------------------------------------------------------
  template <typename T>
    inline void add(const Matrix4x4<T>& mat1, 
		    const Matrix4x4<T>& mat2, 
		    Matrix4x4<T>& out)
    {
      assert(&mat1 != &out);
      assert(&mat2 != &out);

      const T* p1=&mat1[0][0];
      const T* p1end=&mat1[3][3];
      const T* p2=&mat2[0][0];
      T* pout=&out[0][0];

      for (;p1<=p1end; p1++,p2++,pout++)
	*pout=*p1+*p2;       
    }

  //---------------------------------------------------------------
  template <typename T>
    inline void rt_mul(const Matrix4x4<T>& mat, 
		    const  Vector3<T>& vec, 
		    Vector3<T>& out)
    {
      T out_x = mat[0][0] * vec.x + 
	mat[0][1] * vec.y + 
	mat[0][2] * vec.z + 
	mat[0][3]; //we assume vec.w = 1
  
      T out_y = mat[1][0] * vec.x + 
	mat[1][1] * vec.y + 
	mat[1][2] * vec.z + 
	mat[1][3]; //we assume vec.w = 1
  
      T out_z = mat[2][0] * vec.x + 
	mat[2][1] * vec.y + 
	mat[2][2] * vec.z + 
	mat[2][3]; //we assume vec.w = 1

      out.set(out_x, out_y, out_z);
    }

  //---------------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix4x4<T>& mat, 
		    const Vector4<T>& vec, 
		    Vector4<T>& out)
    {
      T out_x = mat[0][0] * vec.x + 
	mat[0][1] * vec.y + 
	mat[0][2] * vec.z + 
	mat[0][3] * vec.w;
  
      T out_y = mat[1][0] * vec.x + 
	mat[1][1] * vec.y + 
	mat[1][2] * vec.z + 
	mat[1][3] * vec.w;
  
      T out_z = mat[2][0] * vec.x + 
	mat[2][1] * vec.y + 
	mat[2][2] * vec.z + 
	mat[2][3] * vec.w; 
  
      T out_w = mat[3][0] * vec.x + 
	mat[3][1] * vec.y + 
	mat[3][2] * vec.z + 
	mat[3][3] * vec.w;

      out.set(out_x, out_y, out_z, out_w);
    }

  //---------------------------------------------------------------
  template <typename T>
    std::ostream& operator<<(std::ostream& os, 
			     const Matrix4x4<T>& m)
    {
      os << "[";      
      for (int r=0; r<4; r++)
	{
	  os << "(";      
	  for (int c=0; c<4; c++)
	    {
	      os << m[r][c] << ", ";
	    }
	  os << ")";      
	}
	  
      os << "]";      
      return os;
    }
  /*@}*/
} //namespace ivllib

#endif //IVLLIB_MATRIX4X4_OP_H
