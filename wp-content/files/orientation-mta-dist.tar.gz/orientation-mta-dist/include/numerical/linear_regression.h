/**
 * \file    linear_regression.h
 * \brief   linear regression algorithms
 * \author  $LastChangedBy: cusano $
 * \date    $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_LINEAR_REGRESSION_H
#define IVLLIB_LINEAR_REGRESSION_H

//--- Headers ---------------------------------------------------------
#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/linear_systems.h>
#include <iterator>
#include <cassert>
#include <algorithm>

namespace ivllib
{
  //--- Function declarations -----------------------------------------
  
  /** \addtogroup numerical */
  /*@{*/

  /**
   * Linear regression.
   *
   * Solve the least squares fitting problem:
   * \f$ w^T x = y + e \f$,
   * where \f$ x \f$ are the pattern vectors in the range <tt> [patterns_from,patterns_to) </tt>;
   * \f$ y \f$ are the scalar target values in the range <tt> [targets_from,advance(targets_from+n)) </tt>,
   * <tt> n = std::distance(patterns_from,patterns_to) </tt>; \f$ w \f$ is the output vector; \f$ e \f$ is the
   * residual error to be minimized (not computed).
   * 
   * \p FwdIter1 must be a forward iterator. The elements iterated by a \p FwdIter1 must be of type
   * <tt> Vector<U> </tt> with \p U convertible to \p T.
   * \p FwdIter2 must be a forward iterator. The elements iterated by a \p FwdIter2 must be of
   * convertible to \p T.
   * \p T must be a floating point type.
   * The range <tt> [patterns_from,patterns_to) </tt> must be valid and non-empty. All the vectors 
   * in the range must have the same non-empty size.
   * The range <tt> [targets_from,advance(targets_from+n)) </tt> must be valid
   * (<tt> n = std::distance(patterns_from,patterns_to) </tt>).
   *
   * \param patterns_from iterator to the first pattern
   * \param patterns_to iterator past the last pattern
   * \param targets_from iterator to the first target value
   * \param out output vector
   *
   * \pre patterns_from != patterns_to
   * \pre patterns_from->size() > 0
   * \post out.size() == patterns_from->size()
   */
  template <typename FwdIter1,typename FwdIter2,typename T>
  void linear_regression(FwdIter1 patterns_from,
			 FwdIter1 patterns_to,
			 FwdIter2 targets_from,
			 Vector<T>& out);
  
  /*@}*/  

  //--- Implementations ----------------------------------------------
  template <typename FwdIter1,typename FwdIter2,typename T>
  void linear_regression(FwdIter1 patterns_from,
			 FwdIter1 patterns_to,
			 FwdIter2 targets_from,
			 Vector<T>& out)
  {
    /*
     * the output coefficients w are found solving the linear system
     *
     *   (A'*A)*w = A'*y
     *
     * where:
     * - A is a matrix whose rows are the input patterns
     * - A' is the transpose of A
     * - y is the vector of target values
     */

    typedef typename Matrix<T>::size_type size_type;
    typedef typename Matrix<T>::element_type value_type;
    
    assert( patterns_from != patterns_to );
    assert( patterns_from->size() > 0 );

    size_type m = patterns_from->size();

    // compute rhs = A'*y
    Matrix<T> rhs(m,1,0);
    FwdIter2 it2 = targets_from;
    for (FwdIter1 it1 = patterns_from; it1 != patterns_to; ++it1) {
      assert( it1->size() == m );
      for (size_type i = 0; i < m; i++) {
	rhs[i][0] += (*it2) * (*it1)[i];
      }
      ++it2;
    }
    
    // compute ata = A'*A
    Matrix<T> ata(m,m,0);
    for (size_type i = 0; i < m; i++) {
      for (size_type j = i; j < m; j++) {
	for (FwdIter1 it = patterns_from; it != patterns_to; ++it) 
	  ata[i][j] += (*it)[i] * (*it)[j];
	ata[j][i] = ata[i][j];
      }
    }
    
    Matrix<T> sol; // the solution of the linear system
    Matrix<T> inv; // ignored

    // solve the linear system ata*sol = rhs
    solve_gauss(ata,rhs,inv,sol);
    
    assert( sol.columns() == 1 );
    
    // copy the result in a vector
    Vector<T> result(m);
    std::copy(sol.column_begin(0),
	      sol.column_end(0),
	      result.begin());
    
    // commit
    out.swap(result);
  }
  
} //ivllib

#endif //IVLLIB_LINEAR_REGRESSION_H
