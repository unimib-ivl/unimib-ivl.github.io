/**
 * \file    matrix_op.h
 * \brief   matrix operations
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef MATRIX_OP_H
#define MATRIX_OP_H

//--- Headers ---------------------------------------------------------
#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <cassert>
#include <numeric>

namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  //--- Declarations ------------------------------------------------

  /** <tt> res[i][j] = m1[i][j] + m2[i][j] </tt> */
  template<typename A, typename B, typename C>
  inline void add(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res);

  /** <tt> res[i][j] = m1[i][j] - m2[i][j] </tt> */
  template<typename A, typename B, typename C>
  inline void sub(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res);

  /**  matrix multiplication */
  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res);

  /** matrix transposition and multiplication */
  template<typename A, typename B, typename C>
  inline void transposed_mul(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res);

  /**  matrix/vector mutliplication */
  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m, const Vector<B>& v, Vector<C>& res);

  /** matrix transposition and multiplication */
  template<typename A, typename B, typename C>
  inline void transposed_mul(const Matrix<A>& m, const Vector<B>& v, Vector<C>& res);

  /** <tt> res[i][j] = m1[i][j] + scalar </tt> */
  template<typename A, typename B, typename C>
  inline void add(const Matrix<A>& m1, const B& scalar, Matrix<C>& res);

  /** <tt> res[i][j] = m1[i][j] - scalar </tt> */
  template<typename A, typename B, typename C>
  inline void sub(const Matrix<A>& m1, const B& scalar, Matrix<C>& res);

  /** <tt> res[i][j] = m1[i][j] * scalar </tt> */
  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m1, const B& scalar, Matrix<C>& res);

  /** <tt> res[i][j] = m1[i][j] / scalar </tt> */
  template<typename A, typename B, typename C>
  inline void div(const Matrix<A>& m1, const B& scalar, Matrix<C>& res);

  /** \return true if the matrix have the same elements */
  template<typename A, typename B>
  inline bool compare(const Matrix<A>& m1, const Matrix<B>& m2);

  /** <tt> res[i][j] = m1[j][i] </tt> */
  template<typename A,typename B>
  inline void transpose(const Matrix<A>& m1,Matrix<B>& res);

  /** <tt> m1[i][j] == (i == j ? 1 : 0) </tt> */
  template<typename A> 
  inline void identity(Matrix<A>& m1);

  /** <tt> m1[i][j] += m2[i][j] </tt> */
  template<typename A, typename B>
  inline void add_to(Matrix<A>& m1, const Matrix<B>& m2);

  /** <tt> m1[i][j] -= m2[i][j] </tt> */
  template<typename A, typename B>
  inline void sub_to(Matrix<A>& m1, const Matrix<B>& m2);

  /** <tt> m1[i][j] += scalar </tt> */
  template<typename A, typename B>
  inline void add_to(Matrix<A>& m1, const B& scalar);

  /** <tt> m1[i][j] -= scalar </tt> */
  template<typename A, typename B, typename C>
  inline void sub_to(Matrix<A>& m1, const B& scalar);

  /** <tt> m1[i][j] *= scalar </tt> */
  template<typename A, typename B>
  inline void mul_to(Matrix<A>& m1, const B& scalar);

  /** <tt> m1[i][j] /= scalar </tt> */
  template<typename A, typename B>
  inline void div_to(Matrix<A>& m1, const B& scalar);

  /** <tt> res[i][j] = v1[i][j] * v2[i][j] </tt> */
  template<typename A, typename B, typename C>
  inline void elements_mul(const Matrix<A>& v1, const Matrix<B>& v2, Matrix<C>& res);

  /** <tt> res[i][j] = v1[i][j] / v2[i][j] </tt> */
  template<typename A, typename B, typename C>
  inline void elements_div(const Matrix<A>& v1, const Matrix<B>& v2, Matrix<C>& res);

  /** <tt> v1[i][j] *= v2[i][j] </tt> */
  template<typename A, typename B>
  inline void elements_mul_to(Matrix<A>& v1, const Matrix<B>& v2);

  /** <tt> v1[i][j] /= v2[i][j] </tt> */
  template<typename A, typename B>
  inline void elements_div_to(Matrix<A>& v1, const Matrix<B>& v2);


  /** 
   * Outer product
   *
   * Compute the matrix \p out define as:
   *
   * \f[ out = \left[
   * \begin{array}{cccc}
   * u_1 v_1 & u_1 v_2 & \cdots & u_1 v_m \\
   * u_2 v_1 & u_2 v_2 & \cdots & u_2 v_m \\
   * \vdots & \vdots & \ddots & \vdots \\
   * u_n v_1 & u_n v_2 & \cdots & u_n v_m \\
   * 
   * \end{array}
   * \right] \f]
   *
   * \post out.rows() == u.size()
   * \post out.columns() == v.size()
   *
   * \return the outer product of the input vectors.
   */
  template<typename A, typename B, typename C>
  void outer_product(const Vector<A>& u, const Vector<B>& v, Matrix<C>& out);

  /*@}*/  

  //--- Implementations -----------------------------------------------

  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m, const Vector<B>& v, Vector<C>& res)
  {
    assert(m.columns() == v.size());

    typedef typename Matrix<A>::size_type size_type;

    size_type n = m.rows();
    size_type k = m.columns();
    
    Vector<C> temp(n);

    size_type k1 = k - k % 8;
    
    for(size_type r = 0; r < n; r++) {
      typename Vector<C>::element_type x = 0;
      size_type i = 0;
      while (i < k1) {
	x += m[r][i] * v[i]
	  + m[r][i+1] * v[i+1]
	  + m[r][i+2] * v[i+2]
	  + m[r][i+3] * v[i+3]
	  + m[r][i+4] * v[i+4]
	  + m[r][i+5] * v[i+5]
	  + m[r][i+6] * v[i+6]
	  + m[r][i+7] * v[i+7];
	  i += 8;
      }
      while (i < k) {
	x += m[r][i] * v[i];
	++i;
      }
      temp[r] = x;
    }
    
    temp.swap(res);
  }

  //-------------------------------------------------------------------

  /** matrix transposition and multiplication
   *
   * \f[
   * res = m^T \times v.
   * \f]
   */
  template<typename A, typename B, typename C>
  inline void transposed_mul(const Matrix<A>& m, const Vector<B>& v, Vector<C>& res)
  {
    assert(m.rows() == v.size());

    typedef typename Matrix<A>::size_type size_type;

    size_type n = m.rows();
    size_type k = m.columns();
    
    Vector<C> temp(k,C());

    for (size_type j = 0; j < n; ++j) {
      typename Vector<A>::element_type x = v[j];
      typename Matrix<A>::const_row_iterator row = m.row_begin(j);
      for (size_type i = 0; i < k; ++i)
	temp[i] += x * row[i];
    }

    temp.swap(res);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B, typename C>
  inline void add(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res)
  {
    assert(m1.rows() == m2.rows());
    assert(m1.columns() == m2.columns());
    
    typename Matrix<A>::const_iterator iter1=m1.begin();
    typename Matrix<B>::const_iterator iter2=m2.begin();
    Matrix<C> tmp(m1.rows(), m1.columns());
    typename Matrix<C>::iterator iterR=tmp.begin();
    
    for (; iter1 != m1.end(); iter1++, iter2++, iterR++)
      *iterR = *iter1 + *iter2;
    
    res.swap(tmp);
  }
  
  //-------------------------------------------------------------------
  template<typename A, typename B, typename C>
  inline void sub(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res)
  {
    assert(m1.rows() == m2.rows());
    assert(m1.columns() == m2.columns());      

    typename Matrix<A>::const_iterator iter1=m1.begin();
    typename Matrix<B>::const_iterator iter2=m2.begin();

    Matrix<C> tmp(m1.rows(), m1.columns());
    typename Matrix<C>::iterator iterR=tmp.begin();

    for (; iter1 != m1.end(); iter1++, iter2++, iterR++)
      *iterR = *iter1 - *iter2;

    res.swap(tmp);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res)
  {
    assert(m1.columns() == m2.rows());
    
    typedef typename Matrix<A>::size_type size_type;
    
    size_type n = m1.rows();
    size_type k = m1.columns();
    size_type m = m2.columns();
    
    Matrix<C> tmp(n,m,C());

    for (size_type r = 0; r < n; r++) {
      for (size_type i = 0; i < k; i++) {
	typename Matrix<A>::element_type x = m1[r][i];
	typename Matrix<C>::row_iterator rc = tmp.row_begin(r);
	typename Matrix<B>::const_row_iterator r2 = m2.row_begin(i);
	for (size_type c = 0; c < m; ++c)
	  rc[c] += x * r2[c];
      }
    }
    
    res.swap(tmp);
  }
  
  //-------------------------------------------------------------------

  /** matrix transposition and multiplication
   *
   * \f[
   * res = m_1^T \times m_2.
   * \f]
   */
  template<typename A, typename B, typename C>
  inline void transposed_mul(const Matrix<A>& m1, const Matrix<B>& m2, Matrix<C>& res)
  {
    assert(m1.rows() == m2.rows());
    
    typedef typename Matrix<A>::size_type size_type;
    
    size_type n = m1.rows();
    size_type k = m1.columns();
    size_type m = m2.columns();
    
    Matrix<C> tmp(k,m,C());

    for (size_type l = 0; l < n; l++) {
      for (size_type i = 0; i < k; i++) {
	typename Matrix<A>::element_type x = m1[l][i];
	typename Matrix<C>::row_iterator rc = tmp.row_begin(i);
	typename Matrix<B>::const_row_iterator r2 = m2.row_begin(l);
	
	for (size_type j = 0; j < m; ++j)
	  rc[j] += x * r2[j];
      }
    }
    
    res.swap(tmp);
  }

  //-------------------------------------------------------------------
  template<typename A, typename B, typename C>
  inline void add(const Matrix<A>& m1, const B& scalar, Matrix<C>& res)
  {
    typename Matrix<A>::const_iterator iter1=m1.begin();

    Matrix<C> tmp(m1.rows(), m1.columns());    
    typename Matrix<C>::iterator iterR=tmp.begin();
    
    for ( ; iter1 != m1.end(); iter1++, iterR++ )
      *iterR = *iter1 + scalar;

    res.swap(tmp);
  }

  //-------------------------------------------------------------------
  template<typename A, typename B, typename C>
  inline void sub(const Matrix<A>& m1, const B& scalar, Matrix<C>& res)
  {
    typename Matrix<A>::const_iterator iter1=m1.begin();
    Matrix<C> tmp(m1.rows(), m1.columns());    
    typename Matrix<C>::iterator iterR=tmp.begin();
    
    for ( ; iter1 != m1.end(); iter1++, iterR++ )
      *iterR = *iter1 - scalar;
    
    res.swap(tmp);
  }

  //-------------------------------------------------------------------
  template<typename A, typename B, typename C>
  inline void mul(const Matrix<A>& m1, const B& scalar, Matrix<C>& res)
  {
    typename Matrix<A>::const_iterator iter1=m1.begin();
    Matrix<C> tmp(m1.rows(), m1.columns());    
    typename Matrix<C>::iterator iterR=tmp.begin();
    
    for ( ; iter1 != m1.end(); iter1++, iterR++ )
      *iterR = *iter1 * scalar;

    res.swap(tmp);
  }
  
  //-------------------------------------------------------------------
  template<typename A, typename B, typename C>
  inline void div(const Matrix<A>& m1, const B& scalar, Matrix<C>& res)
  {
    typename Matrix<A>::const_iterator iter1=m1.begin();
    Matrix<C> tmp(m1.rows(), m1.columns());    
    typename Matrix<C>::iterator iterR=tmp.begin();
    
    for ( ; iter1 != m1.end(); iter1++, iterR++ )
      *iterR = *iter1 / scalar;

    res.swap(tmp);
  }

  //-------------------------------------------------------------------
  template<typename A,typename B>
  inline bool compare(const Matrix<A>& m1, const Matrix<B>& m2)
    {
    if ( (m1.rows() != m2.rows()) || 
	 (m1.columns() != m2.columns()) )
      return false;
    
    typename Matrix<A>::const_iterator iter1=m1.begin();
    typename Matrix<A>::const_iterator iter2=m2.begin();
    
    for (; iter1 != m1.end(); iter1++)
      if (*iter1 != *iter2) return false;
    
    return true;
  }

  //-------------------------------------------------------------------
  template<typename A> 
  inline void identity(Matrix<A>& m1)
  {
    assert(m1.rows() == m1.columns());
    typedef typename Matrix<A>::size_type size_type;
    
    for (size_type r=0; r < m1.rows(); r++)
      for (size_type c=0; c < m1.rows(); c++)
	m1[r][c] = (r == c) ? 1 : 0;    
  }
  
  //-------------------------------------------------------------------
  template<typename A,typename B>
  inline void transpose(const Matrix<A>& m1, Matrix<B>& res)
  {
    assert(m1.rows() != 0);
    assert(m1.columns() != 0);
    
    Matrix<B> tmp(m1.columns(), m1.rows());
    
    for (typename Matrix<A>::size_type i = 0; i < m1.rows(); i++)
      std::copy(m1.row_begin(i),
		m1.row_end(i),
		tmp.column_begin(i));
        
    res.swap(tmp);   
  }
  //-------------------------------------------------------------------
  template<typename A, typename B>
  inline void add_to(Matrix<A>& m1, const Matrix<B>& m2)
  {
    assert(m1.rows() == m2.rows());
    assert(m1.columns() == m2.columns());
    
    typename Matrix<A>::iterator iter1=m1.begin();
    typename Matrix<B>::const_iterator iter2=m2.begin();
    
    for (; iter1 != m1.end(); iter1++, iter2++)
      *iter1 += *iter2;
  }
  //-------------------------------------------------------------------
  template<typename A, typename B>
  inline void sub_to(Matrix<A>& m1, const Matrix<B>& m2)
  {
    assert(m1.rows() == m2.rows());
    assert(m1.columns() == m2.columns());
    
    typename Matrix<A>::iterator iter1=m1.begin();
    typename Matrix<B>::const_iterator iter2=m2.begin();
    
    for (; iter1 != m1.end(); iter1++, iter2++)
      *iter1 = *iter1 - *iter2;   
  }

  //-------------------------------------------------------------------
  template<typename A, typename B>
  inline void add_to(Matrix<A>& m1, const B& scalar)
  {
    typename Matrix<A>::iterator iter1=m1.begin();
    
    for ( ; iter1 != m1.end(); iter1++ )
      *iter1 = *iter1 + scalar;
  }
  //-------------------------------------------------------------------

  template<typename A, typename B>
  inline void sub_to(Matrix<A>& m1, const B& scalar)
  {
    typename Matrix<A>::iterator iter1=m1.begin();
    
    for ( ; iter1 != m1.end(); iter1++ )
      *iter1 = *iter1 - scalar;    
  }
  //-------------------------------------------------------------------

  template<typename A, typename B>
  inline void mul_to(Matrix<A>& m1, const B& scalar)
  {
    typename Matrix<A>::iterator iter1=m1.begin();
    
    for ( ; iter1 != m1.end(); iter1++ )
      *iter1 = *iter1 * scalar;    
  }

  //-------------------------------------------------------------------  

  template<typename A, typename B>
  inline void div_to(Matrix<A>& m1, const B& scalar)
  {
    typename Matrix<A>::iterator iter1=m1.begin();
    
    for ( ; iter1 != m1.end(); iter1++ )
      *iter1 = *iter1 / scalar;    
  }

  //-------------------------------------------------------------------

  template<typename A, typename B, typename C>
  inline void elements_mul(const Matrix<A>& v1, const Matrix<B>& v2, Matrix<C>& res)
  {
    assert( v1.rows() == v2.rows() );
    assert( v1.columns() == v2.columns() );
    
    Matrix<C> tmp(v1.rows(),v1.columns());

    typename Matrix<A>::const_iterator iter1 = v1.begin();
    typename Matrix<B>::const_iterator iter2 = v2.begin();
    typename Matrix<C>::iterator iter3 = tmp.begin();

    for( ; iter1 != v1.end(); ++iter1,++iter2,++iter3)
      *iter3 = (*iter1) * (*iter2);

    res.swap(tmp);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B, typename C>
  inline void elements_div(const Matrix<A>& v1, const Matrix<B>& v2, Matrix<C>& res)
  {
    assert( v1.rows() == v2.rows() );
    assert( v1.columns() == v2.columns() );

    Matrix<C> tmp(v1.rows(),v1.columns());

    typename Matrix<A>::const_iterator iter1 = v1.begin();
    typename Matrix<B>::const_iterator iter2 = v2.begin();
    typename Matrix<C>::iterator iter3 = tmp.begin();

    for( ; iter1 != v1.end(); ++iter1,++iter2,++iter3)
      *iter3 = (*iter1) / (*iter2);

    res.swap(tmp);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B>
  inline void elements_mul_to(Matrix<A>& v1, const Matrix<B>& v2)
  {
    assert( v1.rows() == v2.rows() );
    assert( v1.columns() == v2.columns() );

    typename Matrix<A>::iterator iter1 = v1.begin();
    typename Matrix<B>::const_iterator iter2 = v2.begin();

    for( ; iter1 != v1.end(); ++iter1,++iter2)
      *iter1 *= (*iter2);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B>
  inline void elements_div_to(Matrix<A>& v1, const Matrix<B>& v2)
  {
    assert( v1.rows() == v2.rows() );
    assert( v1.columns() == v2.columns() );

    assert( v1.rows() == v2.rows() );
    assert( v1.columns() == v2.columns() );

    typename Matrix<A>::iterator iter1 = v1.begin();
    typename Matrix<B>::const_iterator iter2 = v2.begin();

    for( ; iter1 != v1.end(); ++iter1,++iter2)
      *iter1 /= (*iter2);
  }

  //-------------------------------------------------------------------

  template<typename A, typename B, typename C>
  void outer_product(const Vector<A>& u, const Vector<B>& v, Matrix<C>& out)
  {
    typedef typename Matrix<C>::size_type size_type;

    size_type n = u.size();
    size_type m = v.size();

    Matrix<C> res(n, m);
    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
	res[i][j] = u[i] * v[j];

    out.swap(res);
  }

} //ivllib

#endif //MATRIX_OP_H
