/**
 * \file vector2_op.h
 * \brief Vector2 template class operations definition file
 * \author $LastChangedBy$
 * \date $LastChangedDate: 2007-01-12 17:10:56 +0100 (Fri, 12 Jan 2007) $
 * \version $LastChangedRevision$
 */

#ifndef IVLLIB_VECTOR2_OP_H
#define IVLLIB_VECTOR2_OP_H

//--- Headers ----------------------------------------------------------------------
#include "numerical/vector2.h"
#include <iostream>
#include <cmath>
#include <cassert>


namespace ivllib {
  
  /** \addtogroup numerical */
  /*@{*/


  /**
   * normalize the input vector so that length()=1.
   */
  template<typename T> 
    inline bool normalize(Vector2<T>& v);
  /**
   * computes the length (euclidean distance) of the current vector
   */
  template<typename T>
    inline T length(const Vector2<T>& v);
  
  /**
   * computes the squared length (euclidean distance) of the current vector
   */
  template<typename T>
    inline T lengthsq(const Vector2<T>& v);

  /**
   * Compute the cosine of the angle between the current vector and
   * the vector passed as argument.
   */
  template<typename T>
    inline bool cos(const Vector2<T>&, const Vector2<T>&, T&);

  /**
   * Computes the sum (component by component) of the vectors passed as arguments.
   * @ return the resulting vector
   */
  template<typename A, typename B, typename C>
    inline void add(const Vector2<A>&, const Vector2<B>&, Vector2<C>& out);

  /**
   * Computes the subtraction (component by component) of the vectors
   * passed as arguments.  
   * @ return the resulting vector
   */
  template<typename A, typename B, typename C>
    inline void sub(const Vector2<A>&, const Vector2<B>&, Vector2<C>& out);
  
  /**
   * vector by scalar multiplication
   */
  template<typename A, typename B, typename C>
    inline void mul_scalar(const Vector2<A>&, B, Vector2<C>& out);
  
  /**
   * vector by scalar division
   */
  template<typename A, typename B, typename C>
    inline void div_scalar(const Vector2<A>&, B, Vector2<C>& out);
  
  /**
   * Computes the inner product (or dot product) of the current vector
   * and the vector passed as argument
   */
  template<typename A, typename B, typename C>
    inline C inner_product(const Vector2<A>& v1, const Vector2<B>& v2, C scalar_base);

  //-----------------------------------------------------------------------
  template<typename T> 
    inline bool normalize(Vector2<T>& v)
    {
      T length = sqrt(v.x*v.x + v.y*v.y);
	
      if (length == 0.0f)
	return false;
	
      v.x/=length;
      v.y/=length;

      return true;
    }

  //----------------------------------------------------------------------
  template<typename T>
    inline T length(const Vector2<T>& v)
    {
      return sqrt(lengthsq(v));
    }

  //----------------------------------------------------------------------
  template<typename T>
    inline T lengthsq(const Vector2<T>& v)
    {
      return v.x*v.x + v.y*v.y;
    }

  //----------------------------------------------------------------------
  template<typename T>
    inline bool cos(const Vector2<T>& v1, 
		    const Vector2<T>& v2, 
		    T& res)
    {
      T temp;
	
      temp = lengthsq(v1) * lengthsq(v2);
	
      if (temp == 0.0) 
	return false;
	
      res = inner_product(v1,v2,0.0) / temp;
      return true;
    }

  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline void add(const Vector2<A>& a, const Vector2<B>& b, Vector2<C>& out)
  {
    out.x = a.x + b.x;
    out.y = a.y + b.y;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline void sub(const Vector2<A>& a, const Vector2<B>& b, Vector2<C>& out)
  {
    out.x = a.x - b.x;
    out.y = a.y - b.y;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline void mul_scalar(const Vector2<A>& a, B k, Vector2<C>& out)
  {
    out.x = a.x * k;
    out.y = a.y * k;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline void div_scalar(const Vector2<A>& a, B k, Vector2<C>& out)
  {
    out.x = a.x / k;
    out.y = a.y / k;
  }
  //----------------------------------------------------------------------
  template<typename A, typename B, typename C>
    inline C inner_product(const Vector2<A>& v1, const Vector2<B>& v2, C scalar_base)
  {
    return scalar_base + v1.x*v2.x + v1.y*v2.y;
  }

} //namespace ivllib

//----------------------------------------------------------------------
/**
 * output utility operator
 */
template<typename T>
std::ostream& operator<<(std::ostream& os, 
			 const ivllib::Vector2<T>& v); 

//----------------------------------------------------------------------
template<typename T>
inline std::ostream& operator<<(std::ostream& os, 
				const ivllib::Vector2<T>& v)
{
  os << v.x << " " << v.y;
  return os;
}
//----------------------------------------------------------------------

/*@}*/
#endif //IVLLIB_VECTOR2_OP_H
