#ifndef IVLLIB_MATRIX4X4_H
#define IVLLIB_MATRIX4X4_H

//--- Headers -------------------------------------------------------------------------
#include <cstring>

//--- Types --------------------------------------------------------------------------

namespace ivllib {

  /** \addtogroup numerical */
  /*@{*/
  
  /**
   * A matrix of fixed size dimensions (4x4).  Its primary use is for 3D
   * homogeneus coordinates transformations.
   *
   *     [ R t ]
   * T = [     ]
   *     [ 0 1 ]
   */

  template <typename T>
  class Matrix4x4
  {
        
  public:
    typedef T element_type; ///< type of the matrix elements
    typedef size_t size_type; ///< type of indexes
    typedef element_type* iterator; ///< iterator type
    typedef const element_type* const_iterator; ///< const iterator type

    /**
     * \brief default constructor.
     *
     * the default constructor makes no initializations on the matrix
     * for efficency reasons.
     */
    Matrix4x4() {}

    /**
     * constructs a matrix specifying all the elements.
     */
    Matrix4x4 (element_type m00, element_type m01, element_type m02, element_type m03,
	       element_type m10, element_type m11, element_type m12, element_type m13,
	       element_type m20, element_type m21, element_type m22, element_type m23,
	       element_type m30, element_type m31, element_type m32, element_type m33)
    {
      set (m00,   m01,   m02,   m03,
	   m10,   m11,   m12,   m13,
	   m20,   m21,   m22,   m23,
	   m30,   m31,   m32,   m33);
    }

    /**
     * \brief default destructor
     */
    ~Matrix4x4() {}

    /**
     * @return an iterator pointing to the element at (0,0)
     */    
    iterator begin()
    { return mData; }
      
    /**
     * @return an iterator pointing to the element at (0,0)
     */    	
    const_iterator begin() const
    { return mData; }

    /**
     * @return an iterator pointing to past the end
     */    
    iterator end()
    { return mData+16; }

    /**
     * @return an iterator pointing to past the end
     */    
    const_iterator end() const
    { return mData+16; }

    /**
     * sets the entries of the matrix with the parameters passed as
     * arguments.  mij indicates the entry at row i and column j.
     */
    inline void set (element_type m00, element_type m01, element_type m02, element_type m03,
		     element_type m10, element_type m11, element_type m12, element_type m13,
		     element_type m20, element_type m21, element_type m22, element_type m23,
		     element_type m30, element_type m31, element_type m32, element_type m33)
    {
      (*this)[0][0]=m00;
      (*this)[0][1]=m01;
      (*this)[0][2]=m02;
      (*this)[0][3]=m03;
      (*this)[1][0]=m10;
      (*this)[1][1]=m11;
      (*this)[1][2]=m12;
      (*this)[1][3]=m13;
      (*this)[2][0]=m20;
      (*this)[2][1]=m21;
      (*this)[2][2]=m22;
      (*this)[2][3]=m23;
      (*this)[3][0]=m30;
      (*this)[3][1]=m31;
      (*this)[3][2]=m32;
      (*this)[3][3]=m33;
    }

    /**
     * @return an iterator pointing to the first elementh of the specified row
     */
    inline iterator operator[] (size_type row)
    { return (mData + (row * 4)); }

    /**
     * @return an iterator pointing to the first elementh of the specified row
     */
    inline const_iterator operator[] (size_type row) const
    { return (mData + (row * 4)); }

  private:
    element_type mData[16];

  }; //end of Matrix4x4 class definition
  
  typedef Matrix4x4<float> Matrix4x4f; ///< a 4x4 matrix of floats
  typedef Matrix4x4<double> Matrix4x4d; ///< a 4x4 matrix of doubles

  /*@}*/

} //namespace ivllib

#endif //IVLLIB_MATRIX4X4_H
