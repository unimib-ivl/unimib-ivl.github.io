/**
 * \file    math_io.h
 * \brief   io for vectors and matrices
 */

#ifndef math_io_h
#define math_io_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <platform.h>

#include <istream>
#include <ostream>
#include <sstream>
#include <cstddef>
#include <vector>
#include <stdexcept>


namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/



  /**
   * Parse a vector from a text stream
   *
   * Read a vector representation: one line of text formed by elements
   * of type \c T, separated by whitespaces, and terminated by a
   * newline character.  Comments (text following '#') are ignored.
   * An empty line in interpeted as an empty vector.
   *
   * \param is input stream
   * \param v output vector
   * 
   * \return a reference to the stream
   */
  template <typename T>  
  std::istream&
  read_vector_txt(std::istream& is, Vector<T>& v);

  /**
   * Write a vector as text.
   *
   * Write the elements of \a v, separated by \a sep, on \a os.  The
   * output is terminated with a newline character.
   *
   * \param os output stream
   * \param v input vector
   * \param sep element separator
   *
   * \return a reference to the stream
   */
  template <typename T>  
  std::ostream&
  write_vector_txt(std::ostream& os, const Vector<T>& v,
		   const std::string& sep="\t");


  /**
   * Parse a matrix from a text stream
   *
   * Read a matrix representation: one line of text for each row,
   * formed by elements of type \c T, separated by whitespaces.  The
   * matrix is terminated by an empty line.  Comments (text following
   * '#') are ignored.  An empty line in interpeted as an empty
   * matrix.
   *
   * \param is input stream
   * \param m output matrix
   * 
   * \return a reference to the stream
   */
  template <typename T>  
  std::istream&
  read_matrix_txt(std::istream& is, Matrix<T>& m);
  
  /**
   * Write a matrix as text.
   *
   * Write the rows od \a m, separated by newlines.  Each element of
   * the rows are separated by \a sep.  The output is terminated with
   * an empty line.
   *
   * \param os output stream
   * \param m input matrix
   * \param sep element separator
   *
   * \return a reference to the stream
   */
  template <typename T>  
  std::ostream&
  write_matrix_txt(std::ostream& os, const Matrix<T>& m,
		   const std::string& sep="\t");
  
  // content type constants
  const int BFCT_vector = 0;  ///< vector encoding
  const int BFCT_matrix = 1;  ///< matrix encoding


  // data types
  const int BFDT_int8 = 0;  ///< one signed byte
  const int BFDT_uint8 = 1;  ///< one unsigned byte
  const int BFDT_int16 = 2;  ///< two signed bytes
  const int BFDT_uint16 = 3;  ///< two unsigned bytes
  const int BFDT_int32 = 4;  ///< four signed bytes
  const int BFDT_uint32 = 5;  ///< four unsigned bytes
  const int BFDT_int64 = 6;  ///< eight signed bytes
  const int BFDT_uint64 = 7;  ///< eight unsigned bytes
  const int BFDT_float32 = 8;  ///< single precision floating point
  const int BFDT_float64 = 9;  ///< double precision floating point
  const int BFDT_reserved_last = 10;  ///< sentinel

  // encodings
  const int BFE_plain = 0;  ///< plain encoding
  const int BFE_reserved_last = 1;  ///< sentinel


  /**
   * The header of a binary structure.
   *
   * Can be used for both vectors and matrices.
   */
  struct MathHeader
  {
    int content_type;  ///< vector or matrix
    int data_type;  ///< type of the elements
    int encoding;  ///< encoding
    std::size_t length;   ///< number of elements (vector) or rows (matrix)
    std::size_t columns;  ///< 1 for vectors
    std::size_t datalength;  ///< bytes of the data chunk
  };


  /**
   * Write a vector to a stream.
   *
   * \param os output stream
   * \param v the vector
   * \param binary_encoding the encoding
   */
  template <typename T>
  void write_vector(std::ostream& os,
		    const Vector<T>& v,
		    int binary_encoding = BFE_plain);

  /**
   * Write a matrix to a stream.
   *
   * \param os output stream
   * \param m the matrix
   * \param binary_encoding the encoding
   */
  template <typename T>
  void write_matrix(std::ostream& os,
		    const Matrix<T>& m,
		    int binary_encoding = BFE_plain);

  /**
   * Read a vector from a stream.
   *
   * \param is input stream
   * \param v output vector
   *
   * \return true if the vector has been correctly read; false in case
   * of an EOF.
   */
  template <typename T>
  bool read_vector(std::istream& is, Vector<T>& v);


  /**
   * Read a matrix from a stream.
   *
   * \param is input stream
   * \param m output matrix
   *
   * \return true if the matrix has been correctly read; false in case
   * of an EOF.
   */
  template <typename T>
  bool read_matrix(std::istream& is, Matrix<T>& m);

  /**
   * Read the header of a vector or matrix.
   *
   * \param is input stream
   * \param h output header
   *
   * \return true if the header has been correctly read; false in case
   * of an EOF.
   */
  bool read_math_header(std::istream& is, MathHeader& h);


  /**
   * Read the data of a vector.
   *
   * \param is input stream
   * \param h the header corresponding to the vector
   * \param v the output vector
   */
  template <typename T>
  void read_vector_data(std::istream& is,
			const MathHeader& h,
			Vector<T>& v);

  /**
   * Read the data of a matrix.
   *
   * \param is input stream
   * \param h the header corresponding to the matrix
   * \param m the output matrix
   */
  template <typename T>
  void read_matrix_data(std::istream& is,
			const MathHeader& h,
			Matrix<T>& m);

  /*@}*/


  //------------------------------------------------------------
  // Implementation


  /** \cond detail */
  namespace detail_txt_io
  {
    // define intermediate type conversion:
    // used to treat int8 and uint8 as integers
    template <typename T>
    struct txtconv
    {
      typedef T type;
    };

    template <>
    struct txtconv<int8> {
      typedef int type;
    };

    template <>
    struct txtconv<uint8> {
      typedef unsigned int type;
    };
  };
  /** \endcond */

  template <typename T>
  std::istream&
  read_vector_txt(std::istream& is, Vector<T>& v)
  {
    std::string line;
    
    if (!is)
      return is;
    
    if (!std::getline(is, line))
      return is;
    
    std::size_t pos = line.find('#');
    if (pos != std::string::npos)
      line.erase(pos);
    
    std::istringstream iss(line);
    std::vector<T> temp;
    typename detail_txt_io::txtconv<T>::type val;
    
    while (iss >> val)
      temp.push_back(val);
    
    if (!iss.eof())
      is.setstate(std::ios::failbit);
    else
      v.assign(temp.begin(), temp.end());

    return is;
  }


  template <typename T>
  std::ostream&
  write_vector_txt(std::ostream& os, const Vector<T>& v,
		   const std::string& sep)
  {
    typedef typename Vector<T>::size_type size_type;

    size_type n = v.size();
    for (size_type i = 0; i < n; i++) {
      typename detail_txt_io::txtconv<T>::type val = v[i];
      if (!(os << val))
	break;
      if (i + 1 != n && !(os << sep))
	break;
    }
    if (os)
      os << '\n';

    return os;
  }


  template <typename T>
  std::istream&
  read_matrix_txt(std::istream& is, Matrix<T>& m)
  {
    typedef typename Matrix<T>::size_type size_type;

    if (!is)
      return is;

    size_type rows = 0;
    size_type cols = 0;
    std::string line;
    std::vector<T> temp;
    
    while (std::getline(is, line)) {
      // each iteration read a row which is appended to temp
      std::size_t pos = line.find('#');
      if (pos != std::string::npos)
	line.erase(pos);
      std::istringstream iss(line);
      typename detail_txt_io::txtconv<T>::type val;
      size_type n = 0;
      while (iss >> val) {
	temp.push_back(val);
	++n;
      }
      if (!iss.eof()) {
	is.setstate(std::ios::failbit);
	return is;
      }

      if (n == 0)
	break;  // finished reading the data
      
      if (rows == 0) {
	cols = n;
      } else if (n != cols) {
	// the number of elements does not match the number of columns
	is.setstate(std::ios::failbit);
	return is;
      }
      ++rows;
    }

    if ((is.good() || is.eof()) && rows > 0) {
      m.assign(temp.begin(), temp.end(), cols);
      is.clear(std::ios::goodbit); 
    }

    return is;
  }


  template <typename T>
  std::ostream&
  write_matrix_txt(std::ostream& os, const Matrix<T>& m,
		   const std::string& sep)
  {
    typedef typename Vector<T>::size_type size_type;

    size_type n = m.rows();
    size_type k = m.columns();

    for (size_type i = 0; i < n; i++) {
      for (size_type j = 0; j < k; j++) {
	typename detail_txt_io::txtconv<T>::type val = m[i][j];
	if (!(os << val))
	  return os;
	if (j + 1 != k && !(os << sep))
	  return os;
      }
      if (!(os << '\n'))
	return os;
    }
    os << '\n';

    return os;
  }


  /** \cond detail */
  namespace detail
  {
    // convert a type to its code
    template <typename T>
    struct BinaryDataType
    {
    };

    template <> struct BinaryDataType<int8> { enum {type = BFDT_int8};};
    template <> struct BinaryDataType<uint8> { enum {type = BFDT_uint8};};
    template <> struct BinaryDataType<int16> { enum {type = BFDT_int16};};
    template <> struct BinaryDataType<uint16> { enum {type = BFDT_uint16};};
    template <> struct BinaryDataType<int32> { enum {type = BFDT_int32};};
    template <> struct BinaryDataType<uint32> { enum {type = BFDT_uint32};};
    template <> struct BinaryDataType<int64> { enum {type = BFDT_int64};};
    template <> struct BinaryDataType<uint64> { enum {type = BFDT_uint64};};
    template <> struct BinaryDataType<float32> { enum {type = BFDT_float32};};
    template <> struct BinaryDataType<float64> { enum {type = BFDT_float64};};


    // write the header h to os
    void write_math_header(std::ostream& os,
			   const MathHeader& h);

    // write the data in *ptr to os according to h
    void write_data(std::ostream& os,
		    const MathHeader& h,
		    const void* ptr);

    // fill h with the appropriate information
    void fill_header(MathHeader& h,
		     int content_type,
		     int data_type,
		     std::size_t itemsize,
		     int encoding,
		     std::size_t elements,
		     std::size_t columns);

    // read data from is to *ptr according to h, data_type and
    // itemsize
    void read_raw_data(std::istream& is,
		       const MathHeader& h,
		       int data_type,
		       std::size_t itemsize,
		       void* ptr);

  } // detail
  /** \endcond */


  template <typename T>
  void write_vector(std::ostream& os,
		    const Vector<T>& v,
		    int binary_encoding)
  {
    MathHeader h;
    detail::fill_header(h,
			BFCT_vector,
			detail::BinaryDataType<T>::type,
			sizeof(T),
			binary_encoding,
			v.size(),
			1);

    detail::write_math_header(os, h);
    if (v.size() > 0)
      detail::write_data(os, h, &(v[0]));
    else
      detail::write_data(os, h, 0);
  }


  template <typename T>
  void write_matrix(std::ostream& os,
		    const Matrix<T>& m,
		    int binary_encoding)
  {
    MathHeader h;
    detail::fill_header(h,
			BFCT_matrix,
			detail::BinaryDataType<T>::type,
			sizeof(T),
			binary_encoding,
			m.rows(),
			m.columns());

    detail::write_math_header(os, h);
    if (h.datalength > 0) 
      detail::write_data(os, h, &(m[0][0]));
    else
      detail::write_data(os, h, 0);
  }

  template <typename T>
  bool read_vector(std::istream& is, Vector<T>& v)
  {
    MathHeader h;
    if (!read_math_header(is, h))
      return false;
    read_vector_data(is, h, v);
    return true;
  }


  template <typename T>
  bool read_matrix(std::istream& is, Matrix<T>& m)
  {
    MathHeader h;
    if (!read_math_header(is, h))
      return false;
    read_matrix_data(is, h, m);
    return true;
  }


  template <typename T>
  void read_vector_data(std::istream& is,
			const MathHeader& h,
			Vector<T>& v)
  {
    if (h.content_type != BFCT_vector)
      throw std::runtime_error("Content type mismatch");

    Vector<T> tmp(h.length);

    if (h.length > 0) {
      detail::read_raw_data(is,
			    h,
			    detail::BinaryDataType<T>::type,
			    sizeof(T),
			    &(tmp[0]));
    } else {
      detail::read_raw_data(is,
			    h,
			    detail::BinaryDataType<T>::type,
			    sizeof(T),
			    0);
    }

    v.swap(tmp);
  }


  template <typename T>
  void read_matrix_data(std::istream& is,
			const MathHeader& h,
			Matrix<T>& m)
  {
    if (h.content_type != BFCT_matrix)
      throw std::runtime_error("Content type mismatch");

    Matrix<T> tmp(h.length, h.columns);

    if (h.length > 0 && h.columns > 0) {    
      detail::read_raw_data(is,
			    h,
			    detail::BinaryDataType<T>::type,
			    sizeof(T),
			    &(tmp[0][0]));
    } else {
      detail::read_raw_data(is,
			    h,
			    detail::BinaryDataType<T>::type,
			    sizeof(T),
			    0);
    }

    m.swap(tmp);
  }

} // ivllib

#endif
