/**
 * \file vector4.h
 * \brief vector4 template class definition file
 * \author $LastChangedBy$
 * \date $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_VECTOR4_H
#define IVLLIB_VECTOR4_H

//--- Types ----------------------------------------------------------------------
namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  
  /**
   * A template class representing a four-dimensional vector.
   */
  template <typename T>
  class Vector4 
  {
  public:
    /// type of the elements
    typedef T element_type;

    element_type x; ///< a component of the vector
    element_type y; ///< a component of the vector
    element_type z; ///< a component of the vector
    element_type w; ///< a component of the vector

    /**
     * Default constructor. no initialization is done.
     */
    Vector4() {}
	
    /**
     * Copy-constructor.
     */
    template <typename U>
    Vector4(const Vector4<U>& v) : x(v.x), y(v.y), z(v.z), w(v.w) {} 

    /// constructor
    Vector4(element_type _x, 
	    element_type _y, 
	    element_type _z, 
	    element_type _w) : x(_x), y(_y), z(_z), w(_w) {}

    /// set the components of the vector
    inline void set(element_type _x, 
		    element_type _y, 
		    element_type _z, 
		    element_type _w) 
    { x=_x; y=_y; z=_z; w=_w;}

    /// comparison
    inline bool operator==(const Vector4& v) const
    { return x==v.x && y==v.y && z==v.z && w==v.w; }

    /// comparison
    inline bool operator!=(const Vector4& v) const
    { return x!=v.x || y!=v.y || z!=v.z || w!=v.w; }

    /// assignement
    template<typename U>
    Vector4 operator=(const Vector4<U>& a)
    {
      this->x = a.x;
      this->y = a.y;	  
      this->z = a.z;
      this->w = a.w;
    }
  }; //Vector4

  typedef Vector4<float> Vector4f;  ///< vector with four floating points elements (single precision)
  typedef Vector4<double> Vector4d; ///< vector with four floating points elements (double precision)

  /*@}*/

} //namespace ivllib

#endif //IVLLIB_VECTOR_H 
