/**
 * /file quaternion_op.h
 * /brief quaternion operations definition file
 * /author $LastChangedBy$
 * /date $LastChangedDate$
 * /version $LastChangedRevision$
 */

#ifndef ivllib_quaternion_op_h
#define ivllib_quaternion_op_h

#include "numerical/ivl_math.h"
#include "numerical/quaternion.h"
#include "numerical/matrix4x4.h"

namespace ivllib
{  
  /// Quaternion addition
  template <typename T>
  void add(const Quaternion<T>& pLeft, 
	   const Quaternion<T>& pRight, 
	   Quaternion<T>& pRes);
  
  /// Quaternion multiplication
  template <typename T>
  void mul(const Quaternion<T>& pLeft, 
	   const Quaternion<T>& pRight, 
	   Quaternion<T>& pRes);

  /// Quaternion normalization
  template <typename T>
  void normalize(Quaternion<T>& q);
  
  /// Quaternion to Matrix4x4 conversion
  template <typename T>
  void Quaternion_to_Matrix4x4(const Quaternion<T>& pQuat, 
			       Matrix4x4<T>& pMat);
} //namespace ivllib

//--- Implementation -----------------------------------------------------------------
template <typename T>
void ivllib::add(const ivllib::Quaternion<T>& pLeft, 
		 const ivllib::Quaternion<T>& pRight, 
		 ivllib::Quaternion<T>& pRes)
{
  pRes.w = pLeft.w + pRight.w;
  pRes.x = pLeft.x + pRight.x;
  pRes.y = pLeft.y + pRight.y;
  pRes.z = pLeft.z + pRight.z;
}

//------------------------------------------------------------------------------------
template <typename T>
void ivllib::mul(const ivllib::Quaternion<T>& pLeft, 
		 const ivllib::Quaternion<T>& pRight, 
		 ivllib::Quaternion<T>& pRes)
{
  pRes.w = pLeft.w*pRight.w - pLeft.x*pRight.x - pLeft.y*pRight.y - pLeft.z*pRight.z;
  pRes.x = pLeft.w*pRight.x + pLeft.x*pRight.w + pLeft.z*pRight.y - pLeft.y*pRight.z;
  pRes.y = pLeft.w*pRight.y + pLeft.y*pRight.w + pLeft.x*pRight.z - pLeft.z*pRight.x;
  pRes.z = pLeft.w*pRight.z + pLeft.z*pRight.w + pLeft.y*pRight.x - pLeft.x*pRight.y;  
}

//------------------------------------------------------------------------------------
/// Quaternion to Matrix4x4 conversion
template <typename T>
void ivllib::Quaternion_to_Matrix4x4(const ivllib::Quaternion<T>& pQuat, 
				     ivllib::Matrix4x4<T>& pMat)
{
  pMat[0][0] = 1 - 2*(sqr(pQuat.y) + sqr(pQuat.z));
  pMat[0][1] = 2 * (pQuat.x * pQuat.y - pQuat.w * pQuat.z);
  pMat[0][2] = 2 * (pQuat.x * pQuat.z + pQuat.w * pQuat.y);
  pMat[0][3] = 0;

  pMat[1][0] = 2 * (pQuat.x * pQuat.y + pQuat.w * pQuat.z);
  pMat[1][1] = 1 - 2*(sqr(pQuat.x) + sqr(pQuat.z));  
  pMat[1][2] = 2 * (pQuat.y * pQuat.z - pQuat.w * pQuat.x);
  pMat[1][3] = 0;

  pMat[2][0] = 2 * (pQuat.x * pQuat.z - pQuat.w * pQuat.y);
  pMat[2][1] = 2 * (pQuat.y * pQuat.z + pQuat.w * pQuat.x);
  pMat[2][2] = 1 - 2*(sqr(pQuat.x) + sqr(pQuat.y));
  pMat[2][3] = 0;

  pMat[3][0] = pMat[3][1] = pMat[3][2] = 0; pMat[3][3] = 1;
}
//------------------------------------------------------------------------------------
template <typename T>
void ivllib::normalize(ivllib::Quaternion<T>& q)
{
  T norm=sqrt(q.x*q.x +q.y*q.y + q.z*q.z + q.w*q.w);
  
  assert(norm!=0.0);

  q.x/=norm;
  q.y/=norm;
  q.z/=norm;
  q.w/=norm;  
}
//------------------------------------------------------------------------------------

#endif //ivllib_quaternion_h
