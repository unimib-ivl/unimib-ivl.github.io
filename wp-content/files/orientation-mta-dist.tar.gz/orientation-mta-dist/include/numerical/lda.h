/**
 * \file    lda.h
 * \brief   Linear Discriminant Analysis
 * \author  $LastChangedBy:$
 * \date    $Date$
 * \version $Revision:$
 */

#ifndef lda_h
#define lda_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <numerical/matrix_op.h>
#include <numerical/eigensystems.h>
#include <numerical/linear_systems.h>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#include <functional>
#include <iterator>
#include <vector>

namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  
  template <typename FwdIter1,typename FwdIter2,typename T>
  void compute_lda_basis(FwdIter1 patterns_from,
			 FwdIter1 patterns_to,
			 FwdIter2 classes_from,
			 typename Matrix<T>::size_type components,
			 Matrix<T>& basis);

  /** \cond detail */
  namespace detail
  {
    // used for LDA computation
    template <typename C,typename P>
    struct pattern
    {
      pattern(const C& c,const P& p) : label(c), data(p) { }
      C label;
      P data;
      bool operator<(const pattern& p) const { return label < p.label; }
    };    
  }
  /** \endcond */
  
  /**
   * Linear Discriminant Analysis.
   *
   * Computes the basis of Fisher's Linear Discriminant Analysis.
   *
   * A pattern \c x (column vector) is projected in the LDA space with 
   * \f$ B x \f$ where \c B is the basis of the transform 
   *
   * The function is called specifying a range [ \c patterns_from, \c patterns_to )
   * of patterns to be analysed. Each pattern is a vector and all vectors must have the same size.
   * \c FwdIter must be a forward iterator which iterates over \c Vector<U>
   * where \c U must be \c float or \c double.
   * The value type of \c FwdIter2 must comparable whiut \c operator<.
   * The range <tt> [classes_from, advance(classes_from,distance(patterns_from,patterns_to))) </tt>
   * must be valid.   
   * The function will place the computed basis in the output paramter \c basis.
   *
   * The parameter \c components indicate the dimension of the space of the projections.
   * If the number of required components is greater then or equal to the
   * number of classes, the exceeding number of components correspond to null rows in
   * the basis computed.
   * Otherwise, the basis is orthonormal.
   *
   * \param patterns_from iterator to the first pattern
   * \param patterns_to iterator past the last pattern
   * \param classes_from iterator to the class of the first pattern
   * \param components number of components of the basis
   * \param basis the base of the transformation
   *
   * \pre patterns_from != patterns_to
   * \pre patterns_from->size() > 0
   * \pre it->size() == patterns_from->size() for each \c it in [ \c patterns_from, \c patterns_to )   
   * \pre components > 0
   * \pre components <= patterns_from->size() > 0
   *
   * \post basis.rows() == components
   * \post basis.columns() == patterns_from->size()
   */
  template <typename FwdIter1,typename FwdIter2,typename T>
  void compute_lda_basis(FwdIter1 patterns_from,
			 FwdIter1 patterns_to,
			 FwdIter2 classes_from,
			 typename Matrix<T>::size_type components,
			 Matrix<T>& basis)
  {
    assert( patterns_from != patterns_to );
    assert( patterns_from->size() > 0 );
    assert( components > 0 );
    assert( components <= patterns_from->size() );

    typedef typename Matrix<T>::size_type size_type;
    typedef typename Matrix<T>::element_type el_type;
    
    typedef typename std::iterator_traits<FwdIter1>::value_type data_type;
    typedef typename std::iterator_traits<FwdIter2>::value_type class_type;
    typedef detail::pattern<class_type,const data_type*> pattern_type;
    typedef std::vector<pattern_type> patterns_type;
    typedef typename patterns_type::iterator patterns_iter;    

    patterns_type patterns;
    size_type n = 0;
    size_type m = patterns_from->size();
    
    Vector<T> mean(m,T(0));
    while (patterns_from != patterns_to) {
      ++n;
      assert( patterns_from->size() == m );
      add_to(mean,*patterns_from);
      patterns.push_back(pattern_type(*classes_from,&(*patterns_from)));
      ++patterns_from;
      ++classes_from;
    }
    mul_to(mean,T(1)/n);
    
    // group the patterns by classes
    std::sort(patterns.begin(),patterns.end());
    
    Matrix<T> Sb(m,m,T(0)); // between class scattern matrix
    Matrix<T> Sw(m,m,T(0)); // within class scattern matrix

    // cycle trought the classes
    patterns_iter to = patterns.begin();
    size_type nclasses = 0;
    while (to != patterns.end()) {
      ++nclasses;
      patterns_iter from = to;
      to = std::find_if(from + 1,patterns.end(),
			std::bind1st(std::less<pattern_type>(),*from));
      
      // compute the mean of the class
      Vector<T> class_mean(m,T(0));
      for (patterns_iter it = from; it != to; ++it)
	add_to(class_mean,*(it->data));
      mul_to(class_mean,T(1)/(to - from));

      // update Sb
      for (size_type i = 0; i < m; i++) {
	T tmp = class_mean[i] - mean[i];
	for (size_type j = i + 1; j < m; j++)
	  Sb[i][j] += (to - from)*(class_mean[j] - mean[j])*tmp;
	Sb[i][i] += (to - from)*tmp*tmp;
      }
            
      // update Sw
      for (patterns_iter it = from; it != to; ++it) {
	for (size_type i = 0; i < m; i++) {
	  T tmp = (*(it->data))[i] - class_mean[i];
	  for (size_type j = i + 1; j < m; j++)
	    Sw[i][j] += ((*(it->data))[j] - class_mean[j])*tmp;
	  Sw[i][i] += tmp*tmp;
	}	
      }
    }

    std::size_t k = std::min(components,nclasses - 1);

    // set the lower triangles of the symmetric matrices Sb and Sw
    for (size_type i = 0; i < m - 1; i++) {
      for (size_type j = i + 1; j < m; j++) {
	Sb[j][i] = Sb[i][j];
	Sw[j][i] = Sw[i][j];
      }
    }

    // solve the generalized eigenvector system Sb*v = Sw*v
    Matrix<T> inv;       // inverse of Sw
    Matrix<T> tmp1(m,1); // see ivllib::solve_gauss
    Matrix<T> tmp2;      // see ivllib::solve_gauss
    solve_gauss(Sw,tmp1,inv,tmp2);
	
    mul(inv,Sb,tmp2); // tmp2 = inv(Sw)*Sb

    // computes the eigenvectors and eigenvalues of tmp2 
	
    Matrix<T> evectors;
    Vector<T> evalues;
    solve_eigensystem_jacobi(tmp2,evectors,evalues);
    
    Matrix<T> result(k,m);
    for (size_type i = 0; i < k; i++)
      std::copy(evectors.column_begin(i),
		evectors.column_end(i),
		result.row_begin(i));
    
    basis.swap(result);
  }

  /*@}*/

} // ivllib

#endif
