/**
 * \file    linear_systems.h
 * \brief   linear systems algorithms
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_LINEAR_SYSTEMS_H
#define IVLLIB_LINEAR_SYSTEMS_H

//--- Headers ---------------------------------------------------------
#include "ivl_matrix.h"
#include "ivl_vector.h"
#include <cassert>
#include <algorithm>
#include <cmath>

namespace ivllib
{
  //--- Function declarations -----------------------------------------
  
  /** \addtogroup numerical */
  /*@{*/

  /**
   * Computes matrix inverse and linear system solution.
   * pA is a n*n square matrix and pRhs is a n*m matrix.
   * The results are stored in pInv (resized to n*n) and pSol
   * (resized to n*m).
   *
   * pA must be a square matrix, and pA and pHrs must have the same
   * number of rows.
   *
   * If pA is singular a std::runtime_error exception is thrown.
   *
   * \param pA coeffiecient matrix
   * \param pRhs right-and side vectors
   * \param pInv inverse of the matrix pA
   * \param pSol solution of the linear system
   *
   * \pre pA.rows() == pA.columns()
   * \pre pA.rows() == pRhs.rows()
   *
   * \post pInv.rows() == pA.rows()
   * \post pInv.columns() == pA.rows()
   * \post pSol.rows() == pA.rows()
   * \post pSol.columns() == pRhs.columns()
   */
  template <typename T>
  void solve_gauss(const Matrix<T>& pA,
		   const Matrix<T>& pRhs,
		   Matrix<T>& pInv,
		   Matrix<T>& pSol);    

  /**
   * Computes matrix inverse and linear system solution.
   * pA is a n*n square matrix and pRhs is a n dimensional vector.
   * The results are stored in pInv (resized to n*n) and pSol
   * (resized to n).
   *
   * If pA is singular a std::runtime_error exception is thrown.
   *
   * \param pA coeffiecient matrix
   * \param pRhs right-and side vector
   * \param pInv inverse of the matrix pA
   * \param pSol solution of the linear system
   *
   * \pre pA.rows() == pA.columns()
   * \pre pA.rows() == pRhs.size()
   *
   * \post pInv.rows() == pA.rows()
   * \post pInv.columns() == pA.rows()
   * \post pSol.rows() == pA.rows()
   */
  template <typename T>
  void solve_gauss(const Matrix<T>& pA,
		   const Vector<T>& pRhs,
		   Matrix<T>& pInv,
		   Vector<T>& pSol);    


  /*@}*/  

  //--- Implementations ----------------------------------------------
  template <typename T>
  void solve_gauss(const Matrix<T>& pA,
		   const Matrix<T>& pRhs,
		   Matrix<T>& pInv,
		   Matrix<T>& pSol)
  {
    typedef typename Matrix<T>::size_type size_type;

    const size_type n = pA.rows();
    const size_type m = pRhs.columns();

    assert(pA.columns() == n);
    assert(pRhs.rows() == n);
    assert(n > 0);

    Matrix<T> a = pA;
    Matrix<T> b = pRhs;

    // arrays used for bookkeeping on the pivoting.
    Vector<size_type> indxc(n,0);
    Vector<size_type> indxr(n,0);
    Vector<size_type> ipiv(n,0);

    // This is the main loop over the columns to be reduced.
    for (size_type i=0; i<n; i++) {
      T big = 0.0;
      size_type icol = 0;
      size_type irow = 0;

      // This is the outer loop of the search for a pivot  element.
      for (size_type j=0; j<n; j++) {
	if (ipiv[j] != 1) {
	  for (size_type k=0; k<n; k++) {
	    if (ipiv[k] == 0) {
	      T val = std::abs(a[j][k]);
	      if (val >= big) {
		big = val;
		irow = j;
		icol = k;
	      }
	    }
	  }
	}
      }
      ++(ipiv[icol]);

      /*  We now have the pivot element, so we interchange rows,
	  if needed, to put the pivot element on the diagonal.
	  The columns are not physically interchanged, only relabeled:
	  indxc[i], the column of the ith pivot element, is the ith
	  column that is reduced, while indxr[i] is the row in which
	  that pivot element was originally located.
	  If indxr[i]!=indxc[i] there is an implied column interchange.
	  With this form of bookkeeping, the solution b�s will end up
	  in the correct order, and the inverse matrix will be
	  scrambled by columns. */

      if (irow != icol) {
	for (size_type l = 0; l<n; l++)
	  std::swap(a[irow][l],a[icol][l]);

	for (size_type l = 0; l<m; l++)
	  std::swap(b[irow][l],b[icol][l]);
      }

      /* We are now ready to divide the pivot row by the pivot element,
	 located at irow and icol. */
      indxr[i] = irow;
      indxc[i] = icol;

      if (a[icol][icol] == 0)
	throw std::runtime_error("GaussJ: Singular matrix");

      T pivinv = T(1)/a[icol][icol];
      a[icol][icol] = 1.0;
      for (size_type l = 0; l<n; l++)
	a[icol][l] *= pivinv;

      for (size_type l = 0; l<m; l++)
	b[icol][l] *= pivinv;

      // Next, we reduce the rows...
      for (size_type ll = 0; ll<n; ll++) {

	//...except for the pivot one, of course.
	if (ll != icol) {
	  T dum = a[ll][icol];
	  a[ll][icol] = 0;
	  for (size_type l = 0; l<n; l++)
	    a[ll][l] -= a[icol][l]*dum;

	  for (size_type l=0; l<m; l++)
	    b[ll][l] -= b[icol][l]*dum;
	}
      }
    }

    /* This is the end of the main loop over columns of the reduction.
       It only remains to unscramble the solution in view of the column
       interchanges. We do this by interchanging pairs of columns in
       the reverse order that the permutation was built up. */

    for (int l = n-1; l>=0; l--)
      if (indxr[l] != indxc[l])
	for (size_type k=0; k < n; k++)
	  std::swap(a[k][indxr[l]], a[k][indxc[l]]);
      
    // and we are done.

    pInv.swap(a);
    pSol.swap(b);
  }

  template <typename T>
  void solve_gauss(const Matrix<T>& pA,
		   const Vector<T>& pRhs,
		   Matrix<T>& pInv,
		   Vector<T>& pSol)
  {
    // convert pRhs to a matrix
    Matrix<T> rhs(pRhs.begin(), pRhs.end(), 1);
    
    Matrix<T> sol;
    solve_gauss(pA, rhs, pInv, sol);
    
    // convert sol to a vector
    Vector<T> ret(sol.begin(), sol.end());
    
    ret.swap(pSol);
  }
  
} //ivllib

#endif //IVLLIB_LINEAR_SYSTEMS_H
