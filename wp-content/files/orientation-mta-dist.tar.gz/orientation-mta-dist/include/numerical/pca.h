/**
 * \file    pca.h
 * \brief   Principal Component Analysis
 * \author  Claudio Cusano
 */

#ifndef pca_h
#define pca_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <numerical/matrix_op.h>
#include <numerical/svd.h>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#include <functional>

#include <iostream>

namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/

  template <typename FwdIter,typename T>
  void compute_pca_basis(FwdIter patterns_from,
			 FwdIter patterns_to,
			 double retained_variance,
			 typename Matrix<T>::size_type min_components,
			 Matrix<T>& basis,
			 Vector<T>& mean,
			 Vector<T>& eigenvalues);

  template <typename FwdIter,typename T>
  void compute_pca_basis(FwdIter patterns_from,
			 FwdIter patterns_to,
			 double retained_variance,
			 typename Matrix<T>::size_type min_components,
			 Matrix<T>& basis,
			 Vector<T>& mean);


  /**
   * Principal Component Analysis.
   *
   * Computes the basis of the Principal Component Analysis transform.
   *
   * A pattern \c x (column vector) is projected in the PCA space with
   * \f$ B (x - m) \f$
   * where \c B is the basis of the transform and \c m is the mean pattern.
   *
   * The function is called specifying a range [ \c patterns_from, \c
   * patterns_to ) of patterns to be analysed. \c FwdIter must be a
   * forward iterator which iterates over \c Vector<U> where \c U must
   * be \c float or \c double.  The function will place the computed
   * basis and the mean pattern in the output paramters \c basis and
   * \c mean respectively.
   *
   * The parameters \c retained_variance and \c min_components
   * determine the number of components retained.
   *
   * \param patterns_from iterator to the first pattern
   * \param patterns_to iterator past the last pattern
   * \param retained_variance minimum fraction of total variance to be preserved
   * \param min_components minimum number of components to be retained
   * \param basis the base of the transformation
   * \param mean the offset of the transformation
   * \param eigenvalues eigenvalues associated to the principal components
   *
   * \pre patterns_from != patterns_to
   * \pre patterns_from->size() > 0
   * \pre retained_variance >= 0.0
   * \pre retained_variance <= 1.0
   */
  template <typename FwdIter,typename T>
  void compute_pca_basis(FwdIter patterns_from,
			 FwdIter patterns_to,
			 double retained_variance,
			 typename Matrix<T>::size_type min_components,
			 Matrix<T>& basis,
			 Vector<T>& mean,
			 Vector<T>& eigenvalues)
  {
    assert( patterns_from != patterns_to );
    assert( patterns_from->size() > 0 );
    assert( retained_variance >= 0.0 );
    assert( retained_variance <= 1.0 );

    typedef typename Matrix<T>::size_type size_type;
    typedef typename Matrix<T>::element_type el_type;

    size_type n = 0;
    size_type m = patterns_from->size();

    // computes the mean vector
    Vector<T> res_mean(m,T(0));
    for (FwdIter it = patterns_from; it != patterns_to; ++it) {
      ++n;
      assert( it->size() == m );
      add_to(res_mean,*it);
    }

    mul_to(res_mean,T(1)/n);

    // builds the matrix X whose rows are the patterns
    // translated by the mean vector
    Matrix<T> X(n,m);
    for (size_type i = 0; i < n; i++) {
      std::transform(patterns_from->begin(),
		     patterns_from->end(),
		     res_mean.begin(),
		     X.row_begin(i),
		     std::minus<T>());
      ++patterns_from;
    }

    // Use SVD to factor X in U * S * V^T.  The columns on V will
    // contain the principal components, and the elements of the
    // diagonal matrix S will be the square root of the corresponding
    // variance (to be scaled by the number of samples).

    Matrix<T> V;
    Vector<T> s;

    if (m < n) {
      svd(X, s, V);
    } else {
      transpose(X, V);
      svd(V, s, X);
    }

    // Note that the columns in V are already normalized.

    el_type var = 0;
    for (size_type i = 0; i < s.size(); i++) {
      s[i] *= s[i];
      s[i] /= n;
      var += s[i];
    }
    var *= retained_variance;

    // computes the number of components to retain
    size_type nretained = 0;

    while (nretained < m && nretained < n && var > 0)
      var -= s[nretained++];

    if (nretained < min_components)
      nretained = min_components;

    if (nretained > n)
      nretained = n;

    if (nretained > m)
      nretained = m;

    // R will contain the retained eigenvectors
    Matrix<T> R(nretained, m);
    // E will contain the associated eigenvalues
    Vector<T> E(nretained);
    for (size_type i = 0; i < nretained; i++) {
      std::copy(V.column_begin(i),
		V.column_end(i),
		R.row_begin(i));
      E[i] = s[i];
    }

    // commit
    basis.swap(R);
    mean.swap(res_mean);
    eigenvalues.swap(E);
  }

  /**
   * Principal Component Analysis.
   *
   * Computes the basis of the Principal Component Analysis transform.
   *
   * A pattern \c x (column vector) is projected in the PCA space with
   * \f$ B (x - m) \f$
   * where \c B is the basis of the transform and \c m is the mean pattern.
   *
   * The function is called specifying a range [ \c patterns_from, \c
   * patterns_to ) of patterns to be analysed. \c FwdIter must be a
   * forward iterator which iterates over \c Vector<U> where \c U must
   * be \c float or \c double.  The function will place the computed
   * basis and the mean pattern in the output paramters \c basis and
   * \c mean respectively.
   *
   * The parameters \c retained_variance and \c min_components
   * determine the number of components retained.
   *
   * \param patterns_from iterator to the first pattern
   * \param patterns_to iterator past the last pattern
   * \param retained_variance minimum fraction of total variance to be preserved
   * \param min_components minimum number of components to be retained
   * \param basis the base of the transformation
   * \param mean the offset of the transformation
   *
   * \pre patterns_from != patterns_to
   * \pre patterns_from->size() > 0
   * \pre it->size() == patterns_from->size() for each \c it in [ \c patterns_from, \c patterns_to )
   * \pre retained_variance >= 0.0
   * \pre retained_variance <= 1.0
   * \pre min_components <= patterns_from->size()
   * \pre min_components <= distance(patterns_from,patterns_to)
   */
  template <typename FwdIter,typename T>
  void compute_pca_basis(FwdIter patterns_from,
			 FwdIter patterns_to,
			 double retained_variance,
			 typename Matrix<T>::size_type min_components,
			 Matrix<T>& basis,
			 Vector<T>& mean)
  {
    Vector<T> unused;

    compute_pca_basis(patterns_from,
		      patterns_to,
		      retained_variance,
		      min_components,
		      basis,
		      mean,
		      unused);
  }

  /*@}*/

} // ivllib

#endif
