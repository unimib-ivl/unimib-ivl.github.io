#ifndef IVLLIB_MATRIX3X3_H
#define IVLLIB_MATRIX3X3_H

//--- Headers -------------------------------------------------------------------------
#include <cstring>

//--- Types --------------------------------------------------------------------------
namespace ivllib {  

  /** \addtogroup numerical */
  /*@{*/

  /**
   * A matrix of fixed size dimensions (3x3).  Its primary use is for 2D
   * homogeneus coordinates transformations.
   *
   *     [ R t ]
   * T = [     ]
   *     [ 0 1 ]
   */
  template <typename T>
    class Matrix3x3 
    {
      
    public:
      typedef T element_type; ///< type of the matrix elements
      typedef size_t size_type; ///< type of indexes
      typedef element_type* iterator; ///< iterator type
      typedef const element_type* const_iterator; ///< const iterator type
      

      /**
       * \brief default constructor.
       *
       * the default constructor makes no initializations on the
       * matrix for efficency reasons.
       */
      Matrix3x3() {}


      /**
       * constructs a matrix specifying all the elements.
       */
      Matrix3x3 ( element_type m00, element_type m01, element_type m02, 
		  element_type m10, element_type m11, element_type m12, 
		  element_type m20, element_type m21, element_type m22)
	{
	  set (   m00,   m01,   m02, 
		  m10,   m11,   m12, 
		  m20,   m21,   m22);
	}
      
      /**
       * \brief default destructor
       */
      ~Matrix3x3() {}
	
      /**
       * @return an iterator pointing to the element at (0,0)
       */    
      iterator begin()
	{ return mData; }
	
      /**
       * @return an iterator pointing to the element at (0,0)
       */    
      const_iterator begin() const
	{ return mData; }
	
      /**
       * @return an iterator pointing to the past-the-end element
       */    
      iterator end()
	{ return mData + 9; }
	
      /**
       * @return an iterator pointing to the past-the-end element
       */    
      const_iterator end() const
	{ return mData + 9; }

      /**
       * sets the entryes of the matrix with the parameters passed as
       * arguments. mij indicates the entry at row i and column j.
       */
      inline void set (element_type m00, element_type m01, element_type m02, 
		       element_type m10, element_type m11, element_type m12, 
		       element_type m20, element_type m21, element_type m22)
	{
	  (*this)[0][0]=m00;
	  (*this)[0][1]=m01;
	  (*this)[0][2]=m02;
	  (*this)[1][0]=m10;
	  (*this)[1][1]=m11;
	  (*this)[1][2]=m12;
	  (*this)[2][0]=m20;
	  (*this)[2][1]=m21;
	  (*this)[2][2]=m22;
	}

      /**
       * @return an iterator pointing to the first elementh of the specified row
       */      
      inline iterator operator[] (size_type row)
	{ return (mData + (row * 3)); }

      /**
       * @return an iterator pointing to the first elementh of the specified row
       */
      inline const_iterator  operator[] (size_type row) const
	{ return (mData + (row * 3)); }

    private:
      element_type mData[9];

    }; //end of Matrix3x3 class definition

  typedef Matrix3x3<float> Matrix3x3f; ///< a 3x3 matrix of floats
  typedef Matrix3x3<double> Matrix3x3d; ///< a 3x3 matrix of doubles

  /*@}*/

} //namespace ivllib

#endif //IVLLIB_MATRIX3X3_H
