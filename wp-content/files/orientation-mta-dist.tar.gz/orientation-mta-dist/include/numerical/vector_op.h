/**
 * \file    vector_op.h
 * \brief   vector operations
 * \author  $LastChangedBy:$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef VECTOR_OP_H
#define VECTOR_OP_H

//--- Headers ---------------------------------------------------------
#include <ivl_vector.h>
#include <cassert>

namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  //--- Declarations ------------------------------------------------

  /** <tt> res[i] = v1[i] + v2[i] </tt> */
  template<typename A, typename B, typename C>
  inline void add(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res);

  /** <tt> res[i] = v1[i] - v2[i] </tt> */
  template<typename A, typename B, typename C>
  inline void sub(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res);

  /** <tt> res[i] = v1[i] + scalar </tt> */
  template<typename A, typename B, typename C>
  inline void add(const Vector<A>& v1, const B& scalar, Vector<C>& res);
  
  /** <tt> res[i] = v1[i] - scalar </tt> */
  template<typename A, typename B, typename C>
  inline void sub(const Vector<A>& v1, const B& scalar, Vector<C>& res);

  /** <tt> res[i] = v1[i] * scalar </tt> */
  template<typename A, typename B, typename C>
  inline void mul(const Vector<A>& v1, const B& scalar, Vector<C>& res);

  /** <tt> res[i] = v1[i] / scalar </tt> */
  template<typename A, typename B, typename C>
  inline void div(const Vector<A>& v1, const B& scalar, Vector<C>& res);

  /** <tt> res[i] = v1[i] * v2[i] </tt> */
  template<typename A, typename B, typename C>
  inline void elements_mul(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res);

  /** <tt> res[i] = v1[i] / v2[i] </tt> */
  template<typename A, typename B, typename C>
  inline void elements_div(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res);

  /** \return true if the vectors have the same elements */
  template<typename A, typename B>
  inline bool compare(const Vector<A>& v1, const Vector<B>& v2);

  /** <tt> v1[i] += v2[i] </tt> */
  template<typename A, typename B>
  inline void add_to(Vector<A>& v1, const Vector<B>& v2);

  /** <tt> v1[i] -= v2[i] </tt> */
  template<typename A, typename B>
  inline void sub_to(Vector<A>& v1, const Vector<B>& v2);

  /** <tt> v1[i] += scalar </tt> */
  template<typename A, typename B>
  inline void add_to(Vector<A>& v1, const B& scalar);

  /** <tt> v1[i] -= scalar </tt> */
  template<typename A, typename B>
  inline void sub_to(Vector<A>& v1, const B& scalar);
  
  /** <tt> v1[i] *= scalar </tt> */
  template<typename A, typename B>
  inline void mul_to(Vector<A>& v1, const B& scalar);

  /** <tt> v1[i] /= scalar </tt> */
  template<typename A, typename B>
  inline void div_to(Vector<A>& v1, const B& scalar);

  /** <tt> v1[i] *= v2[i] </tt> */
  template<typename A, typename B>
  inline void elements_mul_to(Vector<A>& v1, const Vector<B>& v2);

  /** <tt> v1[i] /= v2[i] </tt> */
  template<typename A, typename B>
  inline void elements_div_to(Vector<A>& v1, const Vector<B>& v2);

  /** \return \p scalar_base + the inner product of the input vectors */
  template<typename A, typename B, typename C>
  inline C inner_product(const Vector<A>& v1, const Vector<B>& v2, C scalar_base);
  
  /*@}*/  

  //--- Implementations -----------------------------------------------
  template<typename A, typename B, typename C>
  inline void add(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = *ia + *ib;
      ++ia;
      ++ib;
      ++ic;
    }

    res.swap(tmp);
  }
  
  template<typename A, typename B, typename C>
  inline void sub(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = *ia - *ib;
      ++ia;
      ++ib;
      ++ic;
    }

    res.swap(tmp);
  }

  template<typename A, typename B, typename C>
  inline void add(const Vector<A>& v1, const B& scalar, Vector<C>& res)
  {
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = *ia + scalar;
      ++ia;
      ++ic;
    }

    res.swap(tmp);
  }
  
  template<typename A, typename B, typename C>
  inline void sub(const Vector<A>& v1, const B& scalar, Vector<C>& res)
  {
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = *ia - scalar;
      ++ia;
      ++ic;
    }

    res.swap(tmp);
  }

  template<typename A, typename B, typename C>
  inline void mul(const Vector<A>& v1, const B& scalar, Vector<C>& res)
  {
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = (*ia) * scalar;
      ++ia;
      ++ic;
    }

    res.swap(tmp);
  }
  
  template<typename A, typename B, typename C>
  inline void div(const Vector<A>& v1, const B& scalar, Vector<C>& res)
  {
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_c ic = tmp.begin();
    
    while (ia != stop) {
      *ic = *ia / scalar;
      ++ia;
      ++ic;
    }

    res.swap(tmp);
  }

  template<typename A, typename B, typename C>
  inline void elements_mul(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = (*ia) * (*ib);
      ++ia;
      ++ib;
      ++ic;
    }

    res.swap(tmp);
  }

  template<typename A, typename B, typename C>
  inline void elements_div(const Vector<A>& v1, const Vector<B>& v2, Vector<C>& res)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    typedef typename Vector<C>::iterator iter_c;
    
    Vector<C> tmp(v1.size());

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    iter_c ic = tmp.begin();

    while (ia != stop) {
      *ic = (*ia) / (*ib);
      ++ia;
      ++ib;
      ++ic;
    }

    res.swap(tmp);
  }

  template<typename A, typename B>
  inline bool compare(const Vector<A>& v1, const Vector<B>& v2)
  {
    if (v1.size() != v2.size())
      return false;
    
    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      if (*ia != *ib)
	return false;
      ++ia;
      ++ib;
    }
    
    return true;
  }

  template<typename A, typename B>
  inline void add_to(Vector<A>& v1, const Vector<B>& v2)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      *ia += *ib;
      ++ia;
      ++ib;
    }
  }

  template<typename A, typename B>
  inline void sub_to(Vector<A>& v1, const Vector<B>& v2)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      *ia -= *ib;
      ++ia;
      ++ib;
    }
  }

  template<typename A, typename B>
  inline void add_to(Vector<A>& v1, const B& scalar)
  {
    typedef typename Vector<A>::iterator iter_a;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    
    while (ia != stop) {
      *ia += scalar;
      ++ia;
    }
  }
  
  template<typename A, typename B>
  inline void sub_to(Vector<A>& v1, const B& scalar)
  {
    typedef typename Vector<A>::iterator iter_a;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    
    while (ia != stop) {
      *ia -= scalar;
      ++ia;
    }
  }

  template<typename A, typename B>
  inline void mul_to(Vector<A>& v1, const B& scalar)
  {
    typedef typename Vector<A>::iterator iter_a;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    
    while (ia != stop) {
      *ia *= scalar;
      ++ia;
    }
  }
  
  template<typename A, typename B>
  inline void div_to(Vector<A>& v1, const B& scalar)
  {
    typedef typename Vector<A>::iterator iter_a;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    
    while (ia != stop) {
      *ia /= scalar;
      ++ia;
    }
  }

  template<typename A, typename B>
  inline void elements_mul_to(Vector<A>& v1, const Vector<B>& v2)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      (*ia) *= *ib;
      ++ia;
      ++ib;
    }
  }

  template<typename A, typename B>
  inline void elements_div_to(Vector<A>& v1, const Vector<B>& v2)
  {
    assert( v1.size() == v2.size() );
    
    typedef typename Vector<A>::iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;
    
    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      *ia /= *ib;
      ++ia;
      ++ib;
    }
  }

  template<typename A, typename B, typename C>
  inline C inner_product(const Vector<A>& v1, const Vector<B>& v2, C scalar_base)
  {
    assert( v1.size() == v2.size() );

    typedef typename Vector<A>::const_iterator iter_a;
    typedef typename Vector<B>::const_iterator iter_b;

    iter_a ia = v1.begin();
    iter_a stop = v1.end();
    iter_b ib = v2.begin();
    
    while (ia != stop) {
      scalar_base += (*ia) * (*ib);
      ++ia;
      ++ib;
    }
    
    return scalar_base;
  }
  
} //ivllib

#endif //VECTOR_OP_H
