/* vector2.h
 * \brief vector2 template class definition file
 * \author $LastChangedBy$
 * \date $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_VECTOR2_H
#define IVLLIB_VECTOR2_H

//--- Types ----------------------------------------------------------------------
namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/


  /**
   * A class representing two-dimensional vectors
   */
  template <typename T>
  class Vector2
  {
  public:
    /// type of the elements
    typedef T element_type;

    element_type x; ///< a component of the vector
    element_type y; ///< a component of the vector

    /**
     * default constructor. no inizializations are done.
     */
    Vector2()
    {
    }

    /**
     * copy-constructor
     */
    template<typename U>
    Vector2(const Vector2<U>& v)  
      : x(v.x),
	y(v.y)
    {
    }

    /**
     * constructor for initializing components
     */
    Vector2(element_type ax, element_type ay)
      : x(ax),
	y(ay)
    {
    }

    /**
     * A method for setting components
     */
    inline void set(element_type ax, element_type ay)
    {
      x = ax;
      y = ay;
    }

    /// comparison
    inline bool operator==(const Vector2& v) const
    {
      return (x == v.x) && (y == v.y);
    }

    /// comparison
    inline bool operator!=(const Vector2& v) const
    {
      return (x != v.x) || (y != v.y);
    }

    /// assignement
    template<typename U>
    Vector2& operator=(const Vector2<U>& a)
    {
      x = a.x;
      y = a.y;

      return *this;
    }
  };

  /// vector with two floating points elements (single precision)
  typedef Vector2<float> Vector2f;

  /// vector with two floating points elements (double precision)
  typedef Vector2<double> Vector2d;

  /*@}*/

} //namespace ivllib

#endif //IVLLIB_VECTOR2_H

