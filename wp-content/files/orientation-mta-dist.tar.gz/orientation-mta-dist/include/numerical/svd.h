/**
 * \file    svd.h
 * \brief   Routines for the Singular Value Decomposition.
 * \author  Claudio Cusano
 */

#ifndef ivllib_svd_h
#define ivllib_svd_h


#include <ivl_matrix.h>
#include <numerical/matrix_op.h>
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <limits>
#include <stdexcept>


namespace ivllib
{

  /** \addtogroup numerical */
  /*@{*/

  /** \cond detail */
  namespace detail_svd
  {
    // Declaration of helper functions.

    template <typename T>
    void svd_decompose(Matrix<T>& u, Vector<T>& w, Matrix<T>& v);

    template <typename T>
    void svd_sort(Matrix<T>& u, Vector<T>& w, Matrix<T>& v);
  }
  /** \endcond */

  /**
   * SVD decomposition.
   *
   * Factorization of the matrix \a A into
   *
   * \f[
   *   A = U \times S \times V^T.
   * \f]
   *
   * The orthogonal matrices U and V are the first and the third
   * elements of the returned tuple.  The second element is a vector
   * containing the singular values in decreasing order (it
   * corresponds to the diagonal of S).
   *
   * Note that the "thin" version of the SVD is computed, with U
   * having the same shape of \a A.  This is the most commonly-used
   * form in practice (in the "full" SVD U would be M-by-M).
   *
   * V is a square orthogonal matrix with a size equal to the number
   * of columns in \a A.  Note that to reconstruct \a A the matrix V
   * must be transposed.
   *
   * This function uses the Golub-Reinsch algorithm.
   */
  template <typename T>
  void svd(Matrix<T>& A, Vector<T>& w, Matrix<T>& V)
  {
    Vector<T> w2(A.columns());
    Matrix<T> v2(A.columns(), A.columns());
    detail_svd::svd_decompose(A, w2, v2);
    detail_svd::svd_sort(A, w2, v2);
    w.swap(w2);
    V.swap(v2);
  }


  /**
   * Compute the pseudo-inverse of \a A.
   *
   * Given the n-by-m matrix \a A, SVD is used to produce its m-by-n
   * pseudo-inverse.
   *
   * The \a threshold value is used to determine the singular values
   * that will be considered zero.  When the threshold is negative, a
   * heuristic value is determined.
   *
   * \param A input matrix
   * \param pinv resulting pseudoinverse
   * \param threshold limit to small singular values 
   */
  template <typename T>
  void pseudo_inverse_svd(Matrix<T> A, Matrix<T>& pinv, double threshold=-1)
  {
    typedef typename Matrix<T>::size_type size_type;

    size_type m = A.rows();
    size_type n = A.columns();

    Vector<T> w(n);
    Matrix<T> V(n, n);
    detail_svd::svd_decompose(A, w, V);

    // 1) Determine the threshold.
    T thr = (threshold < 0
	     ? (0.5 * std::sqrt(m + n + 1) * w[0] *
		std::numeric_limits<T>::epsilon())
	     : threshold);

    // 2) Compute the pseudo inverse of the singular values, setting
    // to zero the small ones.
    for (size_type i = 0; i < n; i++)
      w[i] = (w[i] > thr ? 1.0 / w[i] : 0);

    // 3) compute A * diag(w)
    for (size_type i = 0; i < m; i++)
      for (size_type j = 0; j < n; j++)
	A[i][j] *= w[j];

    // 4) Compute the final matrix.
    mul(V, A, pinv);
  }


  /**
   * Solve a linear least squares problem.
   *
   * This function uses SVD to solve the problem
   * \f[
   *    \max_X  \| A X - B \|^2.
   * \f]
   *
   * The \a threshold value is used to determine the singular values
   * that will be considered zero.  When the threshold is negative, a
   * heuristic value is determined.
   *
   * \param A matrix of coefficients
   * \param B right hand side matrix
   * \param result output coefficients
   * \param threshold limit to small singular values 
   *
   * \pre A.rows() == B.rows()
   */
  template <typename T, typename U>
  void least_squares_svd(Matrix<T> A,
			 const Matrix<U>& B,
			 Matrix<U>& result,
			 double threshold=-1)
  {
    assert(A.rows() == B.rows());

    typedef typename Matrix<T>::size_type size_type;
    
    size_type m = A.rows();
    size_type n = A.columns();
    size_type p = B.columns();

    Vector<T> w(n);
    Matrix<T> V(n, n);
    detail_svd::svd_decompose(A, w, V);
    Matrix<U> X(n, p, U());  // The result.
    Vector<T> temp(n, T());

    // 1) Determine the threshold.
    T thr = (threshold < 0
	     ? (0.5 * std::sqrt(m + n + 1) * w[0] *
		std::numeric_limits<T>::epsilon())
	     : threshold);

    // 2) Compute the pseudo inverse of the singular values, setting
    // to zero the small ones.
    for (size_type i = 0; i < n; i++)
      w[i] = (w[i] > thr ? 1.0 / w[i] : 0);

    
    // 3) Process each column of B independently... !!!
    for (size_type c = 0; c < p; c++) {
      // Compute diag(w) * U^T * B[:, c]
      for (size_type i = 0; i < n; i++) {
	if (w[i] > 0) {
	  for (size_type j = 0; j < m; j++)
	    temp[i] += A[j][i] * B[j][c];
	  temp[i] *= w[i];
	}
      }
      
      // Compute the c-th column of the result.
      for (size_type i = 0; i < n; i++)
	for (size_type j = 0; j < n; j++)
	  X[i][c] += V[i][j] * temp[j];
    }
    
    result.swap(X);
  }


  /**
   * Solve a linear least squares problem.
   *
   * This function uses SVD to solve the problem
   * \f[
   *    \max_x  \| A x - b \|^2.
   * \f]
   *
   * The \a threshold value is used to determine the singular values
   * that will be considered zero.  When the threshold is negative, a
   * heuristic value is determined.
   *
   * \param A matrix of coefficients
   * \param b right hand side vector
   * \param threshold limit to small singular values 
   *
   * \pre A.rows() == b.size()
   */
  template <typename T, typename U>
  void least_squares_svd(Matrix<T> A,
			 const Vector<U>& b,
			 Vector<U>& result,
			 double threshold=-1)
  {
    assert(A.rows() == b.size());
    
    typedef typename Matrix<T>::size_type size_type;
    
    size_type m = A.rows();
    size_type n = A.columns();

    Vector<T> w(n);
    Matrix<T> V(n, n);
    detail_svd::svd_decompose(A, w, V);
    Vector<U> X(n, U());  // The result.
    Vector<T> temp(n, T());

    // 1) Determine the threshold.
    T thr = (threshold < 0
	     ? (0.5 * std::sqrt(m + n + 1) * w[0] *
		std::numeric_limits<T>::epsilon())
	     : threshold);

    // 2) Compute the pseudo inverse of the singular values, setting
    // to zero the small ones.
    for (size_type i = 0; i < n; i++)
      w[i] = (w[i] > thr ? 1.0 / w[i] : 0);

    
    // 3) Compute diag(w) * U^T * b.
    for (size_type i = 0; i < n; i++) {
      if (w[i] > 0) {
	for (size_type j = 0; j < m; j++)
	  temp[i] += A[j][i] * b[j];
	temp[i] *= w[i];
      }
    }
      
    // 4) Compute the result.
    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < n; j++)
	X[i] += V[i][j] * temp[j];
    
    X.swap(result);
  }


  /** \cond detail */
  namespace detail_svd
  {

    template <typename T>
    T copysign(T x, T y)
    {
      return (y < 0 ? -std::abs(x) : std::abs(x));
    }

    template <typename T>
    T sqr(T x)
    {
      return x * x;
    }

    template <typename T>
    T hypot(T a, T b)
    {
      T absa = std::abs(a);
      T absb = std::abs(b);
      return (absa > absb
	      ? absa*std::sqrt(1.0 + sqr(absb / absa))
	      : (absb == 0.0
		 ? 0.0
		 : absb * std::sqrt(1.0 + sqr(absa / absb))));
    }


    // Given the matrix A stored in u[0..m-1][0..n-1], this routine
    // computes its singular value decomposition, A = U * W * V^T
    // and stores the results in the matrices u and v, and the
    // vector w.
    template <typename T>
    void svd_decompose(Matrix<T>& u,
		       Vector<T>& w,
		       Matrix<T>& v)
    {

      assert(w.size() == u.columns());
      assert(v.rows() == u.columns());
      assert(v.columns() == u.columns());

      typedef typename Matrix<T>::size_type size_type;

      const T eps = std::numeric_limits<T>::epsilon();
      const int max_iterations = 30;

      size_type m = u.rows();
      size_type n = u.columns();
      Vector<T> rv1(n);

      // Householder reduction to bidiagonal form.
      T anorm = 0;
      size_type l;
      double g = 0;
      double scale = 0;
      for (size_type i = 0; i < n; i++) {
	l = i + 2;
	rv1[i] = scale * g;
	g = 0;
	double s = 0;
	scale = 0;
	if (i < m) {
	  for (size_type k = i; k < m; k++)
	    scale += std::abs(u[k][i]);
	  if (scale != 0) {
	    for (size_type k = i; k < m; k++) {
	      u[k][i] /= scale;
	      s += u[k][i] * u[k][i];
	    }
	    double f = u[i][i];
	    g = -copysign(std::sqrt(s), f);
	    double h = f * g - s;
	    u[i][i] = f - g;
	    for (size_type j = l - 1; j < n; j++) {
	      s = 0;
	      for (size_type k = i; k < m; k++)
		s += u[k][i] * u[k][j];
	      f = s / h;
	      for (size_type k = i; k < m; k++)
		u[k][j] += f * u[k][i];
	    }
	    for (size_type k = i; k < m; k++)
	      u[k][i] *= scale;
	  }
	}
	w[i] = scale * g;
	g = 0;
	s = 0;
	scale = 0;
	if (i + 1 <= m && i+1 != n) {
	  for (size_type k = l - 1; k < n; k++)
	    scale += std::abs(u[i][k]);
	  if (scale != 0) {
	    for (size_type k = l - 1; k<n; k++) {
	      u[i][k] /= scale;
	      s += u[i][k] * u[i][k];
	    }
	    double f = u[i][l - 1];
	    g = -copysign(std::sqrt(s),f);
	    double h = f * g - s;
	    u[i][l - 1] = f - g;
	    for (size_type k = l - 1;k < n; k++)
	      rv1[k] = u[i][k] / h;
	    for (size_type j = l - 1; j < m; j++) {
	      s = 0;
	      for (size_type k = l - 1; k < n; k++)
		s += u[j][k] * u[i][k];
	      for (size_type k = l - 1; k < n; k++)
		u[j][k] += s * rv1[k];
	    }
	    for (size_type k = l - 1; k < n; k++)
	      u[i][k] *= scale;
	  }
	}
	anorm = std::max(anorm, (std::abs(w[i]) + std::abs(rv1[i])));
      }

      // Accumulation of right-hand transformations.
      size_type ii = n;
      while (ii > 0) {
	--ii;
	if (ii < n - 1) {
	  if (g != 0) {
	    for (size_type j = l; j < n; j++)
	      // Double division to avoid possible underflow.
	      v[j][ii] = (u[ii][j] / u[ii][l]) / g;
	    for (size_type j = l; j < n; j++) {
	      double s = 0;
	      for (size_type k = l; k < n; k++)
		s += u[ii][k] * v[k][j];
	      for (size_type k = l; k < n; k++)
		v[k][j] += s * v[k][ii];
	    }
	  }
	  for (size_type j = l; j < n; j++)
	    v[ii][j] = v[j][ii] = 0;
	}
	v[ii][ii] = 1;
	g = rv1[ii];
	l = ii;
      }

      // Accumulation of left-hand transformations.
      size_type i = std::min(m, n);
      while (i > 0) {
	--i;
	l = i + 1;
	g = w[i];
	for (size_type j = l; j < n; j++)
	  u[i][j] = 0;
	if (g != 0) {
	  g = 1.0 / g;
	  for (size_type j = l; j < n; j++) {
	    double s = 0;
	    for (size_type k = l; k < m; k++)
	      s += u[k][i] * u[k][j];
	    double f = (s / u[i][i]) * g;
	    for (size_type k = i; k < m; k++)
	      u[k][j] += f * u[k][i];
	  }
	  for (size_type j = i; j < m; j++)
	    u[j][i] *= g;
	} else {
	  for (size_type j = i; j < m; j++)
	    u[j][i] = 0;
	}
	++u[i][i];
      }

      // Diagonalization of the bidiagonal form: loop over singular
      // values, and over allowed iterations.
      size_type k = n;
      while (k > 0) {
	--k;
	for (int iterations = 0; iterations < max_iterations; iterations++) {
	  // Test for splitting.
	  bool flag = true;
	  size_type l = k + 1;
	  size_type nm;
	  while (l > 0) {
	    --l;
	    nm = l - 1;
	    if (l == 0 || std::abs(rv1[l]) <= eps * anorm) {
	      flag = false;
	      break;
	    }
	    if (std::abs(w[nm]) <= eps * anorm)
	      break;
	  }
	  if (flag) {
	    // Cancellation of rv1[l], if l > 0.
	    double c = 0;
	    double s = 1;
	    for (size_type i = l; i < k + 1; i++) {
	      double f = s * rv1[i];
	      rv1[i] = c * rv1[i];
	      if (std::abs(f) <= eps * anorm)
		break;
	      g = w[i];
	      double h = hypot(f,g);
	      w[i] = h;
	      h = 1.0 / h;
	      c = g * h;
	      s = -f * h;
	      for (size_type j = 0; j < m; j++) {
		double y = u[j][nm];
		double z = u[j][i];
		u[j][nm] = y * c + z * s;
		u[j][i] = z * c - y * s;
	      }
	    }
	  }
	  double z = w[k];
	  if (l == k) {
	    // Convergence.
	    if (z < 0) {
	      // Singular value is made nonnegative.
	      w[k] = -z;
	      for (size_type j = 0; j < n; j++)
		v[j][k] = -v[j][k];
	    }
	    break;
	  }
	  if (iterations == max_iterations - 1) {
	    const char* msg = "SVD: too many iterations without convergence";
	    throw std::runtime_error(msg);
	  }

	  // Shift from bottom 2-by-2 minor.
	  double x = w[l];
	  nm = k - 1;
	  double y = w[nm];
	  g = rv1[nm];
	  double h = rv1[k];
	  double f = ((y - z) * (y + z) + (g - h) * (g + h))/(2.0 * h * y);
	  g = hypot(f, 1.0);
	  f = ((x - z) * (x + z) +
	       h * ((y / (f + copysign(g, f))) - h)) / x;

	  // Next QR transformation:
	  double c = 1;
	  double s = 1;
	  for (size_type j = l; j <= nm; j++) {
	    i = j + 1;
	    g = rv1[i];
	    y = w[i];
	    h = s * g;
	    g = c * g;
	    z = hypot(f, h);
	    rv1[j] = z;
	    c = f / z;
	    s = h / z;
	    f = x * c + g * s;
	    g = g * c - x * s;
	    h = y * s;
	    y *= c;
	    for (size_type jj = 0; jj < n; jj++) {
	      x = v[jj][j];
	      z = v[jj][i];
	      v[jj][j] = x * c + z * s;
	      v[jj][i] = z * c - x * s;
	    }
	    z = hypot(f, h);
	    w[j] = z;
	    // Rotation can be arbitrary if z == 0.
	    if (z) {
	      z = 1.0 / z;
	      c = f * z;
	      s = h * z;
	    }
	    f = c * g + s * y;
	    x = c * y - s * g;
	    for (size_type jj = 0; jj < m; jj++) {
	      y = u[jj][j];
	      z = u[jj][i];
	      u[jj][j] = y * c + z * s;
	      u[jj][i] = z * c - y * s;
	    }
	  }
	  rv1[l] = 0;
	  rv1[k] = f;
	  w[k] = x;
	}
      }
    }


    // Given the output of decompose, this routine sorts the
    // singular values, and corresponding columns of u and v, by
    // decreasing magnitude. Also, signs of corresponding columns
    // are flipped so as to maximize the number of positive
    // elements.
    template <typename T>
    void svd_sort(Matrix<T>& u, Vector<T>& w, Matrix<T>& v)
    {
      assert(w.size() == u.columns());
      assert(v.rows() == u.columns());
      assert(v.columns() == u.columns());

      typedef typename Matrix<T>::size_type size_type;
      
      size_type m = u.rows();
      size_type n = u.columns();

      // Since this step is much less intensive than decomposition, we
      // can use Shell's sort even though it may be non optimal.

      size_type inc = 1;
      do {
	inc *= 3;
	inc++;
      } while (inc <= n);

      double sw;
      Vector<T> su(m);
      Vector<T> sv(n);

      do {
	inc /= 3;
	for (size_type i = inc; i < n; i++) {
	  sw = w[i];
	  for (size_type k = 0; k < m; k++)
	    su[k] = u[k][i];
	  for (size_type k = 0; k < n; k++)
	    sv[k] = v[k][i];
	  size_type j = i;
	  while (w[j - inc] < sw) {
	    w[j] = w[j - inc];
	    for (size_type k = 0; k < m; k++)
	      u[k][j] = u[k][j - inc];
	    for (size_type k = 0; k < n; k++)
	      v[k][j] = v[k][j - inc];
	    j -= inc;
	    if (j < inc)
	      break;
	  }
	  w[j] = sw;
	  for (size_type k = 0; k < m; k++)
	    u[k][j] = su[k];
	  for (size_type k = 0; k < n; k++)
	    v[k][j] = sv[k];
	}
      } while (inc > 1);

      // Flip signs.
      for (size_type k = 0; k < n; k++) {
	size_type s = 0;
	for (size_type i = 0; i < m; i++)
	  if (u[i][k] < 0)
	    s++;
	for (size_type j = 0; j < n; j++)
	  if (v[j][k] < 0)
	    s++;
	if (2 * s > m + n) {
	  for (size_type i = 0; i < m; i++)
	    u[i][k] = -u[i][k];
	  for (size_type j = 0; j < n; j++)
	    v[j][k] = -v[j][k];
	}
      }
    }

  }  // namespace detail_svd
  /** \endcond */


  /*@}*/

}  // namespace ivllib


#endif  // ivllib_svd_h
