/**
 * \file vector3.h
 * \brief vector3 template class definition file
 * \author $LastChangedBy$
 * \date $Date$
 * \version $Revision$
 */

#ifndef IVLLIB_VECTOR3_H
#define IVLLIB_VECTOR3_H

//--- Types ----------------------------------------------------------------------
namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/


  /**
   * A template class representing a three-dimensional vector.
   */
  template <typename T>
  class Vector3 
  {
  public:
    /// type of the elements
    typedef T element_type;

    element_type x; ///< a component of the vector
    element_type y; ///< a component of the vector
    element_type z; ///< a component of the vector

    /**
     * default constructor. no initialization is done for performance reasons.
     */
    Vector3() {}

    /**
     * copy construnctor.
     */
    template <typename U>
    Vector3(const Vector3<U>& v)  : x(v.x), y(v.y), z(v.z) { }
	
    /**
     * constructor for initialization of components.
     */
    Vector3(element_type _x, 
	    element_type _y, 
	    element_type _z) : x(_x), y(_y), z(_z) {}
	
    /**
     * A setter method.
     */
    void set(element_type _x, 
	     element_type _y, 
	     element_type _z) 
    { x=_x; y=_y; z=_z; }

    /// comparison
    inline bool operator==(const Vector3& v) const
    { return x==v.x && y==v.y && z==v.z; }
      
    /// comparison
    inline bool operator!=(const Vector3& v) const
    { return x!=v.x || y!=v.y || z!=v.z; }
      

    /// assignement
    template<typename U>
    Vector3& operator=(const Vector3<U>& a)
    {
      x = a.x;
      y = a.y;	  
      z = a.z;

      return *this;
    }
  };

  typedef Vector3<float> Vector3f;  ///< vector with three floating points elements (single precision)
  typedef Vector3<double> Vector3d; ///< vector with three floating points elements (double precision)
  
  /*@}*/

} //namespace ivllib
#endif //IVLLIB_VECTOR3_H
