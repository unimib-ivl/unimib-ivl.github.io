/**
 * @file quaternion.h
 * @brief quaternion template class definition file
 * @author $LastChangedBy$
 * @date $LastChangedDate$
 * @version $LastChangedRevision$
 */

#ifndef ivllib_quaternion_h
#define ivllib_quaternion_h

namespace ivllib
{
  /**
   * Generic class reprsenting a Quaternion. The template type T is used for
   * specifying the type of the quaternion components.
   */
  template <typename T>
  class Quaternion
  {  
  public:

    /// published type of the quaternion components
    typedef T element_type;
  
    /*
     * Quaternion components. Q = w + ix + jy + kz
     */
    element_type w; ///< w component
    element_type x; ///< x component
    element_type y; ///< y component
    element_type z; ///< z component

    /// empty constructor
    Quaternion() {}

    /// constructs a new quaternion with the specified components
    Quaternion(element_type pW, 
	       element_type pX, 
	       element_type pY, 
	       element_type pZ) : w(pW), x(pX), y(pY), z(pZ) {}

    /// Set the components of the quaternion.
    void set(element_type pW, 
	     element_type pX, 
	     element_type pY, 
	     element_type pZ)
    { w=pW; x=pX; y=pY; z=pZ;}    
  };
} //namespace ivllib
#endif //ivllib_quaternion_h
