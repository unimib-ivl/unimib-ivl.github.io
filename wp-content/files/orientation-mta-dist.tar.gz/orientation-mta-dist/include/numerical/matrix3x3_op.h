#ifndef IVLLIB_MATRIX3X3_OP_H
#define IVLLIB_MATRIX3X3_OP_H

//--- Headers ---------------------------------------------------
#include <cassert>
#include <cmath>
#include <stdexcept>
#include "numerical/matrix3x3.h"
#include "numerical/matrix2x2.h"
#include "numerical/vector3.h"
#include "numerical/vector2.h"
#include "numerical/numerical_exceptions.h"
#include "numerical/ivl_math.h"

namespace ivllib {

  /** \addtogroup numerical */
  /*@{*/
  
  /**
   * Sets the translational components ot the matrix 
   *
   * @note only the translational components of the matrix are
   * changed.
   */
  template<typename T>
    inline void setTranslationVector (Matrix3x3<T>& m, 
				      const Vector2<T>& v);     
  /**
   * computes the transpose of a matrix.
   * @param m the input matrix
   * @param out the output matrix
   */
  template<typename T>
    inline void transpose (const Matrix3x3<T>& m, 
			   Matrix3x3<T>& out);

  /**
   * build a 2D rotation matrix by the angle specified as argument.
   *
   * @param m the output rotation matrix
   * @param theta the angle of rotation in radians
   */
  template<typename T>
    void buildRotationMatrix (Matrix3x3<T>& m, 
			      T theta);

  /**
   * These functions performs an axis/angle rotation. For greater
   * speed, always use a unit vector (length = 1). In these versions,
   * we will assume an arbitrary length and normalize.
   *
   * @param m the output rotation matrix
   * @param v the 3D vector used as rotation axis
   * @param theta the angle of rotation in radians
   */
  template<typename T>
    void buildRotationMatrix (Matrix3x3<T>& m, 
			      const Vector3<T> v, 
			      T theta);

  /**
   * gets the 2x2 rotational components of the input matrix
   *
   * @param m the input 3x3 matrix
   * @param out the output 2x2 rotation matrix
   */
  template<typename T>
    inline void getRotationMatrix (const Matrix3x3<T>& m,
				   Matrix2x2<T>& out);

  /**
   * sets the 2x2 rotational components of the input matrix
   * @note the other matrix components are not changed
   * @param m the output 3x3 matrix
   * @param in the input 2x2 rotation matrix
   */
  template<typename T>
    inline void setRotationMatrix (Matrix3x3<T>& m,
				   const Matrix2x2<T>& in);
   
  /**
   * computes the euler angles from the 3D rotational matrix. The
   * convention used is the heading, pitch and bank.
   */
  template<typename T>
    void getEulerAngles(const Matrix3x3<T>& m, 
			T& heading, 
			T& pitch, 
			T& bank);

  /**
   * @return the translation component of the current matrix
   */
  template<typename T>
    inline void getTranslationVector(const Matrix3x3<T>& m, 
				     Vector2<T>& out);

  /**
   * Matrix3x3 multiplication
   * @param mat1 first matrix
   * @param mat2 second matrix
   * @param out result matrix (mat1 * mat2)
   */
  template <typename T>
    inline void mul(const Matrix3x3<T>& mat1, 
		    const Matrix3x3<T>& mat2, 
		    Matrix3x3<T>& out);


  /**
   * Matrix3x3 / Vector3 multiplication.
   * @param mat transformation matrix
   * @param vec the 3D vector to be transformed. 
   * @param out result matrix (mat * vec)
   */
  template <typename T>
    inline void mul(const Matrix3x3<T>& mat, 
		    const Vector3<T>& vec, 
		    Vector3<T>& out);

  /**
   * Matrix3x3 / Vector2 rototranslation mul.  This mul operation
   * multiplies only the rotation and tanslation components of the
   * matrix.
   *
   * @param mat transformation matrix 
   * @param vec the vector to be transformed 
   * @param out result matrix (mat * vec)
   */
  template <typename T>
    inline void rt_mul(const Matrix3x3<T>& mat, 
		       const Vector2<T>& vec, 
		       Vector2<T>& out);

  /**
   * Set the input matrix to identity.
   */
  template <typename T>
    void Identity(Matrix3x3<T>& m);

  //---------------------------------------------------------------
  template <typename T>
    void Identity(Matrix3x3<T>& m)
    {
      m.set( 1,0,0,
	     0,1,0,
	     0,0,1 );
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void setTranslationVector (Matrix3x3<T>& m, 
				      const Vector2<T>& v)
    {
      m[0][2] = v.x;
      m[1][2] = v.y;  
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void transpose (const Matrix3x3<T>& m, 
			   Matrix3x3<T>& out)
    {
      out[0][0] = m [0][0];
      out[0][1] = m [1][0];
      out[0][2] = m [2][0];
      out[1][0] = m [0][1];
      out[1][1] = m [1][1];
      out[1][2] = m [2][1];
      out[2][0] = m [0][2];
      out[2][1] = m [1][2];
      out[2][2] = m [2][2];
    }

  //---------------------------------------------------------------
  template<typename T>
    void buildRotationMatrix (Matrix3x3<T>& m, 
			      T theta)
    {
      m[0][0] = std::cos(theta);
      m[0][1] = std::sin(theta);
      m[0][2] = 0;
      m[1][0] = -std::sin(theta);
      m[1][1] = std::cos(theta);
      m[1][2] = 0;
      m[2][0] = 0;
      m[2][1] = 0;
      m[2][2] = 1;
    }
  //---------------------------------------------------------------
  template<typename T>
    void buildRotationMatrix (Matrix3x3<T>& m, 
			      const Vector3<T> v, 
			      T theta)
    {
      Vector3<T> _v=v;
  
      double c,s,t;
  
      // normalize
      if (!normalize(_v))
	throw VectorNormalizationError("Cannot normalize vector.");
  
      // do the trig
      c = std::cos(theta);
      s = std::sin(theta);
      t = 1-c;

      // build the rotation matrix
      m[0][0] = t*_v.x*_v.x + c;
      m[0][1] = t*_v.x*_v.y - s*_v.z;
      m[0][2] = t*_v.x*_v.z + s*_v.y;

      m[1][0] = t*_v.x*_v.y + s*_v.z;
      m[1][1] = t*_v.y*_v.y + c;
      m[1][2] = t*_v.y*_v.z - s*_v.x;


      m[2][0] = t*_v.x*_v.z - s*_v.y;
      m[2][1] = t*_v.y*_v.z + s*_v.x;
      m[2][2] = t*_v.z*_v.z + c;
    }

  //---------------------------------------------------------------
  template<typename T>
    inline void getRotationMatrix (const Matrix3x3<T>& m,
				   Matrix2x2<T>& out)
    {
      out[0][0] = m[0][0];
      out[0][1] = m[0][1];
      out[1][0] = m[1][0];
      out[1][1] = m[1][1];
    }

  //---------------------------------------------------------------
  template<typename T>
    inline void setRotationMatrix (Matrix3x3<T>& m,
				   const Matrix2x2<T>& in)
    {
      m[0][0] = in[0][0];
      m[0][1] = in[0][1];
      m[1][0] = in[1][0];
      m[1][1] = in[1][1];
    }

  //---------------------------------------------------------------
  template<typename T>
    void getEulerAngles(const Matrix3x3<T>& m, 
			T& heading, 
			T& pitch, 
			T& bank)
    {
      // Extract sin(pitch) from m[1][2]
      T sp=-m[1][2];
  
      // Check for Gimbal lock
      if (std::fabs(sp) > 0.9999f) 
	{
	  // Looking straight up or down
	  pitch = (M_PI / 2.0f) * sp;
	  //  Compute heading, slam bank to zero
	  heading = std::atan2(-m[2][0], m[0][0]);
	  bank = 0.0f;
	} else 
	{
	  // Compute angles. We don't have to use the "safe" asin
	  // function because we already checked for range errors when
	  // checking for Gimbal lock
	  heading = std::atan2(m[0][2], m[2][2]);
	  pitch = std::sin(sp);
	  bank = std::atan2(m[1][0], m[1][1]);
	}  
    }
  //---------------------------------------------------------------
  template<typename T>
    inline void getTranslationVector(const Matrix3x3<T>& m, 
				     Vector2<T>& out)
    {
      out.x = m[0][2];
      out.y = m[1][2];
    }

  //---------------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix3x3<T>& mat1, 
		    const Matrix3x3<T>& mat2, 
		    Matrix3x3<T>& out)
    {

      assert(&mat1 != &out);
      assert(&mat2 != &out);

#define compute(r,c) out[(r)][(c)] = mat1[(r)][0] * mat2[0][(c)] +	\
	mat1[(r)][1] * mat2[1][(c)] +					\
	mat1[(r)][2] * mat2[2][(c)];
  
      compute(0,0);
      compute(0,1);
      compute(0,2);
      compute(1,0);
      compute(1,1);
      compute(1,2);
      compute(2,0);
      compute(2,1);
      compute(2,2);
	
#undef compute
    }



  //---------------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix3x3<T>& mat, 
		    const Vector3<T>& vec, 
		    Vector3<T>& out)
    {
      T out_x = mat[0][0] * vec.x + 
	mat[0][1] * vec.y + 
	mat[0][2] * vec.z;
  
      T out_y = mat[1][0] * vec.x + 
	mat[1][1] * vec.y + 
	mat[1][2] * vec.z;
  
      T out_z = mat[2][0] * vec.x + 
	mat[2][1] * vec.y + 
	mat[2][2] * vec.z;

      out.set(out_x, out_y, out_z);
    }
  //---------------------------------------------------------------
  template <typename T>
    inline void rt_mul(const Matrix3x3<T>& mat, 
		       const Vector2<T>& vec, 
		       Vector2<T>& out)
    {
      T out_x = mat[0][0] * vec.x + 
	mat[0][1] * vec.y + 
	mat[0][2]; // we assme a w component = 1
  
      T out_y = mat[1][0] * vec.x + 
	mat[1][1] * vec.y + 
	mat[1][2]; // we assme a w component = 1  

      out.set(out_x, out_y);
    }
  //---------------------------------------------------------------


  template <typename T, typename U, typename V>
  void solve_cramer(const Matrix3x3<T>& A,
		    const Vector3<U>& b,
		    Vector3<V>& sol)
  {
    V detA = (A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) -
	      A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0]) +
	      A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]));
    if (detA == V(0))
      throw std::runtime_error("Cramer: Singular matrix");
    
    U b0 = b.x;
    U b1 = b.y;
    U b2 = b.z;

    sol.x = (b0 * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) -
	     A[0][1] * (b1 * A[2][2] - A[1][2] * b2) +
	     A[0][2] * (b1 * A[2][1] - A[1][1] * b2)) / detA;

    sol.y = (A[0][0] * (b1 * A[2][2] - A[1][2] * b2) -
	     b0 * (A[1][0] * A[2][2] - A[1][2] * A[2][0]) +
	     A[0][2] * (A[1][0] * b2 - b1 * A[2][0])) / detA;

    sol.z = (A[0][0] * (A[1][1] * b2 - b1 * A[2][1]) -
	     A[0][1] * (A[1][0] * b2 - b1 * A[2][0]) +
	     b0 * (A[1][0] * A[2][1] - A[1][1] * A[2][0])) / detA;

  }

  /*@}*/
  
} //namespace ivllib

#endif //IVLLIB_MATRIX3X3_OP_H
