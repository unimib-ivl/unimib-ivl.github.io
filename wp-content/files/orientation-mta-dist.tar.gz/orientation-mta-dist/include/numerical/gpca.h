/**
 * \file    gpca.h
 * \brief   Gappy Principal Component Analysis
 * \author  Alessandro Colombo
 */
#ifndef gpca_h
#define gpca_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <numerical/matrix_op.h>
#include <numerical/eigensystems.h>
#include <numerical/pca.h>
#include <numerical/vector_distances.h>
#include <numerical/linear_systems.h>
#include <cassert>
#include <cmath>
#include <numeric>
#include <algorithm>
#include <functional>
#include <vector>
#include <mat_algorithm.h>

#ifdef IVLLIB_GPCA_DEBUG
#include <iostream>
#endif

namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/

  template <typename DataIter, typename FlagIter, typename T>
  void compute_gpca_basis(DataIter patterns_from,
			  DataIter patterns_to,
			  FlagIter flags_from,			  
			  double retained_variance,
			  unsigned min_components,
			  Matrix<T>& basis,
			  Vector<T>& mean,
			  Vector<T>& eigenvalues,
			  unsigned max_iters=100,
			  double EPSILON=0.000001);

  template <typename T, typename F>
  void gpca_project(const Vector<T>& pIn, 
		    const Vector<F>& pMask,
		    const Matrix<T>& basis,
		    const Vector<T>& mean,
		    unsigned components,
		    Vector<T>& pOut);

  template <typename T, typename F>
  void gpca_project(const Vector<T>& pIn, 
		    const Vector<F>& pMask,
		    const Matrix<T>& basis,
		    const Vector<T>& mean,
		    Vector<T>& pOut);

  template <typename T>
  double commonality(const Matrix<T>& a,
		     const Matrix<T>& b,
		     unsigned components);

  template <typename T>
  double commonality(const Matrix<T>& a,
		     const Matrix<T>& b);



  //------------ Implementation-----------------------

  /** See the other version */
  template <typename T>
  double commonality(const Matrix<T>& a,
		     const Matrix<T>& b)
  {

    assert(a.rows() == b.rows());
    assert(a.columns() == b.columns());
    
    return commonality(a,b,a.rows());
  }

  //--------------------------------------------------
  /**
   * This method computes the commonality between the projectors of
   * two subspaces, i.e. the trace of a*transposed(b) normalized
   * between 0-1.
   */
  template <typename T>
  double commonality(const Matrix<T>& a,
		     const Matrix<T>& b,
		     unsigned components)
  {
    assert(a.rows() >= components);
    assert(b.rows() >= components);
    assert(a.columns() == b.columns());
    //compute trace
    Matrix<T> tr(components, components);
    for (unsigned r=0; r < components; r++) 
      for (unsigned c=0; c < components; c++)
 	{ 
 	  tr[r][c] = 0.0; 
 	  for (unsigned j=0; j < a.columns(); j++) 
	    tr[r][c] += a[r][j] * b[c][j];	       
 	} 
	  
    double ret=0.0;
    for (unsigned j=0; j < components; j++)
      ret+=fabs(tr[j][j]);
    
    return ret/components;
  }
  
  //--------------------------------------------------
  namespace
  {
    template<typename A, typename B, typename F>
    void mask_vec(const ivllib::Vector<A>& pV1, 
		  const ivllib::Vector<F>& pM, 
		  ivllib::Vector<B>& res)
    {
      assert(pV1.size() == pM.size());
      assert(pV1.size() == res.size());
      
      typedef typename ivllib::Vector<A>::size_type size_type;

      for (size_type i = 0; i < pV1.size(); i++)     
	res[i] = (pM[i]) ? pV1[i] : 0;
    }    
  }
  

  /**
   * Projects a gappy vector (i.e. with missing components) into the
   * eigenspace.  The mask passed as argument identifies missing
   * components.  
   *
   * @param pIn the high dimensional gappy vector to
   * project 
   * @param pMask the boolen mask of gappy components. A false
   * value (i.e == 0) stands for a missing component.  
   * @param mean the mean vector of the eigenspace
   * @param basis the matrix of eigenvectors (by rows)
   * @param pOut the projected low-dimensional output vector. 
   * @param rec_components the components of the basis used in the reconstruction
   *
   */
  template <typename T, typename F>
  void gpca_project(const Vector<T>& pIn, 
		    const Vector<F>& pMask,
		    const Matrix<T>& basis,
		    const Vector<T>& mean,
		    unsigned rec_components,
		    Vector<T>& pOut)
  {
    assert(pIn.size() == pMask.size());
    assert(basis.columns() == pIn.size());
    assert(basis.columns() == mean.size());
    assert(rec_components <= basis.rows());    
   
    size_t reduced_dimensions = rec_components; 
    size_t total_dimensions = basis.columns();    
    
    //build M matrix
    ivllib::Matrix<double> M(reduced_dimensions, reduced_dimensions);
    for(std::size_t row=0; row < reduced_dimensions; row++)
      for (std::size_t column=0; column < reduced_dimensions; column++)
	{
	  M[row][column] = 0;
	  for(std::size_t i=0; i < total_dimensions; i++)
	    if (pMask[i]) 
	      M[row][column] += basis[row][i] * basis[column][i];
	}
  
    //build f vector
    ivllib::Matrix<double> f(reduced_dimensions, 1);
    ivllib::Vector<double> g(total_dimensions);
    ivllib::Vector<double> phi(total_dimensions);

    sub(pIn, mean, g);
    mask_vec(g, pMask, g);
  
    for (std::size_t i=0; i < reduced_dimensions; i++)
      {
	//extract eigenvector i
	for (std::size_t j=0; j < total_dimensions; j++) phi[j] = basis[i][j];      
	mask_vec(phi, pMask, phi);
	f[i][0] = std::inner_product(g.begin(), g.end(), phi.begin(), 0.0f);
      }
  
    //risolvo Mb=f
    ivllib::Matrix<double> M_inv(reduced_dimensions, reduced_dimensions);
    ivllib::Matrix<double> sol(reduced_dimensions, 1);
  

    ivllib::solve_gauss(M, f, M_inv, sol);

    ivllib::Vector<T> ret(reduced_dimensions);
    //fill pOut with the solution
    for (std::size_t j=0; j < reduced_dimensions; j++) 
      ret[j] = sol[j][0];

    pOut.swap(ret);
  }
  //--------------------------------------------------

  /** See the other version */
  template <typename T, typename F>
  void gpca_project(const Vector<T>& pIn, 
		    const Vector<F>& pMask,
		    const Matrix<T>& basis,
		    const Vector<T>& mean,
		    Vector<T>& pOut)
  {
    gpca_project(pIn, 
		 pMask,
		 basis,
		 mean,
		 basis.rows(),
		 pOut);
  }

  /**
   * Gappy Principal Component Analysis.
   *
   * See: R. Everson and L. Sirovich "Karhunen–Love procedure for
   * gappy data", J. Opt. Soc. Am. A, Vol. 12, No. 8,  August 1995.
   *
   * Computes the basis of the Principal Component Analysis transform
   * starting from gappy data.
   *
   * A pattern \c x (column vector) is projected in the PCA space with 
   * \f$ B (x - m) \f$
   * where \c B is the basis of the transform and \c m is the mean pattern.
   * 
   * The function is called specifying a range [ \c patterns_from, \c
   * patterns_to ) of patterns to be analysed and the relative
   * validity vectors \c flags_from,. \c DataIter must be a forward
   * iterator which iterates over \c Vector<U> where \c U must be \c
   * float or \c double. The parameter F is a bool-convertible
   * type. True means valid data; false means missing data.  The
   * function will place the computed basis and the mean pattern in
   * the output paramters \c basis and \c mean respectively.
   *
   * The parameters \c retained_variance and \c min_components
   * determine the number of components retained.
   *
   * \param patterns_from iterator to the first pattern \param
   * patterns_to iterator past the last pattern \param flags_from
   * iterator to the the first pattern validity vector \param
   * retained_variance minimum fraction of total variance to be
   * preserved \param min_components minimum number of components to
   * be retained \param basis the base of the transformation \param
   * mean the offset of the transformation \param eigenvalues
   * eigenvalues associated to the principal components \param
   * max_iters the maximum number of iterations min_error the minimum
   * accepted error; i.e. the euclidean distance between the vectors
   * of eigenvalues at step n and n-1.
   *
   * \pre patterns_from != patterns_to
   * \pre patterns_from->size() > 0
   * \pre it->size() == patterns_from->size() for each \c it in [ \c patterns_from, \c patterns_to )
   * \pre retained_variance >= 0.0
   * \pre retained_variance <= 1.0
   * \pre min_components <= patterns_from->size()
   * \pre min_components <= distance(patterns_from,patterns_to)
   *
   * \param EPSILON  ???
   */
  template <typename DataIter, typename FlagIter, typename T>
  void compute_gpca_basis(DataIter patterns_from,
			  DataIter patterns_to,
			  FlagIter flags_from,			  
			  double retained_variance,
			  unsigned min_components,
			  Matrix<T>& basis,
			  Vector<T>& mean,
			  Vector<T>& eigenvalues,
			  unsigned max_iters=100,
			  double EPSILON=0.000001)
  {

    assert( patterns_from != patterns_to );
    typedef typename Matrix<T>::size_type size_type;
    typedef typename Matrix<T>::element_type el_type;

    //calcolo la prima base e stimo il numero di componenti inziali in
    //base alla varianza e ai componenti minimi
    size_type total_dimensions=patterns_from->size();
    size_type n_patterns = 0;

    //compute per pixel mean
    Vector<T> perpixel_mean(total_dimensions, 0.0);
    Vector<size_type> perpixel_count(total_dimensions, 0);
    FlagIter fit = flags_from;

    for (DataIter it = patterns_from; 
	 it != patterns_to; 
	 it++, fit++, n_patterns++ ) 
      {
	assert( it->size() == total_dimensions );
	assert( fit->size() == total_dimensions );

	for(size_type i=0; i < total_dimensions; i++)	 
	  if ( (*fit)[i] )
	    {	      
	      perpixel_count[i]++;
	      perpixel_mean[i] += (*it)[i];
	    }	
      }

    for(size_type i=0; i < total_dimensions; i++)	 
      {
	if(perpixel_count[i] == 0)
	  throw std::runtime_error("GPCA: Missing informations on some dimensions.");
	perpixel_mean[i] /= perpixel_count[i];
      }
    
    //repair patterns using mean values
    std::vector < Vector<T> > repaired_patterns(n_patterns, Vector<T>(total_dimensions));
    typename std::vector < Vector<T> >::iterator rit=repaired_patterns.begin();
    fit = flags_from;
    for (DataIter it = patterns_from; 
	 it != patterns_to; 
	 it++, fit++, rit++ )
      {
	for(size_type i=0; i < total_dimensions; i++)	 
	  {
	    if ( (*fit)[i] )	      
	      (*rit)[i] = (*it)[i];
	    else
	      (*rit)[i] = perpixel_mean[i];

	  }
      }
    
    //compute a base with repaired vectors
    Matrix<T> tbase;
    Vector<T> tmean;    
    Vector<T> teigenvalues;    
    
#ifdef IVLLIB_GPCA_DEBUG
    std::cout << "Iteration 0: (mean-repaired)";
#endif
        
    compute_pca_basis(repaired_patterns.begin(),
		      repaired_patterns.end(),
		      retained_variance,
		      min_components,
		      tbase,
		      tmean,
		      teigenvalues);

#ifdef IVLLIB_GPCA_DEBUG
    std::cout << "\tcomponents: " << teigenvalues.size() << std::endl;
#endif

    //faccio partire il loop di Everson-Sirovich; calcolo la
    //commonality rispetto al minimo numero di componenti. 

    //---------------------------- main loop ----------------------------
    unsigned iteration=0;
    Vector<T> projected;
    Matrix<T> old_base;
    Vector<T> old_mean;    
    Vector<T> old_eigenvalues;
    double comm;
    
    do {
      //repair patterns with the new base      
      rit=repaired_patterns.begin();
      fit = flags_from;
      for (DataIter it = patterns_from; 
	   it != patterns_to; 
	   it++, fit++, rit++ )
	{
	  //project gappy pattern
	  gpca_project(*it,
		       *fit,
		       tbase,
		       tmean,
		       tbase.rows(),
		       projected);

	  //project back
	  for (unsigned c=0; c < total_dimensions; c++)
	    {
	      (*rit)[c] = 0.0;
	      for (unsigned r=0; r < tbase.rows(); r++)	    
		(*rit)[c] += tbase[r][c] * projected[r];
	    }
	  add((*rit), tmean, (*rit));	 
	}                  
      
      old_base.swap(tbase);
      old_mean.swap(tmean);
      old_eigenvalues.swap(teigenvalues);

      //compute a base with repaired vectors    
      compute_pca_basis(repaired_patterns.begin(),
			repaired_patterns.end(),
			retained_variance,
			min_components,
			tbase,
			tmean,
			teigenvalues);

      iteration++;      

      comm = commonality(tbase, old_base, std::min(tbase.rows(), old_base.rows()));
            
#ifdef IVLLIB_GPCA_DEBUG
      std::cout << "Iteration: " << iteration;
      std::cout << "\t components:" << tbase.rows();
      std::cout << "\t commonality:" << comm << std::endl;

#endif
    } while ((iteration < max_iters) && ((1.0 - comm) > EPSILON));    
    
    // commit
    basis.swap(tbase);
    mean.swap(tmean);
    eigenvalues.swap(teigenvalues);    
  }

  /*@}*/  
  
} // ivllib

#endif
