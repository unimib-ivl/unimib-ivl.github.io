#ifndef IVLLIB_MATRIX2X2_H
#define IVLLIB_MATRIX2X2_H

//--- Headers -------------------------------------------------------------------------
#include <cstring>

//--- Types --------------------------------------------------------------------------

namespace ivllib {  

  /** \addtogroup numerical */
  /*@{*/

  /**
   * A matrix of fixed size dimensions (2x2)
   */
  template <typename T>
  class Matrix2x2 
  {
      
  public:
    typedef T element_type; ///< type of the matrix elements
    typedef size_t size_type; ///< type of indexes
    typedef element_type* iterator; ///< iterator type
    typedef const element_type* const_iterator; ///< const iterator type
      

    /**
     * \brief default constructor.
     *
     * the default constructor makes no initializations on the
     * matrix for efficency reasons.
     */
    Matrix2x2() {}


    /**
     * constructs a matrix specifying all the elements.
     */
    Matrix2x2 ( element_type m00, element_type m01, 
		element_type m10, element_type m11)
    {
      set ( m00,   m01, 
	    m10,   m11);
    }
      
    /**
     * \brief default destructor
     */
    ~Matrix2x2() {}

	
    /**
     * @return an iterator pointing to the element at (0,0)
     */    
    iterator begin()
    { return mData; }

    /**
     * @return an iterator pointing to the element at (0,0)
     */    	
    const_iterator begin() const
    { return mData; }
	
    /**
     * @return an iterator pointing to past the end
     */    
    iterator end()
    { return mData + 4; }

    /**
     * @return an iterator pointing to past the end
     */    
    const_iterator end() const
    { return mData + 4; }

    /**
     * sets the entryes of the matrix with the parameters passed as
     * arguments. mij indicates the entry at row i and column j.
     */
    inline void set (element_type m00, element_type m01,
		     element_type m10, element_type m11)
    {
      (*this)[0][0]=m00;
      (*this)[0][1]=m01;
      (*this)[1][0]=m10;
      (*this)[1][1]=m11;
    }
	
    /**
     * @return an iterator pointing to the first elementh of the specified row
     */
    inline iterator operator[] (size_type row)
    { return (mData + (row * 2)); }

    /**
     * @return an iterator pointing to the first elementh of the specified row
     */
    inline const_iterator  operator[] (size_type row) const
    { return (mData + (row * 2)); }

  private:
    element_type mData[4];

  }; //end of Matrix2x2 class definition

  typedef Matrix2x2<float> Matrix2x2f; ///< a 2x2 matrix of floats
  typedef Matrix2x2<double> Matrix2x2d; ///< a 2x2 matrix of doubles
  
  /*@}*/

} //namespace ivllib


#endif //IVLLIB_MATRIX2X2_H
