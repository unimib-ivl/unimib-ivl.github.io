/**
 * \file vector_distances.h
 * \brief vector norms and distances
 */

#ifndef vector_distances_h
#define vector_distances_h


#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <cstdlib>
#include <cmath>
#include <cassert>


namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/

  /**
   * Compute the 1-norm.
   *
   * \param v input vector
   *
   * \return the norm of v
   */
  template <typename T>
  T norm1(const ivllib::Vector<T>& v);

  /**
   * Compute the Euclidean norm.
   *
   * \param v input vector
   *
   * \return the norm of v
   */
  template <typename T>
  T norm2(const ivllib::Vector<T>& v);

  /**
   * Compute the inf-norm.
   *
   * \param v input vector
   *
   * \return the norm of v
   */
  template <typename T>
  T normmax(const ivllib::Vector<T>& v);

  /**
   * Compute the norm of order p.
   *   
   * \param v input vector
   * \param p order of the norm
   *
   * \return the norm of v
   *
   * \pre p >= 1
   */
  template <typename T>
  T normp(const ivllib::Vector<T>& v, double p);


  /**
   * Compute the Manhattan distance.
   *
   * \param v first vector
   * \param w second vector
   *
   * \return the distance between the two vectors
   *
   * \pre v.size() == w.size()
   */
  template <typename T>
  T distance1(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w);

  /**
   * Compute the Euclidean distance.
   *
   * \param v first vector
   * \param w second vector
   *
   * \return the distance between the two vectors
   *
   * \pre v.size() == w.size()
   */
  template <typename T>
  T distance2(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w);

  /**
   * Compute the max distance.
   *
   * \param v first vector
   * \param w second vector
   *
   * \return the distance between the two vectors
   *
   * \pre v.size() == w.size()
   */
  template <typename T>
  T distancemax(const ivllib::Vector<T>& v,
		const ivllib::Vector<T>& w);

  /**
   * Compute the distance of order p.
   *
   * \param v first vector
   * \param w second vector
   * \param p order of the metric
   *
   * \return the distance between the two vectors
   *
   * \pre v.size() == w.size()
   * \pre p >= 1
   */
  template <typename T>
  T distancep(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w,
	      double p);


  /**
   * Compute the cosine of the angle between the two vectors.
   *
   * \param v first vector
   * \param w second vector
   *
   * \return the cosine of the angle between the two vectors
   *
   * \pre v.size() == w.size()
   */
  template <typename T>
  T cosine(const ivllib::Vector<T>& v,
	   const ivllib::Vector<T>& w);


  /*@}*/


  template <typename T>
  T norm1(const ivllib::Vector<T>& v)
  {
    using std::abs;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++)
      ret += abs(v[i]);

    return ret;
  }


  template <typename T>
  T norm2(const ivllib::Vector<T>& v)
  {
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++)
      ret += v[i]*v[i];

    return std::sqrt(ret);
  }


  template <typename T>
  T normmax(const ivllib::Vector<T>& v)
  {
    using std::abs;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++) {
      T x = abs(v[i]);
      if (x > ret)
	ret = x;
    }

    return ret;
  }


  template <typename T>
  T normp(const ivllib::Vector<T>& v, double p)
  {
    assert( p >= 1 );

    using std::abs;
    using std::pow;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    double ret = 0;

    for (size_type i = 0; i < n; i++) {
      double x = abs(v[i]);
      ret += pow(x, p);
    }

    return pow(ret, 1.0/p);
  }


  template <typename T>
  T distance1(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w)
  {
    assert( v.size() == w.size() );

    using std::abs;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++)
      ret += abs(v[i] - w[i]);

    return ret;
  }


  template <typename T>
  T distance2(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w)
  {
    assert( v.size() == w.size() );

    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++) {
      T x = v[i] - w[i];
      ret += x*x;
    }

    return std::sqrt(ret);
  }


  template <typename T>
  T distancemax(const ivllib::Vector<T>& v,
		const ivllib::Vector<T>& w)
  {
    assert( v.size() == w.size() );

    using std::abs;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    T ret = 0;

    for (size_type i = 0; i < n; i++) {
      T x = abs(v[i] - w[i]);
      if (x > ret)
	ret = x;
    }

    return ret;
  }


  template <typename T>
  T distancep(const ivllib::Vector<T>& v,
	      const ivllib::Vector<T>& w,
	      double p)
  {
    assert( v.size() == w.size() );
    assert( p >= 1 );

    using std::abs;
    using std::pow;
    typedef typename ivllib::Vector<T>::size_type size_type;

    size_type n = v.size();
    double ret = 0;

    for (size_type i = 0; i < n; i++)
      {
	double x = abs(v[i] - w[i]);
	ret += pow(x, p);
      }

    return std::pow(ret, 1.0/p);
  }


  template <typename T>
  T cosine(const ivllib::Vector<T>& v,
	   const ivllib::Vector<T>& w)
  {
    assert( v.size() == w.size() );
    T den = norm2(v) * norm2(w);
    assert( den > 0 );

    return inner_product(v, w, T(0)) / den;
  }


}  // namespace ivllib


#endif  // vector_distances_h
