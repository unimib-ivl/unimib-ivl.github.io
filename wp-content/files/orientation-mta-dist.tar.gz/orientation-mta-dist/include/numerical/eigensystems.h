/**
 * \file    eigensystems.h
 * \brief   algorithms for the computation of eigenvalues and eigenvectors
 * \author  $LastChangedBy:$
 * \date    $Date$
 * \version $Revision:$
 */

#ifndef eigensystems_h
#define eigensystems_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector_op.h>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <limits>


namespace ivllib
{
  /** \addtogroup numerical */
  /*@{*/
  
  template <typename T>
  void solve_eigensystem_jacobi(const Matrix<T>& in,
				Matrix<T>& evectors,
				Vector<T>& evalues);
  
  template <typename T>
  void eigenvalues_ql(Matrix<T> A, Vector<T>& v);

  template <typename T>
  void eigen_ql(Matrix<T> A, Matrix<T>& evecs, Vector<T>& evals);



  // implementation

  /** \cond detail */
  namespace detail
  {
    // used by "solve_eigensystem_jacobi(...)"
    template <typename T>
    inline void jacobi_rotate(Matrix<T>& a,
			      typename Matrix<T>::size_type i,
			      typename Matrix<T>::size_type j,
			      typename Matrix<T>::size_type k,
			      typename Matrix<T>::size_type l,
			      typename Matrix<T>::element_type tau,
			      typename Matrix<T>::element_type s)
    {
      typename Matrix<T>::element_type g = a[i][j];
      typename Matrix<T>::element_type h = a[k][l];
      a[i][j] = g - s*(h + g*tau);
      a[k][l] = h + s*(g - h*tau);
    }
  } // detail
  /** \endcond */

  /**
   * Jacobi algorithm
   *
   * Computes eigenvectors and eigenvalues of the symmetric square
   * matrix \p in using the Jacobi method.
   *
   * After the execution, the columns of \p evectors are the normalized
   * eigenvectors of pArg, the corresponding eigenvalues are stored in
   * \p evalues in decreasing order.
   *
   * If the method does not converge a \p std::runtime_error
   * exception is thrown.
   *
   * \pre in.rows() > 0
   * \pre in.rows() == in.columns()
   * \pre in[i][j] == in[j][i]
   *
   * \post evectors.rows() == in.rows()
   * \post evectors.columns() == in.rows()
   * \post evalues.size() == in.rows()
   * \post evalues[i] >= evalues[i+1]
   */
  template <typename T>
  void solve_eigensystem_jacobi(const Matrix<T>& in,
				Matrix<T>& evectors,
				Vector<T>& evalues)
  {
    assert( in.rows() > 0 );
    assert( in.rows() == in.columns() );

    using std::abs;

    // maximum number of iterations
    const int MAX_ITER = 50;

    typedef typename Matrix<T>::size_type size_type;
    typedef typename Matrix<T>::element_type el_type;

    const size_type n = in.rows();
    
    // make a local copy of the matrix in
    Matrix<T> a = in;
    
    // create the structures holding temp results
    Matrix<T> evec(n,n,0);
    Vector<T> eval(n);

    // Initialize evec to the identity matrix
    std::fill_n(evec.diagonal_begin(),n,1);
    
    // Initialize eval to the diagonal of pArg
    std::copy(a.diagonal_begin(),
	      a.diagonal_end(),
	      eval.begin());
    
    // Initialize a vector b to the diagonal of pArg
    Vector<T> b = eval;
    
    // The vector z will accumulate terms of the form ta[p][q]
    Vector<T> z(n,0);
    
    // Sum off-diagonal elements, when 0 convergence has occured
    el_type sm = 0;
    for (size_type i = 0; i < n-1; i++)
      for (size_type j = i + 1; j < n; j++)
	sm += abs(a[i][j]);
    
    int iter = 0;
    while (sm > 0) {
      // Stop the method after MAX_ITER iterations
      if (++iter == MAX_ITER)
	throw std::runtime_error("solve_eigensystem_jacobi: too many iterations");
      
      // In the first iterations, do not consider elements smaller then tresh
      el_type tresh = (iter < 4 ? sm/(5*n*n) : 0);

      // For each off-diagonal element ...
      for (size_type i = 0; i < n-1; i++) {
	for (size_type j = i + 1; j < n; j++) {
	  el_type g = 100*abs(a[i][j]);
	  
	  // After four iterations, skip if the off diagonal element is small
	  if (iter > 4 && abs(eval[i]) + g == abs(eval[i]) &&
	      abs(eval[j]) + g == abs(eval[j])) {
	    
	    a[i][j] = 0;

	  } else if (abs(a[i][j]) > tresh) {
	    el_type diff = eval[j] - eval[i];
	    el_type t;
	    if ((abs(diff) + g) == abs(diff)) {
	      t = a[i][j] / diff;
	    } else {
	      el_type theta = diff/(2*a[i][j]);
	      t = 1.0/(abs(theta)+std::sqrt(1+theta*theta));
	      if (theta < 0)
		t = -t;
	    }
	    el_type c = 1/std::sqrt(1+t*t);
	    el_type s = t*c;
	    el_type tau = s/(1+c);
	    el_type h = t*a[i][j];

	    z[i] -= h;
	    z[j] += h;
	    eval[i] -= h;
	    eval[j] += h;
	    a[i][j] = 0;
	    
	    // Case of rotations 0 = j < p
	    for (size_type k = 0; k < i ; k++)
	      detail::jacobi_rotate(a,k,i,k,j,tau,s);

	    // Case of rotations p < j < q
	    for (size_type k = i+1; k < j; k++)
	      detail::jacobi_rotate(a,i,k,k,j,tau,s);

	    // Case of rotations q < j < n
	    for (size_type k = j+1; k < n; k++)
	      detail::jacobi_rotate(a,i,k,j,k,tau,s);

	    // update evec
	    for (size_type k = 0; k < n; k++)
	      detail::jacobi_rotate(evec,k,i,k,j,tau,s);
	  }
	}
      }

      // update eval, b, and z
      add_to(b,z); // b += z;
      eval = b;
      std::fill(z.begin(),z.end(),0);

      // update sm
      sm = 0;
      for (size_type i = 0; i < n - 1; i++)
	for (size_type j = i + 1; j < n; j++)
	  sm += abs(a[i][j]);
    }

    // sort eigenvalues and eigenvectors
    for (size_type i = 0; i < n - 1; i++) {
      for (size_type j = i + 1; j < n; j++) {
	if (eval[i]<eval[j]) {
	  std::swap(eval[i],eval[j]);
	  for (size_type k = 0; k < n; k++)
	    std::swap(evec[k][i],evec[k][j]);
	}
      }
    }
    
    // commit
    evectors.swap(evec);
    evalues.swap(eval);
  }



  /** \cond detail */
  namespace detail
  {
    // Helper functions.

    template <typename T, typename U>
    void householder_reduction(Matrix<T>& A,
			       Vector<U>& d,
			       Vector<U>& e,
			       bool onlyvalues);

    template <typename T, typename U>
    void ql_implicit_shift(Matrix<T>& A,
			   Vector<U>& d,
			   Vector<U>& e,
			   bool onlyvalues);
  }
  /** \endcond */


  /**
   * Computes the eigenvalues of the symmetric matrix \a A.
   *
   * The eigenvalues are returned in non increasing order.  Note that
   * this method is significantly faster than eigen_ql, which also
   * computes the eigenvectors.
   *
   * This function uses the Householder reduction to transform \a A in
   * tridiagonal form.  The the QL method with implicit shifts
   * recovers the eigenvalues.
   *
   * If the method does not converge a \p std::runtime_error exception
   * is thrown.
   *
   * \pre A.rows() == A.columns()
   * \pre A[i][j] == A[j][i]
   */
  template <typename T>
  void eigenvalues_ql(Matrix<T> A, Vector<T>& v)
  {
    assert(A.rows() == A.columns());

    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = A.rows();
    Vector<T> d(n);
    Vector<T> e(n);
    detail::householder_reduction(A, d, e, true);
    detail::ql_implicit_shift(A, d, e, true);
    std::sort(d.begin(), d.end(), std::greater<T>());
    v.swap(d);
  }


  /**
   * Computes eigenvectors and eigenvalues of the symmetric matrix \a
   * A.
   *
   * The first element of the returned pair is the matrix of
   * normalized eigenvectors (stored in the columns).  The
   * corresponding eigenvalues are the second element of the returned
   * pair (in non increasing order).
   *
   * This function uses the Householder reduction to transform \a A in
   * tridiagonal form.  The the QL method with implicit shifts
   * recovers eigenvalues and eigenvectors.
   *
   * If the method does not converge a \p std::runtime_error exception
   * is thrown.
   *
   * \pre A.rows() == A.columns()
   * \pre A[i][j] == A[j][i]
   */
  template <typename T>
  void eigen_ql(Matrix<T> A, Matrix<T>& evecs, Vector<T>& evals)
  {
    assert(A.rows() == A.columns());

    typedef typename Matrix<T>::size_type size_type;

    size_type n = A.rows();
    Vector<T> d(n);
    Vector<T> e(n);
    detail::householder_reduction(A, d, e, false);
    detail::ql_implicit_shift(A, d, e, false);
    
    // Sort the eigenvalues and the corresponding eigenvectors.  Use
    // Shell sort since anyway it will require a neglible amount of
    // time with respect to the work already done.
    using std::swap;
    size_type inc = 4;
    while (inc < n)
      inc = 3 * inc + 1;
    do {
      inc = (inc - 1) / 3;
      for (size_type i = inc; i < n; i++) {
	for (size_type j = i; j >= inc; j-= inc) {
	  if (d[j] < d[j - inc])
	    break;
	  swap(d[j], d[j - inc]);
	  for (size_type k = 0; k < n; k++)
	    swap(A[k][j], A[k][j - inc]);
	}
      }
    } while(inc > 1);

    // Make it so each eigenvector has more positive than negative
    // elements.
    for (size_type j = 0; j < n; j++) {
      size_type neg = 0;
      for (size_type i = 0; i < n; i++)
	if (A[i][j] < 0)
	  ++neg;
      if (2 * neg > n)
	for (size_type i = 0; i < n; i++)
	  A[i][j] = -A[i][j];
    }

    evecs.swap(A);
    evals.swap(d);
  }


  /** \cond detail */
  namespace detail
  {
    template <typename T>
    T copysign(T x, T y)
    {
      return (y < 0 ? -std::abs(x) : std::abs(x));
    }

    template <typename T>
    T sqr(T x)
    {
      return x * x;
    }

    template <typename T>
    T hypot(T a, T b)
    {
      T absa = std::abs(a);
      T absb = std::abs(b);
      return (absa > absb
	      ? absa*std::sqrt(1.0 + sqr(absb / absa))
	      : (absb == 0.0
		 ? 0.0
		 : absb * std::sqrt(1.0 + sqr(absa / absb))));
    }



    template <typename T, typename U>
    void householder_reduction(Matrix<T>& A,
			       Vector<U>& d,
			       Vector<U>& e,
			       bool onlyvalues)
    {
      // Householder reduction of a real symmetric matrix
      // z[0..n-1][0..n-1].  (The input matrix A to Symmeig is stored
      // in z.)  On output, z is replaced by the orthogonal matrix Q
      // effecting the transformation.  d[0..n-1] contains the
      // diagonal elements of the tridiagonal matrix and e[0..n-1] the
      // off-diagonal elements, with e[0] = 0.  If yesvecs is false,
      // so that only eigenvalues will subsequently be determined,
      // several statements are omitted, in which case A contains no
      // useful information on output.

      assert(A.rows() == A.columns());
      assert(A.rows() == d.size());
      assert(A.rows() == e.size());

      typedef typename Matrix<T>::size_type size_type;

      using std::abs;
      size_type n = A.rows();

      for (size_type i = n - 1; i > 0; i--) {
	size_type l = i - 1;
	T scale = 0;
	T h = 0;
	if (l > 0) {
	  for (size_type k = 0; k < i; k++)
	    scale += abs(A[i][k]);
	  // The row is null, skip the transformation.
	  if (scale == 0) {
	    e[i] = A[i][l];
	  } else {
	    T iscale = 1.0 / scale;
	    for (size_type k = 0; k < i; k++) {
	      // Use scaled a’s for transformation.
	      A[i][k] *= iscale;
	      // Form sigma in h.
	      h += A[i][k] * A[i][k];
	    }
	    T f = A[i][l];
	    T g = -copysign(std::sqrt(h), f);
	    e[i] = scale * g;
	    h -= f * g;
	    // At this point h is half the squared norm of the
	    // transformation vector.
	    A[i][l] = f - g;
	    f = 0;
	    for (size_type j = 0; j < i; j++) {
	    // Store u in row i of A.
	      if (!onlyvalues)  // Store u / H in column i of A.
		A[j][i] = A[i][j] / h;
	      g = 0;
	      // Form an element of Au in g.
	      for (size_type k = 0; k < j + 1; k++)
		g += A[j][k] * A[i][k];
	      for (size_type k = j + 1;k < i; k++)
		g += A[k][j] * A[i][k];
	      // Form element of p in temporarily unused element of e.
	      e[j] = g / h;
	      f += e[j] * A[i][j];
	    }
	    // Form K.
	    T hh = f / (h + h);
	    // Form q and store in e overwriting p.
	    for (size_type j = 0; j < i; j++) {
	      f = A[i][j];
	      e[j] = g = e[j] - hh * f;
	      // Reduce A.
	      for (size_type k = 0; k < j + 1; k++)
		A[j][k] -= (f * e[k] + g * A[i][k]);
	    }
	  }
	} else {
	  e[i] = A[i][l];
	}
	d[i] = h;
      }
      if (!onlyvalues)
	d[0] = 0;
      e[0] = 0;
      // Begin accumulation of transformation matrices.
      for (size_type i = 0; i < n; i++) {
	if (!onlyvalues) {
	  // This block skipped when i=0.
	  if (d[i] != 0) {
	    for (size_type j = 0; j < i; j++) {
	      T g = 0;
	      // Use u and u / H stored in A to form PQ.
	      for (size_type k = 0; k < i; k++)
		g += A[i][k] * A[k][j];
	      for (size_type k = 0; k < i; k++)
		A[k][j] -= g * A[k][i];
	    }
	  }
	  d[i] = A[i][i];
	  // Reset row and column of A to identity matrix for next
	  // iteration.
	  A[i][i] = 1;
	  for (size_type j = 0; j < i; j++)
	    A[j][i] = A[i][j] = 0;
	} else {
	  // Only this statement remains.
	  d[i] = A[i][i];
	}
      }
    }


    template <typename T, typename U>
    void ql_implicit_shift(Matrix<T>& A,
			   Vector<U>& d,
			   Vector<U>& e,
			   bool onlyvalues)
    {
      // QL algorithm with implicit shifts to determine the
      // eigenvalues and (optionally) the eigenvectors of a real,
      // symmetric, tridiagonal matrix, or of a real symmetric matrix
      // previously reduced by householder_reduction.  On input,
      // d[0..n-1] contains the diagonal elements of the tridiagonal
      // matrix.  On output, it returns the eigenvalues. The vector
      // e[0..n-1] inputs the subdiagonal elements of the tridiagonal
      // matrix, with e[0] arbitrary. If the eigenvectors of a
      // tridiagonal matrix are desired, the matrix A[0..n-1][0..n-1]
      // is input as the identity matrix.  If the eigenvectors of a
      // matrix that has been reduced by householder_reduction are
      // required, then A is input as the matrix output by
      // householder_reduction. In either case, column k of A returns
      // the normalized eigenvector corresponding to d[k].

      assert(A.rows() == A.columns());
      assert(A.rows() == d.size());
      assert(A.rows() == e.size());
      
      typedef typename Matrix<T>::size_type size_type;

      using std::abs;

      size_type n = A.rows();

      const U eps = std::numeric_limits<U>::epsilon();
      const int MAX_ITERS = 30;

      // It is convenient to renumber the elements of e.
      for (size_type i = 1; i < n; i++)
	e[i - 1] = e[i];
      e[n - 1] = 0;
      for (size_type l = 0; l < n; l++) {
	int iter = 0;
	size_type m;
	do {
	  // Look for a single small subdiagonal element to split the
	  // matrix.
	  for (m = l; m + 1 < n; m++) {
	    U dd = abs(d[m]) + abs(d[m + 1]);
	    if (abs(e[m]) <= eps * dd)
	      break;
	  }
	  if (m == l)
	    break;
	  if (iter++ == MAX_ITERS)
	    throw std::runtime_error("ql_implicit_shift: too many iterations.");
	  
	  // Form shift.
	  U g = (d[l + 1] - d[l]) / (2.0 * e[l]);
	  U r = hypot<U>(g, 1);
	  // This is d[m] - k[s] .
	  g = d[m] - d[l] + e[l] / (g + copysign(r,g));
	  U s = 1;
	  U c = 1;
	  U p = 0;
	  // A plane rotation as in the original QL, followed by
	  // Givens rotations to restore tridiagonal form.
	  size_type i = m;
	  while (i > l) {
	    --i;
	    U f = s * e[i];
	    U b = c * e[i];
	    r = hypot(f, g);
	    e[i + 1] = r;
	    if (r == 0) {
	      // Recover from underflow.
	      d[i + 1] -= p;
	      e[m] = 0;
	      break;
	    }
	    s = f / r;
	    c = g / r;
	    g = d[i + 1] - p;
	    r = (d[i] - g) * s + 2 * c * b;
	    p = s * r;
	    d[i + 1] = g + p;
	    g = c * r - b;
	    if (!onlyvalues) {
	      // Form eigenvectors.
	      for (size_type k = 0; k < n; k++) {
		f = A[k][i + 1];
		A[k][i + 1] = s * A[k][i] + c * f;
		A[k][i] = c * A[k][i] - s * f;
	      }
	    }
	  }
	  if (r == 0.0 && i >= l)
	    continue;
	  d[l] -= p;
	  e[l] = g;
	  e[m] = 0;
	} while (m != l);
      }
    }

  }  // namespace detail
  /** \endcond */


  /*@}*/  

} // ivllib

#endif
