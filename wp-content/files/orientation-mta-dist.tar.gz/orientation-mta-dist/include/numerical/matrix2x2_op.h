#ifndef IVLLIB_MATRIX2X2_OP_H
#define IVLLIB_MATRIX2X2_OP_H

//--- Headers ---------------------------------------------------
#include "numerical/matrix2x2.h"
#include <cassert>
#include <cmath>

namespace ivllib {

  /** \addtogroup numerical */
  /*@{*/

  /**
   * computes the transpose of a matrix.
   * @param m the input matrix
   * @param out the output matrix
   */
  template<typename T>
    inline void transpose (const Matrix2x2<T>& m, 
			   Matrix2x2<T>& out);


  /**
   * build a 2D rotation matrix by the angle specified as argument.
   *
   * @param m the output rotation matrix
   * @param theta the angle of rotation in radians
   */
  template<typename T>
    void buildRotationMatrix (Matrix2x2<T>& m, 
			      T theta);

  /**
   * Matrix2x2 multiplication
   * @param mat1 first matrix
   * @param mat2 second matrix
   * @param out result matrix (mat1 * mat2)
   */
  template <typename T>
    inline void mul(const Matrix2x2<T>& mat1, 
		    const Matrix2x2<T>& mat2, 
		    Matrix2x2<T>& out);

  
  /**
   * Matrix2x2 - Vector2 multiplication
   * @param mat1 input matrix
   * @param vec input vector
   * @param out result vector
   */
  template <typename T>
    inline void mul(const Matrix2x2<T>& mat1, 
		    const Vector2<T>& vec, 
		    Vector2<T>& out);

  /**
   * set the matrix to identity
   */
  template <typename T>
    void Identity(Matrix2x2<T>& m);

  //----------------------------------------------------------
  //Implementation
  //----------------------------------------------------------
  template <typename T>
    void Identity(Matrix2x2<T>& m)
    {
      m.set( 1,0,
	     0,1);
    }
  //----------------------------------------------------------
  template<typename T>
    inline void transpose (const Matrix2x2<T>& m, 
			   Matrix2x2<T>& out)
    {
    assert( &m != &out );

      out[0][0] = m [0][0];
      out[0][1] = m [1][0];
      out[1][0] = m [0][1];
      out[1][1] = m [1][1];
    }

  //-----------------------------------------------------------
  template<typename T>
    void buildRotationMatrix (Matrix2x2<T>& m, 
			      T theta)
    {
      m[0][0] = std::cos(theta);
      m[0][1] = std::sin(theta);
      m[1][0] = -std::sin(theta);
      m[1][1] = std::cos(theta);
    }

  //-----------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix2x2<T>& mat1, 
		    const Matrix2x2<T>& mat2, 
		    Matrix2x2<T>& out)
    {
  
      assert(&mat1 != &out);
      assert(&mat2 != &out);
  
#define m2x2_compute(r,c) out[(r)][(c)] = mat1[(r)][0] * mat2[0][(c)] + \
	mat1[(r)][1] * mat2[1][(c)];
  
      m2x2_compute(0,0);
      m2x2_compute(0,1);
      m2x2_compute(1,0);
      m2x2_compute(1,1);
  
#undef m2x2_compute
    }

  //-----------------------------------------------------------
  template <typename T>
    inline void mul(const Matrix2x2<T>& mat1, 
		    const Vector2<T>& vec, 
		    Vector2<T>& out)
    {
     
      out.x = mat1[0][0] * vec.x + mat1[0][1] * vec.y;
      out.y = mat1[1][0] * vec.x + mat1[1][1] * vec.y;
    }

  /*@}*/

} //namespace ivllib

#endif //IVLLIB_MATRIX2X2_OP_H
