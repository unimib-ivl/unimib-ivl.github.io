/**
 * \file queue.h
 *
 * \author Claudio Cusano
 *
 * \brief A synchronized FIFO queue for multi-threaded applications.
 */

#ifndef cc_queue_h
#define cc_queue_h


#include <threading/threading.h>
#include <memory>


namespace cc
{

  /**
   * A synchronized queue for multi-threaded communication.
   *
   * Multiple threads can safely push and pop elements in the queue.
   * Elements are returned in a FIFO order.  The queue has a capacity
   * which limits the number of elements that can be hold.  When such
   * a limit is reached, the threads which want to push new elements
   * must wait until some other thread pop an element.  When the queue
   * is closed it is not possible to insert new elements, but elements
   * which have been already inserted can still be popped out.
   */
  template <typename T, typename Allocator = std::allocator<T> >
  class Queue
  {
  public:

    /// Allocator type.
    typedef Allocator allocator_type;

    /// Element type.
    typedef typename allocator_type::value_type value_type;

    /// Reference to element.
    typedef typename allocator_type::reference reference;

    /// Constant reference to element.
    typedef typename allocator_type::const_reference const_reference;

    /// Quantities of elements.
    typedef typename allocator_type::size_type size_type;


    /**
     * Constructor.
     *
     * \pre sz >= 0
     *
     * \post is_open() == (sz > 0)
     * \post capacity() == sz
     */
    explicit Queue(size_type sz = 0);
    
    /**
     * Constructor.
     *
     * \post is_open() == false
     * \post capacity() == 0
     */
    explicit Queue(const allocator_type& allocator);

    /**
     * Constructor.
     *
     * \pre sz >= 0
     *
     * \post is_open() == (sz > 0)
     * \post capacity() == sz
     */
    Queue(size_type sz, const allocator_type& allocator);

    /// Destructor.
    ~Queue();

    /// Retrieve the capacity of the queue.
    size_type capacity() const;

    /**
     * Change the capacity of the queue.
     *
     * If a reallocation occurs, old elements are copied into the new
     * internal buffer.  The new capacity is the maximum between \a
     * new_capacity and the number of elements stored.
     *
     * \param new_capacity the capacity of the queue
     *
     * \pre new_capacity >= 0
     *
     * \post capacity() >= new_capacity
     */
    void set_capacity(size_type new_capacity);

    /**
     * Open the queue.
     *
     * The capacity of the queue is changed according to \a
     * new_capacity.  Elements already contained are preserved.
     *
     * \param new_capacity the new capacity of the queue
     *
     * \pre new_capacity >= 0     
     *
     * \post is_open()
     * \post capacity() >= new_capacity
     */
    void open(size_type new_capacity);

    /** Close the queue.
     *
     * \post !is_open()
     */
    void close();

    /// Tell if the queue is open
    bool is_open() const;

    /**
     * Put an element into the queue.
     *
     * Insert \a x into the queue. If the queue is full the thread
     * waits until an element is popped by another thread. If the
     * queue is closed the element is not inserted and the method
     * returns false.
     *
     * \param x the element to be inserted
     *
     * \return true if the element has been inserted, false otherwise.
     */
    bool push(const_reference x);

    /**
     * Get an element from the queue.
     *
     * Extract an element from the queue and put it into \a x.  If the
     * queue is empty the thread waits until an element is pushed by
     * another thread, or the queue is closed. If the queue is empty
     * and closed the content of \a x is not changed and the method
     * returns false.
     *
     * \param x reference where the extracted element will be copied
     *
     * \return true if an element has been extracted, false otherwise.
     */
    bool pop(reference x);

    /// Delete all elements in the queue.
    void clear();

    /// Return the allocator object used to constuct the queue.
    allocator_type get_allocator() const;

  private:

    // Pointer to element.
    typedef typename allocator_type::pointer pointer;

    // Deny copy.
    Queue(const Queue&);

    // Deny assignment.
    Queue& operator=(const Queue&);

    // Next pointer in the buffer.
    pointer next_(pointer p) const;

    // Tell if the queue is empty
    bool is_empty_() const;

    // Tell if the queue is full
    bool is_full_() const;

    allocator_type alloc_;  // The allocator
    pointer begin_;  // Begin of the allocated buffer
    pointer end_;  // End of the allocated buffer
    pointer front_;  // First element
    pointer back_;  // Past the last element
    bool open_;  // Open/closed flag
    cc::Mutex mutex_;  // For synchronization
    cc::Condition empty_cond_;  // For synchronization
    cc::Condition full_cond_;  // For synchronization

  };  // class Queue

}  // namespace cc


template <typename T, typename A>
cc::Queue<T, A>::Queue(size_type sz)
  : alloc_(),
    begin_(0),
    end_(0),
    front_(0),
    back_(0),
    open_(sz > 0),
    mutex_(),
    empty_cond_(),
    full_cond_()
{
  begin_ = alloc_.allocate(sz + 1);
  end_ = begin_ + (sz + 1);
  front_ = begin_;
  back_ = begin_;
}


template <typename T, typename A>
cc::Queue<T, A>::Queue(const allocator_type& allocator)
  : alloc_(allocator),
    begin_(0),
    end_(0),
    front_(0),
    back_(0),
    open_(false),
    mutex_(),
    empty_cond_(),
    full_cond_()
{
  begin_ = alloc_.allocate(1);
  end_ = begin_ + 1;
  front_ = begin_;
  back_ = begin_;
}


template <typename T, typename A>
cc::Queue<T, A>::Queue(size_type sz, const allocator_type& allocator)
  : alloc_(allocator),
    begin_(0),
    end_(0),
    front_(0),
    back_(0),
    open_(sz > 0),
    mutex_(),
    empty_cond_(),
    full_cond_()
{
  begin_ = alloc_.allocate(sz + 1);
  end_ = begin_ + (sz + 1);
  front_ = begin_;
  back_ = begin_;
}


template <typename T, typename A>
cc::Queue<T, A>::~Queue()
{
  clear();
  alloc_.deallocate(begin_, end_ - begin_);
}


template <typename T, typename A>
typename cc::Queue<T, A>::size_type
cc::Queue<T, A>::capacity() const
{
  return (end_ - begin_) - 1;
}


template <typename T, typename A>
void cc::Queue<T, A>::set_capacity(size_type new_capacity)
{
  cc::Lock lock(mutex_);  

  // compute the actual number of enqueued elements
  size_type sz = (front_ <= back_
		  ? back_ - front_
		  : (end_ - front_) + (back_ - begin_));

  // ensure that there is enough space to store the elements
  if (new_capacity < sz)
    new_capacity = sz;
  
  if (capacity() == new_capacity)
    return;

  // allocate the new buffer and copy the elements into it
  pointer new_buf = alloc_.allocate(new_capacity + 1);
  pointer new_back = new_buf;
  try {
    for (pointer p = front_; p != back_; p = next_(p)) {
      alloc_.construct(new_back, *p);
      ++new_back;
    }
  } catch (...) {
    while (new_back != new_buf) {
      --new_back;
      alloc_.destroy(new_back);
    }
    throw;
  }
    
  // free the old buffer
  clear();
  alloc_.deallocate(begin_);
    
  // setup the new buffer
  begin_ = new_buf;
  end_ = begin_ + (new_capacity + 1);
  front_ = begin_;
  back_ = new_back;

  // wakeup threads waiting for insertion
  full_cond_.notify_all();
}


template <typename T, typename A>
void cc::Queue<T, A>::open(size_type new_capacity)
{
  set_capacity(new_capacity);
  cc::Lock lock(mutex_);
  open_ = true;
}


template <typename T, typename A>
void cc::Queue<T, A>::close()
{
  cc::Lock lock(mutex_);
  open_ = false;
  empty_cond_.notify_all();
  full_cond_.notify_all();
}


template <typename T, typename A>
bool cc::Queue<T, A>::is_open() const
{
  return open_;
}


template <typename T, typename A>
bool cc::Queue<T, A>::push(const_reference x)
{  
  cc::Lock lock(mutex_);

  // wait while the queue is full and open
  while (is_open() && is_full_())
    full_cond_.wait(lock);    
  
  if (!is_open())
    return false;

  // insert the new element and notify the event
  alloc_.construct(back_, x);
  back_ = next_(back_);
  empty_cond_.notify();
  
  return true;
}


template <typename T, typename A>
bool cc::Queue<T, A>::pop(reference x)
{
  cc::Lock lock(mutex_);

  // wait while the queue is empty and open
  while (is_open() && is_empty_())
    empty_cond_.wait(lock);
  
  if (is_empty_())
    return false;

  // extract the element and notify the event
  full_cond_.notify();
  x = *front_;
  alloc_.destroy(front_);
  front_ = next_(front_);
  
  return true;
}


template <typename T, typename A>
void cc::Queue<T, A>::clear()
{
  cc::Lock lock(mutex_);
  for (pointer p = front_; p != back_; p = next_(p))
    alloc_.destroy(p);
  front_ = begin_;
  back_ = begin_;
}


template <typename T, typename A>
typename cc::Queue<T, A>::allocator_type
cc::Queue<T, A>::get_allocator() const
{
  return alloc_;
}


template <typename T, typename A>
typename cc::Queue<T, A>::pointer
cc::Queue<T, A>::next_(pointer p) const
{
  ++p;
  if (p == end_)
    p = begin_;
  return p;
}


template <typename T, typename A>
bool cc::Queue<T, A>::is_empty_() const
{
  return front_ == back_;
}


template <typename T, typename A>
bool cc::Queue<T, A>::is_full_() const
{
  return (next_(back_) == front_);
}



//----------------------------------------------------------------------
// Implementation


#endif  // cc_queue_h
