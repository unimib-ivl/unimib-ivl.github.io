/**
 * \file threading.h
 *
 * \author Claudio Cusano
 *
 * \brief A minimal framework for multi-threading.
 */

#ifndef cc_threading_h
#define cc_threading_h


#include <tr1/functional>


namespace cc
{

  /**
   * Class representing a thread.
   *
   * The thread is activated by the start method.  The code to execute
   * must be passed as a functor to the start method.
   */
  class Thread
  {
  public:

    /**
     * Constructor.
     *
     * \post !joinable()
     */
    Thread();

    /**
     * Destructor.
     *
     * If the thread is joinable the detach method is called.
     */
    virtual ~Thread();

    /**
     * Start the thread.
     *
     * A copy of the function \a f is executed into the new thread.
     *
     * \pre !joinable()
     *
     * \post joinable()
     */
    void start(const std::tr1::function<void()>& f);

    /**
     * Join the thread.
     *
     * Wait for the termination of the thread.  If the thread ends
     * with an exception, a runtime_error is propagated to the caller
     * of the join method.
     *
     * \pre joinable()
     *
     * \post !joinable()
     */
    void join();

    /**
     * Tell if the thread of execution is joinable.
     *
     * \return true iff the thread is joinable
     */
    bool joinable() const;

    /**
     * Detach a joinable thread.
     *
     * When the associated thread terminates, its resources are
     * reclaimed.  The std::terminated funciton is called if the
     * thread ends because of an uncaught exception.
     *
     * \pre joinable()
     * \post !joinable()
     */
    void detach();

  private:

    // deny copy
    Thread(const Thread&);

    // deny assignement
    Thread& operator=(const Thread&);

    static void* thread_run_(void*);

    struct impl;
    impl* impl_;

  };  // class Thread


  /**
   * A mutex for multi-threading synchronization.
   */
  class Mutex
  {
  public:

    /// Constructor.
    Mutex();

    /// Destructor.
    ~Mutex();

    /**
     * Lock the mutex. The caller is put into the waiting queue until
     * the mutex is locked by other threads.
     */
    void lock();

    /**
     * Lock the mutex.
     *
     * If unlocked, the mutex is locked and the method return
     * true. Otherwise, the mutex is kept locked and the method return
     * false.
     */
    bool trylock();

    /// Unlock the mutex.
    void unlock();

  private:

    // deny copy
    Mutex(const Mutex&);

    // deny assignement
    Mutex operator=(const Mutex&);

    struct impl;
    impl* impl_;

    friend class Condition;

  };  // class Mutex


  /**
   * RAII acquisition of a mutex.
   */
  class Lock
  {
  public:

    /// Constructor.
    Lock();

    /**
     * Constructor.
     *
     * The mutex \a m is locked.
     */
    explicit Lock(Mutex& m);

    /**
     * Destructor.
     *
     * If a mutex is locked is it first unlocked.
     */
    ~Lock();

    /**
     * Lock a mutex.
     *
     * If another mutex is locked, it is unlocked after that \a m has
     * been locked.
     */
    void lock(Mutex& m);

    /**
     * Lock a mutex.
     *
     * Return true if \a m was unlocked (and has been now locked).
     * Return false otherwise. If another mutex is locked, it is
     * unlocked after that \a m has been successfully locked.  If \a m
     * has not been locked, the other mutex is not unlocked.
     */
    bool trylock(Mutex& m);

    /**
     * Unlock a mutex, if any.
     *
     * It is ok to call the method when locked() is false.
     */
    void unlock();

    /// Return true iff a mutex is currently locked.
    bool locked() const;

  private:

    // deny copy
    Lock(const Lock&);

    // deny assignement
    Lock operator=(const Lock&);

    // the mutex (null if no mutex has been locked).
    Mutex* mutex_;

    friend class Condition;

  };  // class Lock


  /**
   * Condition variable.
   *
   * Condition variables allow threads to synchronize based upon the
   * actual value of data.  Without condition variables, the
   * programmer would need to have threads continually polling to
   * check if a condition is met. A condition variable is always used
   * in conjunction with a mutex via a lock object.
   */
  class Condition
  {
  public:

    /// Constructor
    Condition();

    /// Destructor
    ~Condition();

    /**
     * Block the calling thread until the condition is notified.
     *
     * This method should be called while a mutex is locked by \a l.
     * The method automatically release the mutex while it
     * waits. After notification is received the thread is awakened,
     * and the mutex will be automatically locked within \a l for use
     * by the thread. The programmer is then responsible for unlocking
     * the mutex when the thread is finished with it.
     *
     * \param l lock object which locks a mutex
     *
     * \pre l.locked()
     *
     * \post l.locked()
     */
    void wait(Lock& l);

    /**
     * Wait for a condition, or a timeout.
     *
     * Block the calling thread until the condition is notified, or
     * after \a timeout seconds. The method should be called while a
     * mutex is locked by \a l.  While waiting, the mutex is released.
     * When the method returns, and the mutex is locked by \a l. The
     * programmer is then responsible for unlocking the mutex when the
     * thread is finished with it.  The method return true if the
     * condition has been notified.  The method return false in the
     * case of a timeout.
     *
     * \param l lock object which locks a mutex
     * \param timeout maximum blocking time (in seconds)
     *
     * \pre l.locked()
     * \pre timeout >= 0
     *
     * \post l.locked()
     *
     * \return true if the condition has been notified, false
     * if the timeout occurred.
     */
    bool wait(Lock& l, double timeout);

    /*
     * Wake up another thread which is waiting on the condition.
     *
     * The mutex on which the waiting threads are blocked should be
     * locked before notification and unlocked after, in order for
     * wait() method to complete.
     */
    void notify();

    /*
     * Wake up all the threads waiting on the condition.
     *
     * The mutex on which the waiting threads are blocked should be
     * locked before notification and unlocked after, in order for
     * wait() method to complete.
     */
    void notify_all();

  private:

    // deny copy
    Condition(const Condition&);

    // deny assignment
    Condition& operator=(const Condition&);

    struct impl;

    impl* impl_;

  };  // class Condition

}  // namespace cc


#endif  // cc_threading_h
