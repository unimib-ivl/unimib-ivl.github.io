#ifndef features_basic_features_h
#define features_basic_features_h

/**
 * \file basic_features.h
 *
 * Common image features:
 * - moments in the YUV feature space;
 * - histogram of the RGB components;
 * - edge direction histogram;
 * - lbp histograms.
 */

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <ivl_box.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <imaging/yuv.h>
#include <imaging/labeling.h>
#include <cstddef>
#include <cmath>


/**
 * Computed the histogram on \a img.
 *
 * Put into \a out the counts of the labels in \a img.  The labels in
 * \a img must be non-negative and smaller than \a nbins.
 *
 * \param img input quantized image
 * \param nbins number of bins in the histogram
 * \param out output histogram
 *
 * \post out.size() == nbins
 */
void make_histogram(const ivllib::Matrix<ivllib::label_type>& img,
		    ivllib::label_type nbins,
		    ivllib::Vector<std::size_t>& out);


/**
 * Computed the histogram on \a img.
 *
 * Put into \a out the counts of the pixels in \a box.  The labels of
 * the pixels in \a box must be non-negative and smaller than \a
 * nbins.
 *
 * \param img input quantized image
 * \param nbins number of bins in the histogram
 * \param out output histogram
 *
 * \pre box.bottom() <= img.rows()
 * \pre box.right() <= img.columns()
 * \post out.size() == nbins
 */
void make_histogram(const ivllib::Matrix<ivllib::label_type>& img,
		    ivllib::label_type nbins,
		    const ivllib::Box& box,
		    ivllib::Vector<std::size_t>& out);


/**
 * Normalized the histogram to have unitary sum.
 *
 * \post in.size() == out.size()
 */
void normalize_histogram(const ivllib::Vector<std::size_t>& in,
			 ivllib::Vector<double>& out);


/**
 * Moments in the YUV color space.
 *
 * Compute the moments on the whole image converted in the YUV space.
 *
 * \param img input image
 * \param box area on which the moments are computed
 * \param output features
 * \param normalized normalization flag
 *
 * \pre box.bottom() <= img.rows()
 * \pre box.right() <= img.columns()
 *
 * \post features.size() == 6
 */
void yuvmoments(const ivllib::Matrix<ivllib::RGB8>& img,
		ivllib::Vector<double>& features,
		bool normalized=false);


/**
 * Moments in the YUV color space.
 *
 * Compute the mean and standard deviation of the YUV components.
 * The components of the resulting vector are (in order):
 * - mean Y;
 * - mean U;
 * - mean V;
 * - standard deviation of Y;
 * - standard deviation of U;
 * - standard deviation of V.
 *
 * The optional normalization scale the means by 255 and the
 * deviations by 127.5 so that they will fall in the range [0,1].
 *
 * \param img input image
 * \param box area on which the moments are computed
 * \param output features
 * \param normalized normalization flag
 *
 * \pre box.bottom() <= img.rows()
 * \pre box.right() <= img.columns()
 *
 * \post features.size() == 6
 */
void yuvmoments(const ivllib::Matrix<ivllib::YUV8>& img,
		const ivllib::Box& box,
		ivllib::Vector<double>& features,
		bool normalized=false);



/**
 * Quantize the RGB image.
 *
 * The output labels represent the combined quantization of the red,
 * green, and blue channel.
 * \f[
 * label = \frac{R \times q_R}{256} \times q_G \times q_B +
 * \frac{G \times q_G}{256} \times q_B +
 * \frac{B \times q_B}{256}.
 * \f]
 *
 * \param img input image
 * \param qred bins for the red channel
 * \param qgreen bins for the green channel
 * \param qblue bins for the blue channel
 * \param out output quantized image
 *
 * \pre qred >= 1
 * \pre qgreen >= 1
 * \pre qblue >= 1
 * \pre qred <= 256
 * \pre qgreen <= 256
 * \pre qblue <= 256
 *
 * \post img.rows() == out.rows()
 * \post img.columns() == out.columns()
 */
void rgbquantization(const ivllib::Matrix<ivllib::RGB8>& img,
		     int qred,
		     int qgreen,
		     int qblue,
		     ivllib::Matrix<ivllib::label_type>& out);


void edgedirections(const ivllib::Matrix<ivllib::Gray8>& img,
		    int ndirs,
		    ivllib::Matrix<ivllib::label_type>& out,
		    double sigma=1.0,
		    double threshold=0.5);



// LBP Computation.

typedef ivllib::label_type lbp_type;

/**
 * Create a look up table for LBP patterns.
 *
 * Create a mapping from raw patterns to the final lbp encoding.
 *
 * \param n number of neighbors
 * \param rotinv tell if the patterns need to be rotation invariant
 * \param uniform teel if uniform patterns are considered
 *
 * \return the number of distinct patterns stored in the lut.
 *
 * \pre n > 0
 * \pre n <= 16
 */
ivllib::Vector<lbp_type>::size_type
make_lbp_lut(int n, bool rotinv, bool uniform, ivllib::Vector<lbp_type>& lut);






/**
 * Compute an image of raw LBPs (i.e. non uniform, non rotation invariant).
 *
 * \param n number of neighbors
 * \param r radius of the neighborhood
 * \param pred ordering functor
 * \param blend blending functor
 *
 * \pre n > 0
 * \pre n <= 16
 * \pre r > 0
 */
template <typename T, typename BinPred, typename Blend>
void rawlbp(const ivllib::Matrix<T>& in,
	    int n,
	    double r,
	    ivllib::Matrix<lbp_type>& out,
	    BinPred pred,
	    Blend blend)
{
  assert(n > 0);
  assert(n <= 16);
  assert(r > 0);

  typedef typename ivllib::Matrix<lbp_type>::size_type size_type;
  const double pi = 3.141592653589793;

  // Precompute the indices and coefficients for the bilinear
  // interpolation.
  ivllib::Vector<int> di(n);
  ivllib::Vector<int> dj(n);
  ivllib::Vector<double> ai(n);
  ivllib::Vector<double> aj(n);
  for (int c = 0; c < n; c++) {
    double a = (c * pi * 2) / n;
    double x = r * std::cos(a);
    double y = -r * std::sin(a);

    double tmp = std::floor(y);
    di[c] = tmp;
    ai[c] = 1 - (y - tmp);
    tmp = std::floor(x);
    dj[c] = tmp;
    aj[c] = 1 - (x - tmp);
  }

  size_type rows = in.rows();
  size_type cols = in.columns();
  ivllib::Matrix<lbp_type> lbp(rows, cols);

  if (rows < 2 || cols < 2) {
    out.swap(lbp);
    return;
  }
  
  // Precompute the coordinates in the image plane.
  ivllib::Matrix<size_type> ii(rows, n);
  for (size_type i = 0; i < rows; i++)
    for (int c = 0; c < n; c++)
      ii[i][c] = std::min<int>(std::max<int>(0, i + di[c]), rows - 2);

  ivllib::Matrix<size_type> jj(cols, n);
  for (size_type j = 0; j < cols; j++)
    for (int c = 0; c < n; c++)
      jj[j][c] = std::min<int>(std::max<int>(0, j + dj[c]), cols - 2);
  

  // Compute the patterns.
  for (size_type i = 0; i < rows; i++) {
    for (size_type j = 0; j < cols; j++) {
      size_type p = 0;
      for (int c = 0; c < n; c++) {
	T val = blend(blend(in[ii[i][c]][jj[j][c]],
			    in[ii[i][c] + 1][jj[j][c]],
			    ai[c]),
		      blend(in[ii[i][c]][jj[j][c] + 1],
			    in[ii[i][c] + 1][jj[j][c] + 1],
			    ai[c]),
		      aj[c]);
	if (pred(in[i][j], val))
	  p = p | (1 << c);
      }
      lbp[i][j] = p;
    }
  }
  
  out.swap(lbp);
}


/**
 * Compute an image of LBPs.
 *
 * It uses a LUT made by make_lbp_lut.
 *
 * \param n number of neighbors
 * \param r radius of the neighborhood
 * \param lut look up table.
 * \param pred ordering functor
 * \param blend blending functor
 *
 * \pre n > 0
 * \pre n <= 16
 * \pre r > 0
 */
template <typename T, typename BinPred, typename Blend>
void lbpimage(const ivllib::Matrix<T>& in,
	      int n,
	      double r,
	      const ivllib::Vector<lbp_type>& lut,
	      ivllib::Matrix<lbp_type>& out,
	      BinPred pred,
	      Blend blend)
{
  typedef ivllib::Matrix<lbp_type>::size_type size_type;
  ivllib::Matrix<lbp_type> ret;
  rawlbp(in, n, r, ret, pred, blend);
  
  size_type rows = ret.rows();
  size_type cols = ret.columns();

  for (size_type i = 0; i < rows; i++)
    for (size_type j = 0; j < cols; j++)
      ret[i][j] = lut[ret[i][j]];

  out.swap(ret);
}


/**
 * Compute an image of LBPs.
 *
 * See the more general version.
 */
template <typename T>
void lbpimage(const ivllib::Matrix<T>& in,
	      int n,
	      double r,
	      const ivllib::Vector<lbp_type>& lut,
	      ivllib::Matrix<lbp_type>& out)
{
  lbpimage(in, n, r, lut, out, std::less<T>(), ivllib::Blend<T>());
}


#endif  // features_basic_features_h
