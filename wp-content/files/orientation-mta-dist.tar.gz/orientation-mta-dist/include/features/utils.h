#ifndef features_utils_h
#define features_utils_h


/**
 * \file utils.h
 *
 * Some routines about features I/O, sparsification, etc...
 */


#include <istream>
#include <ostream>
#include <string>
#include <ivl_vector.h>
#include <vector>
#include <utility>


std::istream&
read_features(std::istream& is, ivllib::Vector<double>& v);

std::istream&
read_features(std::istream& is, std::string& label, ivllib::Vector<double>& v);

std::ostream&
write_features(std::ostream& os, const ivllib::Vector<double>& v);

std::ostream&
write_features(std::ostream& os,
	       const std::string& label,
	       const ivllib::Vector<double>& v);


void
sparsify(const ivllib::Vector<double>& dense,
	 std::vector<std::pair<long, double> >& sparse,
	 double toll=1e-15);


void
unsparsify(const std::vector<std::pair<long, double> >& sparse,
	   ivllib::Vector<double>& dense,
	   ivllib::Vector<double>::size_type minsize=0);


std::istream&
read_sparse_features(std::istream& is, std::vector<std::pair<long, double> >& v);

std::istream&
read_sparse_features(std::istream& is,
		     std::string& label,
		     std::vector<std::pair<long, double> >& v);

std::ostream&
write_sparse_features(std::ostream& os,
		      const std::vector<std::pair<long, double> >& sparse);

std::ostream&
write_sparse_features(std::ostream& os,
		      const std::string& label,
		      const std::vector<std::pair<long, double> >& sparse,
		      long start_index=1);


#endif  // features_utils_h
