/**
 * \file    mat_algorithm.h
 * \brief   stl-like algorithms on matrices
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef mat_algorithm_h
#define mat_algorithm_h

#include <ivl_matrix.h>
#include <ivl_box.h>

#include <algorithm>
#include <numeric>
#include <cassert>

namespace ivllib
{
  /** \addtogroup basic */
  /*@{*/

  /**
   * Copy the elements of a matrix into another matrix
   *
   * The output matrix is resized to the same dimension
   * of the input matrix. The elements of the input matrix
   * must be assignable to the elements of the output matrix.
   *
   * \param src input matrix
   * \param dst output matrix
   *
   * \post dst.rows() == src.rows()
   * \post dst.columns() == src.columns()
   */
  template <typename T,typename U>
  void mat_copy(const Matrix<T>& src,Matrix<U>& dst);

  /**
   * Element-wise transformation
   *
   * Apply an operation to the elements of a matrix and put the
   * result into another matrix.
   * The output matrix is resized to the same dimension
   * of the input matrix. The expression
   * <tt> dst[i][j] = op(src[i][j]) </tt> must be valid.
   *
   * \param src input matrix
   * \param dst output matrix
   * \param op operation
   *
   * \post dst.rows() == src.rows()
   * \post dst.columns() == src.columns()
   */
  template <typename T,typename U,typename UnaryOp>
  void mat_transform(const Matrix<T>& src,
		     Matrix<U>& dst,
		     UnaryOp op);

  /**
   * Element-wise transformation
   *
   * Apply an operation to the elements of two matrices and put the
   * result into another matrix.
   * The output matrix is resized to the same dimension
   * of the input matrix. The expression
   * <tt> dst[i][j] = op(src1[i][j],src2[i][j]) </tt> must be valid.
   *
   * \param src1 first input matrix
   * \param src2 second input matrix
   * \param dst output matrix
   * \param op operation
   *
   * \pre src1.rows() == src2.rows()
   * \pre src1.columns() == src2.columns()
   *
   * \post dst.rows() == src1.rows()
   * \post dst.columns() == src1.columns()
   */
  template <typename T,typename U,typename V,typename BinaryOp>
  void mat_transform(const Matrix<T>& src1,
		     const Matrix<U>& src2,
		     Matrix<V>& dst,
		     BinaryOp op);

  /**
   * Copy a block of elements
   *
   * The elements of \p src inside \p sbox are copy in the matrix \p dst.
   * Destination pixel are inside \p dbox.
   * The elements of the input matrix must be assignable to the
   * elements of the output matrix.
   *
   * \param src input matrix
   * \param sbox source box
   * \param dst output matrix
   * \param dbox destination box
   *
   * \pre sbox.bottom() - sbox.top() == dbox.bottom() - dbox.top()
   * \pre sbox.right() - sbox.left() == dbox.right() - dbox.left()
   * \pre sbox.bottom() <= src.rows()
   * \pre sbox.right() <= src.columns()
   * \pre dbox.bottom() <= dst.rows()
   * \pre dbox.right() <= dst.columns()
   */
  template <typename T,typename U>
  void mat_copy_box(const Matrix<T>& src,const Box& sbox,
		    Matrix<U>& dst, const Box& dbox);

  /**
   * Element-wise transformation
   *
   * Apply an operation to the elements of a matrix inside a box
   * and put the result into another matrix.
   * The expression <tt> dst[i][j] = op(src[i][j])</tt>
   * must be valid.
   *
   * \param src input matrix
   * \param sbox source box
   * \param dst output matrix
   * \param dbox destination box
   * \param op operation
   *
   * \pre sbox.bottom() - sbox.top() == dbox.bottom() - dbox.top()
   * \pre sbox.right() - sbox.left() == dbox.right() - dbox.left()
   * \pre sbox.bottom() <= src.rows()
   * \pre sbox.right() <= src.columns()
   * \pre dbox.bottom() <= dst.rows()
   * \pre dbox.right() <= dst.columns()
   */
  template <typename T,typename U,typename UnaryOp>
  void mat_transform_box(const Matrix<T>& src,const Box& sbox,
			 Matrix<U>& dst, const Box& dbox,
			 UnaryOp op);

  /**
   * Element-wise transformation
   *
   * Apply an operation to the elements of two matrices inside and
   * put the result into another matrix. Only the elements inside
   * the specified boxes are considered.
   * The expression <tt> dst[i][j] = op(src1[i][j],src2[i][j])</tt>
   * must be valid.
   *
   * \param src1 first input matrix
   * \param sbox1 first source box
   * \param src2 second input matrix
   * \param sbox2 second source box
   * \param dst output matrix
   * \param dbox destination box
   * \param op operation
   *
   * \pre sbox1.bottom() - sbox1.top() == dbox.bottom() - dbox.top()
   * \pre sbox1.right() - sbox1.left() == dbox.right() - dbox.left()
   * \pre sbox1.bottom() <= src1.rows()
   * \pre sbox1.right() <= src1.columns()
   * \pre sbox2.bottom() - sbox2.top() == dbox.bottom() - dbox.top()
   * \pre sbox2.right() - sbox2.left() == dbox.right() - dbox.left()
   * \pre sbox2.bottom() <= src2.rows()
   * \pre sbox2.right() <= src2.columns()
   * \pre dbox.bottom() <= dst.rows()
   * \pre dbox.right() <= dst.columns()
   */
  template <typename T,typename U,typename V,typename BinaryOp>
  void mat_transform_box(const Matrix<T>& src1,const Box& sbox1,
			 const Matrix<U>& src2,const Box& sbox2,
			 Matrix<V>& dst, const Box& dbox,
			 BinaryOp op);

  /**
   * Assign a value to all elements of a matrix
   *
   * A value of tpye \p U must be assignamble to
   * a variable of type \p T.
   *
   * \param dst matrix to be modified
   * \param value value to be assigned
   */
  template <typename T,typename U>
  void mat_fill(Matrix<T>& dst,const U& value);

  /**
   * Assign a value to all elements of a matrix inside a box
   *
   * A value of tpye \p U must be assignamble to
   * a variable of type \p T.
   *
   * \param dst matrix to be modified
   * \param box bounds of the modified elements
   * \param value value to be assigned
   */
  template <typename T,typename U>
  void mat_fill_box(Matrix<T>& dst,const Box& box,const U& value);

  /**
   * Accumulate all elements in a matrix into a single value
   *
   * Sum the elements of a matrix.
   * The result of each operation is returned in \p init.
   * This process aggregates the result of performing the operation on
   * every element of the matrix into a single value.
   * \p init is modified with <tt>init = init + src[i][j]</tt>.
   *
   * \param src input matix
   * \param init initial value
   *
   */
  template <typename T,typename U>
  U mat_accumulate(const Matrix<T>& src,U init);

  /**
   * Accumulate all elements in a matrix into a single value
   *
   * Applies a binary operation to \p init and each value in the matrix.
   * The result of each operation is returned in \p init.
   * This process aggregates the result of performing the operation on
   * every element of the matrix into a single value.
   * \p init is modified with <tt>init = bin_op(init,src[i][j])</tt>.
   *
   * \param src input matix
   * \param init initial value
   * \param bin_op binary functor
   */
  template <typename T,typename U,typename BinOp>
  U mat_accumulate(const Matrix<T>& src,U init,BinOp bin_op);

  /**
   * Accumulate all elements in a matrix into a single value
   *
   * Sum the elements of a matrix inside a given box.
   * The result of each operation is returned in \p init.
   * This process aggregates the result of performing the operation on
   * every element of the matrix into a single value.
   * \p init is modified with <tt>init = init + src[i][j]</tt>.
   *
   * \param src input matix
   * \param box input box
   * \param init initial value
   *
   * \pre box.bottom() <= src.rows()
   * \pre box.rigth() <= src.columns()
   */
  template <typename T,typename U>
  U mat_accumulate_box(const Matrix<T>& src,const Box& box,U init);

  /**
   * Accumulate all elements in a matrix into a single value
   *
   * Applies a binary operation to \p init and each value in the matrix
   * inside a given box.
   * The result of each operation is returned in \p init.
   * This process aggregates the result of performing the operation on
   * every element of the matrix into a single value.
   * \p init is modified with <tt>init = bin_op(init,src[i][j])</tt>.
   *
   * \param src input matix
   * \param box input box
   * \param init initial value
   * \param bin_op binary functor
   *
   * \pre box.bottom() <= src.rows()
   * \pre box.rigth() <= src.columns()
   */
  template <typename T,typename U,typename BinOp>
  U mat_accumulate_box(const Matrix<T>& src,
		       const Box& box,
		       U init,
		       BinOp bin_op);

  /**
   * Compute inner product of two matrices
   *
   * Starting with an initial value of \a init, multiplies 
   * corresponding elements of the two matrices and sum
   * each result into the accumulated value
   *
   * \param a first input matrix
   * \param b second input matrix
   * \param init starting value to add other values to
   * \return the final inner product
   *
   * \pre a.rows() == b.rows()
   * \pre a.columns() == b.columns()
   */
  template <typename T,typename U,typename V>
  V mat_inner_product(const Matrix<T>& a,
		      const Matrix<U>& b,
		      V init);

  /**
   * Compute inner product of two matrices
   *
   * Starting with an initial value of \a init, applies \a op2 to
   * corresponding elements of the two matrices and accumulates
   * each result into the accumulated value using \a op1.
   *
   * \param a first input matrix
   * \param b second input matrix
   * \param init starting value to add other values to
   * \param op1 function object to accumulate with
   * \param op2 function object to apply to pairs of input values
   * \return the final inner product
   *
   * \pre a.rows() == b.rows()
   * \pre a.columns() == b.columns()
   */
  template <typename T,typename U,typename V,typename BinOp1,typename BinOp2>
  V mat_inner_product(const Matrix<T>& a,
		      const Matrix<U>& b,
		      V init,
		      BinOp1 op1,
		      BinOp2 op2);

  /**
   * Compute inner product of two sub-matrices
   *
   * Starting with an initial value of \a init, multiplies 
   * corresponding elements of the two sub-matrices and sum
   * each result into the accumulated value
   *
   * \param a first input matrix
   * \param box_a first sub-matrix boundary
   * \param b second input matrix
   * \param box_b second sub-matrix boundary
   * \param init starting value to add other values to
   * \return the final inner product
   *
   * \pre box_a.bottom() <= a.rows()
   * \pre box_a.right() <= a.columns()
   * \pre box_b.bottom() <= b.rows()
   * \pre box_b.right() <= b.columns()
   * \pre box_a.bottom() - box_a.top() == box_b.bottom() - box_b.top()
   * \pre box_a.right() - box_a.left() == box_b.right() - box_b.left()   
   */
  template <typename T,typename U,typename V>
  V mat_inner_product_box(const Matrix<T>& a,
			  const Box& box_a,
			  const Matrix<U>& b,
			  const Box& box_b,
			  V init);

  /**
   * Compute inner product of two sub-matrices
   *
   * Starting with an initial value of \a init, applies \a op2 to
   * corresponding elements of the two sub-matrices and accumulates
   * each result into the accumulated value using \a op1.
   *
   * \param a first input matrix
   * \param box_a first sub-matrix boundary
   * \param b second input matrix
   * \param box_b second sub-matrix boundary
   * \param init starting value to add other values to
   * \param op1 function object to accumulate with
   * \param op2 function object to apply to pairs of input values
   * \return the final inner product
   *
   * \pre box_a.bottom() <= a.rows()
   * \pre box_a.right() <= a.columns()
   * \pre box_b.bottom() <= b.rows()
   * \pre box_b.right() <= b.columns()
   * \pre box_a.bottom() - box_a.top() == box_b.bottom() - box_b.top()
   * \pre box_a.right() - box_a.left() == box_b.right() - box_b.left()   
   */
  template <typename T,typename U,typename V,typename BinOp1,typename BinOp2>
  V mat_inner_product_box(const Matrix<T>& a,
			  const Box& box_a,
			  const Matrix<U>& b,
			  const Box& box_b,
			  V init,
			  BinOp1 op1,
			  BinOp2 op2);

  /**
   * Return the minimum element in the matrix.
   *
   * Elements are compared using <tt> operator<() </tt>
   *
   * \param mat input matrix
   * 
   * \return the minimum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T>
  const T& mat_min_element(const Matrix<T>& mat);

  /**
   * Return the minimum element in the matrix
   *
   * Elements are compared using <tt> operator<() </tt>
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the minimum found.
   *
   * \param mat input matrix
   * \param row the row index of the minimum value
   * \param col the column index of the minimum value
   * 
   * \return the minimum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T>
  const T& mat_min_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col);

  /**
   * Return the minimum element in the matrix
   *
   * Elements are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param p comparison predicate
   * 
   * \return the minimum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T,typename BinPred>
  const T& mat_min_element(const Matrix<T>& mat,BinPred p);

  /**
   * Return the minimum element in the matrix
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the minimum found.
   * Elements are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param row the row index of the minimum value
   * \param col the column index of the minimum value
   * \param p comparison predicate
   * 
   * \return the minimum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T,typename BinPred>
  const T& mat_min_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col,
			   BinPred p);


  /**
   * Return the minimum element in the matrix.
   *
   * Elements inside the box are compared using <tt> operator<() </tt>
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * 
   * \return the minimum value
   */
  template <typename T>
  const T& mat_min_element_box(const Matrix<T>& mat,const Box& box);

  /**
   * Return the minimum element in the matrix
   *
   * Elements inside the box are compared using <tt> operator<() </tt>
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the minimum found.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param row the row index of the minimum value
   * \param col the column index of the minimum value
   * 
   * \return the minimum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T>
  const T& mat_min_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col);

  /**
   * Return the minimum element in the matrix
   *
   * Elements inside the box are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param p comparison predicate
   * 
   * \return the minimum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T,typename BinPred>
  const T& mat_min_element_box(const Matrix<T>& mat,const Box& box,BinPred p);


  /**
   * Return the minimum element in the matrix
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the minimum found.
   * Elements inside the box are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param row the row index of the minimum value
   * \param col the column index of the minimum value
   * \param p comparison predicate
   * 
   * \return the minimum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T,typename BinPred>
  const T& mat_min_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col,
			       BinPred p);
  /**
   * Return the maximum element in the matrix.
   *
   * Elements are compared using <tt> operator<() </tt>
   *
   * \param mat input matrix
   * 
   * \return the maximum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T>
  const T& mat_max_element(const Matrix<T>& mat);

  /**
   * Return the maximum element in the matrix
   *
   * Elements are compared using <tt> operator<() </tt>
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the maximum found.
   *
   * \param mat input matrix
   * \param row the row index of the maximum value
   * \param col the column index of the maximum value
   * 
   * \return the maximum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T>
  const T& mat_max_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col);

  /**
   * Return the maximum element in the matrix
   *
   * Elements are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param p comparison predicate
   * 
   * \return the maximum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T,typename BinPred>
  const T& mat_max_element(const Matrix<T>& mat,BinPred p);

  /**
   * Return the maximum element in the matrix
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the maximum found.
   * Elements are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param row the row index of the maximum value
   * \param col the column index of the maximum value
   * \param p comparison predicate
   * 
   * \return the maximum value
   *
   * \pre mat.rows() > 0
   * \pre mat.columns() > 0
   */
  template <typename T,typename BinPred>
  const T& mat_max_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col,
			   BinPred p);
  
  /**
   * Return the maximum element in the matrix.
   *
   * Elements inside the box are compared using <tt> operator<() </tt>
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * 
   * \return the maximum value
   */
  template <typename T>
  const T& mat_max_element_box(const Matrix<T>& mat,const Box& box);

  /**
   * Return the maximum element in the matrix
   *
   * Elements inside the box are compared using <tt> operator<() </tt>
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the maximum found.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param row the row index of the maximum value
   * \param col the column index of the maximum value
   * 
   * \return the maximum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T>
  const T& mat_max_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col);

  /**
   * Return the maximum element in the matrix
   *
   * Elements inside the box are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param p comparison predicate
   * 
   * \return the maximum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T,typename BinPred>
  const T& mat_max_element_box(const Matrix<T>& mat,const Box& box,BinPred p);

  /**
   * Return the maximum element in the matrix
   *
   * The output parameters \p row ans \p col will contain the row and
   * the column of the maximum found.
   * Elements inside the box are compared using the given binary predicate.
   *
   * \param mat input matrix
   * \param box determine the elements to be compared
   * \param row the row index of the maximum value
   * \param col the column index of the maximum value
   * \param p comparison predicate
   * 
   * \return the maximum value
   *
   * \pre box.top() < box.bottom()
   * \pre box.left() < box.right()
   */
  template <typename T,typename BinPred>
  const T& mat_max_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col,
			       BinPred p);
  
  /*@}*/  

  // implementation

  template <typename T,typename U>
  void mat_copy(const Matrix<T>& src,Matrix<U>& dst)
  {
    Matrix<U> tmp(src.rows(),src.columns());
    std::copy(src.begin(),src.end(),tmp.begin());
    dst.swap(tmp);
  }

  template <typename T,typename U,typename UnaryOp>
  void mat_transform(const Matrix<T>& src,
		     Matrix<U>& dst,
		     UnaryOp op)
  {
    Matrix<U> tmp(src.rows(),src.columns());
    std::transform(src.begin(),src.end(),
		   tmp.begin(),
		   op);
    dst.swap(tmp);
  }

  template <typename T,typename U,typename V,typename BinaryOp>
  void mat_transform(const Matrix<T>& src1,
		     const Matrix<U>& src2,
		     Matrix<V>& dst,
		     BinaryOp op)
  {
    assert(src1.rows() == src2.rows());
    assert(src1.columns() == src2.columns());

    Matrix<V> tmp(src1.rows(),src1.columns());
    std::transform(src1.begin(),src1.end(),
		   src2.begin(),
		   tmp.begin(),
		   op);
    dst.swap(tmp);
  }

  template <typename T,typename U>
  void mat_copy_box(const Matrix<T>& src,const Box& sbox,
		    Matrix<U>& dst, const Box& dbox)
  {
    assert(sbox.bottom() - sbox.top() == dbox.bottom() - dbox.top());
    assert(sbox.right() - sbox.left() == dbox.right() - dbox.left());
    assert(sbox.bottom() <= src.rows());
    assert(sbox.right() <= src.columns());
    assert(dbox.bottom() <= dst.rows());
    assert(dbox.right() <= dst.columns());
    
    Box::size_type i = sbox.top();
    Box::size_type j = dbox.top();

    while (i != sbox.bottom()) {
      std::copy(src.row_begin(i) + sbox.left(),
		src.row_begin(i) + sbox.right(),
		dst.row_begin(j) + dbox.left());
      ++i;
      ++j;
    }
  }

  template <typename T,typename U,typename UnaryOp>
  void mat_transform_box(const Matrix<T>& src,const Box& sbox,
			 Matrix<U>& dst, const Box& dbox,
			 UnaryOp op)
  {
    assert(sbox.bottom() - sbox.top() == dbox.bottom() - dbox.top());
    assert(sbox.right() - sbox.left() == dbox.right() - dbox.left());
    assert(sbox.bottom() <= src.rows());
    assert(sbox.right() <= src.columns());
    assert(dbox.bottom() <= dst.rows());
    assert(dbox.right() <= dst.columns());
    
    Box::size_type i = sbox.top();
    Box::size_type j = dbox.top();
    
    while (i != sbox.bottom()) {
      std::transform(src.row_begin(i) + sbox.left(),
		     src.row_begin(i) + sbox.right(),
		     dst.row_begin(j) + dbox.left(),
		     op);
      ++i;
      ++j;
    }
  }

  template <typename T,typename U,typename V,typename BinaryOp>
  void mat_transform_box(const Matrix<T>& src1,const Box& sbox1,
			 const Matrix<U>& src2,const Box& sbox2,
			 Matrix<V>& dst, const Box& dbox,
			 BinaryOp op)
  {
    assert(sbox1.bottom() - sbox1.top() == dbox.bottom() - dbox.top());
    assert(sbox1.right() - sbox1.left() == dbox.right() - dbox.left());
    assert(sbox2.bottom() - sbox2.top() == dbox.bottom() - dbox.top());
    assert(sbox2.right() - sbox2.left() == dbox.right() - dbox.left());
    assert(sbox1.bottom() <= src1.rows());
    assert(sbox1.right() <= src1.columns());
    assert(sbox2.bottom() <= src2.rows());
    assert(sbox2.right() <= src2.columns());
    assert(dbox.bottom() <= dst.rows());
    assert(dbox.right() <= dst.columns());
    
    Box::size_type i = sbox1.top();
    Box::size_type j = sbox2.top();
    Box::size_type k = dbox.top();

    while (i != sbox1.bottom()) {
      std::transform(src1.row_begin(i) + sbox1.left(),
		     src1.row_begin(i) + sbox1.right(),
		     src2.row_begin(j) + sbox2.left(),
		     dst.row_begin(k) + dbox.left(),
		     op);
      ++i;
      ++j;
      ++k;
    }
  }

  template <typename T,typename U>
  void mat_fill(Matrix<T>& dst,const U& value)
  {
    std::fill(dst.begin(),dst.end(),value);
  }

  template <typename T,typename U>
  void mat_fill_box(Matrix<T>& dst,const Box& box,const U& value)
  {
    for (Box::size_type i = box.top(); i!= box.bottom(); i++)
      std::fill(dst.row_begin(i) + box.left(),
		dst.row_begin(i) + box.right(),
		value);
  }

  template <typename T,typename U>
  U mat_accumulate(const Matrix<T>& src,
		   U init)
  {
    return std::accumulate(src.begin(),
			   src.end(),
			   init);
  }

  template <typename T,typename U,typename BinOp>
  U mat_accumulate(const Matrix<T>& src,
		    U init,
		    BinOp bin_op)
  {
    return std::accumulate(src.begin(),
			   src.end(),
			   init,
			   bin_op);
  }

  template <typename T,typename U>
  U mat_accumulate_box(const Matrix<T>& src,
		       const Box& box,
		       U init)
  {
    assert( box.bottom() <= src.rows() );
    assert( box.right() <= src.columns() );

    for (Box::size_type i = box.top(); i != box.bottom(); i++)
      init = std::accumulate(src.row_begin(i)+box.left(),
			     src.row_begin(i)+box.right(),
			     init);
    return init;
  }

  template <typename T,typename U,typename BinOp>
  U mat_accumulate_box(const Matrix<T>& src,
		       const Box& box,
		       U init,
		       BinOp bin_op)
  {
    assert( box.bottom() <= src.rows() );
    assert( box.right() <= src.columns() );

    for (Box::size_type i = box.top(); i != box.bottom(); i++)
      init = std::accumulate(src.row_begin(i)+box.left(),
			     src.row_begin(i)+box.right(),
			     init,
			     bin_op);
    return init;
  }

  template <typename T,typename U,typename V>
  V mat_inner_product(const Matrix<T>& a,
		      const Matrix<U>& b,
		      V init)  
  {
    assert( a.rows() == b.rows() );
    assert( a.columns() == b.columns() );

    return std::inner_product(a.begin(),a.end(),
			      b.begin(),
			      init);
  }

  template <typename T,typename U,typename V,typename BinOp1,typename BinOp2>
  V mat_inner_product(const Matrix<T>& a,
		      const Matrix<U>& b,
		      V init,
		      BinOp1 op1,
		      BinOp2 op2)
  {
    assert( a.rows() == b.rows() );
    assert( a.columns() == b.columns() );
    
    return std::inner_product(a.begin(),a.end(),
			      b.begin(),
			      init,
			      op1,
			      op2);
  }

  template <typename T,typename U,typename V>
  V mat_inner_product_box(const Matrix<T>& a,
			  const Box& box_a,
			  const Matrix<U>& b,
			  const Box& box_b,
			  V init)  
  {
    assert( box_a.bottom() <= a.rows() );
    assert( box_a.right() <= a.columns() );

    assert( box_b.bottom() <= b.rows() );
    assert( box_b.right() <= b.columns() );


    assert( box_a.bottom() - box_a.top() == box_b.bottom() - box_b.top() );
    assert( box_a.right() - box_a.left() == box_b.right() - box_b.left() );

    Box::size_type i = box_a.top(); 
    Box::size_type j = box_b.top();

    while (i != box_a.bottom()) {
      init = std::inner_product(a.row_begin(i) + box_a.left(),
				a.row_begin(i) + box_a.right(),
				b.row_begin(j) + box_b.left(),
				init);
      ++i;
      ++j;
    }

    return init;
  }

  template <typename T,typename U,typename V,typename BinOp1,typename BinOp2>
  V mat_inner_product_box(const Matrix<T>& a,
			  const Box& box_a,
			  const Matrix<U>& b,
			  const Box& box_b,
			  V init,
			  BinOp1 op1,
			  BinOp2 op2)
  {
    assert( box_a.bottom() <= a.rows() );
    assert( box_a.right() <= a.columns() );

    assert( box_b.bottom() <= b.rows() );
    assert( box_b.right() <= b.columns() );


    assert( box_a.bottom() - box_a.top() == box_b.bottom() - box_b.top() );
    assert( box_a.right() - box_a.left() == box_b.right() - box_b.left() );

    Box::size_type i = box_a.top(); 
    Box::size_type j = box_b.top();

    while (i != box_a.bottom()) {
      init = std::inner_product(a.row_begin(i) + box_a.left(),
				a.row_begin(i) + box_a.right(),
				b.row_begin(j) + box_b.left(),
				init,
				op1,
				op2);
      ++i;
      ++j;
    }

    return init;
  }

  template <typename T>
  const T& mat_min_element(const Matrix<T>& mat)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    return *std::min_element(mat.begin(),mat.end());
  }

  template <typename T>
  const T& mat_min_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    typedef typename Matrix<T>::size_type size_type;

    row = 0;
    col = 0;

    for (size_type i = 0; i < mat.rows(); i++)
      for (size_type j = 0; j < mat.columns(); j++)
	if (mat[i][j] < mat[row][col]) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }

  template <typename T,typename BinPred>
  const T& mat_min_element(const Matrix<T>& mat,BinPred p)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    return *std::min_element(mat.begin(),mat.end(),p);
  }

  template <typename T,typename BinPred>
  const T& mat_min_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col,
			   BinPred p)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    typedef typename Matrix<T>::size_type size_type;

    row = 0;
    col = 0;

    for (size_type i = 0; i < mat.rows(); i++)
      for (size_type j = 0; j < mat.columns(); j++)
	if (p(mat[i][j],mat[row][col])) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }

  template <typename T>
  const T& mat_min_element_box(const Matrix<T>& mat,const Box& box)
  {
    typename Matrix<T>::size_type ignored_row;
    typename Matrix<T>::size_type ignored_col;

    return mat_min_element_box(mat,box,ignored_row,ignored_col);
  }    

  template <typename T>
  const T& mat_min_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col)
  {
    assert( box.top() < box.bottom() );
    assert( box.left() < box.right() );

    typedef typename Matrix<T>::size_type size_type;

    row = box.top();
    col = box.left();

    for (size_type i = box.top(); i < box.bottom(); i++)
      for (size_type j = box.left(); j < box.right(); j++)
	if (p(mat[i][j],mat[row][col])) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }


  template <typename T,typename BinPred>
  const T& mat_min_element_box(const Matrix<T>& mat,const Box& box,BinPred p)
  {
    typename Matrix<T>::size_type ignored_row;
    typename Matrix<T>::size_type ignored_col;

    return mat_min_element_box(mat,box,ignored_row,ignored_col,p);
  }    

  template <typename T,typename BinPred>
  const T& mat_min_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col,
			       BinPred p)
  {
    assert( box.top() < box.bottom() );
    assert( box.left() < box.right() );

    typedef typename Matrix<T>::size_type size_type;

    row = box.top();
    col = box.left();

    for (size_type i = box.top(); i < box.bottom(); i++)
      for (size_type j = box.left(); j < box.right(); j++)
	if (p(mat[i][j],mat[row][col])) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }

  template <typename T>
  const T& mat_max_element(const Matrix<T>& mat)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    return *std::max_element(mat.begin(),mat.end());
  }

  template <typename T>
  const T& mat_max_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    typedef typename Matrix<T>::size_type size_type;

    row = 0;
    col = 0;

    for (size_type i = 0; i < mat.rows(); i++)
      for (size_type j = 0; j < mat.columns(); j++)
	if (mat[row][col] < mat[i][j]) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }

  template <typename T,typename BinPred>
  const T& mat_max_element(const Matrix<T>& mat,BinPred p)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    return *std::max_element(mat.begin(),mat.end(),p);
  }

  template <typename T,typename BinPred>
  const T& mat_max_element(const Matrix<T>& mat,
			   typename Matrix<T>::size_type& row,
			   typename Matrix<T>::size_type& col,
			   BinPred p)
  {
    assert( mat.rows() > 0 );
    assert( mat.columns() > 0 );

    typedef typename Matrix<T>::size_type size_type;

    row = 0;
    col = 0;

    for (size_type i = 0; i < mat.rows(); i++)
      for (size_type j = 0; j < mat.columns(); j++)
	if (p(mat[row][col],mat[i][j])) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }

  template <typename T>
  const T& mat_max_element_box(const Matrix<T>& mat,const Box& box)
  {
    typename Matrix<T>::size_type ignored_row;
    typename Matrix<T>::size_type ignored_col;

    return mat_max_element_box(mat,box,ignored_row,ignored_col);
  }    

  template <typename T>
  const T& mat_max_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col)
  {
    assert( box.top() < box.bottom() );
    assert( box.left() < box.right() );

    typedef typename Matrix<T>::size_type size_type;

    row = box.top();
    col = box.left();

    for (size_type i = box.top(); i < box.bottom(); i++)
      for (size_type j = box.left(); j < box.right(); j++)
	if (mat[row][col] < mat[i][j]) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }


  template <typename T,typename BinPred>
  const T& mat_max_element_box(const Matrix<T>& mat,const Box& box,BinPred p)
  {
    typename Matrix<T>::size_type ignored_row;
    typename Matrix<T>::size_type ignored_col;

    return mat_max_element_box(mat,box,ignored_row,ignored_col,p);
  }    

  template <typename T,typename BinPred>
  const T& mat_max_element_box(const Matrix<T>& mat,
			       const Box& box,
			       typename Matrix<T>::size_type& row,
			       typename Matrix<T>::size_type& col,
			       BinPred p)
  {
    assert( box.top() < box.bottom() );
    assert( box.left() < box.right() );

    typedef typename Matrix<T>::size_type size_type;

    row = box.top();
    col = box.left();

    for (size_type i = box.top(); i < box.bottom(); i++)
      for (size_type j = box.left(); j < box.right(); j++)
	if (p(mat[row][col],mat[i][j])) {
	  row = i;
	  col = j;
	}
    
    return mat[row][col];
  }
  
} // ivllib

#endif
