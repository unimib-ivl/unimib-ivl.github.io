/**
 * \file    yuv.h
 * \brief   yuv colorspace structures
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivllib_yuv_h
#define ivllib_yuv_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>


namespace ivllib 
{
  /** \addtogroup color */
  /*@{*/

  /**
   * Pixels in the YUV color space
   */
  template <typename T>
  struct YUV
  {    
    typedef T channel_type; ///< type of the components
	
    channel_type y; ///< y component
    channel_type u; ///< u component
    channel_type v; ///< v component

    /// Black value in YUV
    YUV()
      : y(0),u(0),v(0)
    {
    }
	
    /// Construction from the channels values
    YUV(channel_type ay,
	channel_type au,
	channel_type av)
      : y(ay),
	u(au),
	v(av)
    {
    }
  };

  /**
   * Eight bits YUV pixels
   *
   * The three components are in the range 0-255.
   * \c Y ranges from dark (0) to bright (255).
   * \c U and \c V components are shifted so that for acromatic
   * pixels <tt> u=v=128 </tt>.
   */
  typedef YUV<unsigned char> YUV8;

  // pixel conversions

  /**
   * Conversion from gray to YUV (8 bits)
   *
   * Y is set to the graylevel
   * U and V are set to 128 (acromatic)
   */
  template <>
  struct PixelConversion<Gray8,YUV8>
    : public std::unary_function<Gray8,YUV8>
  {
    /// conversion
    YUV8 operator()(Gray8 p) const
    {
      return YUV8(p,128,128);
    }
  };

  /**
   * YUV to RGB colorspace conversion
   *
   * conversion of 8-bits YUV pixels to 8-bits RGB values.
   *
   * \f[
   * \left(\begin{array}{c} r \\ g \\ b \end{array}\right) =
   * \left[\begin{array}{rrr}
   * 1.0000 & 0.0000 & 1.4075 \\
   * 1.0000 & -0.3455 & -0.7169 \\
   * 1.0000 & 1.7790 & 0.0000
   * \end{array}\right] \times
   * \left(\begin{array}{l}
   * y \\ u - 128 \\ v - 128
   * \end{array}\right)
   * \f]
   */
  template <>
  struct PixelConversion<YUV8,RGB8>
    : public std::unary_function<YUV8,RGB8>
  {
    /// conversion
    RGB8 operator()(const YUV8 p) const
    {
      int u = p.u - 128;
      int v = p.v - 128;
      
      // fixed point computation
      int y = 32768 + (static_cast<int>(p.y) << 16); 

      int r = (y +  92242 * v) >> 16;
      int g = (y -  22643 * u - 46983 * v) >> 16;
      int b = (y + 116589 * u) >> 16;
      
      if (r < 0)
	r = 0;
      else if (r > 255)
	r = 255;

      if (g < 0)
	g = 0;
      else if (g > 255)
	g = 255;

      if (b < 0)
	b = 0;
      else if (b > 255)
	b = 255;

      return RGB8(r,g,b);
    }
  };

  /**
   * RGB to YUV colorspace conversion
   *
   * conversion of 8-bits RGB pixels to 8-bits YUV values.
   *
   * \f[
   * \left(\begin{array}{c} y \\ u \\ v \end{array}\right) =
   * \left[\begin{array}{rrr}
   * 0.299 & 0.587 & 0.114 \\
   * -0.169 & -0.0331 & -0.500 \\
   * 0.500 & -0.419 & -0.081
   * \end{array}\right] \times
   * \left(\begin{array}{l}
   * r \\ g \\ b
   * \end{array}\right) +
   * \left(\begin{array}{r}
   * 0 \\ 128 \\ 128
   * \end{array}\right)
   * \f]
   */
  template <>
  struct PixelConversion<RGB8,YUV8>
    : public std::unary_function<RGB8,YUV8>
  {
    /// conversion
    YUV8 operator()(const RGB8& p) const
    {
      int y = ( 19595 * p.red + 38470 * p.green +  7471 * p.blue) >> 16;
      int u = (-11075 * p.red - 21692 * p.green + 32768 * p.blue + 8388608 ) >> 16;
      int v = ( 32768 * p.red - 27460 * p.green -  5308 * p.blue + 8388608) >> 16;

      return YUV8(y,u,v);
    }
  };

  /**
   * Specialization of Blend for YUV pixels
   *
   * Blend(a,b,0.0) = b and Blend(a,b,1.0) = a.
   *
   * The result is linear in \p f.
   */
  template <typename T>
  struct Blend<YUV<T> >
  {
    /// conversion
    YUV<T> operator()(const YUV<T>& a,
		      const YUV<T>& b,
		      double f) const
    {
      return YUV<T>(static_cast<T>(a.y * (1-f) + b.y * f),
		    static_cast<T>(a.u * (1-f) + b.u * f),
		    static_cast<T>(a.v * (1-f) + b.v * f));
    }
  };  

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const YUV<T>& a,const YUV<T>&b)
  {
    return a.y == b.y && 
      a.u == b.u &&
      a.v == b.v;
  }

  /// inequality
  template <typename T>
  bool operator!=(const YUV<T>& a,const YUV<T>&b)
  {
    return !(a == b);
  }

  /// lexicographical comparisons of the channels (y-u-v order)
  template <typename T>
  bool operator<(const YUV<T>& a,const YUV<T>&b)
  {
    if (a.y < b.y)
      return true;
    if (b.y < a.y)
      return false;
    if (a.u < b.u)
      return true;
    if (b.u < a.u)
      return false;
    
    return a.v < b.v;
  }

  /// lexicographical comparisons of the channels (y-u-v order)
  template <typename T>
  bool operator>(const YUV<T>& a,const YUV<T>&b)
  {
    return b < a;
  }

  /// lexicographical comparisons of the channels (y-u-v order)
  template <typename T>
  bool operator<=(const YUV<T>& a,const YUV<T>&b)
  {
    return !(b < a);
  }

  /// lexicographical comparisons of the channels (y-u-v order)
  template <typename T>
  bool operator>=(const YUV<T>& a,const YUV<T>&b)
  {
    return !(b > a);
  }

/*@}*/

} // namespace ivllib

#endif // ivllib_yuv_h
