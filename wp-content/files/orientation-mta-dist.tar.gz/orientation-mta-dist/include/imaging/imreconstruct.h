/**
 * \file imreconstruct.h
 *
 * Definition of the image_reconstruct procedure.
 */

//---------------------------------------------------------------------------
#ifndef imagereconstructH
#define imagereconstructH

#include <numerical/vector2.h>
#include <ivl_matrix.h>
#include <list>
#include <cassert>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Morphological reconstruction.
   *
   * Performs morphological reconstruction of the matrix marker under
   * the matrix mask.  Marker must be the same size as mask, and its
   * elements must be less than or equal to the corresponding elements
   * of mask. operator< is used to compare pixels.
   *
   * \param pMask original matrix
   * \param pMarker marker matrix
   * \param pNeigh neighbourd size (4 or 8)
   * \param pDst output matrix
   *
   * \pre pMask[i][j] >= pMarker[i][j] for all i and j
   * \pre pMask.rows()>=2
   * \pre pMask.columns()>=2
   * \pre pMask.rows()==pMarker.rows()
   * \pre pMask.columns()==pMarker.columns()
   * \pre pNeigh==4 || pNeigh==8
   *
   * \post pDst.rows() == pMask.rows()
   * \post pDst.columns() == pMask.columns()
   */
  template <class MatType>
  void image_reconstruct(const Matrix<MatType> &pMask,
			 const Matrix<MatType> &pMarker,
			 unsigned char pNeigh,
			 Matrix<MatType> &pDst)
  {
    assert(pMask.rows()>=2);
    assert(pMask.columns()>=2);

    assert(pMask.rows()==pMarker.rows());
    assert(pMask.columns()==pMarker.columns());

    assert(pNeigh==4 || pNeigh==8);

    typename Matrix<MatType>::const_iterator m,me,mk;

    bool valid=true;

    int ii=0;
    for(m=pMask.begin(),me=pMask.end(),mk=pMarker.begin();m!=me && valid;m++,mk++,ii++)
      valid=valid && (*m>=*mk);

    assert(valid);

    int rows,cols;

    cols=pMask.columns();
    rows=pMask.rows();

    Matrix<MatType> Temp(pMarker);
    typedef Vector2<int> imrec_point;

    static const imrec_point Neigh8[9]={imrec_point(-1,-1),
					imrec_point(-1, 0),
					imrec_point(-1,+1),
					imrec_point( 0,-1),
					imrec_point( 0, 0),
					imrec_point( 0, 1),
					imrec_point( 1,-1),
					imrec_point( 1, 0),
					imrec_point( 1, 1)};

    static const imrec_point Neigh4[5]={imrec_point(-1, 0),
					imrec_point( 0,-1),
					imrec_point( 0, 0),
					imrec_point( 0, 1),
					imrec_point( 1, 0)};

    const imrec_point *Neigh;
    int nNeigh;

    if (pNeigh==4)
      {
	Neigh=Neigh4;
	nNeigh=2;
      }
    else
      {
	Neigh=Neigh8;
	nNeigh=4;
      }

    typename Matrix<MatType>::element_type max_value,valJ,valI;
    int x,y,i;

    // Scan mask in raster order
    for(y=1;y<rows-1;y++) for(x=1;x<cols-1;x++)
			    {
			      for(max_value=Temp[y][x],i=0;i<=nNeigh;i++)
				{
				  valJ=Temp[y+Neigh[i].y][x+Neigh[i].x];
				  if (max_value<valJ) max_value=valJ;
				}
			      Temp[y][x]=(max_value<pMask[y][x])?max_value:pMask[y][x];
			    }

    // Scan mask in anti raster order
    std::list<imrec_point>ToCheck;
    for(y=rows-2;y>1;y--) for(x=cols-2;x>1;x--)
			    {
			      for(max_value=Temp[y][x],i=nNeigh;i<=pNeigh;i++)
				{
				  valJ=Temp[y+Neigh[i].y][x+Neigh[i].x];
				  if (valJ>max_value) max_value=valJ;
				}

			      Temp[y][x]=(max_value<pMask[y][x])?max_value:pMask[y][x];

			      for(i=nNeigh;i<=pNeigh;i++)
				{
				  max_value=Temp[y+Neigh[i].y][x+Neigh[i].x];
				  if (max_value<Temp[y][x] && max_value<pMask[y][x])
				    {
				      ToCheck.push_back(imrec_point(x,y));
				      break;
				    }
				}
			    }

    // Propagation
    imrec_point pt;
    typename std::list<imrec_point>::iterator il;

    il=ToCheck.begin();
    while (il!=ToCheck.end())
      {
	pt=*il;
	max_value=Temp[pt.y][pt.x];
	for(i=0;i<=pNeigh;i++)
	  {
	    x=pt.x+Neigh[i].x;
	    y=pt.y+Neigh[i].y;
	    valJ=Temp[y][x];
	    valI=pMask[y][x];
	    if (valJ<max_value && valI!=valJ)
	      {
		if (x>0 && y>0 && x<cols-1 && y<rows-1)
		  {
		    Temp[y][x]=(max_value<valI)?max_value:valI;
		    ToCheck.push_back(imrec_point(x,y));
		  }
	      }
	  }
	il=ToCheck.erase(il);
      }

    pDst.swap(Temp);
  }

  /*@}*/

} // namespace ivllib
//---------------------------------------------------------------------------
#endif
