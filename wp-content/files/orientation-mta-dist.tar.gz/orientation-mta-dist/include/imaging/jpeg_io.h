/**
 * \file    jpeg_io.h
 * \brief   io routines for the jpeg graphic format (based on libjpeg)
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef jpeg_io_h
#define jpeg_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <imaging/exception_io.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/

  /**
   * Load an image in the jpeg format
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_jpeg(const std::string& filename,
		 Matrix<RGB8>& out);

  /**
   * Load an image in the jpeg format
   *
   * Alpha channel is set to 255.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_jpeg(const std::string& filename,
		 Matrix<RGBA8>& out);


  /**
   * Load an image in the jpeg format
   *
   * If the image is not encoded as greyscale jpeg,
   * an \p ImageConversionError exception is thrown
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */
  void load_jpeg(const std::string& filename,
		 Matrix<Gray8>& out);
  
  /**
   * Save an image in the Jpeg format
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param quality parameter in the range 0-100
   *
   * \pre quality >= 0
   * \pre quality <= 100
   *
   * \throw ImageFileError
   */ 
  void save_jpeg(const std::string& filename,
		 const Matrix<RGB8>& in,
		 int quality = 95);

  /**
   * Save an image in the Jpeg format
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param quality parameter in the range 0-100
   *
   * \pre quality >= 0
   * \pre quality <= 100
   *
   * \throw ImageFileError
   */ 
  void save_jpeg(const std::string& filename,
		 const Matrix<Gray8>& in,
		 int quality = 95);

  /*@}*/
  
}

#endif
