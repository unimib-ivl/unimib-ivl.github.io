#ifndef merge_h
#define merge_h

#include <ivl_matrix.h>
#include <algorithm>
#include <imaging/pyramid.h>

namespace ivllib {


  // Implementation details -----------------------------------
  namespace detail {

    //flags to double converter functor
    template <class T>
    struct to_double
    {
      double operator()(const T& a)
      {
	if (a)
	  return 1.0;
	else return 0.0;
      }      
    }; // to_double()


    //generic blending functor based on mul and sum functors
    template < class SumFunT,
	       class MulFunT,
	       class PixelTypeT>
    struct GenericBlend
    {
    typedef PixelTypeT result_type;

      SumFunT _sum;
      MulFunT _mul;

      GenericBlend(SumFunT s,
		   MulFunT m) : _sum(s), _mul(m) {}
	
      PixelTypeT operator()(const PixelTypeT& a,
			    const PixelTypeT& b,
			    double alpha) const
      {
	return _sum( _mul(a, alpha), _mul(b, 1.0-alpha));	  
      }
    }; //GenericBlend
  }; //Detail

  // Merge Function -------------------------------------------
  template <class ImgIterT, 
	    class FlagsIterT,
	    class PixelTypeT,
	    class MulFunT,
	    class DiffFunT,
	    class SumFunT>
  void merge(ImgIterT img_begin,
	     ImgIterT img_end,
	     FlagsIterT flags_begin,
	     ivllib::Matrix< PixelTypeT>& out,
	     MulFunT _mul,
	     DiffFunT _diff,
	     SumFunT _sum);
  
  // Implementation -------------------------------------------
  template <class ImgIterT, 
	    class FlagsIterT,
	    class PixelTypeT,
	    class MulFunT,
	    class DiffFunT,
	    class SumFunT>
  void merge(ImgIterT img_begin,
	     ImgIterT img_end,
	     FlagsIterT flags_begin,
	     ivllib::Matrix< PixelTypeT>& out,
	     MulFunT _mul,
	     DiffFunT _diff,
	     SumFunT _sum)
  {           
    typedef typename FlagsIterT::value_type::element_type FlagsT;
    typedef ivllib::Matrix<double> FlagsImgT;
    typedef typename ImgIterT::value_type ImgT;

    typedef std::vector<ImgT> ImgPyramidT;
    typedef std::vector<FlagsImgT> FlagsImgPyramidT;
  
    typedef std::vector<ImgPyramidT> ImgPyramidListT;
    typedef std::vector<FlagsImgPyramidT> FlagsImgPyramidListT;

    detail::GenericBlend<SumFunT,MulFunT,PixelTypeT> blend(_sum, _mul);
  
    ImgPyramidListT imgLPyramids;
    FlagsImgPyramidListT flagsPyramids;
  
    unsigned original_rows, original_columns;
    original_rows = img_begin->rows();
    original_columns = img_begin->columns();

    ImgIterT it = img_begin;
    FlagsIterT itf = flags_begin;

    //-- Build pyramids -- 
    for (;it != img_end; it++, itf++)
      {
	assert(original_rows == it->rows());
	assert(original_columns == it->columns());
	assert(original_rows == itf->rows());
	assert(original_columns == itf->columns());

	//compute the laplacian pyramid for img
	ImgPyramidT img_gpyr;
	ImgPyramidT img_lpyr;

	make_pyramids(*it, 
		      img_gpyr,
		      img_lpyr,
		      blend, 
		      _diff);

	img_lpyr.push_back(img_gpyr.back());
	imgLPyramids.push_back(img_lpyr);

	//transform flags image to double
	FlagsImgT double_flags(itf->rows(),
			       itf->columns());
	std::transform(itf->begin(),
		       itf->end(),
		       double_flags.begin(),
		       detail::to_double<FlagsT>());
	  
	//make flags gaussian pyramid
	FlagsImgPyramidT flags_pyramid;
	make_gaussian_pyramid(double_flags, 				 
			      flags_pyramid,
			      Blend<double>());
	Matrix<FlagsT> resized;
	bilinear_resampling(*itf,img_lpyr[0].rows(),img_lpyr[0].columns(),resized);
	flags_pyramid.insert(flags_pyramid.begin(),resized);

	flagsPyramids.push_back(flags_pyramid);	  
      } 
           
      
    //-- combine pyramids --      
    ImgPyramidT compositeLaplacian;
    unsigned levels = imgLPyramids[0].size();
    
    for(int lev=levels-1; 
	lev >= 0; lev--)
      {
	unsigned rows=imgLPyramids[0][lev].rows();
	unsigned columns=imgLPyramids[0][lev].columns();
		     
	//create the new composite level
	compositeLaplacian.insert(compositeLaplacian.begin(),
				  ImgT(rows, columns));
		
	for (unsigned r=0; r < rows; r++)
	  for (unsigned c=0; c < columns; c++)
	    {
	      PixelTypeT p=_mul(imgLPyramids[0][lev][r][c],
				flagsPyramids[0][lev][r][c]);
	      double factor_sum=flagsPyramids[0][lev][r][c];
	      for (unsigned i=1; 
		   i < imgLPyramids.size(); 
		   i++)
		
		{	 
		  PixelTypeT m=_mul(imgLPyramids[i][lev][r][c],
				    flagsPyramids[i][lev][r][c]);
		  
		  factor_sum+=flagsPyramids[i][lev][r][c];

		  p=_sum(p,m);		 		  
		}	      
	      //normalize factors
	      compositeLaplacian.front()[r][c]=_mul(p,1.0 / factor_sum);
	    }
      }


    //reconstruct image from composite laplacian    
    ivllib::Matrix< PixelTypeT> level_n(compositeLaplacian.back()), reconstructed;    
    compositeLaplacian.pop_back();
    
    pyramid_reconstruct(compositeLaplacian,
			level_n,
			reconstructed,
			blend,
			_sum);

      
    //resample image to original size!!!!
    bilinear_resampling(reconstructed,
			original_rows,
			original_columns,
			reconstructed, 
			blend);
  
    out.swap(reconstructed);
  } //merge  
} //namespace ivllib

#endif //merge.h
