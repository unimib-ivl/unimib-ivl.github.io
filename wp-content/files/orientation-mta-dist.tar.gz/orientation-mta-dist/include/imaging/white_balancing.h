/**
 * \file  white_balancing.h
 * \brief white balancing for rgb images
 */
#ifndef white_balancing_h
#define white_balancing_h

#include <ivl_matrix.h>
#include <imaging/rgb.h>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Color correction with the max RGB strategy.
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  void white_balancing_maxrgb(const Matrix<RGB8>& in,
			      Matrix<RGB8>& out);


  /**
   * Color correction with the gray world strategy.
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  void white_balancing_grayworld(const Matrix<RGB8>& in,
				 Matrix<RGB8>& out);

  /*@}*/
} // namespace ivllib

#endif // white_balancing_h
