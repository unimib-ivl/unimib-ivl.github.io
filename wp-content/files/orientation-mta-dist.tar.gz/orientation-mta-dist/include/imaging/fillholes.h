/**
 * \file fillholes.h
 *
 * Definition of the fill_holes procedure
 */

#ifndef fill_holesH
#define fill_holesH

#include <algorithm>
#include <cassert>
#include <numerical/vector2.h>
#include <ivl_matrix.h>
#include <imaging/imreconstruct.h>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Fill holes in a matrix.
   *   
   * Fill valleys in \p pSrc and put the result in \p pOut.
   * Pixels on the borders are ignored.
   *
   * \param pSrc input matrix
   * \param pOut output matrix
   *
   * \pre pSrc.rows() > 0
   * \pre pSrc.columns() > 0
   * \post pOut.rows() == pSrc.rows()
   * \post pOut.columns() == pSrc.columns()
   */
  template <typename T>
  void fill_holes(const Matrix<T> &pSrc,Matrix<T> &pOut)
  {
    assert( pSrc.rows() > 0 );
    assert( pSrc.columns() > 0 );

    typename Matrix<T>::iterator m,me,k;
    size_t rows,cols,x,y;
    T max_value;

    rows=pSrc.rows();
    cols=pSrc.columns();

    max_value=*(std::max_element(pSrc.begin(),pSrc.end()));

    Matrix<T> Marker(pSrc),Mask(pSrc),Tmp;

    for(y=1;y<rows-1;y++)
      for(x=1;x<cols-1;x++) Marker[y][x]=max_value;

    for(k=Marker.begin(),m=Mask.begin(),me=Mask.end();m!=me;m++,k++)
      {
	*m=max_value-*m;
	*k=max_value-*k;
      }

    image_reconstruct(Mask,Marker,4,Tmp);

    for(m=Tmp.begin(),me=Tmp.end();m!=me;m++)
      *m=max_value-*m;

    pOut.swap(Tmp);
  }

  /*@}*/

} // namespace ivllib

#endif
