/**
 * \file    bmp_io.h
 * \brief   io routines for the bmp graphic format
 * \author  $LastChangedBy: cusano $
 * \date    $Date$
 * \version $Revision: 65 $
 */

#ifndef bmp_io_h
#define bmp_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/

  /**
   * Load a bitmap file (bmp).
   *
   * Loading of compressed bitmaps is not supported.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_bmp(const std::string& filename,Matrix<RGB8>& out);

  /**
   * Load a bitmap file (bmp).
   *
   * Alpha channel is set to 255.
   * Loading of compressed bitmaps is not supported.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_bmp(const std::string& filename,Matrix<RGBA8>& out);

  /*@}*/

}

#endif
