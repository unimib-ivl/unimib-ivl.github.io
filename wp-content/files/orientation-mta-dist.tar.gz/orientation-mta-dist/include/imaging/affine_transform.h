/**
 * \file    affine_transform.h
 * \brief   affine transformations of the image plane
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef affine_transform_h
#define affine_transform_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <iterator>
#include <cassert> // assert
#include <cmath>   // modf

#include <stdexcept> // !!! trovare eccezione migliore

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Affine transformation using the nearest neighbor strategy.
   *
   * An affine transformation, defined by a \f$ 2 \times 2 \f$ matrix and by
   * two translation parameters, is applied to the image plane.
   * Actually, the inverse transformation is used to map output coordinates
   * into the input image: the nearest pixel is selected and its value is
   * assigned to the destination pixel.
   * If a pixel does not have a corresponding value in the input matrix the
   * padding value is used.
   * For each coordinate \f$ (i,j) \f$ of the output matrix, the corresponding
   * coordinates \f$ (i',j') \f$ in the input matrix are:
   * \f[
   * \left( \begin{array}{r} j' \\ i' \end{array} \right) =
   * \left[ \begin{array}{rr} a_{11} & a_{12} \\ a_{21} & a_{22} \end{array} \right]^{-1}
   * \left( \begin{array}{r} j - b_1 \\ i - b_2 \end{array} \right) 
   * \f]
   *
   * A value of type \p T or \p V must be assignable to a variable of type
   * \p U.
   * If the coefficients \p a11, \p a12, \p a21, \p a22 forms a
   * singular matrix (\f$ a_{11} a_{22} = a_{12} a_{21} \f$), an exception
   * is thrown.
   *
   * \param in input image
   * \param a11 coefficient of the transformation matrix
   * \param a12 coefficient of the transformation matrix
   * \param a21 coefficient of the transformation matrix
   * \param a22 coefficient of the transformation matrix
   * \param b1 horizontal translation
   * \param b2 vertical translation
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param new_rows dimension of the output matrix
   * \param new_columns dimension of the output matrix
   * \param out output image
   * 
   * \throw std::runtime_error
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U,typename V>
  void affine_transform_nearest(const Matrix<T>& in,
				double a11,
				double a12,
				double a21,
				double a22,
				double b1,
				double b2,
				const V& padding,
				typename Matrix<U>::size_type new_rows,
				typename Matrix<U>::size_type new_columns,
				Matrix<U>& out)
  {
    // Note: the output coordinates are represented as fixed points
    // (8 fractional bits)

    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    double det = a11*a22 - a12*a21;

    if (det == 0.0)
      throw std::runtime_error("affine_transform_nearest: singular matrix");

    in_size n = in.rows();
    in_size m = in.columns();

    Matrix<U> result(new_rows,
		     new_columns,
		     padding);
    
    // compute the inverse of a
    double ia11 =  a22 / det;
    double ia12 = -a12 / det;
    double ia21 = -a21 / det;
    double ia22 =  a11 / det;
    
    // precompute some values
    ivllib::Vector<int> jpi(new_columns);
    ivllib::Vector<int> jpj(new_columns);
    for (out_size j = 0; j < new_columns; j++) {
      jpi[j] = 128 + 256 * ia21 * (j - b1);
      jpj[j] = 128 + 256 * ia11 * (j - b1);
    }
    
    int stopn = 256 * n;
    int stopm = 256 * m;
    
    for (out_size i = 0; i < new_rows; i++) {
      int ipi = 256 * ia22 * (i - b2);
      int ipj = 256 * ia12 * (i - b2);
      for (out_size j = 0; j < new_columns; j++) {
	
	int in_j = jpj[j] + ipj;
	int in_i = jpi[j] + ipi;

	if (in_i >= 0 && in_j >= 0 &&
	    in_i < stopn && in_j < stopm) {
	  in_size ii = static_cast<in_size>(in_i >> 8);
	  in_size jj = static_cast<in_size>(in_j >> 8);
	  
	  result[i][j] = in[ii][jj];
	}
      }
    }
    
    out.swap(result);
  }


  /**
   * Affine transformation using a bilinear interpolation
   *
   * An affine transformation, defined by a \f$ 2 \times 2 \f$ matrix and by
   * two translation parameters, is applied to the image plane.
   * Actually, the inverse transformation is used to map output coordinates
   * into the input image: the four nearest pixel are selected, their values
   * are linearly interpolated, and the result is assigned to the destination
   * pixel.
   * If a pixel does not have a corresponding value in the input matrix the
   * padding value is used.
   * For each coordinate \f$ (i,j) \f$ of the output matrix, the corresponding
   * coordinates \f$ (i',j') \f$ in the input matrix are:
   * \f[
   * \left( \begin{array}{r} j' \\ i' \end{array} \right) =
   * \left[ \begin{array}{rr} a_{11} & a_{12} \\ a_{21} & a_{22} \end{array} \right]^{-1}
   * \left( \begin{array}{r} j - b_1 \\ i - b_2 \end{array} \right)
   * \f]
   *
   * A value of type \p V must be assignable to a variable of type \p U.
   * If \p x, \p y, \p z are of type \p double,
   * \p u is of type \p U and \p t1, \p t2, \p t3, \p t4
   * are of type \p const \p T, then the assignement
   * <tt> u = blend(blend(t1,t2,x),blend(t3,t4,y),z) </tt>
   * must be valid.
   * If the coefficients \p a11, \p a12, \p a21, \p a22 forms a
   * singular matrix (\f$ a_{11} a_{22} = a_{12} a_{21} \f$), an exception
   * is thrown.
   *
   * \param in input image
   * \param a11 coefficient of the transformation matrix
   * \param a12 coefficient of the transformation matrix
   * \param a21 coefficient of the transformation matrix
   * \param a22 coefficient of the transformation matrix
   * \param b1 horizontal translation
   * \param b2 vertical translation
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param new_rows dimension of the output matrix
   * \param new_columns dimension of the output matrix
   * \param out output image
   * \param blend blending functor
   * 
   * \throw std::runtime_error
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U,typename V,typename BlendFun>
  void affine_transform_bilinear(const Matrix<T>& in,
				 double a11,
				 double a12,
				 double a21,
				 double a22,
				 double b1,
				 double b2,
				 const V& padding,
				 typename Matrix<U>::size_type new_rows,
				 typename Matrix<U>::size_type new_columns,
				 Matrix<U>& out,
				 BlendFun blend)
  {
    // Note: the output coordinates are represented as fixed points
    // (12 fractional bits)

    typedef int isize;  // integer coordinates (including negative values)
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    double det = a11*a22 - a12*a21;

    if (det == 0.0)
      throw std::runtime_error("affine_transform_nearest: singular matrix");

    in_size n = in.rows();
    in_size m = in.columns();

    Matrix<U> result(new_rows,
		     new_columns,
		     padding);

    // compute the inverse of a
    double ia11 =  a22 / det;
    double ia12 = -a12 / det;
    double ia21 = -a21 / det;
    double ia22 =  a11 / det;

    // precompute some values
    ivllib::Vector<isize> jpj(new_columns);
    ivllib::Vector<isize> jpi(new_columns);
    for (out_size j = 0; j < new_columns; j++) {
      jpi[j] = 4096 * ia21 * (j - b1);
      jpj[j] = 4096 * ia11 * (j - b1);
    }

    isize stopn = n * 4096;
    isize stopm = m * 4096;

    for (out_size i = 0; i < new_rows; i++) {
      isize ipi = 4096 * ia22 * (i - b2);
      isize ipj = 4096 * ia12 * (i - b2);
      for (out_size j = 0; j < new_columns; j++) {

	isize in_j = jpj[j] + ipj;
	isize in_i = jpi[j] + ipi;

	if (in_i >= 0 && in_j >= 0 &&
	    in_i < stopn && in_j < stopm) {
	  int ifr = in_i & 4095;
	  int jfr = in_j & 4095;

	  in_size ii = in_i >> 12;
	  in_size jj = in_j >> 12;
	  
	  in_size iii = ii < n - 1 ? ii + 1 : ii;
	  in_size jjj = jj < m - 1 ? jj + 1 : jj;
	  
	  double ifactor = 1 - ifr / 4096.0;//1 - bfactor[ifr];
	  result[i][j] = blend(blend(in[ii][jj], in[iii][jj], ifactor),
			       blend(in[ii][jjj], in[iii][jjj], ifactor),
			       1 - jfr / 4096.0); // 1 - bfactor[jfr]);
	}
      }
    }
    
    out.swap(result);
  }

  /**
   * Affine transformation using a bilinear interpolation
   *
   * The more general \p affine_transform_bilinear routine is called
   * specifying \p Blend<T> as blending functor.
   * \p V  must be convertible to \p U.
   *
   * \param in input image
   * \param a11 coefficient of the transformation matrix
   * \param a12 coefficient of the transformation matrix
   * \param a21 coefficient of the transformation matrix
   * \param a22 coefficient of the transformation matrix
   * \param b1 horizontal translation
   * \param b2 vertical translation
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param new_rows dimension of the output matrix
   * \param new_columns dimension of the output matrix
   * \param out output image
   * 
   * \throw std::runtime_error
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U,typename V>
  void affine_transform_bilinear(const Matrix<T>& in,
				 double a11,
				 double a12,
				 double a21,
				 double a22,
				 double b1,
				 double b2,
				 const V& padding,
				 typename Matrix<U>::size_type new_rows,
				 typename Matrix<U>::size_type new_columns,
				 Matrix<U>& out)
  {
    affine_transform_bilinear(in,a11,a12,a21,a22,b1,b2,padding,
			      new_rows,new_columns,out,Blend<T>());
  }


  /*@}*/

} // ivllib

#endif
