/**
 * \file    labeling.h
 * \brief   labeling of connected components
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef labeling_h
#define labeling_h

//--- Headers --------------------------------------------------------

#include <ivl_matrix.h>
#include <cassert> // assert
#include <vector>  // std::vector
#include <cstddef> // std::size_t

namespace ivllib
{

  /** \addtogroup processing */
  /*@{*/

  /** Integer type used to represent labels */
  typedef std::size_t label_type;

  /** \cond detail */
  namespace detail
  {
    template <typename T> struct default_foreground;

    template <typename T,typename Pred>
    void labeling4_(const Matrix<T>& in,
		    Matrix<label_type>& out,
		    std::vector<label_type>& labels,
		    Pred pred);

    template <typename T,typename Pred>
    void labeling8_(const Matrix<T>& in,
		    Matrix<label_type>& out,
		    std::vector<label_type>& labels,
		    Pred pred);

    template <typename T,typename Equiv>
    void simplesegmentation4_(const Matrix<T>& in,
			      Matrix<label_type>& out,
			      std::vector<label_type>& labels,
			      Equiv quiv);
  }
  /** \endcond */

  /**
   * Connected components labeling.
   *
   * Labels a binary image with a different integer
   * for each maximally four-connected region of foreground pixels.
   * Background pixels are labeled with 0. Foreground pixels are
   * labeled with 1,...,\c n, where \c n is the number of regions found.
   * If @e is an expression of type @c T then the expression @c pred(e) must
   * be valid and its result must be convertible to @c bool.
   *
   * \param in input matrix
   * \param out output matrix
   * \param pred functor which determines if input pixels are foreground (true) or background (false)
   * \return number of foreground regions found (i.e. the largest label assigned to the pixels)
   * 
   * \post in.rows() == out.rows()
   * \post in.columns() == out.columns()
   * \post 0 <= out[i][j] && out[i][j] <= return_value
   * \post pred(in[i][j]) && (out[i][j] > 0)
   * \post !pred(in[i][j]) && (out[i][j] == 0)
   */
  template <typename T,typename Pred>
  label_type labeling4(const Matrix<T>& in,
		       Matrix<label_type>& out,
		       Pred pred)
  {
    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    label_type bg_label = 0;

    std::vector<label_type> equiv;
    Matrix<label_type> result(n,m,bg_label);

    detail::labeling4_(in,result,equiv,pred);
    
    // encode and assign the final labels
    std::vector<label_type> labels(equiv.size());
    labels[0] = bg_label;
    label_type last_class = 0;
    for (label_type i = 1; i < equiv.size(); i++) {
      if (equiv[i] == i) {
	++last_class;
	for (label_type j = 1; j < equiv.size(); j++)
	  if (equiv[j] == i)
	    labels[j] = last_class;
      }
    }
    
    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
	if (result[i][j] != bg_label)
	  result[i][j] = labels[result[i][j]];

    // commit
    out.swap(result);
    return last_class;
  }	       

  /**
   * Connected components labeling.
   *
   * Input pixels must be convertible to @c bool: When the result
   * is true the pixels are considered as foreground, otherwise they
   * are considered as part of the background.
   */
  template <typename T>
  label_type labeling4(const Matrix<T>& in,
		       Matrix<label_type>& out)
  {
    return labeling4(in,out,detail::default_foreground<T>());
  }

  /**
   * Connected components labeling.
   *
   * Labels a binary image with a different integer
   * for each maximally eight-connected region of foreground pixels.
   * Background pixels are labeled with 0. Foreground pixels are
   * labeled with 1,...,\c n, where \c n is the number of regions found.
   * If @e is an expression of type @c T then the expression @c pred(e) must
   * be valid and its result must be convertible to @c bool.
   *
   * \param in input matrix
   * \param out output matrix
   * \param pred functor which determines if input pixels are foreground (true) or background (false)
   * \return number of foreground regions found (i.e. the largest label assigned to the pixels)
   * 
   * \post in.rows() == out.rows()
   * \post in.columns() == out.columns()
   * \post 0 <= out[i][j] && out[i][j] <= return_value
   * \post pred(in[i][j]) && (out[i][j] > 0)
   * \post !pred(in[i][j]) && (out[i][j] == 0)
   */
  template <typename T,typename Pred>
  label_type labeling8(const Matrix<T>& in,
		       Matrix<label_type>& out,
		       Pred pred)
  {
    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    label_type bg_label = 0;

    std::vector<label_type> equiv;
    Matrix<label_type> result(n,m,bg_label);

    detail::labeling8_(in,result,equiv,pred);
    
    // encode and assign the final labels
    std::vector<label_type> labels(equiv.size());
    labels[0] = bg_label;
    label_type last_class = 0;
    for (label_type i = 1; i < equiv.size(); i++) {
      if (equiv[i] == i) {
	++last_class;
	for (label_type j = 1; j < equiv.size(); j++)
	  if (equiv[j] == i)
	    labels[j] = last_class;
      }
    }
    
    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
	if (result[i][j] != bg_label)
	  result[i][j] = labels[result[i][j]];

    // commit
    out.swap(result);
    return last_class;
  }	       

  /**
   * Connected components labeling.
   *
   * Input pixels must be convertible to @c bool: When the result
   * is true the pixels are considered as foreground, otherwise they
   * are considered as part of the background.
   */
  template <typename T>
  label_type labeling8(const Matrix<T>& in,
		       Matrix<label_type>& out)
  {
    return labeling8(in,out,detail::default_foreground<T>());
  }


  /**
   * Simple segmentation.
   *
   * Segments an image by labeling connected regions of "equivalent"
   * pixels.  Region pixels are labeled with 0,...,\c n - 1, where \c
   * n is the number of regions found.  If @c e1 ans @c e2 are
   * expressions of type @c T then the expression @c equiv(e1, e2)
   * must be valid and its result must be convertible to @c bool.
   *
   * \param in input matrix
   * \param out output matrix
   * \param equiv functor which determines if two input pixels are equivalent
   * \return number of regions found
   * 
   * \post in.rows() == out.rows()
   * \post in.columns() == out.columns()
   * \post 0 <= out[i][j] && out[i][j] < return_value
   */
  template <typename T,typename Equiv>
  label_type simplesegmentation4(const Matrix<T>& in,
				 Matrix<label_type>& out,
				 Equiv equiv)
  {
    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    std::vector<label_type> equivcl;
    Matrix<label_type> result(n, m);

    detail::simplesegmentation4_(in, result, equivcl, equiv);
    
    // encode and assign the final labels
    std::vector<label_type> labels(equivcl.size());
    label_type last_class = 0;
    for (label_type i = 0; i < equivcl.size(); i++) {
      if (equivcl[i] == i) {
	for (label_type j = 0; j < equivcl.size(); j++)
	  if (equivcl[j] == i)
	    labels[j] = last_class;
	++last_class;
      }
    }
    
    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
    	result[i][j] = labels[result[i][j]];

    // commit
    out.swap(result);
    return last_class;
  }

	       
  /**
   * Simple segmentation.
   *
   * Segments an image by labeling connected regions of equal pixels.
   * Region pixels are labeled with 0,...,\c n - 1, where \c n is the
   * number of regions found.  The standard functor \c std::equal_to
   * must be supported by @c T.
   *
   * \param in input matrix
   * \param out output matrix
   * \return number of regions found
   * 
   * \post in.rows() == out.rows()
   * \post in.columns() == out.columns()
   * \post 0 <= out[i][j] && out[i][j] < return_value
   */
  template <typename T>
  label_type simplesegmentation4(const Matrix<T>& in,
				 Matrix<label_type>& out)
  {
    return simplesegmentation4(in, out, std::equal_to<T>());
  }

  /*@}*/

} // ivllib

/** \cond detail */
// helper functions and structures
template <typename T>
struct ivllib::detail::default_foreground
{
  bool operator()(const T& x) const
  {
    return x;
  }
};

template <typename T,typename Pred>
void ivllib::detail::labeling4_(const ivllib::Matrix<T>& in,
				ivllib::Matrix<label_type>& out,
				std::vector<label_type>& labels,
				Pred pred)
{
  // precondition: out[i][j] == 0 for all i and j
  assert(labels.size() == 0);
  assert(out.rows() == in.rows());
  assert(out.columns() == in.columns());
  
  typedef typename Matrix<T>::size_type size_type;
      
  size_type n = in.rows();
  size_type m = in.columns();

  label_type bg_label = 0;
  labels.push_back(bg_label);
    
  if (n < 1 || m < 1)
    return;
  
  // label the top-left corner
  if (pred(in[0][0])) {
    out[0][0] = labels.size();
    labels.push_back(labels.size());
  }
    
  // label the first row
  for (size_type j = 1; j < m; j++) {
    if (pred(in[0][j])) {
      if (out[0][j-1] == bg_label) {
	out[0][j] = labels.size();
	labels.push_back(labels.size());
      } else {
	out[0][j] = out[0][j-1];
      }
    }
  }
  
  // label the first column
  for (size_type i = 1; i < n; i++) {
    if (pred(in[i][0])) {
      if (out[i-1][0] == bg_label) {
	out[i][0] = labels.size();
	labels.push_back(labels.size());
      } else {
	out[i][0] = out[i-1][0];
      }
    }
  }

  // process the remaining image
  for (size_type i = 1; i < n; i++) {
    for (size_type j = 1; j < m; j++) {
      if (pred(in[i][j])) {
	label_type lp = out[i][j-1];
	label_type lq = out[i-1][j];
  
	if (lp == bg_label) {
	  if (lq == bg_label) {
	    out[i][j] = labels.size();
	    labels.push_back(labels.size());
	  } else {
	    out[i][j] = lq;
	  }
	} else {
	  if (lq == bg_label) {
	    out[i][j] = lp;
	  } else {
	    if (labels[lp] != labels[lq]) {
	      if (labels[lp] == labels.size() - 1) {
		labels[lp] = labels[lq];
	      } else if (labels[lq] == labels.size() - 1) {
		labels[lq] = labels[lp];
	      } else {
		label_type old_eq = labels[lq];
		label_type new_eq = labels[lp];
		for (label_type k = 1; k<labels.size(); k++)
		  if (labels[k] == old_eq)
		    labels[k] = new_eq;
	      }
	    }
	    out[i][j] = lp;
	  }
	}
      }
    }
  }
}

template <typename T,typename Pred>
void ivllib::detail::labeling8_(const ivllib::Matrix<T>& in,
				ivllib::Matrix<label_type>& out,
				std::vector<label_type>& labels,
				Pred pred)
{
  // precondition: out[i][j] == 0 for all i and j
  assert(labels.size() == 0);
  assert(out.rows() == in.rows());
  assert(out.columns() == in.columns());

  typedef typename Matrix<T>::size_type size_type;
    
  size_type n = in.rows();
  size_type m = in.columns();

  label_type bg_label = 0;
  labels.push_back(bg_label);
      
  if (n < 1 || m < 1)
    return;
      
  // label the top-left corner
  if (pred(in[0][0])) {
    out[0][0] = labels.size();
    labels.push_back(labels.size());
  }
    
  // label the first row
  for (size_type j = 1; j < m; j++) {
    if (pred(in[0][j])) {
      if (out[0][j-1] == bg_label) {
	out[0][j] = labels.size();
	labels.push_back(labels.size());
      } else {
	out[0][j] = out[0][j-1];
      }
    }
  }

  // label the pixel of index 1,0
  if (n > 1) {
    if (pred(in[1][0])) {
      if (out[0][0] != bg_label)
	out[1][0] = out[0][0];
      else if (m > 1 && out[0][1] != bg_label)
	out[1][0] = out[0][1];
    }
  }

  // label the first column
  for (size_type i = 2; i < n; i++) {
    if (pred(in[i][0])) {
      if (out[i-1][0] == bg_label) {
	out[i][0] = labels.size();
	labels.push_back(labels.size());
      } else {
	out[i][0] = out[i-1][0];
      }
    }
  }

  // process the remaining image
  for (size_type i = 1; i < n; i++) {
    for (size_type j = 1; j <  m - 1; j++) {
      if (pred(in[i][j])) {
	//
	// | a | b | c |
	// +---+---+---+
	// | d | X |
	//

	label_type la = out[i-1][j-1];
	label_type lb = out[i-1][j];
	label_type lc = out[i-1][j+1];
	label_type ld = out[i][j-1];
	  
	if (lb != bg_label) {
	  // b is adjacent to all a,b,c, and d so, all
	  // possible conflicts have already been resolved
	  out[i][j] = lb;
	} else {
	  label_type lad = (la != bg_label ? la : ld);
	  if (lad == bg_label) {
	    if (lc == bg_label) {
	      // all background: new label
	      out[i][j] = labels.size();
	      labels.push_back(labels.size());
	    } else {
	      out[i][j] = lc;
	    } 
	  } else {
	    // no unresolved conflict between la and ld
	    if (lc == bg_label) {
	      out[i][j] = lad;
	    } else {
	      if (labels[lad] != labels[lc]) {		  
		// conflict between a/d and c
		if (labels[lad] == labels.size() - 1) {
		  labels[lad] = labels[lc];
		} else if (labels[lc] == labels.size() - 1) {
		  labels[lc] = labels[lad];
		} else {
		  label_type old_eq = labels[lad];
		  label_type new_eq = labels[lc];
		  for (label_type k = 1; k<labels.size(); k++)
		    if (labels[k] == old_eq)
		      labels[k] = new_eq;		    
		}
	      }
	      out[i][j] = lc;
	    }
	  }
	}
      }
    }
    // process the last column
    if (pred(in[i][m-1])) {
      label_type la = out[i-1][m-2];
      label_type lb = out[i-1][m-1];
      label_type ld = out[i][m-2];
	
      // no possible conflict

      out[i][m-1] = (la != bg_label ? la
		     : lb != bg_label ? lb
		     : ld);
    }
  }
}


template <typename T,typename Equiv>
void ivllib::detail::simplesegmentation4_(const ivllib::Matrix<T>& in,
					  ivllib::Matrix<label_type>& out,
					  std::vector<label_type>& labels,
					  Equiv equiv)
{
  assert(labels.size() == 0);
  assert(out.rows() == in.rows());
  assert(out.columns() == in.columns());
  
  typedef typename Matrix<T>::size_type size_type;
      
  size_type n = in.rows();
  size_type m = in.columns();

  if (n < 1 || m < 1)
    return;
  
  // process the top-left corner
  out[0][0] = labels.size();
  labels.push_back(labels.size());
    
  // process the first row
  for (size_type j = 1; j < m; j++) {
    if (equiv(in[0][j-1], in[0][j])) {
      out[0][j] = out[0][j-1];
    } else {
      out[0][j] = labels.size();
      labels.push_back(labels.size());
    }
  }
  
  // process the first column
  for (size_type i = 1; i < n; i++) {
    if (equiv(in[i-1][0], in[i][0])) {
      out[i][0] = out[i-1][0];
    } else {
      out[i][0] = labels.size();
      labels.push_back(labels.size());
    }
  }
  
  // process the remaining image
  for (size_type i = 1; i < n; i++) {
    for (size_type j = 1; j < m; j++) {
      label_type lp = out[i][j-1];
      label_type lq = out[i-1][j];
  
      bool ep = equiv(in[i][j-1], in[i][j]);
      bool eq = equiv(in[i-1][j], in[i][j]);

      if (ep) {
	if (eq) {
	  if (labels[lp] != labels[lq]) {
	    if (labels[lp] == labels.size() - 1) {
	      labels[lp] = labels[lq];
	    } else if (labels[lq] == labels.size() - 1) {
	      labels[lq] = labels[lp];
	    } else {
	      label_type old_eq = labels[lq];
	      label_type new_eq = labels[lp];
	      for (label_type k = 0; k < labels.size(); k++)
		if (labels[k] == old_eq)
		  labels[k] = new_eq;
	    }
	  }
	  out[i][j] = lp;
	} else {
	  out[i][j] = lp;
	}
      } else if (eq) {
	out[i][j] = lq;
      } else {
	out[i][j] = labels.size();
	labels.push_back(labels.size());
      }
    }
  }
}

    
/** \endcond */

#endif

