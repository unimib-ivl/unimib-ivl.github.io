/**
 * \file    png_io.h
 * \brief   io routines for the png graphic format (based on libpng)
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef png_io_h
#define png_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <imaging/exception_io.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/

  /**
   * Load an image in the png format
   *
   * If the image is encoded with an alpha channel
   * a ImageConversionError exception is thrown
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void load_png(const std::string& filename,
		Matrix<RGB8>& out);

  /**
   * Load an image in the png format
   *
   * Alpha channel is set to 255.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_png(const std::string& filename,
		Matrix<RGBA8>& out);


  /**
   * Load an image in the png format
   *
   * If the image is not encoded as greyscale png,
   * an \p ImageConversionError exception is thrown
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */
  void load_png(const std::string& filename,
		Matrix<Gray8>& out);
  
  /**
   * Save an image in the Png format
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param compression_level parameter in the range from
   *   0 (no compression) to 9 (maximum compression)
   *
   * \pre compression_level <= 9
   *
   * \throw ImageFileError
   */ 
  void save_png(const std::string& filename,
		const Matrix<RGB8>& in,
		unsigned int compression_level=6);

  /**
   * Save an image in the Png format
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param compression_level parameter in the range from
   *   0 (no compression) to 9 (maximum compression)
   *
   * \pre compression_level <= 9
   *
   * \throw ImageFileError
   */ 
  void save_png(const std::string& filename,
		const Matrix<RGBA8>& in,
		unsigned int compression_level=6);

  /**
   * Save an image in the Png format
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param compression_level parameter in the range from
   *   0 (no compression) to 9 (maximum compression)
   *
   * \pre compression_level <= 9
   *
   * \throw ImageFileError
   */ 
  void save_png(const std::string& filename,
		const Matrix<Gray8>& in,
		unsigned int compression_level=6);

  /*@}*/
  
}

#endif
