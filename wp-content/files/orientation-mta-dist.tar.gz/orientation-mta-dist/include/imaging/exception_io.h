/**
 * \file    exception_io.h
 * \brief   exception classes for image io errors
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef exception_io_h
#define exception_io_h

#include <stdexcept>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/
  
  /**
   * General exception type for image io.
   */
  class ImageIoError
    : public std::runtime_error
  {
  public:
    /// constructor
    explicit ImageIoError(const std::string& message)
      : std::runtime_error(message)
    {
    }
  };

  /**
   * Format exception type for image io.
   *
   * Raised while parsing an ill formed file.
   */
  class ImageFormatError
    : public ImageIoError
  {
  public:
    /// constructor
    explicit ImageFormatError(const std::string& message)
      : ImageIoError(message)
    {
    }
  };
  
  /**
   * File exception type for image io.
   *
   * Raised when there are problem (not concerning the format)
   * reading/writing an image from/to a file.
   */
  class ImageFileError
    : public ImageIoError
  {
  public:
    /// constructor
    ImageFileError(const std::string& message)
      : ImageIoError(message)
    {
    }
  };

  /**
   * File exception type for image io.
   *
   * Raised when the specified graphic format
   * is incompatible with the destination image
   * (e.g. loading a RGB image into a matrix of scalar values)
   */
  class ImageConversionError
    : public ImageIoError
  {
  public:
    /// constructor
    ImageConversionError(const std::string& message)
      : ImageIoError(message)
    {
    }
  };

  /*@}*/ 

} // namespace ivllib

#endif
