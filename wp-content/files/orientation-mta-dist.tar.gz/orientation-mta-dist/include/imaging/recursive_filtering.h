/**
 * \file recursive_filtering.h
 * \brief local filters implemented recursively
 */
#ifndef recursive_filtering_h
#define recursive_filtering_h

#include <cmath>
#include <ivl_matrix.h>
#include <ivl_vector.h>



// Note:
//
// The implementation of recursive filters for the Gaussian and its
// derivatives is based on:
//
// I. T. Young, L. J. van Vliet, "Recursive Implementation of the
// Gaussian Filter," Signal Processing (44), pp. 139-151, 1995.
//
// with some minor adjustment taken from
//
// A. Lukin, "Tips & Tricks: Fast Image Filtering
// Algorithms," Proceedings of GraphiCon, 2007, pp. 186-189
//
// and with the boundary correction from
//
// B. Triggs and M. Sdika, "Boundary Conditions for Young–van Vliet
// Recursive Filtering," IEEE Trans. on Signal Processing (54 no. 6),
// pp. 2365-2367, 2006.


namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Recursive Gaussian filter.
   *
   * Apply Gaussian smoothing, or derivative, to the matrix \a src,
   * and store the result in the matrix \a dest.  Both \c T and \c Q
   * should be scalar.  Some intermediate results are stored in
   * doubles, other are directly stored in the output matrix.  Maximum
   * precision is obtained when \c Q is \c double.  The borders of the
   * input matrix is padded by replication.
   *
   * The parameters \a degreeh and \a degreev denotes the degree of
   * derivation of the filter in the horizontal and vertical
   * directions, respectively (first or second derivative, zero
   * denotes standard Gaussian filtering). The parameters \a sigmah
   * and \a sigmav represent the horizontal and vertical scale of the
   * filter (values below 0.5 are discouraged).
   *
   * \pre sigmah > 0
   * \pre sigmav > 0
   * \pre degreeh >= 0
   * \pre degreeh <= 2
   * \pre degreev >= 0
   * \pre degreev <= 2
   *
   * \post src.rows() == dest.rows()
   * \post src.columns() == dest.columns()
   *
   * \param src input matrix
   * \param sigmah horizontal scale
   * \param sigmav vertical scale
   * \param degreeh degree of the derivative in the horizontal direction
   * \param degreev degree of the derivative in the vertical direction
   * \param dest output matrix
   */
  template<typename T, typename Q>
  void recursive_gaussian(const ivllib::Matrix<T>& src,
			  double sigmah,
			  double sigmav,
			  int degreeh,
			  int degreev,
			  ivllib::Matrix<Q>& dest);
  /*@}*/

  /** \cond detail */
  namespace recursive_filt_detail
  {
    // 3x3 matrix multiplication.
    inline void matmul(const double* A, const double* B, double* C)
    {
      for (int i = 0; i < 3; i++) {
	for (int j = 0; j < 3; j++) {
	  C[i + 3 * j] = 0;
	  for (int k = 0; k < 3; k++)
	    C[i + 3 * j] += A[i + 3 * k] * B[k + 3 * j];
	}
      }
    }

    // Matrix/vector multiplication.
    inline void matmulv(const double* A, const double* x, double* y)
    {
      double y0 = A[0] * x[0] + A[3] * x[1] + A[6] * x[2];
      double y1 = A[1] * x[0] + A[4] * x[1] + A[7] * x[2];
      double y2 = A[2] * x[0] + A[5] * x[1] + A[8] * x[2];
      y[0] = y0;
      y[1] = y1;
      y[2] = y2;
    }

    // Solve a 3x3 linear system with Cramer's rule.
    inline void matsolve(const double* A, const double* b, double* x)
    {
      double det = (A[0] * (A[4] * A[8] - A[7] * A[5]) -
		    A[3] * (A[1] * A[8] - A[7] * A[2]) +
		    A[6] * (A[1] * A[5] - A[4] * A[2]));
      double idet = (det == 0 ? 0 : 1.0 / det);

      double s0 = (b[0] * (A[4] * A[8] - A[7] * A[5]) -
		   A[3] * (b[1] * A[8] - A[7] * b[2]) +
		   A[6] * (b[1] * A[5] - A[4] * b[2])) * idet;

      double s1 = (A[0] * (b[1] * A[8] - A[7] * b[2]) -
		   b[0] * (A[1] * A[8] - A[7] * A[2]) +
		   A[6] * (A[1] * b[2] - b[1] * A[2])) * idet;

      double s2 = (A[0] * (A[4] * b[2] - b[1] * A[5]) -
		   A[3] * (A[1] * b[2] - b[1] * A[2]) +
		   b[0] * (A[1] * A[5] - A[4] * A[2])) * idet;

      x[0] = s0;
      x[1] = s1;
      x[2] = s2;
    }


    // Compute the parameters for the filters.
    inline void fastgauss_parameters(double sigma,
				     double& a0,
				     double& a1,
				     double& a2,
				     double& a3,
				     double* M,
				     double* N)
    {
      assert(sigma > 0);

      // 1) Compute the coefficients of the filters.
      double q1 = (sigma >= 2.5
		   ? 0.98711 * sigma - 0.96330
		   : 3.97156 - 4.14554 * std::sqrt(1.0 - 0.26891 * sigma));

      double q2 = q1 * q1;
      double q3 = q2 * q1;

      double lambda = 1.0 / (1.57825 + 2.44413*q1 + 1.4281*q2 + 0.422205*q3);
      a1 = lambda * (2.44413 * q1 + 2.85619 * q2 + 1.26661 * q3);
      a2 = lambda * (-1.4281 * q2 - 1.26661 * q3);
      a3 = lambda * (0.422205 * q3);
      a0 = 1.0 - a1 - a2 - a3;

      // 2) Compute the matrix for the boundary correction.

      // Note: column-major ordering is used so that it is possible to
      // easily extract the columns.
      double A[9] = {
	a1, 1, 0,
	a2, 0, 1,
	a3, 0, 0
      };

      double A2[9];
      matmul(A, A, A2);

      double A3[9];
      matmul(A, A2, A3);

      double K[9];
      for (int i = 0; i < 9; i++)
	K[i] = (i % 4 == 0 ? 1 : 0) - (a1 * A[i] + a2 * A2[i] + a3 * A3[i]);

      double c[3] = {a0, 0, 0};
      matsolve(K, c, M);

      double AM1[3];
      matmulv(A, M + 0, AM1);

      double A2M1[3];
      matmulv(A, AM1, A2M1);

      M[3] = AM1[0] * a2 + A2M1[0] * a3;
      M[4] = AM1[1] * a2 + A2M1[1] * a3;
      M[5] = AM1[2] * a2 + A2M1[2] * a3;

      M[6] = AM1[0] * a3;
      M[7] = AM1[1] * a3;
      M[8] = AM1[2] * a3;

      // 3) Compute the matrix for the correction of the second derivative.
      double D[9] = {
	a0, 0, 0,
	-a0, 0, 0,
	0, 0, 0
      };
      double C[9];
      matmul(D, A, C);
      
      c[0] = C[0];
      c[1] = C[1];
      c[2] = C[2];
      
      double c2[3];
      matmulv(A, C + 3, c2);
      c[0] += c2[0];
      c[1] += c2[1];
      c[2] += c2[2];

      matmulv(A2, C + 6, c2);
      c[0] += c2[0];
      c[1] += c2[1];
      c[2] += c2[2];

      matsolve(K, c, N);
      matmulv(A, N + 0, AM1);
      matmulv(A, AM1, A2M1);

      matmulv(A, C + 6, c2);
      N[3] = C[3] + c2[0] + AM1[0] * a2 + A2M1[0] * a3;
      N[4] = C[4] + c2[1] + AM1[1] * a2 + A2M1[1] * a3;
      N[5] = C[5] + c2[2] + AM1[2] * a2 + A2M1[2] * a3;

      N[6] = C[6] + AM1[0] * a3;
      N[7] = C[7] + AM1[1] * a3;
      N[8] = C[8] + AM1[2] * a3;
    }


    template <typename T, typename U>
    void fastgauss_rows_0(const Matrix<T>& src,
			  Vector<double>& buffer,
			  double a0,
			  double a1,
			  double a2,
			  double a3,
			  const double* M,
			  Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.columns() > 0);
      assert(buffer.size() >= src.columns());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();

      for (size_type i = 0; i < n; i++) {
	// Forward.
	double p1 = src[i][0];
	double p2 = p1;
	double p3 = p1;
	for (size_type j = 0; j < m; j++) {
	  buffer[j] = a0 * src[i][j] + a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[j];
	}

	// Backward.
	double pad = src[i][m - 1];
	double q[3] = { p1 - pad, p2 - pad, p3 - pad };
	matmulv(M, q, q);
	p1 = q[0] + pad;
	p2 = q[1] + pad;
	p3 = q[2] + pad;
	dest[i][m - 1] = p1;
	size_type j = m - 1;
	while(j > 0) {
	  --j;
	  double val = a0 * buffer[j] + a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }


    template <typename T, typename U>
    void fastgauss_rows_1(const Matrix<T>& src,
			  Vector<double>& buffer,
			  double a0,
			  double a1,
			  double a2,
			  double a3,
			  const double* M,
			  Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.columns() > 1);
      assert(buffer.size() >= src.columns());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();
      double a0_2 = a0 * 0.5;

      for (size_type i = 0; i < n; i++) {
	// Forward.
	buffer[0] = a0_2 * (src[i][1] - src[i][0]);
	double p1 = buffer[0];
	double p2 = 0;
	double p3 = 0;
	for (size_type j = 1; j + 1 < m; j++) {
	  buffer[j] = a0_2 * (src[i][j + 1] - src[i][j - 1]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[j];
	}
	buffer[m - 1] = a0_2 * (src[i][m - 1] - src[i][m - 2]) +
	  a1 * p1 + a2 * p2 + a3 * p3;
	p3 = p2;
	p2 = p1;
	p1 = buffer[m - 1];

	// Backward.
	double q[3] = { p1, p2, p3 };
	matmulv(M, q, q);
	p1 = q[0];
	p2 = q[1];
	p3 = q[2];
	dest[i][m - 1] = p1;
	size_type j = m - 1;
	while (j > 0) {
	  --j;
	  double val = a0 * buffer[j] + a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }


    template <typename T, typename U>
    void fastgauss_rows_2(const Matrix<T>& src,
			  Vector<double>& buffer,
			  double a0,
			  double a1,
			  double a2,
			  double a3,
			  const double* M,
			  Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.columns() > 1);
      assert(buffer.size() >= src.columns());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();

      for (size_type i = 0; i < n; i++) {
	// Forward.
	buffer[0] = 0;
	double p1 = 0;
	double p2 = 0;
	double p3 = 0;
	for (size_type j = 1; j < m; j++) {
	  buffer[j] = a0 * (src[i][j] - src[i][j - 1]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[j];
	}

	// Backward.
	double q[3] = { p1, p2, p3 };
	matmulv(M, q, q);
	p1 = q[0];
	p2 = q[1];
	p3 = q[2];
	dest[i][m - 1] = p1;
	size_type j = m - 1;
	while (j > 0) {
	  --j;
	  double val = a0 * (buffer[j + 1] - buffer[j]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }


    template <typename T, typename U>
    void fastgauss_columns_0(const Matrix<T>& src,
			     Vector<double>& buffer,
			     double a0,
			     double a1,
			     double a2,
			     double a3,
			     const double* M,
			     Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.rows() > 0);
      assert(buffer.size() >= src.rows());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();
      
      for (size_type j = 0; j < m; j++) {
	// Forward.
	double p1 = src[0][j];
	double p2 = p1;
	double p3 = p1;
	for (size_type i = 0; i < n; i++) {
	  buffer[i] = a0 * src[i][j] + a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[i];
	}

	// Backward.
	double pad = src[n - 1][j];
	double q[3] = { p1 - pad, p2 - pad, p3 - pad };
	matmulv(M, q, q);
	p1 = q[0] + pad;
	p2 = q[1] + pad;
	p3 = q[2] + pad;
	dest[n - 1][j] = p1;
	size_type i = n - 1;
	while (i > 0) {
	  --i;
	  double val = a0 * buffer[i] + a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }


    template <typename T, typename U>
    void fastgauss_columns_1(const Matrix<T>& src,
			     Vector<double>& buffer,
			     double a0,
			     double a1,
			     double a2,
			     double a3,
			     const double* M,
			     Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.rows() > 1);
      assert(buffer.size() >= src.rows());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();
      double a0_2 = a0 * 0.5;
      
      for (size_type j = 0; j < m; j++) {
	// Forward.
	buffer[0] = a0_2 * (src[1][j] - src[0][j]);
	double p1 = buffer[0];
	double p2 = 0;
	double p3 = 0;

	for (size_type i = 1; i + 1 < n; i++) {
	  buffer[i] = a0_2 * (src[i + 1][j] - src[i - 1][j]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[i];
	}
	buffer[n - 1] = a0_2 * (src[n - 1][j] - src[n - 2][j]) +
	  a1 * p1 + a2 * p2 + a3 * p3;
	p3 = p2;
	p2 = p1;
	p1 = buffer[n - 1];

	// Backward.
	double q[3] = { p1, p2, p3 };
	matmulv(M, q, q);
	p1 = q[0];
	p2 = q[1];
	p3 = q[2];
	dest[n - 1][j] = p1;
	size_type i = n - 1;
	while(i > 0) {
	  --i;
	  double val = a0 * buffer[i] + a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }


    template <typename T, typename U>
    void fastgauss_columns_2(const Matrix<T>& src,
			     Vector<double>& buffer,
			     double a0,
			     double a1,
			     double a2,
			     double a3,
			     const double* M,
			     Matrix<U>& dest)
    {
      assert(src.rows() == dest.rows());
      assert(src.columns() == dest.columns());
      assert(src.rows() > 1);
      assert(buffer.size() >= src.rows());

      typedef typename Matrix<T>::size_type size_type;
      size_type n = src.rows();
      size_type m = src.columns();
      
      for (size_type j = 0; j < m; j++) {
	// Forward.
	buffer[0] = 0;
	double p1 = 0;
	double p2 = 0;
	double p3 = 0;
	for (size_type i = 1; i < n; i++) {
	  buffer[i] = a0 * (src[i][j] - src[i - 1][j]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  p3 = p2;
	  p2 = p1;
	  p1 = buffer[i];
	}

	// Backward.
	double q[3] = { p1, p2, p3 };
	matmulv(M, q, q);
	p1 = q[0];
	p2 = q[1];
	p3 = q[2];
	dest[n - 1][j] = p1;
	size_type i = n - 1;
	while (i > 0) {
	  --i;
	  double val = a0 * (buffer[i + 1] - buffer[i]) +
	    a1 * p1 + a2 * p2 + a3 * p3;
	  dest[i][j] = val;
	  p3 = p2;
	  p2 = p1;
	  p1 = val;
	}
      }
    }

  }
  /** \endcond  */


  template<typename T, typename Q>
  void recursive_gaussian(const ivllib::Matrix<T>& src,
			  double sigmah,
			  double sigmav,
			  int degreeh,
			  int degreev,
			  ivllib::Matrix<Q>& dest)
  {
    assert(sigmah > 0);
    assert(sigmav > 0);
    assert(degreeh >= 0);
    assert(degreeh <= 3);
    assert(degreev >= 0);
    assert(degreev <= 3);

    typedef typename ivllib::Matrix<T>::size_type size_type;
    size_type rows = src.rows();
    size_type cols = src.columns();

    ivllib::Matrix<Q> tmp(rows, cols);

    if (rows < 1 || cols < 1) {
      dest.swap(tmp);
      return;
    }

    double a0;
    double a1;
    double a2;
    double a3;
    double M[9];
    double N[9];
    recursive_filt_detail::fastgauss_parameters(sigmah, a0, a1, a2, a3, M, N);

    Vector<double> buffer(rows > cols ? rows : cols);
    switch (degreeh) {
    case 0:
      recursive_filt_detail::fastgauss_rows_0(src, buffer, a0, a1, a2, a3, M, tmp);
      break;
    case 1:
      recursive_filt_detail::fastgauss_rows_1(src, buffer, a0, a1, a2, a3, M, tmp);
      break;
    case 2:
      recursive_filt_detail::fastgauss_rows_2(src, buffer, a0, a1, a2, a3, N, tmp);
      break;
    default:
      assert(0);
    }

    if (sigmah != sigmav)
      recursive_filt_detail::fastgauss_parameters(sigmav, a0, a1, a2, a3, M, N);

    switch (degreev) {
    case 0:
      recursive_filt_detail::fastgauss_columns_0(tmp, buffer, a0, a1, a2, a3, M,tmp);
      break;
    case 1:
      recursive_filt_detail::fastgauss_columns_1(tmp, buffer, a0, a1, a2, a3, M,tmp);
      break;
    case 2:
      recursive_filt_detail::fastgauss_columns_2(tmp, buffer, a0, a1, a2, a3, N,tmp);
      break;
    default:
      assert(0);
    }
    
    tmp.swap(dest);
  }

}  // namespace ivllib

#endif  // recursive_filtering_h
