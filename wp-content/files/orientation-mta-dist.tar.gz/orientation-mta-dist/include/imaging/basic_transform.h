/**
 * \file    basic_transform.h
 * \brief   basic transformations (rotations ...)
 * \author  $LastChangedBy: cusano $
 * \date    $Date: 2012-05-28 16:40:16 +0200 (Mon, 28 May 2012) $
 * \version $Revision: 397 $
 */

#ifndef basic_transform_h
#define basic_transform_h

#include <ivl_matrix.h>
#include <ivl_box.h>
#include <mat_algorithm.h>
#include <iterator>
#include <algorithm>
#include <cassert> // assert
#include <cmath> // sin,cos

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Rotate an image counterclockwise by a multiple of 90 degrees.
   *
   * A value of type T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param angle degrees of counterclockwise rotation
   * \param out output image
   *
   * \pre (angle % 90) == 0
   *
   * \post out.rows() == (angle % 180) == 0 ? in.rows() : in.columns()
   * \post out.columns() == (angle % 180) == 0 ? in.columns() : in.rows()
   */
  template <typename T,typename U>
  void simple_rotate(const Matrix<T>& in,
		     int angle,
		     Matrix<U>& out)
  {
    while (angle < 0)
      angle += 360;
    while (angle >= 360)
      angle -= 360;

    assert((angle % 90) == 0);
    
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    out_size new_rows = (angle % 180) == 0 ? n : m;
    out_size new_columns = (angle % 180) == 0 ? m : n;

    Matrix<U> result(new_rows,new_columns);

    if (angle == 0) {
      std::copy(in.begin(),in.end(),result.begin());
    } else if (angle == 90) {
      typedef std::reverse_iterator<typename Matrix<U>::column_iterator> rev_iter;
      for (in_size i = 0; i<n; i++) {
	std::copy(in.row_begin(i),
		  in.row_end(i),
		  rev_iter(result.column_end(i)));
      }
    } else if (angle == 180) {
      typedef std::reverse_iterator<typename Matrix<U>::row_iterator> rev_iter;
      for (in_size i = 0; i<n; i++) {
	std::copy(in.row_begin(i),
		  in.row_end(i),
		  rev_iter(result.row_end(n-i-1)));
      }
    } else {
      // angle == 270
      for (in_size i = 0; i<n; i++) {
	std::copy(in.row_begin(i),
		  in.row_end(i),
		  result.column_begin(n-i-1));
      }
    }

    out.swap(result);
  }

  /**
   * Flip an image horizontally
   *
   * A value of type T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param out output image
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U>
  void flip_horizontally(const Matrix<T>& in,
			 Matrix<U>& out)
  {
    typedef typename Matrix<T>::size_type in_size;

    in_size n = in.rows();
    in_size m = in.columns();

    Matrix<U> result(n,m);

    typedef std::reverse_iterator<typename Matrix<U>::row_iterator> rev_iter;
    for (in_size i = 0; i<n; i++) {
      std::copy(in.row_begin(i),
		in.row_end(i),
		rev_iter(result.row_end(i)));
    }

    out.swap(result);
  }

  /**
   * Flip an image vertically
   *
   * A value of type T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param out output image
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U>
  void flip_vertically(const Matrix<T>& in,
		       Matrix<U>& out)
  {
    typedef typename Matrix<T>::size_type in_size;

    in_size n = in.rows();
    in_size m = in.columns();

    Matrix<U> result(n,m);

    for (in_size i = 0; i<n; i++) {
      std::copy(in.row_begin(i),
		in.row_end(i),
		result.row_begin(n - i - 1));
    }

    out.swap(result);
  }

  /** \cond detail*/
  namespace detail
  {
    inline void rotate_point(double i,    // row
			     double j,    // column
			     double cosa, // cos(angle)
			     double sina, // sin(angle)
			     double& ii,  // out_row
			     double& jj)  // out_column
    {
      jj = cosa*j - sina*i;
      ii = sina*j + cosa*i;
    }
  }
  /** \endcond */

  /**
   * Image counterclockwise rotation using the nearest neighbor strategy.
   *
   * A value of type \p T or \p V must be assignable to a variable of type \p U.
   * The size of the output matrix are chosen to contain the input
   * image after the rotation.
   *
   * \param in input image
   * \param angle angle of rotation (in radians)
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param out output image
   */
  template <typename T,typename U,typename V>
  void rotate_nearest(const Matrix<T>& in,
		      double angle,
		      const V& padding,
		      Matrix<U>& out)
  {
    using detail::rotate_point;

    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    double cosa = std::cos(angle);
    double sina = std::sin(angle);

    // compute the coordinates of the four corners of the
    // input image after the rotation around the origin
    in_size in_corners_i[4] = {0,n,n,0};
    in_size in_corners_j[4] = {0,0,m,m};
    
    double min_i = 0.0;
    double min_j = 0.0;
    double max_i = 0.0;
    double max_j = 0.0;

    for (std::size_t k = 1; k<4; k++) {
      
      double ii;
      double jj;

      rotate_point(in_corners_i[k],
		   in_corners_j[k],
		   cosa,
		   -sina,
		   ii,
		   jj);

      if (ii < min_i)
	min_i = ii;
      if (jj < min_j)
	min_j = jj;
      if (ii > max_i)
	max_i = ii;
      if (jj > max_j)
	max_j = jj;
    }
    
    out_size new_rows = static_cast<out_size>(max_i - min_i);
    out_size new_columns = static_cast<out_size>(max_j - min_j);
    
    assert( new_rows >= 0 );
    assert( new_columns >= 0);
    
    Matrix<U> result(new_rows,
		     new_columns,
		     padding);
    
    for (out_size i = 0; i < new_rows; i++) {
      for (out_size j = 0; j < new_columns; j++) {
	double in_i;
	double in_j;

	rotate_point(i + min_i,
		     j + min_j,
		     cosa,
		     sina,
		     in_i,
		     in_j);
	
	in_i += 0.5;
	in_j += 0.5;

	if (in_i >= 0 && in_j >= 0 &&
	    in_i < n && in_j < m) {
	  in_size ii = static_cast<in_size>(in_i);
	  in_size jj = static_cast<in_size>(in_j);

	  result[i][j] = in[ii][jj];
	}
      }
    }
    
    out.swap(result);
  }

  /**
   * Image counterclockwise rotation using a bilinear interpolation strategy.
   *
   * The size of the output matrix are chosen to contain the input
   * image after the rotation.
   * If \p x, \p y, \p z are of type \p double,
   * \p u is of type \p U and \p t1, \p t2, \p t3, \p t4
   * are of type \p const \p T, then the assignement
   * <tt> u = blend(blend(t1,t2,x),blend(t3,t4,y),z) </tt>
   * must be valid.
   * \p W must be convertible to \p U.
   *
   * \param in input image
   * \param angle angle of rotation (in radians)
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param out output image
   * \param blend blending functor
   */
  template <typename T,typename U,typename W,typename BlendFun>
  void rotate_bilinear(const Matrix<T>& in,
		       double angle,
		       const W& padding,
		       Matrix<U>& out,
		       BlendFun blend)
  {
    using detail::rotate_point;

    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    double cosa = std::cos(angle);
    double sina = std::sin(angle);

    // compute the coordinates of the four corners of the
    // input image after the rotation around the origin
    in_size in_corners_i[4] = {0,n,n,0};
    in_size in_corners_j[4] = {0,0,m,m};
    
    double min_i = 0.0;
    double min_j = 0.0;
    double max_i = 0.0;
    double max_j = 0.0;

    for (std::size_t k = 1; k<4; k++) {
      
      double ii;
      double jj;

      rotate_point(in_corners_i[k],
		   in_corners_j[k],
		   cosa,
		   -sina,
		   ii,
		   jj);

      if (ii < min_i)
	min_i = ii;
      if (jj < min_j)
	min_j = jj;
      if (ii > max_i)
	max_i = ii;
      if (jj > max_j)
	max_j = jj;
    }
    
    out_size new_rows = static_cast<out_size>(max_i - min_i);
    out_size new_columns = static_cast<out_size>(max_j - min_j);
    
    assert( new_rows >= 0 );
    assert( new_columns >= 0);
    
    Matrix<U> result(new_rows,
		     new_columns,
		     padding);
    
    for (out_size i = 0; i < new_rows; i++) {
      for (out_size j = 0; j < new_columns; j++) {
	double in_i;
	double in_j;

	rotate_point(i + min_i,
		     j + min_j,
		     cosa,
		     sina,
		     in_i,
		     in_j);
	
	// add 1 to avoid negative ifr or jfr when in_i or in_j
	// are close to 0
	double ifr = std::modf(in_i + 1,&in_i);
	double jfr = std::modf(in_j + 1,&in_j);

	if (in_i >= 0.5 && in_j >= 0.5 &&
	    in_i < n+0.5 && in_j < m+0.5) {
	  // subtract 1 to restore the previous shift
	  in_size ii = static_cast<in_size>(in_i) - 1;
	  in_size jj = static_cast<in_size>(in_j) - 1;
	  
	  in_size iii = ii < n - 1 ? ii + 1 : ii;
	  in_size jjj = jj < m - 1 ? jj + 1 : jj;
	  
	  result[i][j] = blend(blend(in[ii][jj],in[iii][jj],1-ifr),
			       blend(in[ii][jjj],in[iii][jjj],1-ifr),
			       1-jfr);
	}
      }
    }
    
    out.swap(result);
  }

  /**
   * Image counterclockwise rotation using a bilinear interpolation strategy.
   *
   * The more general \p rotate_bilinear routine is called
   * specifying \p Blend<T> as blending functor.
   * W must be convertible to U.
   *
   * \param in input image
   * \param angle angle of rotation (in radians)
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param out output image
   */
  template <typename T,typename U,typename W>
  void rotate_bilinear(const Matrix<T>& in,
		       double angle,
		       const W& padding,
		       Matrix<U>& out)
  {
    rotate_bilinear(in,angle,padding,out,Blend<T>());
  }

  
  /**
   * Crop an image.
   *
   * Copy a rectangular region of \a in into \a out. The region is
   * defined by the \a top, \a left corner (included) and the \a
   * bottom, \a right corner (excluded).  Coordinates may fall outside
   * \a in, and in this case the \a padding value is used.
   *
   * \pre top <= bottom
   * \pre left <= right
   * 
   * \post out.rows() == bottom - top
   * \post out.columns() == right - left
   *
   * \param in input image
   * \param top coordinate
   * \param left coordinate
   * \param bottom coordinate
   * \param right coordinate
   * \param padding value used for the pixels which does not correspond to
   *   points inside the input image
   * \param out output image
   */
  template <typename T,typename U,typename V>
  void crop(const Matrix<T>& in,
	    int top,
	    int left,
	    int bottom,
	    int right,
	    const V& padding,
	    Matrix<U>& out)
  {
    assert(top <= bottom);
    assert(left <= right);

    typedef typename Matrix<T>::size_type size_type;

    ivllib::Matrix<U> res(bottom - top, right - left, padding);
    
    int n = in.rows();
    int m = in.columns();

    if (bottom <= 0 || right <= 0 || top >= n || left >= m) {
      // completely outside the input matrix
      res.swap(out);
      return;
    }
    
    size_type start_i1 = (top > 0 ? top : 0);
    size_type start_i2 = (top > 0 ? 0 : -top);

    size_type start_j1 = (left > 0 ? left : 0);
    size_type start_j2 = (left > 0 ? 0 : -left);

    size_type end_i = (bottom < n ? bottom : n);
    size_type end_j = (right < m ? right : m);
    
    size_type i2 = start_i2;
    for (size_type i1 = start_i1; i1 != end_i; i1++, i2++) {
      std::copy(in.row_begin(i1) + start_j1,
		in.row_begin(i1) + end_j,
		res.row_begin(i2) + start_j2);
    }

    res.swap(out);
  }


  /**
   * Automatically find the ROI of a picture.
   *
   * Given an image look for borders and framed which can be removed.
   * It has been mainly designed for the removal of frames from
   * photographical images (where the luminance image is passed to the
   * function).  The type T must support the '-' operator, and the
   * result of subtraction must be assignable to an int (usually T is
   * Gray8).
   *
   * \param in input image
   *
   * \param maxcropv maximum number of pixels to be remove from top
   * and bottom
   *
   * \param maxcroph maximum number of pixels to be remove from left
   * and right
   *
   * \param grad_threshold threshold used to find edge pixels
   *
   * \param count_threshold minimum fraction of pixels which form the
   * edge of the frame
   *
   * \return a box with the coordinates of the real content of the
   * image
   *
   * \pre grad_threshold >= 0
   * \pre count_threshold >= 0.0
   * \pre count_threshold <= 1.0
   */
  template <typename T>
  Box autocrop(const Matrix<T>& in,
	       typename Matrix<T>::size_type maxcropv,
	       typename Matrix<T>::size_type maxcroph,
	       int grad_threshold = 16,
	       double count_threshold = 0.5)
  {
    assert(grad_threshold >= 0);
    assert(count_threshold >= 0.0);
    assert(count_threshold <= 1.0);
    
    typedef typename Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();
    if (n < 2 || m < 2)
      return Box(0, 0, n, m);

    // Find the top border (up to half the image).
    size_type stop = std::min(n / 2, maxcropv);
    size_type top = 0;
    for (size_type i = 0; i < stop; i++) {
      int count = 0;
      for (size_type j = 0; j < m; j++) {
	int delta = in[i + 1][j] - in[i][j];
	if (delta > grad_threshold)
	  ++count;
	else if (-delta > grad_threshold)
	  --count;
      }
      if (std::abs(count) > count_threshold * m)
	top = i + 1;
    }

    // Find the bottom border (up to half the image, or to the top
    // previously found).
    stop = std::max(1 + n / 2, n - std::min(n - top - 1, maxcropv));
    size_type bottom = n;
    for (size_type i = n; i > stop; i--) {
      int count = 0;
      for (size_type j = 0; j < m; j++) {
	int delta = in[i - 2][j] - in[i - 1][j];
	if (delta > grad_threshold)
	  ++count;
	else if (-delta > grad_threshold)
	  --count;
      }
      if (std::abs(count) > count_threshold * m)
	bottom = i - 1;
    }

    // Find the left border (up to half the image).
    stop = std::min(m / 2, maxcroph);
    size_type left = 0;
    for (size_type j = 0; j < stop; j++) {
      int count = 0;
      for (size_type i = 0; i < n; i++) {
	int delta = in[i][j + 1] - in[i][j];
	if (delta > grad_threshold)
	  ++count;
	else if (-delta > grad_threshold)
	  --count;
      }
      if (std::abs(count) > count_threshold * n)
	left = j + 1;
    }
      
    // Find the right border (up to half the image, or to the left
    // previously found).
    stop = std::max(1 + m / 2, m - std::min(m - left - 1, maxcroph));
    size_type right = m;
    for (size_type j = m; j > stop; j--) {
      int count = 0;
      for (size_type i = 0; i < n; i++) {
	int delta = in[i][j - 2] - in[i][j - 1];
	if (delta > grad_threshold)
	  ++count;
	else if (-delta > grad_threshold)
	  --count;
      }
      if (std::abs(count) > count_threshold * n)
	right = j - 1;
    }

    // If the resulting box is empty, then probably the algorithm
    // found an edge in the content of the picture.  To be safe, keep
    // the whole image.
    if (top == bottom || left == right) {
      top = 0;
      bottom = n;
      left = 0;
      right = m;
    }

    return Box(top, left, bottom, right);
  }


  /** \cond detail */
  namespace pad_detail
  {
    template <typename T, typename U>
    void pad_prepare(const Matrix<T>& in,
		    typename Matrix<U>::size_type top,
		    typename Matrix<U>::size_type left,
		    typename Matrix<U>::size_type bottom,
		    typename Matrix<U>::size_type right,
		    Matrix<U>& out)
    {
      
    }
  };  // namespace pad_detail
  /** \endcond */

  /**
   * Add padding to an image.
   *
   * Copy \a in into \a out and add a border of padding pixels with
   * value \a pad_value.
   *
   * \param in input image
   * \param top rows to add on top
   * \param left columns to add to the left
   * \param bottom rows to add at the bottom
   * \param right columns to add to the right
   * \param pad_value padding value
   * \param out output image
   */
  template <typename T,typename U, typename V>
  void pad_constant(const Matrix<T>& in,
		    typename Matrix<U>::size_type top,
		    typename Matrix<U>::size_type left,
		    typename Matrix<U>::size_type bottom,
		    typename Matrix<U>::size_type right,
		    const V& pad_value,
		    Matrix<U>& out)
  {
    ivllib::Matrix<U> res(in.rows() + top + bottom,
			  in.columns() + left + right,
			  pad_value);
    
    ivllib::mat_copy_box(in,
			 Box(0, 0, in.rows(), in.columns()),
			 res,
			 Box(top, left,
			     top + in.rows(), left + in.columns()));
    out.swap(res);
  }


  /**
   * Add padding to an image.
   *
   * Copy \a in into \a out and add a border of padding pixels by
   * replicate the first and the last rows and columns.
   *
   * \pre in.rows() > 0
   * \pre in.columns() > 0
   *
   * \param in input image
   * \param top rows to add on top
   * \param left columns to add to the left
   * \param bottom rows to add at the bottom
   * \param right columns to add to the right
   * \param out output image
   */
  template <typename T,typename U>
  void pad_replicate(const Matrix<T>& in,
		     typename Matrix<U>::size_type top,
		     typename Matrix<U>::size_type left,
		     typename Matrix<U>::size_type bottom,
		     typename Matrix<U>::size_type right,
		     Matrix<U>& out)
  {
    assert(in.rows() > 0);
    assert(in.columns() > 0);

    typedef typename Matrix<U>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    ivllib::Matrix<U> res(n + top + bottom, m + left + right);
    
    ivllib::mat_copy_box(in,
			 Box(0, 0, n, m),
			 res,
			 Box(top, left, top + n, left + m));
    
    for (size_type i = 0; i < top; i++)
      std::copy(in.row_begin(0), in.row_end(0),
		res.row_begin(i) + left);

    for (size_type i = 0; i < bottom; i++)
      std::copy(in.row_begin(n-1), in.row_end(n-1),
		res.row_begin(n + top + i) + left);

    for (size_type j = 0; j < left; j++)
      std::copy(in.column_begin(0), in.column_end(0),
		res.column_begin(j) + top);

    for (size_type j = 0; j < right; j++)
      std::copy(in.column_begin(m-1), in.column_end(m-1),
		res.column_begin(m + left + j) + top);
    
    mat_fill_box(res, Box(0, 0, top, left), in[0][0]);
    mat_fill_box(res, Box(0, m + left, top, m + left + right),
		 in[0][m-1]);
    mat_fill_box(res, Box(n + top, 0, n + top + bottom, left),
		 in[n-1][0]);
    mat_fill_box(res, Box(n + top, m + left,
			  n + top + bottom, m + left + right),
		 in[n-1][m-1]);
    
    out.swap(res);
  }


  /**
   * Add padding to an image.
   *
   * Copy \a in into \a out and add a border of padding pixels by
   * mirroring the upper, lower rows of the image and the columns at
   * the extreme left and right.
   *
   * \pre in.rows() > 0
   * \pre in.columns() > 0
   *
   * \param in input image
   * \param top rows to add on top
   * \param left columns to add to the left
   * \param bottom rows to add at the bottom
   * \param right columns to add to the right
   * \param out output image
   */
  template <typename T,typename U>
  void pad_symmetric(const Matrix<T>& in,
		     typename Matrix<U>::size_type top,
		     typename Matrix<U>::size_type left,
		     typename Matrix<U>::size_type bottom,
		     typename Matrix<U>::size_type right,
		     Matrix<U>& out)
  {
    assert(in.rows() > 0);
    assert(in.columns() > 0);

    typedef typename Matrix<U>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    ivllib::Matrix<U> res(n + top + bottom, m + left + right);
    
    ivllib::mat_copy_box(in,
			 Box(0, 0, n, m),
			 res,
			 Box(top, left, top + n, left + m));
    
    for (size_type i = 0; i < top; i++) {
      size_type f = i % n;
      if ((i / n) % 2 == 1)
	f = n - 1 - f;
      std::copy(in.row_begin(f), in.row_end(f),
		res.row_begin(top - i - 1) + left);
    }

    for (size_type i = 0; i < bottom; i++) {
      size_type f = i % n;
      if ((i / n) % 2 == 0)
	f = n - 1 - f;
      std::copy(in.row_begin(f), in.row_end(f),
		res.row_begin(n + top + i) + left);
    }

    for (size_type j = 0; j < left; j++) {
      size_type f = j % m;
      if ((j / m) % 2 == 1)
	f = m - 1 - f;
      std::copy(in.column_begin(f), in.column_end(f),
		res.column_begin(left - j - 1) + top);
    }
      
    for (size_type j = 0; j < right; j++) {
      size_type f = j % m;
      if ((j / m) % 2 == 0)
	f = m - 1 - f;
      std::copy(in.column_begin(f), in.column_end(f),
		res.column_begin(m + left + j) + top);
    }

    // Corners.
    for (size_type i = 0; i < top; i++) {
      size_type f = i % n;
      if ((i / n) % 2 == 1)
	f = n - 1 - f;
      for (size_type j = 0; j < left; j++) {
	size_type g = j % m;
	if ((j / m) % 2 == 1)
	  g = m - 1 - g;
	res[top - i - 1][left - j - 1] = in[f][g];
      }
      for (size_type j = 0; j < right; j++) {
	size_type g = j % m;
	if ((j / m) % 2 == 0)
	  g = m - 1 - g;
	res[top - i - 1][j + m + left] = in[f][g];
      }
    }

    for (size_type i = 0; i < bottom; i++) {
      size_type f = i % n;
      if ((i / n) % 2 == 0)
	f = n - 1 - f;
      for (size_type j = 0; j < left; j++) {
	size_type g = j % m;
	if ((j / m) % 2 == 1)
	  g = m - 1 - g;
	res[i + n + top][left - j - 1] = in[f][g];
      }
      for (size_type j = 0; j < right; j++) {
	size_type g = j % m;
	if ((j / m) % 2 == 0)
	  g = m - 1 - g;
	res[i + n + top][j + m + left] = in[f][g];
      }
    }
    out.swap(res);
  }


  /**
   * Add padding to an image.
   *
   * Copy \a in into \a out and add a border of padding pixels by
   * a periodic repetition of the image.
   *
   * \pre in.rows() > 0
   * \pre in.columns() > 0
   *
   * \param in input image
   * \param top rows to add on top
   * \param left columns to add to the left
   * \param bottom rows to add at the bottom
   * \param right columns to add to the right
   * \param out output image
   */
  template <typename T,typename U>
  void pad_cyclic(const Matrix<T>& in,
		  typename Matrix<U>::size_type top,
		  typename Matrix<U>::size_type left,
		  typename Matrix<U>::size_type bottom,
		  typename Matrix<U>::size_type right,
		  Matrix<U>& out)
  {
    assert(in.rows() > 0);
    assert(in.columns() > 0);

    typedef typename Matrix<U>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();

    ivllib::Matrix<U> res(n + top + bottom, m + left + right);
    
    ivllib::mat_copy_box(in,
			 Box(0, 0, n, m),
			 res,
			 Box(top, left, top + n, left + m));
    
    for (size_type i = 0; i < top; i++) {
      // The n*top term guarantee that the argument is positive.
      size_type f = (n*top - top + i) % n;
      std::copy(in.row_begin(f), in.row_end(f),
		res.row_begin(i) + left);
    }
    
    for (size_type i = 0; i < bottom; i++) {
      size_type f = i % n;
      std::copy(in.row_begin(f), in.row_end(f),
		res.row_begin(n + top + i) + left);
    }
    
    for (size_type j = 0; j < left; j++) {
      // The m*left term guarantee that the argument is positive.
      size_type f = (m*left - left + j) % m;
      std::copy(in.column_begin(f), in.column_end(f),
		res.column_begin(j) + top);
    }
      
    for (size_type j = 0; j < right; j++) {
      size_type f = j % m;
      std::copy(in.column_begin(f), in.column_end(f),
		res.column_begin(m + left + j) + top);
    }

    // Corners.
    for (size_type i = 0; i < top; i++) {
      size_type f = (n*top - top + i) % n;
      for (size_type j = 0; j < left; j++) {
	size_type g = (m*left - left + j) % m;
	res[i][j] = in[f][g];
      }
      for (size_type j = 0; j < right; j++) {
	size_type g = j % m;
	res[i][j + left + m] = in[f][g];
      }
    }

    for (size_type i = 0; i < bottom; i++) {
      size_type f = i % n;
      for (size_type j = 0; j < left; j++) {
	size_type g = (m*left - left + j) % m;
	res[i + top + n][j] = in[f][g];
      }
      for (size_type j = 0; j < right; j++) {
	size_type g = j % m;
	res[i + top + n][j + left + m] = in[f][g];
      }
    }

    out.swap(res);
  }

  /*@}*/

} // ivllib

#endif
