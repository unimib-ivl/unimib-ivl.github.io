/**
 * \file pyramid.h
 *
 * \brief functions for multi-resolution pyramids.
 *
 * Basic operations for building multi-resolution pyramids
 * (Gaussians, Laplacian ...)
 */
#ifndef pyramid_h
#define pyramid_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/resampling.h>
#include <iterator>
#include <vector>

/*
 */
namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/
  
  /**
   * Compute a level of a multiresolution pyramid.
   *
   * Compute a smoothed and sub-sampled version of the input matrix.
   * The image is smoothed by a low-pass filter. The shape of the
   * filter is determined by the parameter \p a (the value 0.4 roughly
   * corresponds to a Gaussian filter). Both dimensions of \p in must
   * be odd.
   *
   * The expressions <tt> t = t*d </tt> and <tt> t += t*d </tt> must
   * be valid (where <tt> t and d </tt> are of types <tt> T and
   * double</tt>, respecively).
   *
   * \note Implementation based on the paper: Peter J. Burt and Edward
   * H. Adelson, "The Laplacian Pyramid as a Compact Image Code," IEEE
   * Transactions On Communications, Vol. Com-3l, No. 4, April 1983.
   *
   * \pre in.rows() >= 5
   * \pre in.columns() >= 5
   * \pre in.rows() % 2 == 1
   * \pre in.columns() % 2 == 1
   * \pre a >= 0
   * \pre a <= 1
   *
   * \post out.rows() = (in.rows()+1) / 2
   * \post out.columns() = (in.columns()+1) / 2
   *
   * \param in input matrix
   * \param out output matrix
   * \param a parameter which determines the shape of the low-pass filter.   
   */
  template <typename T>
  void pyramid_reduce(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a);


  /**
   * Compute a level of a multiresolution pyramid.
   *
   * Compute a super-sampled version of the input matrix.  The image
   * is smoothed by a low-pass filter. The shape of the filter is
   * determined by the parameter \p a (the value 0.4 roughly
   * corresponds to a Gaussian filter). Both dimensions of \p in must
   * be odd.
   *
   * The expressions <tt> t = t*d </tt> and <tt> t += t*d </tt> must
   * be valid (where <tt> t and d </tt> are of types <tt> T and
   * double</tt>, respecively).
   *
   * \note Implementation based on the paper: Peter J. Burt and Edward
   * H. Adelson, "The Laplacian Pyramid as a Compact Image Code," IEEE
   * Transactions On Communications, Vol. Com-3l, No. 4, April 1983.
   *
   * \pre in.rows() >= 5
   * \pre in.columns() >= 5
   * \pre in.rows() % 2 == 1
   * \pre in.columns() % 2 == 1
   * \pre a >= 0
   * \pre a <= 1
   *
   * \post out.rows() = (in.rows()+1) / 2
   * \post out.columns() = (in.columns()+1) / 2
   *
   * \param in input matrix
   * \param out output matrix
   * \param a parameter which determines the shape of the low-pass filter.
   */
  template <typename T>
  void pyramid_expand(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a);

  /**
   * Compute a level of a multiresolution pyramid.
   *
   * Compute a smoothed and sub-sampled version of the input matrix.
   * The image is smoothed by a low-pass filter. The shape of the
   * filter is determined by the parameter \p a (the value 0.4 roughly
   * corresponds to a Gaussian filter). Both dimensions of \p in must
   * be odd.
   *
   * The expression <tt> t = blend(t,t,d) </tt> must be valid (where
   * <tt> t</tt> and <tt>d </tt> are of types <tt> T</tt> and
   * <tt>double</tt>, respecively).
   *
   * \note Implementation based on the paper: Peter J. Burt and Edward
   * H. Adelson, "The Laplacian Pyramid as a Compact Image Code," IEEE
   * Transactions On Communications, Vol. Com-3l, No. 4, April 1983.
   *
   * \pre in.rows() >= 5
   * \pre in.columns() >= 5
   * \pre in.rows() % 2 == 1
   * \pre in.columns() % 2 == 1
   * \pre a >= 0
   * \pre a <= 0.5
   *
   * \post out.rows() = (in.rows()+1) / 2
   * \post out.columns() = (in.columns()+1) / 2
   *
   * \param in input matrix
   * \param out output matrix
   * \param a parameter which determines the shape of the low-pass filter.
   * \param blend blending functor
   */
  template <typename T,typename BlendFun>
  void pyramid_reduce(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,		      
		      double a,
		      BlendFun blend);

  /**
   * Compute a level of a multiresolution pyramid.
   *
   * Compute a super-sampled version of the input matrix.  The image
   * is smoothed by a low-pass filter. The shape of the filter is
   * determined by the parameter \p a (the value 0.4 roughly
   * corresponds to a Gaussian filter). Both dimensions of \p in must
   * be odd.
   *
   * The expression <tt> t = blend(t,t,d) </tt> must be valid (where
   * <tt> t</tt> and <tt>d </tt> are of types <tt> T</tt> and
   * <tt>double</tt>, respectively).
   *
   * \note Implementation based on the paper: Peter J. Burt and Edward
   * H. Adelson, "The Laplacian Pyramid as a Compact Image Code," IEEE
   * Transactions On Communications, Vol. Com-3l, No. 4, April 1983.
   *
   * \pre in.rows() >= 5
   * \pre in.columns() >= 5
   * \pre in.rows() % 2 == 1
   * \pre in.columns() % 2 == 1
   * \pre a >= 0
   * \pre a <= 0.5
   *
   * \post out.rows() = (in.rows()+1) / 2
   * \post out.columns() = (in.columns()+1) / 2
   *
   * \param in input matrix
   * \param out output matrix
   * \param a parameter which determines the shape of the low-pass filter.
   * \param blend blending functor
   */
  template <typename T,typename BlendFun>
  void pyramid_expand(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a,
		      BlendFun blend);


  /**
   * compute the laplacian pyramid of an image
   */
    template <typename T,
	      typename BlendFunT,
	      typename Difference,
	      typename U>
    void make_laplacian_pyramid(const ivllib::Matrix<T>& img,				
				typename std::vector<ivllib::Matrix<U> >& out,
				BlendFunT blend,
				Difference diff);

  /**
   * compute the gaussian pyramid of an image
   */
    template <typename T,
    typename BlendFunT>
    void make_gaussian_pyramid(const ivllib::Matrix<T>& img,			      
			       typename std::vector<ivllib::Matrix<T> >& out,
			       BlendFunT blend);

  /**
   * compute the laplacian and gaussian pyramid of an image
   */
    template <typename T,
    typename BlendFunT,
    typename Difference,
    typename U>
    void make_pyramids(const ivllib::Matrix<T>& img,		       
		       typename std::vector<ivllib::Matrix<T> >& g_out,
		       typename std::vector<ivllib::Matrix<U> >& l_out,
		       BlendFunT blend,
		       Difference diff);

    /**
     * reconstruct an image from a pyramidal representation
     */
  template <typename T,
	    typename BlendFunT,
	    typename SumT,
	    typename U>
  void pyramid_reconstruct(const std::vector<ivllib::Matrix<T> >& laplacian,
			   const ivllib::Matrix<U>& level_n,
			   ivllib::Matrix<U>& out,
			   BlendFunT blend,
			   SumT sum);
  
  //-- Implementation ----------------------------------------------------

  /** \cond detail */
  namespace detail
  {
    //utility function used to compute the adjusted image dimensions
    static unsigned int adjust(unsigned int n, int lev)
    {
      if (lev == 0)
	return n;
      
      unsigned int min = 1 + (4 << (lev - 1));
      if (n < min)
	return min;
      
      return 2 + ((n-1) | ((1 << lev) - 1));
    }  
    
    // Since the low-pass filters are separable, reduction and
    // expansion of the levels of a pyramid are implemented as
    // one-dimensional operations. 
    
    template <typename FwdIter,typename OutIter>
    OutIter pyramid_reduce_1d(FwdIter first,
			      FwdIter last,
			      OutIter where,
			      double a)
    {
      assert( std::distance(first,last) % 2 == 1 );
      assert( std::distance(first,last) >= 5 );
      assert( a >= 0.0 );
      assert( a <= 1.0 );

      const double pyramid_filter[5] = {0.25 - 0.5*a, 0.25, a, 0.25, 0.25 - 0.5*a};
      
      // compute the first reduced element (pixels are replicated)
      FwdIter it = first;
      *where = (*it) * (pyramid_filter[0] + pyramid_filter[1] + pyramid_filter[2]);
      ++it;
      *where += (*it) * pyramid_filter[3];
      ++it;
      *where += (*it) * pyramid_filter[4];
      ++where;

      // compute the central elements.
      do {
	it = first;
	double tmp = (*it) * pyramid_filter[0];
	++it;
	tmp += (*it) * pyramid_filter[1];
	++it;
	tmp += (*it) * pyramid_filter[2];
	++it;
	tmp += (*it) * pyramid_filter[3];
	++it;
	tmp += (*it) * pyramid_filter[4];
	++it;

	*where = tmp;
	++where;
	
	++first;
	++first;
      } while (it != last);

      // compute the last reduced element (pixels are replicated)
      it = first;
      *where += (*it) * pyramid_filter[0];
      ++it;
      *where += (*it) * pyramid_filter[1];
      ++it;
      *where = (*it) * (pyramid_filter[2] + pyramid_filter[3] + pyramid_filter[4]);
      ++where;

      assert( ++it == last );

      return where;
    }

    template <typename FwdIter,typename OutIter>
    OutIter pyramid_expand_1d(FwdIter first,FwdIter last,OutIter where,double a)
    {
      assert( std::distance(first,last) >= 3 );
      assert( a >= 0.0 );
      assert( a <= 1.0 );

      typedef typename std::iterator_traits<FwdIter>::value_type T;

      // the values of the coefficients are twice of those used for reduction
      const double pyramid_filter[5] = {0.5 - a, 0.5, 2*a, 0.5, 0.5 - a};

      // compute the first expanded element (pixels are replicated)
      FwdIter it = first;
      *where = (*it) * (pyramid_filter[0] + pyramid_filter[2]);
      ++it;
      *where += (*it) * pyramid_filter[4];
      ++where;
      
      // compute the central elements.
      // Each iteration compute two consecutive output values.
      do {
	it = first;
	T tmp2 = (*it) * pyramid_filter[0];
	T tmp1 = (*it) * pyramid_filter[1];
	++it;
	tmp2 += (*it) * pyramid_filter[2];
	tmp1 += (*it) * pyramid_filter[3];
	++it;
	tmp2 += (*it) * pyramid_filter[4];
	++it;
	
	*where = tmp1;
	++where;
	*where = tmp2;
	++where;

	++first;
      } while (it != last);

      // compute the next to the last expanded element
      it = first;
      *where = (*it) * pyramid_filter[1];
      ++it;
      *where += (*it) * pyramid_filter[3];
      ++it;
      ++where;
      
      // compute the last expanded element (pixels are replicated)
      it = first;
      *where = (*it) * pyramid_filter[0];
      ++it;
      *where += (*it) * (pyramid_filter[2] +pyramid_filter[4]);
      ++where;

      assert( ++it == last );

      return where;
    }

    //----------------------------------------------------------------------

    template <typename FwdIter,typename OutIter,typename BlendFun>
    OutIter pyramid_reduce_1d(FwdIter first,
			      FwdIter last,
			      OutIter where,
			      double a,
			      BlendFun blend)
    {
      assert( std::distance(first,last) % 2 == 1 );
      assert( std::distance(first,last) >= 5 );
      assert( a >= 0.0 );
      assert( a <= 0.5 );

      double aa = 0.5/(1-a);

      typedef typename std::iterator_traits<FwdIter>::value_type T;
      
      // compute the first reduced element (pixels are replicated)

      FwdIter it = first;
      T x3 = *it;
      ++it;
      T x4 = *it;
      ++it;
      T x5 = *it;
      
      T x1 = blend(x3,x5,0.5);
      T x2 = blend(x3,x4,0.5);
      x1 = blend(x2,x1,aa);
      *where = blend(x3,x1,a);
      ++where;
      
      // compute the central elements.
      do {
	it = first;

 	x1 = *it;
 	++it;
 	x2 = *it;
 	++it;
 	x3 = *it;
 	++it;
 	x4 = *it;
 	++it;
 	x5 = *it;
 	++it;	

 	x1 = blend(x1,x5,0.5);
 	x2 = blend(x2,x4,0.5);
 	x1 = blend(x2,x1,aa);
	
	*where = blend(x3,x1,a);
	++where;
	
	++first;
	++first;
      } while (it != last);
      
      // compute the last reduced element (pixels are replicated)
      it = first;
      x1 = *it;
      ++it;
      x2 = *it;
      ++it;
      x3 = *it;
      
      x1 = blend(x1,x3,0.5);
      x2 = blend(x2,x3,0.5);
      x1 = blend(x2,x1,aa);
      *where = blend(x3,x1,a);
      ++where;
      
      assert( ++it == last );

      return where;
    }

    template <typename FwdIter,typename OutIter,typename BlendFun>
    OutIter pyramid_expand_1d(FwdIter first,
			      FwdIter last,
			      OutIter where,
			      double a,
			      BlendFun blend)
    {
      assert( std::distance(first,last) >= 3 );
      assert( a >= 0.0 );
      assert( a <= 0.5 );

      typedef typename std::iterator_traits<FwdIter>::value_type T;
      
      // the values of the coefficients are twice of those used for reduction
      const double a2 = 2*a;

      // compute the first expanded element (pixels are replicated)

      FwdIter it = first;      
      T x2 = *it;
      ++it;
      T x3 = *it;
      
      *where = blend(x2,x3,0.5 + a);
      ++where;
      
      // compute the central elements.
      // Each iteration compute two consecutive output values.
      do {
	it = first;

	T x1 = *it;
	++it;
	x2 = *it;
	++it;
	x3 = *it;
	++it;
	
	*where = blend(x1,x2,0.5);
	++where;
	
	*where = blend(x2,blend(x1,x3,0.5),a2);
	++where;

	++first;
      } while (it != last);

      // compute the next to the last expanded element
      it = first;
      T x1 = *it;
      ++it;
      x2 = *it;
      
      *where = blend(x1,x2,0.5);
      ++where;

      // compute the last expanded element (pixels are replicated)
      *where = blend(x2,x1,0.5 + a);

      assert( ++it == last );

      return where;
    }
    
  } // namespace detail
  /** \endcond */

  //----------------------------------------------------------------------

  template <typename T>
  void pyramid_reduce(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    assert( n >= 5 );
    assert( m >= 5 );
    assert( n % 2 == 1 );
    assert( m % 2 == 1 );
    assert( a >= 0.0 );
    assert( a <= 1.0 );

    size_type new_n = (n+1)/2;
    size_type new_m = (m+1)/2;
    
    Matrix<T> tmp(n,new_m);

    for(size_type i = 0; i < n; ++i)
      detail::pyramid_reduce_1d(in.row_begin(i),
				in.row_end(i),
				tmp.row_begin(i),
				a);

    Matrix<T> res(new_n,new_m);
    
    for (size_type j = 0 ; j < new_m; ++j)
      detail::pyramid_reduce_1d(tmp.column_begin(j),
				tmp.column_end(j),
				res.column_begin(j),
				a);
    out.swap(res);
  }

  template <typename T>
  void pyramid_expand(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    assert( n >= 3 );
    assert( m >= 3 );
    assert( a >= 0.0 );
    assert( a <= 1.0 );

    size_type new_n = 2*n - 1;
    size_type new_m = 2*m - 1;
  
    Matrix<T> tmp(new_n,m);

    for (size_type j = 0 ; j < m; ++j)
      detail::pyramid_expand_1d(in.column_begin(j),
				in.column_end(j),
				tmp.column_begin(j),
				a);

    Matrix<T> res(new_n,new_m);
    
    for(size_type i = 0; i < new_n; ++i)
      detail::pyramid_expand_1d(tmp.row_begin(i),
				tmp.row_end(i),
				res.row_begin(i),
				a);   
    out.swap(res);
  }

  //----------------------------------------------------------------------

  template <typename T,typename BlendFun>
  void pyramid_reduce(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,		      
		      double a,
		      BlendFun blend)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    assert( n >= 5 );
    assert( m >= 5 );
    assert( n % 2 == 1 );
    assert( m % 2 == 1 );
    assert( a >= 0.0 );
    assert( a <= 1.0 );

    size_type new_n = (n+1)/2;
    size_type new_m = (m+1)/2;
    
    Matrix<T> tmp(n,new_m);

    for(size_type i = 0; i < n; ++i)
      detail::pyramid_reduce_1d(in.row_begin(i),
				in.row_end(i),
				tmp.row_begin(i),
				a,
				blend);

    Matrix<T> res(new_n,new_m);
    
    for (size_type j = 0 ; j < new_m; ++j)
      detail::pyramid_reduce_1d(tmp.column_begin(j),
				tmp.column_end(j),
				res.column_begin(j),
				a,
				blend);
    out.swap(res);
  }

  template <typename T,typename BlendFun>
  void pyramid_expand(const ivllib::Matrix<T>& in,
		      ivllib::Matrix<T>& out,
		      double a,
		      BlendFun blend)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    assert( n >= 3 );
    assert( m >= 3 );
    assert( a >= 0.0 );
    assert( a <= 1.0 );

    size_type new_n = 2*n - 1;
    size_type new_m = 2*m - 1;
  
    Matrix<T> tmp(new_n,m);

    for (size_type j = 0 ; j < m; ++j)
      detail::pyramid_expand_1d(in.column_begin(j),
				in.column_end(j),
				tmp.column_begin(j),
				a,
				blend);

    Matrix<T> res(new_n,new_m);
    
    for(size_type i = 0; i < new_n; ++i)
      detail::pyramid_expand_1d(tmp.row_begin(i),
				tmp.row_end(i),
				res.row_begin(i),
				a,
				blend);   
    out.swap(res);
  }

  //-------------------------------------------------------------
  template <typename T,
    typename BlendFunT,
    typename Difference,
    typename U>
    void make_laplacian_pyramid(const ivllib::Matrix<T>& img,
				typename std::vector<ivllib::Matrix<U> >& out,
				BlendFunT blend,
				Difference diff)
    {
      // resample the images to appropriate dimensions, suitable for the
      // construction of a Laplacian pyramid.
      unsigned n = img.rows();
      unsigned m = img.columns();
      
      int levels = 0;
      while ((10u << levels) < n && (10u << levels) < m)
	++levels;
      
      unsigned new_n = detail::adjust(n, levels);
      unsigned new_m = detail::adjust(m, levels);
      
      ivllib::Matrix<T> resampled;
      ivllib::bilinear_resampling(img, new_n, new_m, resampled, blend);
      
      std::vector<ivllib::Matrix<U> > pyramid;
      
      ivllib::Matrix<T> reduced;
      ivllib::Matrix<T> expanded;
      ivllib::Matrix<T> full = resampled;
      
      for (int l = 0 ; l < levels; ++l) {
	ivllib::pyramid_reduce(full,reduced,0.4,blend);
	ivllib::pyramid_expand(reduced,expanded,0.4,blend);
	pyramid.push_back(ivllib::Matrix<U>());
	ivllib::mat_transform(full,expanded,pyramid.back(),diff);
	full.swap(reduced);
      }
      
      out.swap(pyramid);
    }


  //----------------------------------------------------------------
    template <typename T,
    typename BlendFunT>
    void make_gaussian_pyramid(const ivllib::Matrix<T>& img,
			       typename std::vector<ivllib::Matrix<T> >& out,
			       BlendFunT blend)
    {
      // resample the images to appropriate dimensions, suitable for the
      // construction of a Laplacian pyramid.
      unsigned n = img.rows();
      unsigned m = img.columns();
      
      int levels = 0;
      while ((10u << levels) < n && (10u << levels) < m)
	++levels;
      
      unsigned new_n = detail::adjust(n, levels);
      unsigned new_m = detail::adjust(m, levels);
      
      ivllib::Matrix<T> resampled;
      ivllib::bilinear_resampling(img, new_n, new_m, resampled, blend);
      
      std::vector<ivllib::Matrix<T> > pyramid;
      ivllib::Matrix<T> reduced;

      ivllib::pyramid_reduce(resampled, reduced, 0.4, blend);
      pyramid.push_back(reduced);
      
      for (int l = 1 ; l < levels; ++l) {
	ivllib::pyramid_reduce(pyramid.back(), reduced, 0.4, blend);
	pyramid.push_back(reduced);
      }
      
      out.swap(pyramid);            
    }

  //----------------------------------------------------------------
    template <typename T,
    typename BlendFunT,
    typename Difference,
    typename U>
    void make_pyramids(const ivllib::Matrix<T>& img,
		       typename std::vector<ivllib::Matrix<T> >& g_out,
		       typename std::vector<ivllib::Matrix<U> >& l_out,
		       BlendFunT blend,
		       Difference diff)
    {
      // resample the images to appropriate dimensions, suitable for the
      // construction of the pyramids.
      unsigned n = img.rows();
      unsigned m = img.columns();
      
      int levels = 0;
      while ((10u << levels) < n && (10u << levels) < m)
	++levels;
      
      unsigned new_n = detail::adjust(n, levels);
      unsigned new_m = detail::adjust(m, levels);
      
      ivllib::Matrix<T> resampled;
      ivllib::bilinear_resampling(img, new_n, new_m, resampled, blend);
      
      std::vector<ivllib::Matrix<U> > lpyramid;
      std::vector<ivllib::Matrix<T> > gpyramid;
      
      ivllib::Matrix<T> reduced;
      ivllib::Matrix<T> expanded;
      ivllib::Matrix<T> full = resampled;
      
      for (int l = 0 ; l < levels; ++l) {
	ivllib::pyramid_reduce(full,reduced,0.4,blend);
	gpyramid.push_back(reduced);
	ivllib::pyramid_expand(reduced,expanded,0.4,blend);
	lpyramid.push_back(ivllib::Matrix<U>());
	ivllib::mat_transform(full,expanded,lpyramid.back(),diff);
	full.swap(reduced);
      }
      
      l_out.swap(lpyramid);
      g_out.swap(gpyramid);
    }

    //------------------------------------------------------------ */
    template <typename T,
	      typename BlendFunT,
	      typename SumT,
	      typename U>
    void pyramid_reconstruct(const std::vector<ivllib::Matrix<T> >& laplacian,
			     const ivllib::Matrix<U>& level_n,
			     ivllib::Matrix<U>& out,
			     BlendFunT blend,
			     SumT sum)
      {
	
	ivllib::Matrix<U> actual(level_n), expanded;	
	
	for (int i=laplacian.size()-1; i >= 0; i--)
	  {
	    pyramid_expand(actual,expanded,0.4,blend);
	    actual.resize(expanded.rows(), expanded.columns());	    
	    ivllib::mat_transform(expanded,				  
				  laplacian[i],
				  actual,
				  sum);
	  }

	actual.swap(out);
      }

  /*@}*/

} // namespace ivllib

#endif // pyramid_h
