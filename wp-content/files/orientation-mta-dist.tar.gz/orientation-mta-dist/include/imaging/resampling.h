/**
 * \file    resampling.h
 * \brief   resampling functions
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef resampling_h
#define resampling_h

#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <imaging/pixel.h>
#include <cassert>  // assert
#include <cmath>  // modf
#include <utility>  // pair

//--- Headers --------------------------------------------------------
namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Image resampling using the nearest neighbor strategy.
   *
   * A value of type T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param new_rows required height
   * \param new_columns required widht
   * \param out output image
   *
   * \pre in.rows() > 0 || new_rows == 0
   * \pre in.columns() > 0 || new_columns == 0
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U>
  void nearest_resampling(const Matrix<T>& in,
			  typename Matrix<U>::size_type new_rows,
			  typename Matrix<U>::size_type new_columns,
			  Matrix<U>& out)
  {
    Matrix<U> result(new_rows,new_columns);

    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    assert(n>0 || new_rows == 0);
    assert(m>0 || new_columns == 0);

    double iscale = new_rows > 0 ? double(n)/(new_rows) : 0.0;
    double jscale = new_columns >0 ? double(m)/(new_columns) : 0.0;

    // precompute horizontal coordinates
    ivllib::Vector<in_size> jjv(new_columns);
    for (out_size j = 0; j < new_columns; j++) {
      in_size jj = static_cast<in_size>((0.5 + j)*jscale);
      if (jj+1 > m)
	jj = m - 1;
      jjv[j] = jj;
    }

    for (out_size i = 0; i < new_rows; i++) {
      in_size ii = static_cast<in_size>((0.5 + i)*iscale);
      if (ii+1 > n)
        ii = n - 1;

      for (out_size j = 0; j < new_columns; j++)
	result[i][j] = in[ii][jjv[j]];
    }

    out.swap(result);
  }

  /**
   * Image resampling using bilinear interpolation.
   *
   * If \p x, \p y, \p z are of type \p double,
   * \p u is of type \p U and \p t1, \p t2, \p t3, \p t4
   * are of type \p const \p T, then the assignement
   * <tt> u = blend(blend(t1,t2,x),blend(t3,t4,y),z) </tt>
   * must be valid.
   *
   * \param in input image
   * \param new_rows required height
   * \param new_columns required widht
   * \param out output image
   * \param blend blending functor
   *
   * \pre in.rows() > 0 || new_rows == 0
   * \pre in.columns() > 0 || new_columns == 0
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U,typename BlendFun>
  void bilinear_resampling(const Matrix<T>& in,
			   typename Matrix<U>::size_type new_rows,
			   typename Matrix<U>::size_type new_columns,
			   Matrix<U>& out,
			   BlendFun blend)
  {
    Matrix<U> result(new_rows,new_columns);

    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    assert(n>0 || new_rows == 0);
    assert(m>0 || new_columns == 0);

    double iscale = new_rows > 0 ? double(n)/(new_rows) : 0.0;
    double jscale = new_columns > 0 ? double(m)/(new_columns) : 0.0;

    // precompute horizontal coordinates and fraction parts
    ivllib::Vector<in_size> jjv(new_columns);
    ivllib::Vector<in_size> jj2v(new_columns);
    ivllib::Vector<double> jfv(new_columns);
    for (out_size j = 0; j < new_columns; j++) {
      double jd;
      double jfr = 1-std::modf((0.5+j)*jscale, &jd);
      in_size jj = static_cast<in_size>(jd);
      in_size jj2 = jj+1 < m ? jj+1 : jj;
      jjv[j] = jj;
      jj2v[j] = jj2;
      jfv[j] = jfr;
    }

    for (out_size i = 0; i < new_rows; i++) {
      double id;
      double ifr = 1-std::modf((0.5+i)*iscale,&id);
      in_size ii = static_cast<in_size>(id);
      in_size ii2 = ii+1 < n ? ii+1 : ii;
      
      for (out_size j = 0; j < new_columns; j++) {
	double jfr = jfv[j];
	in_size jj = jjv[j];
	in_size jj2 = jj2v[j];
       
	result[i][j] = blend(blend(in[ii][jj],in[ii2][jj],ifr),
			     blend(in[ii][jj2],in[ii2][jj2],ifr),
			     jfr);
      }
    }

    out.swap(result);
  }

  /**
   * Image resampling using bilinear interpolation.
   *
   * The more general \p bilinear_resampling routine is called
   * specifying \p Blend<T> as blending functor.
   *
   * \param in input image
   * \param new_rows required height
   * \param new_columns required widht
   * \param out output image
   *
   * \pre in.rows() > 0 || new_rows == 0
   * \pre in.columns() > 0 || new_columns == 0
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U>
  void bilinear_resampling(const Matrix<T>& in,
			   typename Matrix<U>::size_type new_rows,
			   typename Matrix<U>::size_type new_columns,
			   Matrix<U>& out)
  {
    bilinear_resampling(in,new_rows,new_columns,out,Blend<T>());
  }
 

  /** \cond detail */
  namespace detail
  {
    // procedure used to merge subpixels along a single dimension
    // (horizontal or vertical)
    template <typename RaIter,typename OutIter,typename BlendFun>
    void supersampling_1d(RaIter from,
			  RaIter to,
			  unsigned int subpixels_count,
			  OutIter where,
			  BlendFun blend)
    {
      typedef typename std::iterator_traits<RaIter>::value_type value_type;
      
      assert( (to - from) % subpixels_count == 0 );
      
      if (subpixels_count == 1) {
	std::copy(from, to, where);
	return;
      }
      
      while (from != to) {
	value_type x = *from++;
	
	for (unsigned int i = 2; i <= subpixels_count; i++)
	  x = blend(*from++, x, 1.0/i);
	
	*where = x;
	++where;
      }
    }
  } // namespace detail
  /** \endcond */
  
  /**
   * Image resampling using sub-pixel rendering.
   *
   * The image is first resampled (using bilinear resampling) into an
   * intermediate image of size <tt>(new_rows*v_subpixels,
   * new_columns*h_subpixels)</tt>. Then each block of
   * <tt>(v_subpixels, h_subpixels)</tt> is averaged into a single
   * output pixel.
   *
   * If \p x, \p y, \p z are of type \p double,
   * \p u is of type \p U and \p t1, \p t2, \p t3, \p t4
   * are of type \p const \p T, then the assignement
   * <tt> u = blend(blend(t1,t2,x),blend(t3,t4,y),z) </tt>
   * must be valid.
   *
   * \param in input image
   * \param new_rows required height
   * \param new_columns required widht
   * \param out output image
   * \param v_subpixels number of vertical sub-pixels for each pixel
   * \param h_subpixels number of horizontal sub-pixels for each pixel
   * \param blend blending functor
   *
   * \pre in.rows() > 0 || new_rows == 0
   * \pre in.columns() > 0 || new_columns == 0
   * \pre v_subpixels > 0
   * \pre h_subpixels > 0
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U,typename BlendFun>
  void subpixel_resampling(const Matrix<T>& in,
			   typename Matrix<U>::size_type new_rows,
			   typename Matrix<U>::size_type new_columns,
			   Matrix<U>& out,
			   unsigned int v_subpixels,
			   unsigned int h_subpixels,
			   BlendFun blend)
  {
    assert( v_subpixels > 0 );
    assert( h_subpixels > 0 );

    typedef typename Matrix<T>::size_type size_type;

    // dimensions of the intermediate image
    size_type n2 = new_rows * v_subpixels;
    size_type m2 = new_columns * h_subpixels;

    // sub-pixel rendering using bilinear resampling
    Matrix<T> tmp;
    bilinear_resampling(in, n2, m2, tmp, blend);
    
    // average each row of sub-pixels
    for (size_type i = 0; i < n2; ++i)
      detail::supersampling_1d(tmp.row_begin(i),
			       tmp.row_end(i),
			       v_subpixels,
			       tmp.row_begin(i),
			       blend);

    Matrix<U> ret(new_rows, new_columns);

    // average each column of sub-pixels
    for (size_type j = 0; j < new_columns; ++j)
      detail::supersampling_1d(tmp.column_begin(j),
			       tmp.column_end(j),
			       h_subpixels,
			       ret.column_begin(j),
			       blend);

    // commit
    out.swap(ret);
  }

  /**
   * Image resampling using sub-pixel rendering.
   *
   * The more general \p subpixel_resampling routine is called
   * specifying \p Blend<T> as blending functor.
   *
   * \param in input image
   * \param new_rows required height
   * \param new_columns required widht
   * \param out output image
   * \param v_subpixels number of vertical sub-pixels for each pixel
   * \param h_subpixels number of horizontal sub-pixels for each pixel
   *
   * \pre in.rows() > 0 || new_rows == 0
   * \pre in.columns() > 0 || new_columns == 0
   * \pre v_subpixels > 0
   * \pre h_subpixels > 0
   *
   * \post out.rows() == new_rows
   * \post out.columns() == new_columns
   */
  template <typename T,typename U>
  void subpixel_resampling(const Matrix<T>& in,
			   typename Matrix<U>::size_type new_rows,
			   typename Matrix<U>::size_type new_columns,
			   Matrix<U>& out,
			   unsigned int v_subpixels = 2,
			   unsigned int h_subpixels = 2)
  {
    subpixel_resampling(in,
			new_rows,
			new_columns,
			out,
			v_subpixels,
			h_subpixels,
			Blend<T>());
  }

  
  /// Define the policy of sacling functions.
  enum scaling_dimension {
    scaling_dimension_width,   ///< Specify the width, compute the height.
    scaling_dimension_height,  ///< Specify the height, compute the width.
    scaling_dimension_longest, ///< Specify the longest side, compute the shortest.
    scaling_dimension_shortest ///< Specify the shortest side, compute the longest.
  };
  
  /** \cond detail */
  namespace detail
  {
    // Return a height-width pair with the scales coordinates.
    template <typename T, typename U>
    std::pair<T, T> scale_dimensions(T new_size,
				     U height,
				     U width,
				     scaling_dimension sd) {
      if (sd == scaling_dimension_longest)
	sd = (height >= width
	      ? scaling_dimension_height
	      : scaling_dimension_width);
      else if (sd == scaling_dimension_shortest)
	sd = (height >= width
	      ? scaling_dimension_width
	      : scaling_dimension_height);
      
      if (sd == scaling_dimension_height)
	return std::pair<T, T>(new_size,
			       (height > 0
				? (new_size * width) / height
				: 0));
      return std::pair<T, T>((width > 0
			      ? (new_size * height) / width
			      : 0),
			     new_size);
    }
  }  // namespace detail
  /** \endcond */


  /**
   * Image scaling using the nearest neighbor strategy.
   *
   * Resample the image preserving its aspect ratio.  A value of type
   * T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param new_size required size
   * \param out output image
   * \param sd determine the side to which refers new_size
   *
   * \pre (in.rows() > 0 && in.columns() > 0) || new_size > 0
   */
  template <typename T,typename U>
  void nearest_scaling(const Matrix<T>& in,
		       typename Matrix<U>::size_type new_size,
		       Matrix<U>& out,
		       scaling_dimension sd = scaling_dimension_longest)
  {
    assert(sd == scaling_dimension_width ||
	   sd == scaling_dimension_height ||
	   sd == scaling_dimension_longest ||
	   sd == scaling_dimension_shortest);
    assert((in.rows() > 0 && in.columns() > 0) || new_size > 0);

    if (new_size == 0) {
      out.clear();
      return;
    }
    
    std::pair<typename Matrix<U>::size_type,
      typename Matrix<U>::size_type> dims = 
      detail::scale_dimensions(new_size,
			       in.rows(),
			       in.columns(),
			       sd);
    nearest_resampling(in, dims.first, dims.second, out);
  }


  /**
   * Image scaling using the bilinear interpolation strategy.
   *
   * Resample the image preserving its aspect ratio.  A value of type
   * T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param new_size required size
   * \param out output image
   * \param sd determine the side to which refers new_size
   * \param blend blending functor
   *
   * \pre (in.rows() > 0 && in.columns() > 0) || new_size > 0
   */
  template <typename T,typename U,typename BlendFun>
  void bilinear_scaling(const Matrix<T>& in,
			typename Matrix<U>::size_type new_size,
			Matrix<U>& out,
			scaling_dimension sd,
			BlendFun blend)
  {
    assert(sd == scaling_dimension_width ||
	   sd == scaling_dimension_height ||
	   sd == scaling_dimension_longest ||
	   sd == scaling_dimension_shortest);
    assert((in.rows() > 0 && in.columns() > 0) || new_size > 0);

    if (new_size == 0) {
      out.clear();
      return;
    }

    std::pair<typename Matrix<U>::size_type,
      typename Matrix<U>::size_type> dims =
      detail::scale_dimensions(new_size,
			       in.rows(),
			       in.columns(),
			       sd);
    bilinear_resampling(in, dims.first, dims.second, out, blend);
  }


  /**
   * Image scaling using the bilinear interpolation strategy.
   *
   * The more general \p bilinear_resampling routine is called
   * specifying \p Blend<T> as blending functor.
   */
  template <typename T,typename U>
  void bilinear_scaling(const Matrix<T>& in,
			typename Matrix<U>::size_type new_size,
			Matrix<U>& out,
			scaling_dimension sd = scaling_dimension_longest)
  {
    bilinear_scaling(in, new_size, out, sd, Blend<T>());
  }


  /**
   * Image scaling using  using sub-pixel rendering.
   *
   * Resample the image preserving its aspect ratio.  A value of type
   * T must be assignable to a variable of type U.
   *
   * \param in input image
   * \param new_size required size
   * \param out output image
   * \param sd determine the side to which refers new_size
   * \param v_subpixels number of vertical sub-pixels for each pixel
   * \param h_subpixels number of horizontal sub-pixels for each pixel
   * \param blend blending functor
   *
   * \pre v_subpixels > 0
   * \pre h_subpixels > 0
   * \pre (in.rows() > 0 && in.columns() > 0) || new_size > 0
   */
  template <typename T,typename U,typename BlendingFun>
  void subpixel_scaling(const Matrix<T>& in,
			typename Matrix<U>::size_type new_size,
			Matrix<U>& out,
			scaling_dimension sd,
			unsigned int v_subpixels,
			unsigned int h_subpixels,
			BlendingFun blend)
  {
    assert(sd == scaling_dimension_width ||
	   sd == scaling_dimension_height ||
	   sd == scaling_dimension_longest ||
	   sd == scaling_dimension_shortest);
    assert((in.rows() > 0 && in.columns() > 0) || new_size > 0);
    assert(v_subpixels > 0);
    assert(h_subpixels > 0);

    if (new_size == 0) {
      out.clear();
      return;
    }

    std::pair<typename Matrix<U>::size_type,
      typename Matrix<U>::size_type> dims =
      detail::scale_dimensions(new_size,
			       in.rows(),
			       in.columns(),
			       sd);
    subpixel_resampling(in,
			dims.first,
			dims.second,
			out,
			v_subpixels,
			h_subpixels,
			blend);
  }


  /**
   * Image scaling using subpixel rendering.
   *
   * The more general \p subpixel_scaling routine is called
   * specifying \p Blend<T> as blending functor.
   */
  template <typename T,typename U>
  void subpixel_scaling(const Matrix<T>& in,
			typename Matrix<U>::size_type new_size,
			Matrix<U>& out,
			scaling_dimension sd = scaling_dimension_longest,
			unsigned int v_subpixels = 2,
			unsigned int h_subpixels = 2)
  {
    subpixel_scaling(in,
		     new_size,
		     out,
		     sd,
		     v_subpixels,
		     h_subpixels,
		     Blend<T>());
  }

  /*@}*/

} // ivllib

#endif
