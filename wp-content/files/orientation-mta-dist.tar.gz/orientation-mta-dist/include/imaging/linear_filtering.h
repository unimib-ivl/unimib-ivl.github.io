/**
 * \file    linear_filtering.h
 * \brief   linear convolution and related functions
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef linear_filtering_h
#define linear_filtering_h

//--- Headers --------------------------------------------------------

#include <ivl_matrix.h>
#include <mat_algorithm.h>
#include <cassert> // assert
#include <cmath>   // std::exp

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/


  /**
   * Linear convolution.
   *
   * Computed as in the versions without the extra functor parameters.
   * The functors \p add and \p mult specify respectively the sum and
   * the multiplication.
   */
  template <typename T,
	    typename U,
	    typename V,
	    typename W,
	    typename Add,
	    typename Mult>
  void convolution(const Matrix<T>& in,
		   const Matrix<U>& filter,
		   V init,
		   Add add,
		   Mult mult,
		   Matrix<W>& out)
  {
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type filt_size;
    typedef typename Matrix<W>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    filt_size nfilt = filter.rows();
    filt_size mfilt = filter.columns();

    assert(nfilt > 0);
    assert(mfilt > 0);
    assert(nfilt <= n);
    assert(mfilt <= m);

    out_size nc = (nfilt - 1) / 2;
    out_size mc = (mfilt - 1) / 2;

    out_size nd = n + nc - nfilt + 1;
    out_size md = m + mc - mfilt + 1;

    //
    //    0   mc      md  m
    //  0 +---+-------+---+
    //    | A |   B   | C |
    // nc +---+-------+---+
    //    |   |       |   |
    //    | D |   E   | F |
    //    |   |       |   |
    // nd +---+-------+---+
    //    | G |   H   | I |
    //  n +---+-------+---+
    //

    Matrix<W> result(n,m);

    // top rows
    for (out_size i = 0; i < nc;i++) {

      // left columns (A)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, mc - j, nfilt, mfilt),
					     in,Box(0, 0, nfilt - nc + i, mfilt - mc + j),
					     init, add, mult);
      // central columns (B)
      for (out_size j = mc; j < md; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, 0, nfilt, mfilt),
					     in,Box(0, j - mc, nfilt - nc + i, mfilt + j - mc),
					     init, add, mult);
      // right columns (C)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, 0, nfilt, m + mc - j),
					     in,Box(0, j - mc, nfilt - nc + i,m),
					     init, add, mult);
    }

    // central rows
    for (out_size i = nc; i < nd; i++) {

      // left columns (D)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, mc - j, nfilt, mfilt),
					     in,Box(i - nc, 0, nfilt + i - nc, mfilt - mc + j),
					     init, add, mult);
      // central columns (E)
      Box filt_box(0,0,nfilt,mfilt);

      for (out_size j = mc; j < md; j++)
	result[i][j] = mat_inner_product_box(filter,filt_box,
					     in,Box(i - nc, j - mc, nfilt + i - nc, mfilt + j - mc),
					     init, add, mult);
      // right columns (F)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0,0,nfilt,m + mc - j),
					     in,Box(i - nc, j - mc, nfilt + i - nc, m),
					     init, add, mult);
    }

    // bottom rows
    for (out_size i = nd; i < n; i++) {
      // left columns (G)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, mc - j, n + nc - i, mfilt),
					     in,Box(i - nc, 0, n, mfilt - mc + j),
					     init, add, mult);
      // central columns (H)
      for (out_size j = mc; j<md; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, 0, n + nc - i, mfilt),
					     in,Box(i - nc, j - mc, n, mfilt - mc + j),
					     init, add, mult);
      // right columns (I)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, 0, n + nc - i, m + mc - j),
					     in,Box(i - nc, j - mc, n, m),
					     init, add, mult);
    }

    out.swap(result);
  }

  /**
   * Linear convolution.
   *
   * The output matrix is filled with values computed as:
   * \f[O_{i,j} = init + \sum_{h = 0}^{N-1}
   * \sum_{k = 0}^{M-1} F_{h,k} \times I_{i+h-N_c,j+k-M_c},
   * \mbox{ with }
   * N_c = \left\lfloor \frac{N-1}{2} \right\rfloor,
   * M_c = \left\lfloor \frac{M-1}{2} \right\rfloor ,\f]
   * where \f$ I \f$ and \f$ O \f$ are the input and the output matrix respectively, and
   * \f$ F \f$ is a \f$ N \times M \f$ filter.
   * Note that the terms in the summation for which the indices are outside the boundaries of
   * the input image are not actually computed.
   *
   * \param in input matrix
   * \param filter linear filter
   * \param init base value
   * \param out output matrix
   *
   * \pre filter.rows() > 0
   * \pre filter.columns() > 0
   * \pre filter.rows() <= in.rows()
   * \pre filter.columns() <= in.columns()
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,
	    typename U,
	    typename V,
	    typename W>
  void convolution(const Matrix<T>& in,
		   const Matrix<U>& filter,
		   V init,
		   Matrix<W>& out)
  {
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type filt_size;
    typedef typename Matrix<W>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    filt_size nfilt = filter.rows();
    filt_size mfilt = filter.columns();

    assert(nfilt > 0);
    assert(mfilt > 0);
    assert(nfilt <= n);
    assert(mfilt <= m);

    out_size nc = (nfilt - 1) / 2;
    out_size mc = (mfilt - 1) / 2;

    out_size nd = n + nc - nfilt + 1;
    out_size md = m + mc - mfilt + 1;

    //
    //    0   mc      md  m
    //  0 +---+-------+---+
    //    | A |   B   | C |
    // nc +---+-------+---+
    //    |   |       |   |
    //    | D |   E   | F |
    //    |   |       |   |
    // nd +---+-------+---+
    //    | G |   H   | I |
    //  n +---+-------+---+
    //
    // Only the elements in the sector E are computed
    // with a full convolution.
    //

    Matrix<W> result(n,m);

    // top rows
    for (out_size i = 0; i < nc;i++) {

      // left columns (A)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, mc - j, nfilt, mfilt),
					     in,Box(0, 0, nfilt - nc + i, mfilt - mc + j),
					     init);
      // central columns (B)
      for (out_size j = mc; j < md; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, 0, nfilt, mfilt),
					     in,Box(0, j - mc, nfilt - nc + i, mfilt + j - mc),
					     init);

      // right columns (C)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(nc - i, 0, nfilt, m + mc - j),
					     in,Box(0, j - mc, nfilt - nc + i,m),
					     init);
    }

    // central rows
    for (out_size i = nc; i < nd; i++) {

      // left columns (D)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, mc - j, nfilt, mfilt),
					     in,Box(i - nc, 0, nfilt + i - nc, mfilt - mc + j),
					     init);
      // central columns (E)
      Box filt_box(0,0,nfilt,mfilt);

      for (out_size j = mc; j < md; j++)
	result[i][j] = mat_inner_product_box(filter,filt_box,
					     in,Box(i - nc, j - mc, nfilt + i - nc, mfilt + j - mc),
					     init);

      // right columns (F)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0,0,nfilt,m + mc - j),
					     in,Box(i - nc, j - mc, nfilt + i - nc, m),
					     init);
    }

    // bottom rows
    for (out_size i = nd; i < n; i++) {
      // left columns (G)
      for (out_size j = 0; j < mc; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, mc - j, n + nc - i, mfilt),
					     in,Box(i - nc, 0, n, mfilt - mc + j),
					     init);
      // central columns (H)
      for (out_size j = mc; j<md; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, 0, n + nc - i, mfilt),
					     in,Box(i - nc, j - mc, n, mfilt - mc + j),
					     init);
      // right columns (I)
      for (out_size j = md; j<m; j++)
	result[i][j] = mat_inner_product_box(filter,Box(0, 0, n + nc - i, m + mc - j),
					     in,Box(i - nc, j - mc, n, m),
					     init);
    }

    out.swap(result);
  }

  /**
   * Linear convolution.
   *
   * Computed as in the versions without the extra functor parameters.
   * The functors \p add and \p mult specify respectively the sum and
   * the multiplication.
   */
  template <typename T,
	    typename U,
	    typename V,
	    typename W,
	    typename Add,
	    typename Mult>
  void convolution_valid(const Matrix<T>& in,
			 const Matrix<U>& filter,
			 V init,
			 Add add,
			 Mult mult,
			 Matrix<W>& out)
  {
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type filt_size;
    typedef typename Matrix<W>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    filt_size nfilt = filter.rows();
    filt_size mfilt = filter.columns();

    assert(nfilt > 0);
    assert(mfilt > 0);

    if (nfilt > n || mfilt > m) {
      out.clear();
      return;
    }
     

    out_size nout = (n - nfilt) + 1;
    out_size mout = (m - mfilt) + 1;

    Matrix<W> result(nout, mout);

    Box filt_box(0, 0, nfilt, mfilt);
    for (out_size i = 0; i < nout; i++) {
      for (out_size j = 0; j < mout; j++)
	result[i][j] = mat_inner_product_box(filter, filt_box,
					     in, Box(i, j, nfilt + i, mfilt + j),
					     init, add, mult);
    }
    
    out.swap(result);
  }

  /**
   * Linear convolution.
   *
   * This convolution function compute only those output values only when the
   * filter mask is completely inside the input matrix.  The output matrix is
   * therefore smaller than the input matrix.
   * The output matrix is filled with values computed as:
   * \f[
   * O_{i,j} = init + \sum_{h = 0}^{N-1}
   * \sum_{k = 0}^{M-1} F_{h,k} \times I_{i+h, j+k},
   * \f]
   * where \f$ I \f$ and \f$ O \f$ are the input and the output matrix respectively, and
   * \f$ F \f$ is a \f$ N \times M \f$ filter.
   *
   * \param in input matrix
   * \param filter linear filter
   * \param init base value
   * \param out output matrix
   *
   * \pre filter.rows() > 0
   * \pre filter.columns() > 0
   *
   * \post out.rows() == in.rows() - filter.rows() + 1
   * \post out.columns() == in.columns() - filter.columns() + 1
   */
  template <typename T,
	    typename U,
	    typename V,
	    typename W>
  void convolution_valid(const Matrix<T>& in,
			 const Matrix<U>& filter,
			 V init,
			 Matrix<W>& out)
  {
    typedef typename Matrix<T>::size_type in_size;
    typedef typename Matrix<U>::size_type filt_size;
    typedef typename Matrix<W>::size_type out_size;

    in_size n = in.rows();
    in_size m = in.columns();

    filt_size nfilt = filter.rows();
    filt_size mfilt = filter.columns();

    assert(nfilt > 0);
    assert(mfilt > 0);
    
    if (nfilt > n || mfilt > m) {
      out.clear();
      return;
    }
     
    out_size nout = (n - nfilt) + 1;
    out_size mout = (m - mfilt) + 1;

    Matrix<W> result(nout, mout);

    Box filt_box(0, 0, nfilt, mfilt);
    for (out_size i = 0; i < nout; i++) {
      for (out_size j = 0; j < mout; j++)
	result[i][j] = mat_inner_product_box(filter, filt_box,
					     in, Box(i, j, nfilt + i, mfilt + j),
					     init);
    }

    out.swap(result);
  }

  /**
   * Construct an average filter.
   *
   * \f[ F = \frac{1}{N \times M}\left[\begin{array}{rrr}
   *   1 & \cdots & 1 \\
   *   \vdots & \ddots & \vdots \\
   *   1 & \cdots & 1
   * \end{array}\right] \f]
   *
   * The type of the elements of the matrix must
   * support assignement from doubles.
   *
   * \param nrows number of rows of the filter
   * \param ncolumns number of columns of the filter
   * \param out the output matrix
   *
   * \pre nrows > 0
   * \pre ncolumns > 0
   *
   * \post out.rows() == nrows
   * \post out.columns() == ncolumns
   */
  template <typename T>
  void make_average_filter(typename Matrix<T>::size_type nrows,
			   typename Matrix<T>::size_type ncolumns,
			   Matrix<T>& out)
  {
    assert(nrows > 0);
    assert(ncolumns > 0);
    Matrix<T> result(nrows,ncolumns, 1.0 / (nrows*ncolumns));
    out.swap(result);
  }

  /**
   * Construct a Gaussian filter.
   *
   * \f[ F_{i,j} = scale \frac{1}{2\pi \sigma^2} \exp \left(
   * -\frac{(j-\frac{m-1}{2})^2 + (i - \frac{n-1}{2})^2}{2 \sigma^2} \right) \f]
   *
   * The type of the elements of the matrix must
   * support assignement from doubles.
   *
   * \param nrows number of rows of the filter
   * \param ncolumns number of columns of the filter
   * \param sigma standard deviation of the Gaussian
   * \param out the output matrix
   * \param scale scaling parameter
   *
   * \pre nrows > 0
   * \pre ncolumns > 0
   * \pre sigma > 0
   *
   * \post out.rows() == nrows
   * \post out.columns() == ncolumns
   */
  template <typename T>
  void make_gaussian_filter(typename Matrix<T>::size_type nrows,
			    typename Matrix<T>::size_type ncolumns,
			    double sigma,
			    Matrix<T>& out,
			    double scale = 1.0)
  {
    assert(nrows > 0);
    assert(ncolumns > 0);
    assert(sigma > 0);

    typedef typename Matrix<T>::size_type size_type;

    Matrix<double> tmp(nrows,ncolumns);

    double cy = (nrows-1) * 0.5;
    double cx = (ncolumns-1) * 0.5;

    double den = 0.5/(sigma*sigma);

    double tot = 0.0;
    for (size_type i = 0; i<nrows; i++) {
      for (size_type j = 0; j<ncolumns; j++) {
	tmp[i][j] = std::exp(-((j-cx)*(j-cx) + (i-cy)*(i-cy))*den);
	tot += tmp[i][j];
      }
    }

    assert(tot > 0);

    tot = tot/scale;

    Matrix<T> result(nrows,ncolumns);
    for (size_type i = 0; i<nrows; i++)
      for (size_type j = 0; j<ncolumns; j++)
	result[i][j] = tmp[i][j] / tot;
		       
    out.swap(result);
  }

  /**
   * Construct a horizontal derivative of Gaussian filter.
   *
   * \f[ F_{i,j} = - scale \frac{1}{2\pi \sigma^4} (j - \frac{m-1}{2}) \exp \left(
   * -\frac{(j- \frac{m-1}{2}))^2 + (i - \frac{n-1}{2})^2}{2 \sigma^2} \right) \f]
   *
   * The type of the elements of the matrix must
   * support assignement from doubles.
   *
   * \param nrows number of rows of the filter
   * \param ncolumns number of columns of the filter
   * \param sigma standard deviation of the Gaussian
   * \param out the output matrix
   * \param scale scaling parameter
   *
   * \pre nrows > 0
   * \pre ncolumns > 0
   * \pre sigma > 0
   *
   * \post out.rows() == nrows
   * \post out.columns() == ncolumns
   */
  template <typename T>
  void make_h_gaussian_derivative_filter(typename Matrix<T>::size_type nrows,
					 typename Matrix<T>::size_type ncolumns,
					 double sigma,
					 Matrix<T>& out,
					 double scale = 1.0)
  {
    assert(nrows > 0);
    assert(ncolumns > 0);
    assert(sigma > 0);

    const double pi = 3.1415926535897931; // to be defined elsewhere in the library

    typedef typename Matrix<T>::size_type size_type;

    double cy = (nrows-1) * 0.5;
    double cx = (ncolumns-1) * 0.5;

    double den = 0.5/(sigma*sigma);
    double den2 = -0.5*scale/(pi*sigma*sigma*sigma*sigma);

    Matrix<T> result(nrows,ncolumns);

    for (size_type i = 0; i<nrows; i++)
      for (size_type j = 0; j<ncolumns; j++)
	result[i][j] = (j-cx)*std::exp(-((j-cx)*(j-cx) + (i-cy)*(i-cy))*den)*den2;
		       
    out.swap(result);
  }

  /**
   * Construct a vertical derivative of Gaussian filter.
   *
   * \f[ F_{i,j} = - scale \frac{1}{2\pi \sigma^4} (i- \frac{n-1}{2}) \exp \left(
   * -\frac{(j- \frac{m-1}{2})^2 + (i - \frac{n-1}{2})^2}{2 \sigma^2} \right) \f]
   *
   * The type of the elements of the matrix must
   * support assignement from doubles.
   *
   * \param nrows number of rows of the filter
   * \param ncolumns number of columns of the filter
   * \param sigma standard deviation of the Gaussian
   * \param out the output matrix
   * \param scale scaling parameter
   *
   * \pre nrows > 0
   * \pre ncolumns > 0
   * \pre sigma > 0
   *
   * \post out.rows() == nrows
   * \post out.columns() == ncolumns
   */
  template <typename T>
  void make_v_gaussian_derivative_filter(typename Matrix<T>::size_type nrows,
					 typename Matrix<T>::size_type ncolumns,
					 double sigma,
					 Matrix<T>& out,
					 double scale = 1.0)
  {
    assert(nrows > 0);
    assert(ncolumns > 0);
    assert(sigma > 0);

    typedef typename Matrix<T>::size_type size_type;

    double cy = (nrows-1) * 0.5;
    double cx = (ncolumns-1) * 0.5;

    const double pi = 3.1415926535897931; // to be defined elsewhere in the library
    double den = 0.5/(sigma*sigma);
    double den2 = -0.5*scale/(pi*sigma*sigma*sigma*sigma);

    Matrix<T> result(nrows,ncolumns);

    for (size_type i = 0; i<nrows; i++)
      for (size_type j = 0; j<ncolumns; j++)
	result[i][j] = (i-cy)*std::exp(-((j-cx)*(j-cx) + (i-cy)*(i-cy))*den)*den2;
		       
    out.swap(result);
  }

  /**
   * Construct a Laplacian of Gaussian filter.
   *
   * \f[ F_{i,j} = -scale \frac{1}{\pi \sigma^4}
   * \left(1 - \frac{(j- \frac{m-1}{2})^2 + (i- \frac{n-1}{2})^2}{2\sigma^2}\right)
   * \exp \left(-\frac{(j- \frac{m-1}{2})^2 + (i - \frac{n-1}{2})^2}{2 \sigma^2} \right) \f]
   *
   * The type of the elements of the matrix must
   * support assignement from doubles.
   *
   * \param nrows number of rows of the filter
   * \param ncolumns number of columns of the filter
   * \param sigma standard deviation of the Gaussian
   * \param out the output matrix
   * \param scale scaling parameter
   *
   * \pre nrows > 0
   * \pre ncolumns > 0
   * \pre sigma > 0
   *
   * \post out.rows() == nrows
   * \post out.columns() == ncolumns
   */
  template <typename T>
  void make_laplacian_of_gaussian_filter(typename Matrix<T>::size_type nrows,
					 typename Matrix<T>::size_type ncolumns,
					 double sigma,
					 Matrix<T>& out,
					 double scale = 1.0)
  {
    assert(nrows > 0);
    assert(ncolumns > 0);
    assert(sigma > 0);
    
    typedef typename Matrix<T>::size_type size_type;

    double cy = (nrows-1) * 0.5;
    double cx = (ncolumns-1) * 0.5;
    
    const double pi = 3.1415926535897931; // to be defined elsewhere in the library
    double den = 0.5/(sigma*sigma);
    double den2 = -scale/(pi*sigma*sigma*sigma*sigma);
    
    Matrix<T> result(nrows,ncolumns);

    for (size_type i = 0; i<nrows; i++) {
      for (size_type j = 0; j<ncolumns; j++) {
	double num = -den*((j-cx)*(j-cx) + (i-cy)*(i-cy));
	result[i][j] = den2*(1.0 + num)*std::exp(num);
      }
    }
		       
    out.swap(result);
  }

  /**
   * Construct the horizontal Sobel's filter.
   *
   * \f[ F = \left[\begin{array}{rrr}
   *   -1 & 0 & 1 \\
   *   -2 & 0 & 2 \\
   *   -1 & 0 & 1
   * \end{array}\right] \f]
   *
   * The type of the elements of the matrix must
   * support assignement from integers.
   *
   * \param out the output matrix
   *
   * \post out.rows() == 3
   * \post out.columns() == 3
   */
  template <typename T>
  void make_h_sobel_filter(Matrix<T>& out)
  {
    Matrix<T> result(3,3);

    result[0][0] = -1; result[0][1] = 0; result[0][2] = 1;
    result[1][0] = -2; result[1][1] = 0; result[1][2] = 2;
    result[2][0] = -1; result[2][1] = 0; result[2][2] = 1;

    out.swap(result);
  }

  /**
   * Construct the vertical Sobel's filter.
   *
   * \f[ F = \left[\begin{array}{rrr}
   *   -1 & -2 & -1 \\
   *    0 &  0 &  0 \\
   *    1 &  2 &  1
   * \end{array}\right] \f]
   *
   * The type of the elements of the matrix must
   * support assignement from integers.
   *
   * \param out the output matrix
   *
   * \post out.rows() == 3
   * \post out.columns() == 3
   */
  template <typename T>
  void make_v_sobel_filter(Matrix<T>& out)
  {
    Matrix<T> result(3,3);

    result[0][0] = -1; result[0][1] = -2; result[0][2] = -1;
    result[1][0] =  0; result[1][1] =  0; result[1][2] =  0;
    result[2][0] =  1; result[2][1] =  2; result[2][2] =  1;

    out.swap(result);
  }

  /*@}*/

} // ivllib

#endif
