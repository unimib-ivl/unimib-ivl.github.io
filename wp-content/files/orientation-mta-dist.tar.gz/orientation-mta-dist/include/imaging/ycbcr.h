/**
 * \file    ycbcr.h
 * \brief   ycbcr colorspace structures
 * \author  $LastChangedBy: beccaria $
 */

// sviluppato da Mirko Beccaria
 
#ifndef ivllib_ycbcr_h
#define ivllib_ycbcr_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>

namespace ivllib 
{
  /** \addtogroup color */
  /*@{*/

  /**
   * Pixels in the YCBCR color space
   */
  template <typename T>
  struct YCBCR
  {    
    typedef T channel_type; ///< type of the components
	
    channel_type y;        ///< y component
    channel_type cb;       ///< cb component
    channel_type cr;       ///< cr component

    /// Black value in YCBCR
    YCBCR()
      : y(16),cb(128),cr(128)
    {
    }
	
    /// Construction from the channels values
    YCBCR(channel_type ay,
	  channel_type acb,
	  channel_type acr)
      : y(ay),
	cb(acb),
	cr(acr)
    {
    }
  };

  /**
   * Eight bits YCBCR pixels
   *
   * The three components are in the range 0-255.
   */
  typedef YCBCR<unsigned char> YCBCR8;

  // pixel conversions

  /**
   * Conversion from gray to YCBCR (8 bits)
   * 
   * The original range 0-255 is rescaled
   * in the range 16-235
   */   
  template <>
  struct PixelConversion<Gray8,YCBCR8>
    : public std::unary_function<Gray8,YCBCR8>
  {
    /// conversion
    YCBCR8 operator()(Gray8 p) const
    {
      int y = 16 + ((p*56284) >> 16);

      return YCBCR8(y,128,128);
    }
  };

  /**
   * YCBCR to RGB colorspace conversion
   *
   * conversion of 8-bits YCBCR pixels to 8-bits RGB values.
   *
   */
  template <>
  struct PixelConversion<YCBCR8,RGB8>
    : public std::unary_function<YCBCR8,RGB8>
  {
    /// conversion
    RGB8 operator()(const YCBCR8 p) const
    {
      int y1 = (p.y - 16) * 76284;
      int cb1 = p.cb - 128;
      int cr1 = p.cr - 128;

      int r = (y1 + 104595 * cr1) >> 16;
      int g = (y1 - 53281 * cr1 - 25690 * cb1) >> 16;
      int b = (y1 + 132186 * cb1) >> 16;

      if (r > 255)
	r = 255;
      else if (r < 0)
	r = 0;
            
      if (g > 255)
	g = 255;
      else if (g < 0)
	g = 0;

      if (b > 255)
	b = 255;
      else if (b < 0)
	b = 0;

      return RGB8(r,g,b);
    }
  };

  /**
   * RGB to YCBCR colorspace conversion
   *
   * conversion of 8-bits RGB pixels to 8-bits YCBCR values.
   */
  template <>
  struct PixelConversion<RGB8,YCBCR8>
    : public std::unary_function<RGB8,YCBCR8>
  {
    /// conversion
    YCBCR8 operator()(const RGB8& p) const
    {
      int y = 16 + ((16843*p.red + 33030*p.green + 6423*p.blue) >> 16);
      int cb = 128 + ((-9699*p.red - 19071*p.green + 28770*p.blue) >> 16);
      int cr = 128 + ((28770*p.red - 24117*p.green - 4653*p.blue) >> 16);

      return YCBCR8(y,cb,cr);
    }
  };

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const YCBCR<T>& a,const YCBCR<T>&b)
  {
    return a.y == b.y && 
      a.cb == b.cb &&
      a.cr == b.cr;
  }

  /// inequality
  template <typename T>
  bool operator!=(const YCBCR<T>& a,const YCBCR<T>&b)
  {
    return !(a == b);
  }

  /*@}*/

} // namespace ivllib

#endif // ivllib_ycbcr_h
