/**
 * \file    lab.h
 * \brief   lab colorspace structures
 * \author  $LastChangedBy: ciocca $
 */

#ifndef ivllib_lab_h
#define ivllib_lab_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <cmath>
#include "ivl_vector.h"
#include "xyz.h"

using namespace std;

namespace ivllib
{
  /** \addtogroup color */
  /*@{*/

  /** \cond detail */
	namespace details {
	
		inline double RGB2LabHelper(double q) {
			double value;
			static double e = 1.0/3.0;
			if ( q > 0.008856 ) {
				value = pow ( q, e );
				return value;
			}
			value = 7.787*q + 0.137931;
			return value;
		}	
		
		inline Vector<double> gv(double v0, double v1, double v2) {
			Vector<double> tmp(3);
			tmp[0]=v0; tmp[1]= v1; tmp[2]=v2;
			return tmp;
		}
	}
  /** \endcond */

	static const Vector<double> D65WP=
		details::gv(0.950467,1.000000,1.088969);

  /**
   * Pixels in the LAB color space
   */
  template <typename T>
  struct Lab
  {
    typedef T channel_type; ///< type of the components

    channel_type l; ///< l component
    channel_type a; ///< a component
    channel_type b; ///< b component

    /// Black value in LAB
    Lab()
      : l(0),a(0),b(0)
    {
    }

    /// Construction from the channels values
    Lab(channel_type al,
		channel_type aa,
		channel_type ab)
      : l(al),a(aa),b(ab){}
  };

  /**
   * LAB pixels
   */
  typedef Lab<float> LAB;
  
  // pixel conversions
  
  template<>
  struct PixelConversion<LAB,XYZ> 
		: public std::unary_function<LAB,XYZ> 
	{
  	/**
  	 * Constructor
  	 * @param W white point (default D65)
  	 */
		PixelConversion(const Vector<double> &W=D65WP) : _w(W) {}
		
		XYZ operator()(const LAB &p) const {
			assert(_w.size()==3);
			
			double X,Y,Z,cby,tmp;
			
			if( p.l < 8.0 ) {
				Y = (p.l * _w[1]) / 903.3;
				cby = 7.787 * (Y / _w[1]) + 16.0 / 116.0;
			}
			else {
				cby = (p.l + 16.0) / 116.0;
				Y = _w[1] * cby * cby * cby;
			}

			tmp = p.a / 500.0 + cby;
			if( tmp < 0.2069 )
				X = _w[0] * (tmp - 0.13793) / 7.787;
			else
				X = _w[0] * tmp * tmp * tmp;

			tmp = cby - p.b / 200.0;
			if( tmp < 0.2069 )
				Z = _w[2] * (tmp - 0.13793) / 7.787;
			else
				Z = _w[2] * tmp * tmp * tmp;

			return XYZ(X,Y,Z);
		}
		private:
			Vector<double> _w;
	};  
  
  /**
   * XYZ to LAB colorspace conversion
   */
  template <>
  struct PixelConversion<XYZ,LAB>
    : public std::unary_function<XYZ,LAB>
  {
  	/**
  	 * Constructor
  	 * @param W white point (default D65)
  	 */
		PixelConversion(const Vector<double> &W=D65WP) : _w(W) {}
		
    LAB operator()(const XYZ& p) const {
			assert(_w.size()==3);
			
			double X = p.x / _w[0];
			double Y = p.y / _w[1];
			double Z = p.z / _w[2];
			
			LAB tmp;

			tmp.l = 116 * details::RGB2LabHelper(Y) - 16;
			tmp.a = 500 * (details::RGB2LabHelper(X) - details::RGB2LabHelper(Y));
			tmp.b = 200 * (details::RGB2LabHelper(Y) - details::RGB2LabHelper(Z));

			return tmp;
    }
    private: 
    	Vector<double> _w;
  };


  /**
   * RGB to LAB colorspace conversion
   *
   * Conversion of 8-bits RGB pixels to LAB values.
   * Defaults are sRGB color space and D65 white point
   */
  template <>
  struct PixelConversion<RGB8,LAB>
    : public std::unary_function<RGB8,LAB>
  {
  	/**
  	 * Constructor
  	 * @param M color conversion matrix (default sRGB2XYZD65)
  	 * @param W white point (default D65)
  	 */  	 
		PixelConversion(const Matrix<double> &M=sRGB2XYZD65, 
			const Vector<double> &W=D65WP) : _rgb2xyz(M), _xyz2lab(W) {}
		
    LAB operator()(const RGB8& p) const
    {
    	return _xyz2lab(_rgb2xyz(p));	
		} 
		private:
			PixelConversion<RGB8,XYZ> _rgb2xyz; 	
			PixelConversion<XYZ, LAB> _xyz2lab; 	
	};

  /**
   * LAB to RGB colorspace conversion
   *
   * Conversion LAB values to 8-bits RGB pixels.
   * Defaults are sRGB color space and D65 white point
   */
  template <>
  struct PixelConversion<LAB,RGB8>
    : public std::unary_function<LAB,RGB8>
  {
  	/**
  	 * Constructor
  	 * @param M color conversion matrix (default XYZ2RGBD65)
  	 * @param W white point (default D65)
  	 */  	 
		PixelConversion(const Matrix<double> &M=XYZ2sRGBD65, 
			const Vector<double> &W=D65WP) : _xyz2rgb(M), _lab2xyz(W) {}
		
    RGB8 operator()(const LAB& p) const
    {
    	return _xyz2rgb(_lab2xyz(p));	
		} 
		private:
			PixelConversion<XYZ,RGB8> _xyz2rgb; 	
			PixelConversion<LAB,XYZ>  _lab2xyz; 	
	};

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const Lab<T>& a,const Lab<T>& b)
  {
    return a.l == b.l &&
      		 a.a == b.a &&
      		 a.b == b.b;
  }

  /// inequality
  template <typename T>
  bool operator!=(const Lab<T>& a,const Lab<T>& b)
  {
    return !(a == b);
  }

  /*@}*/

} // namespace ivllib

#endif // ivllib_lab_h
