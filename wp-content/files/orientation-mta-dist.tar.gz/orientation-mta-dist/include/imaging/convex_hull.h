/**
 * \file    convex_hull.h
 * \brief   convex hull computation
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef convex_hull_h
#define convex_hull_h

#include <ivl_matrix.h>
#include <imaging/utils.h>
#include <vector>
#include <algorithm>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  template <typename T,typename U,typename Pred>
  void convex_hull(const Matrix<T>& in,
		   U outside_value,
		   U inside_value,
		   Matrix<U>& out,
		   Pred foreground_pred);

  template <typename T,typename U>
  void convex_hull(const Matrix<T>& in,
		   U outside_value,
		   U inside_value,
		   Matrix<U>& out);
  
  //------------------------------------------------------------

  /** \cond detail */
  namespace detail
  {
    template <typename T>
    struct chull_default_foreground
    {
      bool operator()(const T& x) const { return x; }
    };

    struct hull_point
    {
      typedef int size_type;

      hull_point(size_type ai,size_type aj)
	: i(ai),j(aj)
      {
      }

      size_type i;
      size_type j;
    };

    class hull_cmp
    {
    public:
      typedef int size_type;

      hull_cmp(size_type pivot_i,size_type pivot_j)
	: pi_(pivot_i),
	  pj_(pivot_j)
      {
      }

      bool operator()(const hull_point& a,const hull_point& b) const
      {
	int dx1 = static_cast<int>(a.j) - static_cast<int>(pj_);
	int dy1 = a.i - pi_;
	int dx2 = static_cast<int>(b.j) - static_cast<int>(pj_);
	int dy2 = b.i - pi_;

	return dx1*dy2 > dx2*dy1;
      }

    private:
      size_type pi_;
      size_type pj_;
    };

    namespace
    {
      bool is_right_turn(const hull_point& a,
			 const hull_point& b,
			 const hull_point& c)
      {
	int cp = ((static_cast<int>(b.j) - static_cast<int>(a.j)) *
		  (static_cast<int>(c.i) - static_cast<int>(a.i)));
	cp -= ((static_cast<int>(c.j) - static_cast<int>(a.j)) *
	       (static_cast<int>(b.i) - static_cast<int>(a.i)));
	
	return cp > 0;
      }
    }
  } // detail
  /** \endcond */
  
  /**
   * Convex hull computation.
   *
   * Compute the convex hull of the foreground region.
   * The elements of the output matrix inside the convex hull are set to \p inside_value.
   * The other elements are set to outside_value.
   * The pixels of the foreground region are determined calling the \p foreground_pred
   * predicate. If <tt>foreground_pred(in[i][j]) == true</tt> then the pixel at coordinates
   * <tt>(i,j)</tt> is part of the foreground, otherwise is part of the background.
   * 
   * \param in input image
   * \param outside_value value used to fill pixels outside the convex hull
   * \param inside_value value used to fill pixels inside the convex hull
   * \param out output image
   * \param foreground_pred predicate which determines the foreground pixels
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename Pred>
  void convex_hull(const Matrix<T>& in,
		   U outside_value,
		   U inside_value,
		   Matrix<U>& out,
		   Pred foreground_pred)
  {
    //------------------------
    // based on Graham's scan
    //------------------------

    typedef typename Matrix<T>::size_type size_type;

    // find the pivot point (first pixel scanning top-bottom/left-right)
    bool pivot_found = false;
    size_type pivot_i = 0;
    size_type pivot_j = 0;
    for (size_type i = 0; !pivot_found && i < in.rows(); i++) {
      for(size_type j = 0; !pivot_found && j < in.columns(); j++) {
	if (foreground_pred(in[i][j])) {
	  pivot_i = i;
	  pivot_j = j;
	  pivot_found = true;
	}
      }
    }
    
    if (!pivot_found) {
      // no foreground
      Matrix<U> tmp(in.rows(),in.columns(),outside_value);
      out.swap(tmp);
      return;
    }

    // store the foreground points
    typedef std::vector<detail::hull_point> hull_points;
    hull_points points;
    size_type start_j = 1 + pivot_j;
    for (size_type i = pivot_i; i < in.rows(); i++) {
      for (size_type j = start_j; j < in.columns(); j++) {
	if (foreground_pred(in[i][j]))
	  points.push_back(detail::hull_point(i,j));
      }
      start_j = 0;
    }
    
    if (points.size() == 0) {
      // only one foreground pixel
      Matrix<U> tmp(in.rows(),in.columns(),outside_value);
      tmp[pivot_i][pivot_j] = inside_value;
      out.swap(tmp);
      return;
    }

    // sort the points according to the angle with the pivot
    std::sort(points.begin(),points.end(),detail::hull_cmp(pivot_i,pivot_j));
    
    // compute the convex hull
    hull_points stack;
    stack.push_back(detail::hull_point(pivot_i,pivot_j));
    typename hull_points::iterator it = points.begin();
    stack.push_back(*it);
    ++it;
    while (it != points.end()) {
      while (stack.size() > 2 && !detail::is_right_turn(*(stack.end() - 2),stack.back(),*it))
	stack.pop_back();
      stack.push_back(*it);
      ++it;
    }

    // retrieve the coordinates of the vertices of the hull
    std::vector<size_type> x;
    std::vector<size_type> y;
    
    for (it = stack.begin(); it != stack.end(); ++it) {
      x.push_back(it->j);
      y.push_back(it->i);
    }

    // draw the convex hull on the output matrix
    Matrix<U> tmp(in.rows(),in.columns(),outside_value);
    fill_convex_polygon(tmp,y.begin(),y.end(),x.begin(),inside_value);

    // commit
    out.swap(tmp);
  }

  /**
   * Convex hull computation.
   *
   * Compute the convex hull of the foreground region.
   * The elements of the output matrix inside the convex hull are set to \p inside_value.
   * The other elements are set to outside_value.
   * The pixels of the foreground region are determined by a conversion to \p bool.
   * If <tt>static_cast<bool>(in[i][j]) == true</tt> then the pixel at coordinates
   * <tt>(i,j)</tt> is part of the foreground, otherwise is part of the background.
   * 
   * \param in input image
   * \param outside_value value used to fill pixels outside the convex hull
   * \param inside_value value used to fill pixels inside the convex hull
   * \param out output image
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U>
  void convex_hull(const Matrix<T>& in,
		   U outside_value,
		   U inside_value,
		   Matrix<U>& out)
  {
    convex_hull(in,outside_value,inside_value,out,detail::chull_default_foreground<T>());
  }
  
  /*@}*/

} // ivllib

#endif // convex_hull_h
