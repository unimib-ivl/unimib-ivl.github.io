/**
 * \file draw_text.h
 *
 * Routines for printing ascii text on matrices.
 */
#ifndef draw_text_h
#define draw_text_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <mat_algorithm.h>
#include <string>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/
  
  /**
   * Height of a text region.
   *
   * Return the height of a text region containing the characters in
   * \p str and with a font size of \p font_size.
   *
   * \param str text
   * \param font_size size of the font
   *
   * \return the height in pixel
   */
  unsigned int text_height(const std::string& str,
			   unsigned int font_size);

  /**
   * Width of a text region.
   *
   * Return the width of a text region containing the characters in \p
   * str and with a font size of \p font_size.
   *
   * \param str text
   * \param font_size size of the font
   *
   * \return the width in pixel
   */
  unsigned int text_width(const std::string& str,
			  unsigned int font_size);

  /**
   * Draw text on a matrix.
   *
   * Draw the characters in \p str on the matrix \p out.  The
   * characters are drawn by blending (using <tt>ivllib::Blend </tt>)
   * \p text_color with the pixels in \p out. Text is draw from the
   * position defined \p row (top) and \p col (left).  The parts of
   * the text which lie the output matrix are ignored.
   * 
   * Only printable characters ara drawn. Whitespaces (including tabs
   * and newlines) are treated as a single space.
   *
   * \param str text to be drawn
   * \param font_size size of the font
   * \param text_color color used to draw the characters
   * \param row top boundary of the text region
   * \param col left boundary of the text region
   * \param out destination matrix
   */
  template <typename T>
  void draw_text(const std::string& str,
		 unsigned int font_size,
 		 typename Matrix<T>::element_type text_color,
		 int row,
		 int col,
		 Matrix<T>& out);

  /**
   * Draw text on a matrix.
   *
   * Draw the characters in \p str on the matrix \p out.  The
   * characters are drawn by blending (using <tt>ivllib::Blend </tt>)
   * \p text_color and \p back_color. Text is draw from the position
   * defined \p row (top) and \p col (left).  The parts of the text
   * which lie the output matrix are ignored.
   * 
   * Only printable characters ara drawn. Whitespaces (including tabs
   * and newlines) are treated as a single space.
   *
   * \param str text to be drawn
   * \param font_size size of the font
   * \param text_color color used to draw the characters
   * \param back_color color used to draw the text background
   * \param row top boundary of the text region
   * \param col left boundary of the text region
   * \param out destination matrix
   */
  template <typename T>
  void draw_text(const std::string& str,
		 unsigned int font_size,
		 typename Matrix<T>::element_type text_color,
		 typename Matrix<T>::element_type back_color,
		 int row,
		 int col,
		 Matrix<T>& out);

  /**
   * Draw text on a matrix.
   *
   * Draw the characters in \p str on the matrix \p out.  The
   * characters are drawn by blending (\p blend) \p text_color with
   * the pixels in \p out. Text is draw from the position defined \p
   * row (top) and \p col (left).  The parts of the text which lie
   * the output matrix are ignored.
   * 
   * Only printable characters ara drawn. Whitespaces (including tabs
   * and newlines) are treated as a single space.
   *
   * \param str text to be drawn
   * \param font_size size of the font
   * \param text_color color used to draw the characters
   * \param row top boundary of the text region
   * \param col left boundary of the text region
   * \param out destination matrix
   * \param blend blending functor
   */
  template <typename T,typename BlendFun>
  void draw_text(const std::string& str,
		 unsigned int font_size,
 		 typename Matrix<T>::element_type text_color,
		 int row,
		 int col,
		 Matrix<T>& out,
		 BlendFun blend);
	
  /**
   * Draw text on a matrix.
   *
   * Draw the characters in \p str on the matrix \p out.  The
   * characters are drawn by blending (using \p blend) \p text_color
   * and \p back_color. Text is draw from the position defined \p row
   * (top) and \p col (left).  The parts of the text which lie the
   * output matrix are ignored.
   * 
   * Only printable characters ara drawn. Whitespaces (including tabs
   * and newlines) are treated as a single space.
   *
   * \param str text to be drawn
   * \param font_size size of the font
   * \param text_color color used to draw the characters
   * \param back_color color used to draw the text background
   * \param row top boundary of the text region
   * \param col left boundary of the text region
   * \param out destination matrix
   * \param blend blending functor
   */
  template <typename T,typename BlendFun>
  void draw_text(const std::string& str,
		 unsigned int font_size,
		 typename Matrix<T>::element_type text_color,
		 typename Matrix<T>::element_type back_color,
		 int row,
		 int col,
		 Matrix<T>& out,
		 BlendFun blend);

  /*@}*/
  
  /** \cond detail */
  namespace detail
  {
    // helpers
    
    // create a box with the given text (0 background ... 255 foreground)
    void make_text(const std::string& str,
		   unsigned int font_size,
		   Matrix<unsigned char>& out);

    // Functor which blends text and back colors according to the text
    template <typename T,typename BlendFun>
    struct TextColor
    {
      T fg_;
      T bg_;
      BlendFun fun_;

      static const double i255 = 0.0039215686274509; // 1.0/255
      
      TextColor(const T& foreground,
		const T& background,
		BlendFun fun)
	: fg_(foreground),
	  bg_(background),
	  fun_(fun)
      {
      }

      T operator()(unsigned char c) const {
	return fun_(fg_,bg_,c*i255);
      }
    };

    // Functor which blends text and image colors according to the text
    template <typename T,typename BlendFun>
    struct TextBlend
    {
      T fg_;
      BlendFun fun_;

      static const double i255 = 0.0039215686274509; // 1.0/255
      
      TextBlend(const T& foreground,
		BlendFun fun)
	: fg_(foreground),
	  fun_(fun)
      {
      }

      T operator()(unsigned char c,const T& back) const {
	return fun_(fg_,back,c*i255);
      }
    };

  } // namespace detail
  /** \endcond */

} // namespace ivllib

// Implementation

template <typename T>
void ivllib::draw_text(const std::string& str,
		       unsigned int font_size,
		       typename ivllib::Matrix<T>::element_type text_color,
		       int row,
		       int col,
		       ivllib::Matrix<T>& out)
{
  typedef typename Matrix<T>::element_type E;

  draw_text(str,font_size,text_color,row,col,out,Blend<E>());
}
			   
template <typename T>
void ivllib::draw_text(const std::string& str,
		       unsigned int font_size,
		       typename ivllib::Matrix<T>::element_type text_color,
		       typename ivllib::Matrix<T>::element_type back_color,
		       int row,
		       int col,
		       Matrix<T>& out)
{
  typedef typename Matrix<T>::element_type E;

  draw_text(str,font_size,text_color,back_color,row,col,out,Blend<E>());
}

template <typename T,typename BlendFun>
void ivllib::draw_text(const std::string& str,
		       unsigned int font_size,
		       typename ivllib::Matrix<T>::element_type text_color,
		       int row,
		       int col,
		       ivllib::Matrix<T>& out,
		       BlendFun blend)
{
  typedef typename Matrix<T>::element_type E;
  typedef typename Matrix<T>::size_type size_type;
  
  if (row >= 0 && static_cast<size_type>(row) >= out.rows())
    return;

  if (col >= 0 && static_cast<size_type>(col) >= out.columns())
    return;

  Matrix<unsigned char> txt;
  detail::make_text(str,font_size,txt);

  size_type start_row = (row > 0 ? 0 : static_cast<size_type>(-row));
  size_type start_col = (col > 0 ? 0 : static_cast<size_type>(-col));

  if (start_row >= txt.rows() || start_col >= txt.columns())
    return;

  size_type end_row = txt.rows();
  if (end_row + row > out.rows())
    end_row = out.rows() - row;

  size_type end_col = txt.columns();
  if (end_col + col > out.columns())
    end_col = out.columns() - col;
  
  if (row < 0)
    row = 0;
  
  if (col < 0)
    col = 0;

  mat_transform_box(txt,
		    Box(start_row, start_col, end_row, end_col),
		    out,
		    Box(row, col, row + (end_row - start_row), col + (end_col - start_col)),
		    out,
		    Box(row, col, row + (end_row - start_row), col + (end_col - start_col)),
		    detail::TextBlend<E,BlendFun>(text_color,blend));
}
			   
template <typename T,typename BlendFun>
void ivllib::draw_text(const std::string& str,
		       unsigned int font_size,
		       typename ivllib::Matrix<T>::element_type text_color,
		       typename ivllib::Matrix<T>::element_type back_color,
		       int row,
		       int col,
		       Matrix<T>& out,
		       BlendFun blend)
{
  typedef typename Matrix<T>::element_type E;
  typedef typename Matrix<T>::size_type size_type;

  if (row >= 0 && static_cast<size_type>(row) >= out.rows())
    return;

  if (col >= 0 && static_cast<size_type>(col) >= out.columns())
    return;
  
  Matrix<unsigned char> txt;
  detail::make_text(str,font_size,txt);

  size_type start_row = (row > 0 ? 0 : static_cast<size_type>(-row));
  size_type start_col = (col > 0 ? 0 : static_cast<size_type>(-col));
  
  if (start_row >= txt.rows() || start_col >= txt.columns())
    return;

  size_type end_row = txt.rows();
  if (end_row + row > out.rows()) 
    end_row = out.rows() - row;

  size_type end_col = txt.columns();
  if (end_col + col > out.columns())
    end_col = out.columns() - col;
  
  if (row < 0)
    row = 0;
  
  if (col < 0)
    col = 0;

  mat_transform_box(txt,
		    Box(start_row, start_col, end_row, end_col),
		    out,
		    Box(row, col, row + (end_row - start_row), col + (end_col - start_col)),
		    detail::TextColor<E,BlendFun>(text_color,back_color,blend));
}

#endif // draw_text_h
