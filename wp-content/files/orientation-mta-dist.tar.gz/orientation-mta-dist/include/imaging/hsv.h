/**
 * \file    hsv.h
 * \brief   hsv colorspace structures
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivllib_hsv_h
#define ivllib_hsv_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>

namespace ivllib 
{
  /** \addtogroup color */
  /*@{*/

  /**
   * Pixels in the HSV color space
   */
  template <typename T>
  struct HSV
  {    
    typedef T channel_type; ///< type of the components
	
    channel_type hue;        ///< h component
    channel_type saturation; ///< s component
    channel_type value;      ///< v component

    /// Black value in HSV
    HSV()
      : hue(0),saturation(0),value(0)
    {
    }
	
    /// Construction from the channels values
    HSV(channel_type ahue,
	channel_type asat,
	channel_type aval)
      : hue(ahue),
	saturation(asat),
	value(aval)
    {
    }
  };

  /**
   * Eight bits HSV pixels
   *
   * The three components are in the range 0-255.
   * H ranges from red (0), to green (85), to blue (170), 
   * and then back to red in a modular way.
   * S ranges from achromatic (0) to fully saturated (255).
   * V range from dark (0) to bright (255).
   */
  typedef HSV<unsigned char> HSV8;

  // pixel conversions

  /**
   * Conversion from gray to HSV (8 bits)
   *
   * V is set to the graylevel
   * H and S are set to 0.
   */
  template <>
  struct PixelConversion<Gray8,HSV8>
    : public std::unary_function<Gray8,HSV8>
  {
    /// conversiona
    HSV8 operator()(Gray8 p) const
    {
      return HSV8(0,0,p);
    }
  };

  /**
   * HSV to RGB colorspace conversion
   *
   * conversion of 8-bits HSV pixels to 8-bits RGB values.
   *
   * \f[ H_i = \frac{H*6}{256} \mbox{ mod } 6 \f]
   * \f[ f = 6*H - H_i * 256 \f]
   * \f[ p = \frac{V * (255 - S)}{255} \f]
   * \f[ q = \frac{V * (255 \times 256 - f*S)}{255 \times 256} \f]
   * \f[ t = \frac{V * (255 \times 256 - (256-f)*S)}{255 \times 256} \f]
   * \f[
   *   (R,G,B) = 
   *   \left\{ \begin{array}{cl}
   *     (V,t,p) & \mbox{if } H_i = 0 \\
   *     (q,V,p) & \mbox{if } H_i = 1 \\
   *     (p,V,t) & \mbox{if } H_i = 2 \\
   *     (p,q,V) & \mbox{if } H_i = 3 \\
   *     (t,p,V) & \mbox{if } H_i = 4 \\
   *     (V,p,q) & \mbox{if } H_i = 5
   *   \end{array} \right.
   * \f]
   */
  template <>
  struct PixelConversion<HSV8,RGB8>
    : public std::unary_function<HSV8,RGB8>
  {
    /// conversiona
    RGB8 operator()(const HSV8 p) const
    {
      int hi = ((p.hue * 6) >> 8) % 6;
      int f =  6*p.hue - (hi << 8);
      int r = (p.value * (255 - p.saturation)) / 255;
      int q = (p.value * (255*256 - f*p.saturation)) / (255*256);
      int t = (p.value * (255*256 - (256 - f)*p.saturation)) / (255*256);

      if (hi == 0)
	return RGB8(p.value,t,r);
      else if (hi == 1)
	return RGB8(q,p.value,r);
      else if (hi == 2)
	return RGB8(r,p.value,t);
      else if (hi == 3)
	return RGB8(r,q,p.value);
      else if (hi == 4)
	return RGB8(t,r,p.value);

      return RGB8(p.value,r,q);
    }
  };

  /**
   * RGB to HSV colorspace conversion
   *
   * conversion of 8-bits RGB pixels to 8-bits HSV values.
   *
   * \f[ V = \max \left\{ R,G,B \right\} \f]
   * \f[ m = \min \left\{ R,G,B \right\} \f]
   * \f[
   * S = \left\{ \begin{array}{cl} 
   *   0 & \mbox{if } V = 0 \\
   *   255 \frac{V-m}{V} \mbox{if } V > 0
   * \end{array} \right.
   * \f]
   * \f[
   * H =  \left\{ \begin{array}{cl}
   *   0 & \mbox{if } V = m \\
   *   \frac{G-B}{V-m} \mbox{ mod } 256 & \mbox{if } R = V \neq m \\
   *   \left(\frac{B-R}{V-m} + \frac{256}{3} \right) 
   *      \mbox{ mod } 256 & \mbox{if } G = V \neq m \\
   *   \left(\frac{R-G}{V-m} + \frac{256}{3} \right) 
   *      \mbox{ mod } 256 & \mbox{if } B = V \neq m
   * \end{array} \right.
   * \f]
   */
  template <>
  struct PixelConversion<RGB8,HSV8>
    : public std::unary_function<RGB8,HSV8>
  {
    /// conversiona
    HSV8 operator()(const RGB8& p) const
    {
      int max = p.red;
      int min = p.red;

      if (p.green > p.blue) {
	if (p.green > max)
	  max = p.green;
	if (p.blue < min)
	  min = p.blue;
      } else {
	if (p.green < min)
	  min = p.green;
	if (p.blue > max)
	  max = p.blue;
      }

      int delta = max - min;

      if (delta == 0)
	return HSV8(0,0,max);
      
      if (p.red == max) {
	int h = (((p.green - p.blue) << 8) / (6*delta)) & 255;
	return HSV8(h,(delta*255)/max,max);
      } else if (p.green == max) {
	int h = (((p.blue - p.red + 2 * delta) << 8) / (6*delta)) & 255;
	return HSV8(h,(delta*255)/max,max);
      } 

      int h = (((p.red - p.green + 4 * delta) << 8) / (6*delta)) & 255;
      return HSV8(h,(delta*255)/max,max);
    }
  };

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const HSV<T>& a,const HSV<T>&b)
  {
    return a.hue == b.hue && 
      a.saturation == b.saturation &&
      a.vlaue == b.value;
  }

  /// inequality
  template <typename T>
  bool operator!=(const HSV<T>& a,const HSV<T>&b)
  {
    return !(a == b);
  }

  /** lexicographical comparisons of the channels (h-s-v order)
   *
   * Warning: the hue component is modular but this
   * comparison consider only its raw value
   */
  template <typename T>
  bool operator<(const HSV<T>& a,const HSV<T>&b)
  {
    if (a.hue < b.hue)
      return true;
    if (b.hue < a.hue)
      return false;
    if (a.saturation < b.saturation)
      return true;
    if (b.saturation < a.saturation)
      return false;
    
    return a.value < b.value;
  }

  /** lexicographical comparisons of the channels (h-s-v order)
   *
   * Warning: the hue component is modular but this
   * comparison consider only its raw value
   */
  template <typename T>
  bool operator>(const HSV<T>& a,const HSV<T>&b)
  {
    return b < a;
  }

  /** lexicographical comparisons of the channels (h-s-v order)
   *
   * Warning: the hue component is modular but this
   * comparison consider only its raw value
   */
  template <typename T>
  bool operator<=(const HSV<T>& a,const HSV<T>&b)
  {
    return !(b < a);
  }

  /** lexicographical comparisons of the channels (h-s-v order)
   *
   * Warning: the hue component is modular but this
   * comparison consider only its raw value
   */
  template <typename T>
  bool operator>=(const HSV<T>& a,const HSV<T>&b)
  {
    return !(b > a);
  }

/*@}*/

} // namespace ivllib

#endif // ivllib_hsv_h
