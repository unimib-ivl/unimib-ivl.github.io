/**
 * \file    rgb.h
 * \brief   colorspace structures
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivllib_rgb_h
#define ivllib_rgb_h

#ifdef RGB
#undef RGB
#endif

#include <imaging/pixel.h>

namespace ivllib
{
  /** \addtogroup color */
  /*@{*/


  /**
   * Pixels in the RGB color space
   */
  template <typename T>
  struct RGB
  {
    typedef T channel_type; ///< type of the components
	
    channel_type red;   ///< red component
    channel_type green; ///< green component
    channel_type blue;  ///< blue component
    
    /// Black value in RGB
    RGB()
      : red(0),green(0),blue(0)
    {
    }
    
    /// Construction from the channels values
    RGB(channel_type ared,
	channel_type agreen,
	channel_type ablue)
      : red(ared),
	green(agreen),
	blue(ablue)
    {
    }
  };

  /**
   * RGB pixels with alpha channel
   */
  template <typename T,typename A>
  struct RGBA
  {
    
    typedef T channel_type; ///< type of the components
    typedef A alpha_channel_type; ///< type of the alpha channel
	

    channel_type red;   ///< red component
    channel_type green; ///< green component
    channel_type blue;  ///< blue component
    alpha_channel_type alpha; ///< alpha component

    /// Black value in RGB, alpha is 0
    RGBA()
      : red(0),green(0),blue(0),alpha(0)
    {
    }

    /// Construction from the channels values	
    RGBA(channel_type ared,
	 channel_type agreen,
	 channel_type ablue,
	 alpha_channel_type aalpha)
      : red(ared),
	green(agreen),
	blue(ablue),
	alpha(aalpha)
    {
    }
  };

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const RGB<T>& a,const RGB<T>& b)
  {
    return a.red == b.red && 
      a.green == b.green &&
      a.blue == b.blue;
  }

  /// inequality
  template <typename T>
  bool operator!=(const RGB<T>& a,const RGB<T>& b)
  {
    return !(a == b);
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T>
  bool operator<(const RGB<T>& a,const RGB<T>& b)
  {
    if (a.red < b.red)
      return true;
    if (b.red < a.red)
      return false;
    if (a.green < b.green)
      return true;
    if (b.green < a.green)
      return false;
    
    return a.blue < b.blue;
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T>
  bool operator>(const RGB<T>& a,const RGB<T>& b)
  {
    return b < a;
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T>
  bool operator<=(const RGB<T>& a,const RGB<T>& b)
  {
    return !(b < a);
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T>
  bool operator>=(const RGB<T>& a,const RGB<T>& b)
  {
    return !(b > a);
  }

  /// equality
  template <typename T,typename A>
  bool operator==(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    return a.red == b.red && 
      a.green == b.green &&
      a.blue == b.blue &&
      a.alpha == b.alpha;
  }

  /// inequality
  template <typename T,typename A>
  bool operator!=(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    return !(a == b);
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T,typename A>
  bool operator<(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    if (a.red < b.red)
      return true;
    if (b.red < a.red)
      return false;
    if (a.green < b.green)
      return true;
    if (b.green < a.green)
      return false;
    if (a.blue < b.blue)
      return true;
    if (b.blue < a.blue)
      return false;

    return a.alpha < b.alpha;
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T,typename A>
  bool operator>(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    return b < a;
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T,typename A>
  bool operator<=(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    return !(b < a);
  }

  /// lexicographical comparisons of the channels (r-g-b order)
  template <typename T,typename A>
  bool operator>=(const RGBA<T,A>& a,const RGBA<T,A>& b)
  {
    return !(b > a);
  }
  
  // Type definitions

  /**
   * Eight bits rgb pixel
   *
   * Component are in the range 0-255
   */
  typedef RGB<unsigned char> RGB8;

  /**
   * Eight bits rgb pixel with alpha channel
   *
   * Component (included alpha) are in the range 0-255
   */
  typedef RGBA<unsigned char,unsigned char> RGBA8;


  // Conversions

  /**
   * Conversion from gray to RGB (8 bits)
   *
   * The three components are set to the
   * input graylevel.
   */
  template<typename T>
  struct PixelConversion<T,RGB<T> >
    : public std::unary_function<RGB<T>,T>
  {
    /// conversion
    RGB<T> operator()(T x) const
    {
      return RGB<T>(x,x,x);
    }
  };

  /**
   * Conversion from RGB to RGBA (8 bits)
   *
   * The three color components are copied and
   * alpha is set to 255.
   */
  template<>
  struct PixelConversion<RGB8,RGBA8>
    : public std::unary_function<RGB8,RGBA8>
  {
    /// conversion
    RGBA8 operator()(const RGB8& p) const
    {
      return RGBA8(p.red,p.green,p.blue,255);
    }
  };

  /**
   * Conversion from grayscale to RGBA (8 bits)
   *
   * The three color components are set to the input
   * grayscale and alpha is set to 255.
   */
  template<>
  struct PixelConversion<Gray8,RGBA8>
    : public std::unary_function<Gray8,RGBA8>
  {
    /// conversion
    RGBA8 operator()(const Gray8& p) const
    {
      return RGBA8(p,p,p,255);
    }
  };

  // blending
  
  /**
   * Specialization of Blend for RGB pixels
   */
  template <typename T>
  struct Blend<RGB<T> >
  {
    /// blend two pixels
    RGB<T> operator()(const RGB<T>& a,
		      const RGB<T>& b,
		      double f) const
    {
      return RGB<T>(static_cast<T>(a.red * f + b.red * (1-f)),
		    static_cast<T>(a.green * f + b.green * (1-f)),
		    static_cast<T>(a.blue * f + b.blue * (1-f)));
    }
  };  

  /**
   * Specialization of Blend for RGBA pixels
   */
  template <typename T,typename A>
  struct Blend<RGBA<T,A> >
  {
    /// blend two pixels
    RGBA<T,A> operator()(const RGBA<T,A>& a,
			 const RGBA<T,A>& b,
			 double f) const
    {
      return RGBA<T,A>(static_cast<T>(a.red   * f + b.red   * (1-f)),
		       static_cast<T>(a.green * f + b.green * (1-f)),
		       static_cast<T>(a.blue  * f + b.blue  * (1-f)),
		       static_cast<A>(a.alpha * f + b.alpha * (1-f)));
    }
  };  

  /**
   * Luminance of a RGB pixel (8 bits)
   *
   * \f[ l = 0.299 \times r + 0.587 \times g 0.114 \times b \f]
   *
   * \param p input RGB pixel
   * \return the luminance of p
   */
  inline unsigned char luminance(const RGB8& p)
  {
    // fixed point computation
    return (19595 * p.red + 38470 * p.green +  7471 * p.blue) >> 16;
  }

  /**
   * Luminance of a RGBA pixel (8 bits)
   *
   * \f[ l = (0.299 \times r + 0.587 \times g 0.114 \times b) \frac{\alpha}{255} \f]
   *
   * \param p input RGB pixel
   * \return the luminance of p
   */
  inline unsigned char luminance(const RGBA8& p)
  {
    // fixed point computation
    return ((9836 * p.red + 19310 * p.green +  3751 * p.blue) * p.alpha) >> 23;
  }

  /*@}*/

} // namespace ivllib

#endif // ivllib_rgb_h
