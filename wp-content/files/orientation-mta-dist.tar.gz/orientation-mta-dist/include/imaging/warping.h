/**
 * \file    warping.h
 * \brief   Functions for the management of flows and warping
 */
#ifndef warping_h
#define warping_h

#include <ivl_matrix.h>
#include <numerical/vector2.h>
#include <imaging/pixel.h>
#include <cmath> // modf
#include <cassert>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  /**
   * Warp a matrix according to the given flow.
   *
   * Compute a new matrix whose content is taken from the input
   * matrix. The relative position of output pixels with respect to
   * input pixels is determined by a flow.  The output pixel of
   * coordinates <tt>(i,j)</tt> corresponds to the input pixel of
   * coordinates:
   * \f[
   * \left( \begin{array}{c} j' \\ i'\end{array} \right) = 
   * \left( \begin{array}{c} j \\ i \end{array} \right) - v(i,j),
   * \f]
   * where <tt>v(i,j)</tt> is the 2D vector of the flow at the
   * coordinates <tt>(i,j)</tt>.
   * 
   * The template arguments must adhere to the following constraints:
   * - \c Blend<T> must be defined;
   * - an assignement from \c T to \c V must be defined;
   * - \c U must be <tt>float</tt>, <tt>double</tt>, or <tt>long double</tt>.
   *
   * \param in input matrix
   * \param flow input flow
   * \param out ouput matrix
   *
   * \pre in.rows() > 1
   * \pre in.columns() > 1
   * \pre in.rows() == flow.rows()
   * \pre in.columns() == flow.columns()
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename V>
  void warp(const Matrix<T>& in,
	    const Matrix<Vector2<U> >& flow,
	    Matrix<V>& out);

  /**
   * Warp a matrix according to the given flow.
   *
   * Compute a new matrix whose content is taken from the input
   * matrix. The relative position of output pixels with respect to
   * input pixels is determined by a flow.  The output pixel of
   * coordinates <tt>(i,j)</tt> corresponds to the input pixel of
   * coordinates:
   * \f[
   * \left( \begin{array}{c} j' \\ i'\end{array} \right) = 
   * \left( \begin{array}{c} j \\ i \end{array} \right) - v(i,j),
   * \f]
   * where <tt>v(i,j)</tt> is the 2D vector of the flow at the
   * coordinates <tt>(i,j)</tt>.
   * 
   * The template arguments must adhere to the following constraints:
   * - an assignement from \c T to \c V must be defined;
   * - \c U must be <tt>float</tt>, <tt>double</tt>, or <tt>long double</tt>;
   * - \c BlendFun must be a valid blending functor for the type \c T.
   *
   * \param in input matrix
   * \param flow input flow
   * \param out ouput matrix
   * \param blend blending functor
   *
   * \pre in.rows() > 1
   * \pre in.columns() > 1
   * \pre in.rows() == flow.rows()
   * \pre in.columns() == flow.columns()
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename V,typename BlendFun>
  void warp(const Matrix<T>& in,
	    const Matrix<Vector2<U> >& flow,
	    Matrix<V>& out,
	    BlendFun blend);

  /**
   * Compute the inverse of the given flow.
   *
   * For instance, if \p in_flow is used to map an image F into an
   * image G, then \p out_flow may be used to map G into F.  Both \c T
   * and \c U must be floating point types.
   *
   * \param in_flow input flow
   * \param out_flow output flow
   *
   * \pre in_flow.rows() > 1
   * \pre in_flow.columns() > 1
   * \post out_flow.rows() == in_flow.rows()
   * \post out_flow.columns() == in_flow.columns()
   */
  template <typename T,typename U>
  void invert_flow(const Matrix<Vector2<T> >& in_flow,
		   Matrix<Vector2<U> >& out_flow);

  //-- Implementation ----------------------------------------------------

  template <typename T,typename U,typename V>
  void warp(const Matrix<T>& in,
	    const Matrix<Vector2<U> >& flow,
	    Matrix<V>& out)
  {
    warp(in,flow,out,Blend<T>());
  }

  //----------------------------------------------------------------------

  template <typename T,typename U,typename V,typename BlendFun>
  void warp(const Matrix<T>& in,
	    const Matrix<Vector2<U> >& flow,
	    Matrix<V>& out,
	    BlendFun blend)
  {
    assert( in.rows() > 1 );
    assert( in.columns() > 1 );

    assert( in.rows() == flow.rows() );
    assert( in.columns() == flow.columns() );

    typedef typename Matrix<T>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    Matrix<V> res(n,m);

    // Use inverse mapping: for each output pixel ...
    for (size_type i = 0; i < n; ++i) {
      for (size_type j = 0; j < m; ++j) {

	// compute the corresponding row coordinate in the input
	// matrix.
	size_type ii; // integer part of the row coordinate
	U ifr; // fractional part of the row coordinate ( 0 <= ifr < 1 )
	U new_i = i - flow[i][j].y; // new_i = ii + ifr

	if (new_i <= 0) {
	  // Outside the input matrix. Consider a pixel on the border.
	  ii = 0;
	  ifr = 1.0;
	} else if (new_i >= n-1) {
	  // Outside the input matrix. Consider a pixel on the border.
	  ii = n-2;
	  ifr = 0.0;
	} else {
	  // Inside the input matrix.
	  U id;
	  ifr = 1 - std::modf(new_i, &id);
	  ii = static_cast<size_type>(id);
	}

	// compute the corresponding row coordinate in the input
	// matrix.
	size_type jj; // integer part of the row coordinate
	U jfr; // fractional part of the row coordinate ( 0 <= jfr < 1 )
	U new_j = j - flow[i][j].x; // new_j = jj + jfr

	if (new_j <= 0) {
	  // Outside the input matrix. Consider a pixel on the border.
	  jj = 0;
	  jfr = 1.0;
	} else if (new_j >= m-1) {
	  // Outside the input matrix. Consider a pixel on the border.
	  jj = m-2;
	  jfr = 0.0;
	} else {
	  // Inside the input matrix.
	  U jd;
	  jfr = 1 - std::modf(new_j, &jd);
	  jj = static_cast<size_type>(jd);
	}

	// use bilinear interpolation to compute the value to assign
	// to the current pixel.
	res[i][j] = blend(blend(in[ii][jj],in[ii + 1][jj],ifr),
			  blend(in[ii][jj + 1],in[ii + 1][jj + 1],ifr),
			  jfr);
      }
    }

    // commit
    out.swap(res);
  }

  //----------------------------------------------------------------------

  /** \cond detail */
  namespace detail
  {
    // helper functors used by invert_flow

    template <typename T>
    struct WarpOppositeVector
    {
      Vector2<T> operator()(const Vector2<T>& v) const
      {
	return Vector2<T>(-v.x,-v.y);
      }
    };

    template <typename T>
    struct WarpBlendVector
    {
      Vector2<T> operator()(const Vector2<T>& a,
			    const Vector2<T>& b,
			    double f) const
      {
	return Vector2<T>(a.x*f + b.x*(1-f),
			  a.y*f + b.y*(1-f));
      }
    };
  }
  /** \endcond */

  //----------------------------------------------------------------------

  template <typename T,typename U>
  void invert_flow(const Matrix<Vector2<T> >& in_flow,
		   Matrix<Vector2<U> >& out_flow)
  {
    assert( in_flow.rows() > 1 );
    assert( in_flow.columns() > 1 );
    
    Matrix<Vector2<T> > opp;
    mat_transform(in_flow,opp,detail::WarpOppositeVector<T>());
    
    warp(opp,opp,out_flow,detail::WarpBlendVector<T>());
  }

  /*@}*/
  
} // namespace ivllib

#endif // warping_h
