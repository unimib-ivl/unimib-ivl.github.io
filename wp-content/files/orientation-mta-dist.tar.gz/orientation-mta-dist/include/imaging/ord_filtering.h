/**
 * \file    ord_filtering.h
 * \brief   rank filters: erosion, dilation, median...
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ord_filtering_h
#define ord_filtering_h

//--- Headers --------------------------------------------------------

#include <cstddef>         // std::size_t
#include <algorithm>       // std::min_element
#include <functional>      // std::less
#include <cassert>         // assert
#include <iterator>        // std::iterator_traits
#include <ivl_matrix.h>
#include <ivl_vector.h>    // used as a temporary buffer
#include <mat_algorithm.h> // mat_copy_box, mat_copy, Box
#include <imaging/pixel.h> // in the definition of optimized median



namespace ivllib
{
  /** \cond detail */
  namespace detail
  {
    template <typename RaIter1,
	      typename RaIter2,
	      typename Cmp>
    RaIter2 min_filter_1d(RaIter1 from,
			  RaIter1 to,
			  std::size_t k,
			  RaIter2 where,
			  Cmp cmp)
    {
      assert( k > 0 );
      assert( k <= static_cast<std::size_t>(to - from) );

      std::size_t m = (k-1)/2;
      
      RaIter1 beg = from;
      RaIter1 end = from + m;
      RaIter1 cur = std::min_element(beg,end,cmp);
      RaIter1 stop = beg + k;
      while (end != stop) {
	if (!cmp(*cur,*end))
	  cur = end;
	*where = *cur;
	++where;
	++end;
      }
      
      while (end != to) {
	if (!cmp(*cur,*end))
	  cur = end;
	else if (cur == beg)
	  cur = std::min_element(beg+1,end+1,cmp);
	*where = *cur;
	++beg;
	++end;
	++where;
      }
      
      stop = to - (k - m);
      while (beg != stop) {
	if (cur == beg)
	  cur = std::min_element(beg+1,to,cmp);
	*where = *cur;
	++beg;
	++where;
      }

      return where;
    }


    //------------------------------------------------------------------


    // used by median9
    template <typename T, typename Less>
    struct Sort2
    {
      Less cmp;
      
      Sort2(Less less)
	: cmp(less)
      {
      }

      void operator()(T& a, T& b) const
      {
	if (cmp(b, a))
	  std::swap(a, b);
      }
    };


    //------------------------------------------------------------------


    // used by median3x3
    // Formula from:
    // XILINX XCELL magazine, vol. 23 by John L. Smith
    template <typename RaIter, typename Less>
    typename std::iterator_traits<RaIter>::value_type
    median9(RaIter p, Less less)
    {
      typedef std::iterator_traits<RaIter> traits;
      Sort2<typename traits::value_type, Less> sort2(less);
      
      sort2(p[1], p[2]);
      sort2(p[4], p[5]);
      sort2(p[7], p[8]);
      sort2(p[0], p[1]);
      sort2(p[3], p[4]);
      sort2(p[6], p[7]);
      sort2(p[1], p[2]);
      sort2(p[4], p[5]);
      sort2(p[7], p[8]);
      sort2(p[0], p[3]);
      sort2(p[5], p[8]);
      sort2(p[4], p[7]);
      sort2(p[3], p[6]);
      sort2(p[1], p[4]);
      sort2(p[2], p[5]);
      sort2(p[4], p[7]);
      sort2(p[4], p[2]);
      sort2(p[6], p[4]);
      sort2(p[4], p[2]);

      return p[4];
    }


    //------------------------------------------------------------------


    // Perform out of bounds checks: used to treat the outer frame of
    // the image.
    template <typename T, typename U, typename Less>
    void checked_median_box(const Matrix<T>& in,
			    Box bb,
			    typename Matrix<T>::size_type frows,
			    typename Matrix<T>::size_type fcols,
			    Matrix<U>& out,
			    Less less)
    {
      assert( in.rows() == out.rows() );
      assert( in.columns() == out.columns() );
      assert( frows > 0 );
      assert( fcols > 0 );
      assert( frows % 2 == 1 );
      assert( fcols % 2 == 1 );

      typedef typename Matrix<T>::size_type size_type;

      size_type n = in.rows();
      size_type m = in.columns();
      
      size_type nr = (frows - 1) / 2;
      size_type mr = (fcols - 1) / 2;

      Vector<T> buffer(frows*fcols);

      for (size_type i = bb.top(); i != bb.bottom(); i++) {
	for (size_type j = bb.left(); j != bb.right(); j++) {
	  size_type t = i < nr ? 0 : i - nr;
	  size_type b = i + nr < n ? i + nr + 1 : n;
	  size_type l = j < mr ? 0 : j - mr;
	  size_type r = j + mr < m ? j + mr + 1 : m;
	
	  typename Vector<T>::iterator beg = buffer.begin();
	  typename Vector<T>::iterator end = beg;
	  for (size_type k = t; k != b; k ++)
	    end = std::copy(in.row_begin(k) + l,
			    in.row_begin(k) + r,
			    end);

	  assert( beg != end );
	  
	  size_type mindex = ((end - beg) - 1) / 2;
	  std::nth_element(beg, beg + mindex, end);
	  out[i][j] = *(beg + mindex);
	}
      }
    }


    //------------------------------------------------------------------


    // fast median calling median9
    template <typename T, typename U, typename Less>
    void median3x3(const Matrix<T>& in,
		   Matrix<U>& out,
		   Less less)
    {
      typedef typename Matrix<T>::size_type size_type;
      
      size_type n = in.rows();
      size_type m = in.columns();
      
      Matrix<U> result(n, m);

      if (n < 1 || m < 1) {
	out.swap(result);
	return;
      }

      // compute the outer frame
      checked_median_box(in, Box(0, 0, 1, m), 3, 3, result, less);
      checked_median_box(in, Box(n - 1, 0, n, m), 3, 3, result, less);
      checked_median_box(in, Box(0, 0, n, 1), 3, 3, result, less);
      checked_median_box(in, Box(0, m - 1, n, m), 3, 3, result, less);

      Matrix<T> buffer(3, 3);

      for (size_type i = 1; i + 1< n; i++) {
	for (size_type j = 1; j + 1 < m; j++) {
	  mat_copy_box(in, Box(i - 1, j - 1, i + 2, j + 2),
		       buffer, Box(0, 0, 3, 3));
	  result[i][j] = median9(buffer.begin(), less);
	}
      }
      
      out.swap(result);
    }

    //------------------------------------------------------------------

    // Used by the gray-level specialization.  Keep and update a
    // gray-level histogram.
    class Histogram
    {
    public:
      Histogram()
      {
	std::fill_n(fine, 256, 0);
	std::fill_n(coarse, 16, 0);
      }

      Histogram(const Histogram& h)
      {
	std::copy(h.fine, h.fine + 256, fine);
	std::copy(h.coarse, h.coarse + 16, coarse);
      }
      
      void insert(int val)
      {
	assert( val >= 0 );
	assert( val < 256 );
	
	++fine[val];
	++coarse[val >> 4];
      }
      
      void remove(int val)
      {
	assert( val >= 0 );
	assert( val < 256 );
	assert( fine[val] > 0 );
	assert( coarse[val >> 4] > 0 );
	
	--fine[val];
	--coarse[val >> 4];
      }

      void add(const Histogram& h)
      {
	for (int i = 0; i < 16; i++) {
	  if (h.coarse[i] > 0) {
	    coarse[i] += h.coarse[i];
	    for (int j = i*16; j < i*16 + 16; j++)
	      fine[j] += h.fine[j];
	  }
	}
      }
      
      void sub(const Histogram& h)
      {
	for (int i = 0; i < 16; i++) {
	  if (h.coarse[i] > 0) {
	    assert( coarse[i] >= h.coarse[i] );
	    coarse[i] -= h.coarse[i];
	    for (int j = i*16; j < i*16 + 16; j++) {
	      assert( fine[j] >= h.fine[j] );
	      fine[j] -= h.fine[j];
	    }
	  }
	}
      }

      int order(int k) const
      {
	int m = 0;
	int tot = 0;
	while (m < 15) {
	  int ntot = tot + coarse[m];
	  if (ntot > k)
	    break;
	  tot = ntot;
	  ++m;
	}
      
	m *= 16;
	int stop = m + 15;
      
	while (m < stop) {
	  int ntot = tot + fine[m];
	  if (ntot > k)
	    break;
	  tot = ntot;
	  ++m;
	}
	
	return m;      
      }

    private:
      typedef unsigned int bin_type;

      bin_type fine[256];
      bin_type coarse[16];

    }; // class Histogram
    
  } // namespace detail
  /** \endcond */


  /** \addtogroup processing */
  /** @{ */
  /**
   * Erosion
   *
   * The output matrix is filled with values computed as:
   * \f[O_{i,j} = \min_{
   * \begin{array}{cc}
   *   h \in \left\{ 0, \cdots, kn-1 \right\} \\
   *   k \in \left\{ 0, \cdots, km-1 \right\}
   * \end{array} }
   * \left\{ I_{i+h-N_c,j+k-M_c} \right\},
   * \mbox{ with }
   * N_c = \left\lfloor \frac{kn-1}{2} \right\rfloor,
   * M_c = \left\lfloor \frac{km-1}{2} \right\rfloor ,\f]
   * where \f$ I \f$ and \f$ O \f$ are the input and the output matrix respectively.
   * The minimum is determined according to the order predicate \p cmp.
   * Note that the terms in the expression for which the indices are outside the boundaries of
   * the input image are not actually compared.
   * Values of type \p T must be assignable to variables of type \p U.
   * The functor \p cmp must be callable with two values od type \p T and
   * the result must be convertible to \p bool.
   *
   * \param in input matrix
   * \param kn number of rows of the rectangular structural element
   * \param km number of columns of the rectangular structural element
   * \param out output matrix
   * \param cmp order predicate
   *
   * \pre kn > 0
   * \pre km > 0
   * \pre kn <= in.rows()
   * \pre km <= in.columns()
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename Cmp>
  void erosion(const Matrix<T>& in,
	       typename Matrix<T>::size_type kn,
	       typename Matrix<T>::size_type km,
	       Matrix<U>& out,
	       Cmp cmp)
  {
    assert( kn > 0 );
    assert( km > 0 );
    assert( kn <= in.rows() );
    assert( km <= in.columns() );

    typedef typename Matrix<T>::size_type size_type;
    size_type n = in.rows();
    size_type m = in.columns();

    Matrix<T> tmp(n,m);
    
    if (km > 1) {
      for (size_type i = 0; i < n; i++)
	detail::min_filter_1d(in.row_begin(i),
			      in.row_end(i),
			      km,
			      tmp.row_begin(i),
			      cmp);
    } else {
      std::copy(in.begin(),in.end(),tmp.begin());
    }

    Matrix<U> result(n,m);

    if (kn > 1) {
      for (size_type i = 0; i < m; i++)
	detail::min_filter_1d(tmp.column_begin(i),
			      tmp.column_end(i),
			      kn,
			      result.column_begin(i),
			      cmp);
    } else {
      std::copy(tmp.begin(),tmp.end(),result.begin());
    }

    out.swap(result);
  }


  /**
   * Erosion
   *
   * Call the more general erosion function with
   * <tt> std::less<T>() </tt> as predicate.
   * \p operator< must be defined for type \p T.
   */
  template <typename T,typename U>
  void erosion(const Matrix<T>& in,
	       typename Matrix<T>::size_type kn,
	       typename Matrix<T>::size_type km,
	       Matrix<U>& out)
  {
    erosion(in,kn,km,out,std::less<T>());
  }


  /**
   * Dilation
   *
   * Call the general erosion function with
   * <tt> std::greater<T>() </tt> as predicate.
   * \p operator> must be defined for type \p T.
   */
  template <typename T,typename U>
  void dilation(const Matrix<T>& in,
		typename Matrix<T>::size_type kn,
		typename Matrix<T>::size_type km,
		Matrix<U>& out)
  {
    erosion(in,kn,km,out,std::greater<T>());
  }
    

  /**
   * Median filter
   *
   * The output matrix is filled with values computed as:
   * \f[O_{i,j} = \mathop{median}_{
   * \begin{array}{cc}
   *   h \in \left\{ 0, \cdots, frows-1 \right\} \\
   *   k \in \left\{ 0, \cdots, fcols-1 \right\}
   * \end{array} }
   * \left\{ I_{i+h-N_c,j+k-M_c} \right\},
   * \mbox{ with }
   * N_c = \left\lfloor \frac{frows-1}{2} \right\rfloor,
   * M_c = \left\lfloor \frac{fcols-1}{2} \right\rfloor ,\f]
   * where \f$ I \f$ and \f$ O \f$ are the input and the output matrix respectively.
   * The median is determined according to the order predicate \p less.
   * Note that the terms in the expression for which the indices are outside the boundaries of
   * the input image are not actually compared.
   * Values of type \p T must be assignable to variables of type \p U.
   * The functor \p less must be callable with two values od type \p T and
   * the result must be convertible to \p bool.
   *
   * \param in input matrix
   * \param frows number of rows of the rectangular structural element
   * \param fcols number of columns of the rectangular structural element
   * \param out output matrix
   * \param less order predicate
   *
   * \pre frows > 0
   * \pre fcols > 0
   * \pre frows % 2 == 1
   * \pre fcols % 2 == 1
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,
	    typename U,
	    typename Less>
  void median_filter(const Matrix<T>& in,
		     typename Matrix<T>::size_type frows,
		     typename Matrix<T>::size_type fcols,
		     Matrix<U>& out,
		     Less less)
  {
    assert( frows > 0 );
    assert( fcols > 0 );

    // only odd-sized kernels are allowed
    assert( frows % 2 == 1 );
    assert( fcols % 2 == 1 );

    if (frows == 1 && fcols == 1) {
      mat_copy(in, out);
      return;
    }

    // call the optimized 3x3 version
    if (frows == 3 && fcols == 3) {
      detail::median3x3(in, out, less);
      return;
    }
    
    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();
    
    Matrix<U> result(n, m);

    if (n < 1 || m < 1) {
      out.swap(result);
      return;
    }

    // reduce the size of the kernel, if bigger than the image
    if (frows > n)
      frows = (n % 2 == 0 ? n - 1 : n);
    if (fcols > m)
      fcols = (m % 2 == 0 ? m - 1 : m);

    size_type nr = (frows - 1) / 2;
    size_type mr = (fcols - 1) / 2;

    
    // compute the outer frame
    detail::checked_median_box(in, Box(0, 0, nr, m),
			       frows, fcols, result, less);
    detail::checked_median_box(in, Box(n - nr, 0, n, m),
			       frows, fcols, result, less);
    detail::checked_median_box(in, Box(0, 0, n, mr),
			       frows, fcols, result, less);
    detail::checked_median_box(in, Box(0, m - mr, n, m),
			       frows, fcols, result, less);

    size_type mindex = (frows*fcols - 1) / 2;

    Matrix<T> helper(frows, fcols);
    
    for (size_type i = nr; i + nr < n; i++) {
      for (size_type j = mr; j + mr < m; j++) {
	mat_copy_box(in, Box(i - nr,
			     j - mr,
			     i + nr + 1,
			     j + mr + 1),
		     helper,
		     Box(0, 0, frows, fcols));
	
	typename Matrix<T>::iterator
	  middle = helper.begin() + mindex;
	
	std::nth_element(helper.begin(),
			 middle,
			 helper.end(),
			 less);
	result[i][j] = *(helper.begin() + mindex);
      }
    }
    
    out.swap(result);
  }


  /**
   * Median filter
   *
   * Call the more general median filter function with <tt>
   * std::less<T>() </tt> as predicate.  \p operator< must be defined
   * for type \p T.
   */
  template <typename T,
	    typename U>
  void median_filter(const Matrix<T>& in,
		     typename Matrix<T>::size_type frows,
		     typename Matrix<T>::size_type fcols,
		     Matrix<U>& out)
  {
    median_filter(in, frows, fcols, out, std::less<T>());
  }

  
  /**
   * Median filter
   *
   * Optimized version for \p ivllib::Gray8 images, assuming default
   * order. Values of type \p Gray8 must be convertible to \p U.
   *
   * The algorithm is based on "Median Filtering in Constant Time," by
   * Simon Perreault and Patrick Heber, IEEE Transactions on Image
   * Processing, Vol. 16, No. 9.
   *
   * The algorithm has (almost) constant complexity with respect to
   * kernel size.
   *
   * \param in input matrix
   * \param frows number of rows of the rectangular structural element
   * \param fcols number of columns of the rectangular structural element
   * \param out output matrix
   *
   * \pre frows > 0
   * \pre fcols > 0
   * \pre frows % 2 == 1
   * \pre fcols % 2 == 1
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
    template <typename U>
  void median_filter(const Matrix<Gray8>& in,
		     Matrix<Gray8>::size_type frows,
		     Matrix<Gray8>::size_type fcols,
		     Matrix<U>& out)
  {
    // note: corner cases, such as very small images are correctly
    // computed by the main loop, without any special treatment.

    assert( frows > 0 );
    assert( fcols > 0 );

    // only odd-sized kernels are allowed
    assert( frows % 2 == 1 );
    assert( fcols % 2 == 1 );

    if (frows == 1 && fcols == 1) {
      mat_copy(in, out);
      return;
    }

    // call the optimized 3x3 version
    if (frows == 3 && fcols == 3) {
      detail::median3x3(in, out, std::less<Gray8>());
      return;
    }

    typedef Matrix<Gray8>::size_type size_type;

    size_type n = in.rows();
    size_type m = in.columns();

    size_type nr = (frows - 1) / 2;
    size_type mr = (fcols - 1) / 2;

    Matrix<U> result(n, m);

    // initialize the columns distributions
    Vector<detail::Histogram> columns(m, detail::Histogram());
    size_type szcol = std::min(n, nr);
    for (size_type i = 0; i < szcol; i++)
      for (size_type j = 0; j < m; j++)
	columns[j].insert(in[i][j]);

    // main loop
    for (size_type i = 0; i < n; i++) {
      size_type newrow = i + nr;
      // update the column distributions
      if (newrow < n) {
	++szcol;
	for (size_type j = 0; j < m; j++)
	  columns[j].insert(in[i + nr][j]);
      }
      if (i > nr) {
	--szcol;
	size_type oldrow = i - nr - 1;
	for (size_type j = 0; j < m; j++)
	  columns[j].remove(in[oldrow][j]);
      }

      // initialize the kernel distribution
      size_type szrow = std::min(mr, m);
      detail::Histogram kernel;
      for (size_type j = 0; j < szrow; j++)
	kernel.add(columns[j]);

      size_type sz = szcol*szrow;
      
      // scan the row
      for (size_type j = 0; j < m; j++) {
	// update the kernel
	if (j + mr < m) {
	  kernel.add(columns[j + mr]);
	  sz += szcol;
	}
	if (j > mr) {
	  kernel.sub(columns[j - mr - 1]);
	  sz -= szcol;
	}
	
	// compute the output value
	result[i][j] = kernel.order((sz - 1)/2);
      }
    }
    
    // commit
    out.swap(result);
  }

  /** @} */

} // namespace ivllib

#endif
