/**
 * \file    ppm_io.h
 * \brief   io routines for the ppm graphic format
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ppm_io_h
#define ppm_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/


  /**
   * Load a portable pixmap file (ppm).
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_ppm(const std::string& filename,
		Matrix<RGB8>& out);
  
  /**
   * Load a portable pixmap file (ppm).
   *
   * Alpha channel is set to 255.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_ppm(const std::string& filename,
		Matrix<RGBA8>& out);

  /**
   * Save a portable pixmap file (ppm).
   *
   * if \p binary is false, pixels are encoded as text,
   * otherwise a binary representation is used.
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param binary binary/text flag
   *
   * \throw ImageFileError
   */ 
  void save_ppm(const std::string& filename,
		const Matrix<RGB8>& in,
		bool binary = true);

  /**
   * Save a portable pixmap file (ppm).
   *
   * if \p binary is false, pixels are encoded as text,
   * otherwise a binary representation is used.
   * For each pixel, a rgb triplet is saved to file
   * with the three components equal to the graylevel.
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param binary binary/text flag
   *
   * \throw ImageFileError
   */ 
  void save_ppm(const std::string& filename,
		const Matrix<Gray8>& in,
		bool binary = true);
  
  /*@}*/
}

#endif
