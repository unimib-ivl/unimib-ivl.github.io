/**
 * \file    hough_transform.h
 * \brief   Hough transform
 */

#ifndef hough_transform_h
#define hough_transform_h


#include <ivl_matrix.h>
#include <ivl_vector.h>
#include <numerical/vector2.h>
#include <imaging/ord_filtering.h>
#include <cstddef> // std::size_t
#include <vector>
#include <cmath> // sin, cos


namespace ivllib
{

  /** \cond detail */
  namespace detail
  {

    // default predicate
    template <typename T>
    struct default_hough_predicate
    {
      bool operator()(const T& t) const
      {
	return t;
      }
    };


    // structure used for temporary computation
    struct hough_point
    {
      hough_point(double r, double a, std::size_t c)
	: radius(r),
	  angle(a),
	  count(c)
      {
      }

      double radius;
      double angle;
      std::size_t count;

      bool operator<(const hough_point& hp) const
      {
	return count < hp.count;
      }
    };
    
  } // namespace detail
  /** \endcond */


  /** \addtogroup processing */
  /*@{*/

  /**
   * Compute the Hough transform.
   *
   * Compute the Hough transform of \a in.  The result \a out is the
   * accumulator matrix in the parameter space.  Each point of the
   * matrix represents a pair of parameters (angle and radius)
   * corresponding to the line <tt> radius = x*cos(angle) +
   * y*sin(angle) </tt>.  Angles are sampled according to \a
   * angle_sampling and the radius is samples accordinf to \a
   * radius_sampling.  The size of \a out is determined by the
   * sampling.  The points of \a in taken into account are those for
   * which the functor \a pred is true.  Those points are passed to
   * the \a hough_transform_points function after being shifted by the
   * center of the matrix; the \a max_radius is half the diagonal of
   * the input matrix.
   *   
   * \param in input matrix
   * \param radius_sampling sampling of the radius
   * \param angle_sampling sampling of the angle
   * \param out output matrix
   * \param pred predicate which selects points
   *
   * \pre <tt> radius_sampling > 0 </tt>
   * \pre <tt> angle_sampling > 0 </tt>
   */
  template <typename T, typename Pred>
  void hough_transform(const Matrix<T>& in,
		       double radius_sampling,
		       double angle_sampling,
		       Matrix<std::size_t>& out,
		       Pred pred);
  
  
  /**
   * Compute the Hough transform.
   *
   * Like the more general function, using a default predicate (the
   * points selected are those which assume a true boolean value).
   *
   * \param in input matrix
   * \param radius_sampling sampling of the radius
   * \param angle_sampling sampling of the angle
   * \param out output matrix
   *
   * \pre <tt> radius_sampling > 0 </tt>
   * \pre <tt> angle_sampling > 0 </tt>
   */
  template <typename T>
  void hough_transform(const Matrix<T>& in,
		       double radius_sampling,
		       double angle_sampling,
		       Matrix<std::size_t>& out);


  /**
   * Compute the Hough transform.
   *
   * Compute the Hough transform of the points in the range (\a from,
   * \a to).  The result \a out is the accumulator matrix in the
   * parameter space.  Each point of the matrix represents a pair of
   * parameters (angle and radius) corresponding to the line <tt>
   * radius = x*cos(angle) + y*sin(angle) </tt>.  Angles are sampled
   * according to \a angle_sampling and the radius is samples
   * accordinf to \a radius_sampling.  The size of a \a out is
   * determined by the sampling.  Input points must have numerical \a
   * x and \a y attributes (Vector2, for instance).
   *
   * \param from begin of the input range
   * \param to end of the input range
   * \param radius_sampling sampling of the radius
   * \param angle_sampling sampling of the angle
   * \param max_radius maximum radius included in the transform
   * \param out output matrix
   *
   * \pre <tt> radius_sampling > 0 </tt>
   * \pre <tt> angle_sampling > 0 </tt>
   * \pre <tt> max_radius >= 0 </tt>
   *
   * \post <tt>out.rows() == 1 + floor(max_radius / radius_sampling) </tt>
   * \post <tt>out.columns() == max(1, 2.0 * pi / angle_sampling) </tt>
   */
  template <typename InIter>
  void hough_transform_points(InIter from,
			      InIter to,
			      double radius_sampling,
			      double angle_sampling,
			      double max_radius,
			      Matrix<std::size_t>& out);

  /**
   * Retrieve the lines from an Hough transform matrix.
   *
   * The elements of \a in are scanned and those exceeding the given
   * threshold are onverted into the parameters (radius, angle) of the
   * corresponding line.  The samplings of angle and radius must
   * correspond to those used to compute the transform.  The pairs of
   * parameters are copied into the range defined by \a from and \a
   * to.  The radius is copied into the \a x attribute and the angle
   * into the \a y attribute.  The points are copied from the highest
   * count to the lowest.  At the finally range may not completely
   * filled: the actual end of extracted line is returned.
   *
   * \param in input transform matrix
   * \param radius_sampling sampling of the radius
   * \param angle_sampling sampling of the angle
   * \param threshold limit which determines the lines to extract
   * \param from begin of the output range
   * \param to end of the output range
   *
   * \return the end of the actual range returned
   */
  template <typename OutIter>
  OutIter retrieve_hough_transform_lines(const Matrix<std::size_t>& in,
					 double radius_sampling,
					 double angle_sampling,
					 std::size_t threshold,
					 OutIter from,
					 OutIter to);
  /*@}*/
  
} // namespace ivllib


// Implementation


template <typename T, typename Pred>
void
ivllib::hough_transform(const ivllib::Matrix<T>& in,
			double radius_sampling,
			double angle_sampling,
			ivllib::Matrix<std::size_t>& out,
			Pred pred)
{
  typedef typename ivllib::Matrix<T>::size_type size_type;

  typedef ivllib::Vector2<int> point_type;
  std::vector<point_type> points;

  size_type n = in.rows();
  size_type m = in.columns();

  double max_radius = std::sqrt(n*n + m*m) / 2;

  for (size_type i = 0; i < n; i++)
    for (size_type j = 0; j < m; j++)
      if (pred(in[i][j]))
	points.push_back(point_type(j - m/2, i -n/2));
  
  ivllib::hough_transform_points(points.begin(),
				 points.end(),
				 radius_sampling,
				 angle_sampling,
				 max_radius,
				 out);
}


template <typename T>
void
ivllib::hough_transform(const ivllib::Matrix<T>& in,
			double radius_sampling,
			double angle_sampling,
			ivllib::Matrix<std::size_t>& out)
{
  ivllib::hough_transform(in,
			  radius_sampling,
			  angle_sampling,
			  out,
			  ivllib::detail::default_hough_predicate<T>());
}

  
template <typename InIter>
void
ivllib::hough_transform_points(InIter from,
			       InIter to,
			       double radius_sampling,
			       double angle_sampling,
			       double max_radius,
			       ivllib::Matrix<std::size_t>& out)
{
  assert( radius_sampling > 0.0 );
  assert( angle_sampling > 0.0 );
  assert( max_radius >= 0.0 );

  typedef ivllib::Matrix<std::size_t>::size_type size_type;

  const double pi = 3.1415926535897931;

  size_type n = 1 + static_cast<size_type>(max_radius / radius_sampling);
  size_type m = std::max<size_type>(1, 2.0 * pi / angle_sampling);
  
  ivllib::Vector<double> cos_table(m);
  ivllib::Vector<double> sin_table(m);

  for (size_type j = 0; j < m; j++) {
    double t = j*angle_sampling;
    cos_table[j] = std::cos(t);
    sin_table[j] = std::sin(t);
  }

  double inv_rad = 1.0 / radius_sampling;

  ivllib::Matrix<std::size_t> ret(n, m, 0);

  for( ; from != to; ++from) {
    for (size_type j = 0; j < m; j++) {
      double r = (from->x * cos_table[j]) + (from->y * sin_table[j]); 
      size_type rr = static_cast<size_type>(0.5 + r*inv_rad);
      if (rr >= 0 && rr < n)
	++ret[rr][j];
    }
  }

  // commit
  out.swap(ret);
}

template <typename OutIter>
OutIter
ivllib::retrieve_hough_transform_lines(const ivllib::Matrix<std::size_t>& in,
				       double radius_sampling,
				       double angle_sampling,
				       std::size_t threshold,
				       OutIter from,
				       OutIter to)
{
  typedef Matrix<std::size_t>::size_type size_type;
      
  size_type n = in.rows();
  size_type m = in.columns();
  
  typedef std::vector<detail::hough_point> points_type;
  points_type points;

  // find local maxima exceeding the threshold
  for (size_type i = 0; i < n; i++) {
    for (size_type j = 0; j < m; j++) {
      if (in[i][j] > threshold) {
	
	size_type left = (j > 0 ? j - 1 : m - 1);
	size_type right = (j < m - 1 ? j + 1 : 0);

	if (i != 0 && (in[i][j] <= in[i-1][left] ||
		       in[i][j] <= in[i-1][j] ||
		       in[i][j] <= in[i-1][right]))
	  continue;
	    	    
	if (in[i][j] <= in[i][left] ||
	    in[i][j] < in[i][right])
	  continue;

	if (i != n - 1 && (in[i][j] < in[i+1][left] ||
			   in[i][j] < in[i+1][j] ||
			   in[i][j] < in[i+1][right]))
	  continue;
	
	points.push_back(detail::hough_point(i*radius_sampling,
					     j*angle_sampling,
					     in[i][j]));
      }
    }    
  }

  // get the first k elements, where k == min(points.size(),
  // distance(from, to))

  std::make_heap(points.begin(), points.end());
  points_type::iterator it = points.end();

  while (from != to && it != points.begin()) {
    from->x = points.front().radius;
    from->y = points.front().angle;
    ++from;
    std::pop_heap(points.begin(), it);
    --it;
  }

  return from;
}



#endif // hough_transform_h
