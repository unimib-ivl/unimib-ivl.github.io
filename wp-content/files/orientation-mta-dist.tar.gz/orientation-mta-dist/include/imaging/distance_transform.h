/**
 * \file    distance_transform.h
 * \brief   distance transform
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef distance_transform_h
#define distance_transform_h

#include <iterator>  // iterator_traits
#include <algorithm> // fill
#include <limits>    // numeric_limits
#include <cmath>     // sqrt
#include <ivl_vector.h>
#include <ivl_matrix.h>

namespace ivllib
{
  /** \addtogroup processing */
  /** @{ */

  /** \cond detail */
  namespace detail
  {
    template <typename RaIter1,
	      typename RaIter2>
    void distance_transform_aux(RaIter1 from,
				RaIter1 to,
				RaIter2 out)
    {
      typedef typename std::iterator_traits<RaIter1>::difference_type diff_type;
      
      diff_type n = to-from;

      Vector<diff_type> v(n);
      Vector<double> z(n+1);

      
      diff_type q = 0;
      while (q < n-1 && !(from[q] < std::numeric_limits<double>::infinity()))
	++q;
      v[0] = q;
      ++q;
    
      z[0] = -std::numeric_limits<double>::infinity();
      z[1] = std::numeric_limits<double>::infinity();
      Vector<double>::size_type k = 0;
      
      while (q < n) {
	if (from[q] < std::numeric_limits<double>::infinity()) {
	  bool stop = false;
	  double s = 0.0;
	  while (!stop) {
	    s = static_cast<double>(from[q] + q*q - from[v[k]] - v[k]*v[k])/(2*(q-v[k]));
	    if (s <= z[k])
	      --k;
	    else
	      stop = true;
	  }
	  ++k;
	  v[k] = q;
	  z[k] = s;
	  z[k+1] = std::numeric_limits<double>::infinity();
	}
	++q;
      }
      k = 0;
      for (diff_type q = 0; q<n; q++) {
	while (z[k+1] < q)
	  ++k;
	out[q] = (q - v[k])*(q - v[k]) + from[v[k]];
      }
    }

    template <typename T>
    struct DefaultDistanceTrPred
    {
      bool operator()(const T& x) const
      {
        return x ? true : false;
      }
    };

  } // detail
  /** \endcond */


  /**
   * Compute the distance transform
   *
   * Compute the distance transform of \p in and put the
   * result in \p out. The transform is based on the Euclidean
   * distance. 
   * If <tt>in[i][j]</tt> is a foreground pixel (i.e.
   * <tt>pred(in[i][j])</tt> is \p true) then <tt>out[i][j]</tt>
   * is set to 0. Otherwise <tt>out[i][j]</tt> is set to the
   * distance to the nearest foreground pixel.
   *
   * \param in input matrix
   * \param out output matrix
   * \param pred functor which determines foreground pixels
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename Pred>
  void distance_transform(const Matrix<T>& in,
			  Matrix<double>& out,
			  Pred pred)
  {
    // implementation based on the paper:
    // "Distance Transforms of Sampled Functions",
    // by P.F. Felzenszwalb and D.P. Huttenlocher

    typedef typename Matrix<T>::size_type size_type;
    
    size_type n = in.rows();
    size_type m = in.columns();
    
    Vector<double> buffer(m);
    Matrix<double> tmp(n,m);
    for (size_type i = 0; i<n; i++) {
      bool any = false;
      for (size_type j = 0; j<m; j++) {
	if (pred(in[i][j])){
	  buffer[j] = 0.0;
	  any = true;
	} else {
	  buffer[j] = std::numeric_limits<double>::infinity();
	}
      }
      if (any) 
	detail::distance_transform_aux(buffer.begin(),
				       buffer.end(),
				       tmp.row_begin(i));	
      else
	std::fill(tmp.row_begin(i),
		  tmp.row_end(i),
		  std::numeric_limits<double>::infinity());
    }
      
    Matrix<double> result(n,m);
    for (size_type i = 0; i<m; i++)
      detail::distance_transform_aux(tmp.column_begin(i),
				     tmp.column_end(i),
				     result.column_begin(i));

    double (*f)(double) = std::sqrt;
    std::transform(result.begin(),
		   result.end(),
		   result.begin(),
		   f);
    
    out.swap(result);
  }

  /**
   * Compute the distance transform
   *
   * Compute the distance transform calling the more general
   * routine. Foreground pixels are detected converting input
   * pixels to \p bool. 
   * A value of type \p T must be convertible to \p bool.
   */
  template <typename T>
  void distance_transform(const Matrix<T>& in,
			  Matrix<double>& out)
  {
    distance_transform(in,out,detail::DefaultDistanceTrPred<T>());
  }

  /** @} */
} // ivllib

#endif
