/**
 * \file    hsi.h
 * \brief   ycbcr colorspace structures
 * \author  $LastChangedBy: beccaria $
 */

// sviluppato da Mirko Beccaria

#ifndef ivllib_hsi_h
#define ivllib_hsi_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <cmath>

using namespace std;

namespace ivllib
{
  /** \addtogroup color */
  /*@{*/

  /**
   * Pixels in the HSI color space
   */
  template <typename T>
  struct HSI
  {
    typedef T channel_type; ///< type of the components

    channel_type h; ///< h component
    channel_type s; ///< s component
    channel_type i; ///< i component

    /// Black value in HSI
    HSI()
      : h(0),s(0),i(0)
    {
    }

    /// Construction from the channels values
    HSI(channel_type ah,
	channel_type as,
	channel_type ai)
      : h(ah),
	s(as),
	i(ai)
    {
    }
  };

  /**
   * Eight bits HSI pixels
   *
   * The three components are in the range 0-255.
   */
  typedef HSI<unsigned char> HSI8;
  
  // pixel conversions
  
  /**
   * Conversion from gray to HSI (8 bits)
   */
  template <>
  struct PixelConversion<Gray8,HSI8>
    : public std::unary_function<Gray8,HSI8>
  {
    /// conversiona
    HSI8 operator()(Gray8 p) const
    {
      return HSI8(p,128,128);
    }
  };

  /**
   * HSI to RGB colorspace conversion
   *
   * conversion of 8-bits HSI pixels to 8-bits RGB values.
   *
   */
  template <>
  struct PixelConversion<HSI8,RGB8>
    : public std::unary_function<HSI8,RGB8>
  {
    /// conversiona
    RGB8 operator()(const HSI8& p) const
    {
      int i = p.i;
      double theta = p.h * (3.1415926535897931/128);
      
      int i2 = static_cast<int>(p.s * std::cos(theta));
      int i3 = static_cast<int>(p.s * std::sin(theta));

      int tmp = (2*i3) / 3;
      
      int r = i + i2 - tmp;
      int g = i + 2*tmp;
      int b = i - i2 - tmp;
      
      if (r < 0)
	r = 0;
      else if (r > 255)
	r = 255;

      if (g < 0)
	g = 0;
      else if (g > 255)
	g = 255;

      if (b < 0)
	b = 0;
      else if (b > 255)
	b = 255;

      return RGB8(r,g,b);
    }
  };
  
  /**
   * RGB to HSI colorspace conversion
   *
   * conversion of 8-bits RGB pixels to 8-bits HSI values.
   */
  template <>
  struct PixelConversion<RGB8,HSI8>
    : public std::unary_function<RGB8,HSI8>
  {
    /// conversiona
    HSI8 operator()(const RGB8& p) const
    {
      int r = p.red;
      int g = p.green;
      int b = p.blue;
      
      int i = ((r + g + b) * 21845) >> 16;
      

      int i2 = (r - b) >> 1;
      int i3 = (2*g - r - b) >> 2;

      if (i2 == 0) {
	if (i3 > 0)
	  return HSI8(64,i3,i);
	else
	  return HSI8(192,-i3,i);
      }
      
      double rho = std::sqrt(i2*i2 + i3*i3);

      int s = static_cast<int>(rho);
      
      double theta = std::atan(static_cast<double>(i3)/i2);
      
      int h = static_cast<int>(theta * (128/3.1415926535897931));

      if (i2 < 0)
	h += 128;

      if (h < 0)
	h += 256;
      
      return HSI8(h,s,i);
    }
  };

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const HSI<T>& a,const HSI<T>& b)
  {
    return a.h == b.h &&
      a.s == b.s &&
      a.i == b.i;
  }

  /// inequality
  template <typename T>
  bool operator!=(const HSI<T>& a,const HSI<T>& b)
  {
    return !(a == b);
  }

  /*@}*/

} // namespace ivllib

#endif // ivllib_hsi_h
