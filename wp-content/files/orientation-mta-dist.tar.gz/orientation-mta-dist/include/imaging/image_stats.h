#ifndef IMAGE_STATS_H
#define IMAGE_STATS_H

//--- Headers -----------------------------------------------------------------------------
#include "ivl_matrix.h"
#include "ivl_box.h"
#include "numerical/vector2.h"
#include "imaging/labeling.h"
#include <vector>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/


  //--- Types ----------------------------------------------------------------------------
  /**
   * image_stats is an utility functor used to compute a statistic/s
   * over a labeled image. It can be seen as a container of statistic
   * functors of the same type. The template parameter StatT is the
   * statistc functor to be applied for each label of the image. For
   * each label, a statistic functor is allocated and may be accessed
   * using the operator [].
   */
  template <typename StatT, typename CoordTypeT=std::size_t>
  struct labeling_stats
  {    
  public:    
    /**
     * @param maxLabel the maximum label value present in the image.
     */
    labeling_stats(label_type maxLabel) : mStats(maxLabel+1)
    {
    }

    /**
     * @return the i-th statistic functor
     */
    StatT& operator[](label_type i)
    {
      return mStats[i];
    }

    /**
     * @return the i-th statistic functor
     */
    const StatT& operator[](label_type i) const
    {
      return mStats[i];
    }

    /**
     * @return the number of statistic functors or, equivalently, the number of labels.
     */
    std::size_t size() const
    {
      return mStats.size();
    }
    
    /**
     * @param r row
     * @param c column
     * @param p value of the point located at (r,c)
     */
    void operator()(const CoordTypeT& r, const CoordTypeT& c, const label_type& p)
    {
      assert(p < mStats.size());
      mStats[p](r,c,p);
    }
    
  private:    
    std::vector< StatT > mStats;
  };

  //-----------------------------------------------------

  /**
   * A functor used to compute the centroid of a labeled region.
   * To be used in conjunction of labeling_stat.
   */
  template <typename CentroidCoordTypeT=std::size_t, typename CoordTypeT=std::size_t>
  struct centroid_stat
  {    
  public:        
    centroid_stat(): mCentroid(0,0), mCounter(0)
    {
    }

    /**
     * @param r row
     * @param c column
     * @param p value of the point located at (r,c)
     *
     */
    template <typename PixelTypeT>
    void operator()(const CoordTypeT& r, const CoordTypeT& c, const PixelTypeT& p)
    {
      mCentroid.x+=static_cast<CentroidCoordTypeT>(c);
      mCentroid.y+=static_cast<CentroidCoordTypeT>(r);
      mCounter++;
    }
    
    /**
     * @return the number of points of the region
     */
    std::size_t getCounter() const
    {
      return mCounter;
    }
    
    /**
     * @return the centroid of the region
     */

    Vector2<CentroidCoordTypeT> getCentroid() const
    {
      assert(mCounter!=0);
      return Vector2<CoordTypeT>(mCentroid.x/static_cast<CentroidCoordTypeT>(mCounter), 
				 mCentroid.y/static_cast<CentroidCoordTypeT>(mCounter));
    }

  private:    
    std::size_t mCounter;
    Vector2<CentroidCoordTypeT> mCentroid;
  };
  //-----------------------------------------------------
  /**
   * A functor used to count the number of points of a labeled region.
   * To be used with labeling_stat.
   */
  template <typename CoordTypeT=std::size_t>
  struct counter_stat
  {    
  public:    
    counter_stat(): mCounter(0)
    {
    }
    
    /**
     * @param r row
     * @param c column
     * @param p value of the point located at (r,c)
     */
    template <typename PixelTypeT>
    void operator()(const CoordTypeT& r, const CoordTypeT& c, const PixelTypeT& p)
    {
      mCounter++;
    }

    /**
     * @return the number of points
     */
    std::size_t getCounter() const
    {
      return mCounter;
    }

  private:    
    std::size_t mCounter;
  };

  //-----------------------------------------------------
  /**
   * A functor used to compute the bounding box of a labeled region.
   * To be used with labeling_stat.
   */
  template <typename CoordTypeT=std::size_t>
  struct bounding_box_stat
  {    
  public:
    
    bounding_box_stat(): mBox(), first(true)
    {
    }

    /**
     * @param r row
     * @param c column
     * @param p value of the point located at (r,c)
     */    
    template <typename PixelTypeT>
    void operator()(const CoordTypeT& r, const CoordTypeT& c, const PixelTypeT& p)
    {
      if (first)
	{
	  mBox=GenericBox2D<CoordTypeT>(r, c, r+1, c+1);
	  first=false;
	}
      else
	mBox=GenericBox2D<CoordTypeT>( std::min(r, mBox.top()),
				       std::min(c, mBox.left()),
				       std::max(r+1, mBox.bottom()),
				       std::max(c+1, mBox.right()) );
    }
    
    /**
     * @return the bounding box of the region
     */
    GenericBox2D<CoordTypeT> getBoundingBox() const
    {
      return mBox;
    }

  private:
    GenericBox2D<CoordTypeT> mBox;
    bool first;    
  };
  //-----------------------------------------------------


  //--- Functions -------------------------------------------------------------------------
  /**
   * compute_stat computes the statistic pStat over the labeled image
   * pImg.  The template parameter StatT is the statistic functor
   * type.
   *
   * @param pImg the input labeled image
   * @param pStat the statistic functor
   */
  template <typename PixelTypeT, 
	    typename StatT>
  void compute_stat(const Matrix< PixelTypeT >& pImg, 		    
		    StatT& pStat);

  /**
   * compute_stat computes the statistic pStat over the labeled image
   * pImg.  Only those points that satisfy the predicate pPred are
   * considered. The template parameter StatT is the statistic
   * functor type. The template parameter PredicateT is the predicate
   * type.
   *
   * @param pImg the input labeled image
   * @param pStat the statistic functor
   * @param pPred the predicate evaluated at each point
   */
  template <typename PixelTypeT, 
	    typename StatT,
	    typename PredicateT>
  void compute_stat(const Matrix< PixelTypeT >& pImg, 		    
		    StatT& pStat,
		    PredicateT pPred);
  
  /**
   * compute_stat computes the statistic pStat over the rectangular
   * region specified by pBox over the labeled image pImg.  The
   * template parameter StatT is the statistic functor type.
   *
   * @param pImg the input labeled image
   * @param pStat the statistic functor
   * @param pBox the rectangular region to be considered
   */
  template <typename PixelTypeT, 
	    typename StatT>
  void compute_stat_box(const Matrix< PixelTypeT >& pImg, 
			const GenericBox2D< typename Matrix< PixelTypeT >::size_type >& pBox,
			StatT& pStat);
  
  /**
   * compute_stat computes the statistic pStat over the rectangular
   * region specified by pBox over the labeled image pImg.  Only those
   * points that satisfy the predicate pPred are considered. The
   * template parameter StatT is the statistic functor type. The
   * template parameter PredicateT is the predicate type.
   *
   * @param pImg the input labeled image
   * @param pStat the statistic functor
   * @param pPred the predicate evaluated at each point
   * @param pBox the rectangular region to be considered
   */

  template <typename PixelTypeT, 
	    typename StatT,
	    typename PredicateT>
  void compute_stat_box(const Matrix< PixelTypeT >& pImg, 
			const GenericBox2D<typename Matrix< PixelTypeT >::size_type >& pBox,
			StatT& pStat,
			PredicateT pPred);

  //--- Implementation --------------------------------------------------------------------
  template <typename PixelTypeT, 
	    typename StatT>
  void compute_stat(const Matrix< PixelTypeT >& pImg, 		    
		    StatT& pStat)
  {
    compute_stat_box(pImg, 
		     GenericBox2D< typename Matrix< PixelTypeT >::size_type >(0,0,pImg.rows(), pImg.columns()),
		     pStat);
  }
  //---------------------------------------
  template <typename PixelTypeT, 
	    typename StatT,
	    typename PredicateT>
  void compute_stat(const Matrix< PixelTypeT >& pImg, 		    
		    StatT& pStat,
		    PredicateT pPred)
  {
    compute_stat_box(pImg, 
		     GenericBox2D< typename Matrix< PixelTypeT >::size_type >(0,0,pImg.rows(), pImg.columns()),
		     pStat,
		     pPred);
  }
  //---------------------------------------
  template <typename PixelTypeT, 
	    typename StatT>
  void compute_stat_box(const Matrix< PixelTypeT >& pImg, 
			const GenericBox2D< typename Matrix< PixelTypeT >::size_type >& pBox,
			StatT& pStat)
  {
    assert(pBox.top() <= pImg.rows());
    assert(pBox.left() <= pImg.columns());
    assert(pBox.bottom() <= pImg.rows());
    assert(pBox.right() <= pImg.columns());
  
    for (typename Matrix< PixelTypeT >::size_type r=pBox.top(); r < pBox.bottom(); r++)
      for (typename Matrix< PixelTypeT >::size_type c=pBox.left(); c < pBox.right(); c++)
	pStat(r,c,pImg[r][c]);	    
  }
  //---------------------------------------

  template <typename PixelTypeT, 
	    typename StatT,
	    typename PredicateT>

  void compute_stat_box(const Matrix< PixelTypeT >& pImg, 
			const GenericBox2D< typename Matrix< PixelTypeT >::size_type >& pBox,
			StatT& pStat,
			PredicateT pPred)
  {
    assert(pBox.top() <= pImg.rows());
    assert(pBox.left() <= pImg.columns());
    assert(pBox.bottom() <= pImg.rows());
    assert(pBox.right() <= pImg.columns());
  
    for (typename Matrix< PixelTypeT >::size_type r=pBox.top(); r < pBox.bottom(); r++)
      for (typename Matrix< PixelTypeT >::size_type c=pBox.left(); c < pBox.right(); c++)
	{
	  const PixelTypeT& p = pImg[r][c];
	
	  if (pPred(r,c,p))
	    pStat(r,c,p);	
	}
  }
  //---------------------------------------

  /*@}*/

} //ivllib

#endif //IMAGE_STATS
