/**
 * \file    utils.h
 * \brief   various imaging routines
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef utils_h
#define utils_h


#include <ivl_matrix.h>
#include <ivl_box.h>
#include <imaging/pixel.h>
#include <numerical/vector2.h>

#include <algorithm>
#include <vector>
#include <cmath>


namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  template <typename T>
  void draw_line(Matrix<T>& img,
		 int x0,
		 int y0,
		 int x1,
		 int y1,
		 const T& val);

  template <typename T>
  void draw_frame(Matrix<T>& mat, const Box& box, const T& val);

  template <typename T>
  void draw_frame(Matrix<T>& mat,
		  int x0,
		  int y0,
		  int x1,
		  int y1,
		  const T& val);

  template <typename T>
  void fill_frame(Matrix<T>& mat, const Box& box, const T& val);

  template <typename T>
  void fill_frame(Matrix<T>& mat,
		  int x0,
		  int y0,
		  int x1,
		  int y1,
		  const T& val);

  template <typename T>
  void draw_circle(Matrix<T>& img,
		   int cx,
		   int cy,
		   int radius,
		   const T& val);

  template <typename T>
  void fill_circle(Matrix<T>& img,
		   int cx,
		   int cy,
		   int radius,
		   const T& val);

  template <typename T>
  void draw_arrow(Matrix<T>& img,
		  int fromx,
		  int fromy,
		  int tox,
		  int toy,
		  int headsize,
		  const T& val);
    
  template <typename T,typename U,typename V,typename BlendFun>
  void scale_range(const Matrix<T>& in,V from,V to,Matrix<U>& out,const BlendFun& blend);

  template <typename T,typename U,typename V>
  void scale_range(const Matrix<T>& in,V from,V to,Matrix<U>& out);

  template <typename T,typename FwdIter1,typename FwdIter2>
  void fill_convex_polygon(Matrix<T>& mat,
			   FwdIter1 y_from,
			   FwdIter1 y_to,
			   FwdIter2 x_from,
			   const T& val);

  template <typename T, typename FwdIter1, typename FwdIter2>
  void fill_polygon(Matrix<T>& mat,
		    FwdIter1 y_from,
		    FwdIter1 y_to,
		    FwdIter2 x_from,
		    const T &val);


  /** \cond detail */
  namespace detail
  {
    template <typename T,typename U,typename V,typename BlendFun>
    struct RangeScaler
    {
      double min_;
      double inv_range_;
      V from_;
      V to_;
      const BlendFun& blend_;

      RangeScaler(T min,T max,V from,V to,const BlendFun& blend)
	: min_(static_cast<double>(min)),
	  inv_range_(1.0),
	  from_(from),
	  to_(to),
	  blend_(blend)
      {
	double tmp = static_cast<double>(max);

	if (min_ != tmp)
	  inv_range_ = 1.0/(tmp - min_);
      }
      
      U operator()(const T& x) const
      {
	double tmp = static_cast<double>(x);

	return blend_(to_,from_,(tmp-min_)*inv_range_);
      }
    };


    // used by fill_polygon
    struct poly_edge
    {
      poly_edge() : y0(0), y1(0), x(0), dx(0), next(0) { }
      
      int y0;
      int y1;
      double x;
      double dx;
      poly_edge* next;

      bool operator<(const poly_edge& e) const
      {
        return (y0 - e.y0
		? y0 < e.y0
		: (x - e.x
		   ? x < e.x
		   : dx < e.dx));
      }
    };  // poly_edge


    // used by fill_polygon
    template <typename T>
    void collect_poly_edges(Matrix<T>& img,
			    const std::vector<ivllib::Vector2<int> >& points,
			    std::vector<poly_edge>& edges,
			    const T& val)
    {
      assert(points.size() > 0);

      typedef ivllib::Vector2<int> Point;
      typedef std::vector<Point>::size_type size_type;

      std::vector<poly_edge> new_edges;
      Point pt0 = points.back();
      Point pt1;

      size_type count = points.size();
      new_edges.reserve(count);

      for(size_type i = 0; i < count; i++, pt0 = pt1) {
        pt1 = points[i];
	Point t0 = pt0;
	Point t1 = pt1;

	draw_line(img, t0.x, t0.y, t1.x, t1.y, val);
	
        if(pt0.y == pt1.y)
	  continue;

	poly_edge edge;
        if(pt0.y < pt1.y) {
	  edge.y0 = pt0.y;
	  edge.y1 = pt1.y;
	  edge.x = pt0.x;
        } else {
	  edge.y0 = pt1.y;
	  edge.y1 = pt0.y;
	  edge.x = pt1.x;
        }
        edge.dx = static_cast<double>(pt1.x - pt0.x) / (pt1.y - pt0.y);
        new_edges.push_back(edge);
      }
      edges.swap(new_edges);
    }


    // used by fill_polygon
    template <typename T>
    void fill_edges(Matrix<T>& img,
		    std::vector<poly_edge>& edges,
		    const T& val)
    {
      typedef std::vector<poly_edge>::size_type size_type;

      int n = img.rows();
      int m = img.columns();

      if(edges.size() < 2)
        return;

      size_type total = edges.size();
      int y_max = edges.front().y1;
      double x_max = edges.front().x;
      int y_min = edges.front().y0;
      double x_min = x_max;
      for(size_type i = 1; i < total; i++ ) {
	const poly_edge& e1 = edges[i];
        assert(e1.y0 < e1.y1);
        y_min = std::min(y_min, e1.y0);
        y_max = std::max(y_max, e1.y1);
        x_min = std::min(x_min, e1.x);
        x_max = std::max(x_max, e1.x);
      }

      std::sort(edges.begin(), edges.end());

      // drawing
      poly_edge tmp;
      tmp.y0 = y_max + 1;
      edges.push_back(tmp); 
      size_type i = 0;
      tmp.next = 0;
      poly_edge* e = &edges[i];

      for(int y = e->y0; y < y_max; y++ ) {
        int sort_flag = 0;
        int draw = 0;
        int clipline = (y < 0 || y >= n);

        poly_edge* prelast = &tmp;
        poly_edge* last = tmp.next;
        while(last != 0 || e->y0 == y) {
	  if(last != 0 && last->y1 == y) {
	    // exclude edge if y reachs its lower point
	    prelast->next = last->next;
	    last = last->next;
	    continue;
	  }
	  poly_edge* keep_prelast = prelast;
	  if(last != 0 && (e->y0 > y || last->x < e->x)) {
	    // go to the next edge in active list
	    prelast = last;
	    last = last->next;
	  } else if(i < total) {
	    // insert new edge into active list if y reachs its upper
	    // point
	    prelast->next = e;
	    e->next = last;
	    prelast = e;
	    e = &edges[++i];
	  } else {
	    break;
	  }

	  if (draw) {
	    if(!clipline ) {
	      int x1 = keep_prelast->x;
	      int x2 = prelast->x;

	      if(x1 > x2)
		std::swap(x1, x2);
	      
	      ++x2;
	      if (x1 < 0)
		x1 = 0;
	      if (x2 < 0)
		x2 = 0;
	      
	      if (x1 > m)
		x1 = m;
	      if (x2 > m)
		x2 = m;
	      
	      std::fill(img.row_begin(y) + x1,
			img.row_begin(y) + x2,
			val);
	    }
	    keep_prelast->x += keep_prelast->dx;
	    prelast->x += prelast->dx;
	  }
	  draw ^= 1;
	}

	// sort edges (using bubble sort)
	poly_edge* keep_prelast = 0;

	do {
	  prelast = &tmp;
	  last = tmp.next;

	  while(last != keep_prelast && last->next != 0) {
	    poly_edge* te = last->next;
	      
	    // swap edges
	    if(last->x > te->x) {
	      prelast->next = te;
	      last->next = te->next;
	      te->next = last;
	      prelast = te;
	      sort_flag = 1;
	    } else {
	      prelast = last;
	      last = te;
	    }
	  }
	  keep_prelast = prelast;
	  
	} while(sort_flag && keep_prelast != tmp.next &&
		keep_prelast != &tmp );
      }
    }

  }  // namespace detail
  /** \endcond */

  /**
   * Draw a line onto a matrix.
   *
   * Draw the line between the points <tt>(fromx,fromy)</tt> and
   * <tt>(tox,toy)</tt> using the Bresenham's line algorithm.  The
   * value @p val is assigned to the pixels on the line. The points
   * of the line which lie outside the image are ignored.  Both
   * endpoints are included in the line.
   *
   * \param img image to be modified
   * \param fromx start column
   * \param fromy start row
   * \param tox end column
   * \param toy end row
   * \param val value used to draw the line
   */
  template <typename T>
  void draw_line(Matrix<T>& img,
		 int fromx,
		 int fromy,
		 int tox,
		 int toy,
		 const T& val)
  {
    int n = img.rows();
    int m = img.columns();
    
    bool steep = ((tox > fromx ? tox - fromx : fromx - tox) <
		  (toy > fromy ? toy - fromy : fromy - toy));
    if (steep) {
      std::swap(fromx, fromy);
      std::swap(tox, toy);
    }
    if (fromx > tox) {
      std::swap(fromx, tox);
      std::swap(fromy, toy);
    }

    int deltax = tox - fromx;
    int deltay = (toy > fromy ? toy - fromy : fromy - toy);
    int error = deltax / 2;
    int y = fromy;

    int ystep = (fromy < toy ? 1 : -1);

    for (int x = fromx; x <= tox; ++x) {
      if (steep) {
	if (x >= 0 && y >= 0 && x < n && y < m)
	  img[x][y] = val;
      } else {
	if (x >= 0 && y >= 0 && y < n && x < m)
	  img[y][x] = val;
      }
      
      error -= deltay;
      if (error < 0) {
	y += ystep;
	error += deltax;
      }
    }
  }
  

  /**
   * Draw a rectangular frame.
   *
   * The appropriate elements of \p mat are set to \p val.  The
   * top-left corner if included in the frame, while the bottom-right
   * corner is excluded.  The box must be entirely included in the
   * matrix.
   *
   * \pre box.bottom() <= mat.rows()
   * \pre box.right() <= mat.columns()
   *
   * \param mat the matrix to be modified
   * \param box boundaries of the frame
   * \param val value used to draw the frame
   */
  template <typename T>
  void draw_frame(Matrix<T>& mat,
		  const Box& box,
		  const T& val)
  {
    assert(box.bottom() <= mat.rows());
    assert(box.right() <= mat.columns());

    // draw horizontal lines
    if (box.top() != box.bottom()) {
      std::fill(mat.row_begin(box.top()) + box.left(),
		mat.row_begin(box.top()) + box.right(),
		val);
      std::fill(mat.row_begin(box.bottom() - 1) + box.left(),
		mat.row_begin(box.bottom() - 1) + box.right(),
		val);
    }

    // draw vertical lines
    if (box.left() != box.right()) {
      std::fill(mat.column_begin(box.left()) + box.top(),
		mat.column_begin(box.left()) + box.bottom(),
		val);
      std::fill(mat.column_begin(box.right() - 1) + box.top(),
		mat.column_begin(box.right() - 1) + box.bottom(),
		val);
    }
  }


  /**
   * Draw a rectangular frame.
   *
   * The appropriate elements of \p mat are set to \p val.  The corner
   * (\p x0, \p y0) is included in the frame, while the corner (\p x1,
   * \p y1) is excluded.  Only the part included in \p mat is actually
   * drawn.
   *
   * \param mat the matrix to be modified
   * \param x0 horizontal coordinate of the frame
   * \param y0 vertical coordinate of the frame
   * \param x1 horizontal coordinate of the frame
   * \param y1 vertical coordinate of the frame
   * \param val value used to draw the frame
   */
  template <typename T>
  void draw_frame(Matrix<T>& mat,
		  int x0,
		  int y0,
		  int x1,
		  int y1,
		  const T& val)
  {
    typedef typename Matrix<T>::size_type size_type;

    // sort the coordinates.  Note that the two corners have different
    // boundary conditions (one is included in the frame, the other is
    // excluded).
    if (x1 < x0) {
      int temp = x0;
      x0 = x1 + 1;
      x1 = temp + 1;
    }
    if (y1 < y0) {
      int temp = y0;
      y0 = y1 + 1;
      y1 = temp + 1;
    }

    // draw horizontal lines
    if (y0 != y1) {
      int start = std::max(0, x0);
      int stop = std::min<int>(x1, mat.columns());
      if (start < static_cast<int>(mat.columns()) && stop > 0) {
	if (y0 >= 0 && static_cast<size_type>(y0) < mat.rows()) {
	  std::fill(mat.row_begin(y0) + start,
		    mat.row_begin(y0) + stop,
		    val);
	}
	if (y1 > 0 && static_cast<size_type>(y1) <= mat.rows()) {
	  std::fill(mat.row_begin(y1 - 1) + start,
		    mat.row_begin(y1 - 1) + stop,
		    val);
	}
      }
    }

    // draw vertical lines
    if (x0 != x1) {
      int start = std::max(0, y0);
      int stop = std::min<int>(y1, mat.rows());
      if (start < static_cast<int>(mat.rows()) && stop > 0) {
	if (x0 >= 0 && static_cast<size_type>(x0) < mat.columns()) {
	  std::fill(mat.column_begin(x0) + start,
		    mat.column_begin(x0) + stop,
		    val);
	}
	if (x1 > 0 && static_cast<size_type>(x1) <= mat.columns()) {
	  std::fill(mat.column_begin(x1 - 1) + start,
		    mat.column_begin(x1 - 1) + stop,
		    val);
	}
      }
    }
  }


  /**
   * Fill a rectangular frame.
   *
   * The appropriate elements of \p mat are set to \p val.  The
   * top-left corner if included in the frame, while the bottom-right
   * corner is excluded. The box must be entirely included in the
   * matrix.
   *
   * \pre box.bottom() <= mat.rows()
   * \pre box.right() <= mat.columns()
   *
   * \param mat the matrix to be modified
   * \param box boundaries of the frame
   * \param val value used to fill the frame
   */
  template <typename T>
  void fill_frame(Matrix<T>& mat,
		  const Box& box,
		  const T& val)
  {
    assert(box.bottom() <= mat.rows());
    assert(box.right() <= mat.columns());
    
    typedef typename Matrix<T>::size_type size_type;

    size_type top = box.top();
    size_type left = box.left();
    size_type bottom = box.bottom();
    size_type right = box.right();
    
    for( ;top != bottom; ++top)
      std::fill(mat.row_begin(top) + left,
		mat.row_begin(top) + right,
		val);
  }
  
  /**
   * Fill a rectangular frame.
   *
   * The appropriate elements of \p mat are set to \p val.  The corner
   * (\p x0, \p y0) is included in the frame, while the corner (\p x1,
   * \p y1) is excluded.  Only the part included in \p mat is actually
   * drawn.
   *
   * \param mat the matrix to be modified
   * \param x0 horizontal coordinate of the frame
   * \param y0 vertical coordinate of the frame
   * \param x1 horizontal coordinate of the frame
   * \param y1 vertical coordinate of the frame
   * \param val value used to fill the frame
   */
  template <typename T>
  void fill_frame(Matrix<T>& mat,
		  int x0,
		  int y0,
		  int x1,
		  int y1,
		  const T& val)
  {
    // sort the coordinates.  Note that the two corners have different
    // boundary conditions (one is included in the frame, the other is
    // excluded).
    if (x1 < x0) {
      int temp = x0;
      x0 = x1 + 1;
      x1 = temp + 1;
    }
    if (y1 < y0) {
      int temp = y0;
      y0 = y1 + 1;
      y1 = temp + 1;
    }

    if (x0 >= static_cast<int>(mat.columns()) ||
	y0 >= static_cast<int>(mat.rows()) ||
	x1 <= 0 ||
	y1 <= 0)
      return;

    // clip the coordinates
    x0 = std::max(0, x0);
    y0 = std::max(0, y0);
    x1 = std::min<int>(mat.columns(), x1);
    y1 = std::min<int>(mat.rows(), y1);
    
    fill_frame(mat, Box(y0, x0, y1, x1), val);
  }


  /**
   * Draw a circle
   *
   * The appropriate elements of \p img are set to \p val.  The
   * midpoint circle algorithm (a variant of Bresenham's line
   * algorithm) is used.
   *
   * \param img the matrix to be modified
   * \param cx horizontal coordinate of the center
   * \param cy vertical coordinate of the center
   * \param radius the radius of the circle
   * \param val value used to draw the circle
   *
   * \pre radius >= 0
   */
  template <typename T>
  void draw_circle(Matrix<T>& img,
		   int cx,
		   int cy,
		   int radius,
		   const T& val)
  {
    // implementation found on Wikipedia

    assert(radius >= 0);
    
    int f = 1 - radius;
    int ddF_x = 1;
    int ddF_y = -2 * radius;
    int x = 0;
    int y = radius;
    int n = img.rows();
    int m = img.columns();
 
    if (cx >= 0 && cx < m) {
      int tempy = cy + radius;
      if (tempy >= 0 && tempy < n)
	img[tempy][cx] = val;
      tempy = cy - radius;
      if (tempy >= 0 && tempy < n)
	img[tempy][cx] = val;
    }
    if (cy >= 0 && cy < n) {
      int tempx = cx + radius;
      if (tempx >= 0 && tempx < m)
	img[cy][tempx] = val;
      tempx = cx - radius;
      if (tempx >= 0 && tempx < m)
	img[cy][tempx] = val;
    }
 
    while(x < y) {
      // ddF_x == 2 * x + 1;
      // ddF_y == -2 * y;
      // f == x*x + y*y - radius*radius + 2*x - y + 1;
      if(f >= 0) {
	y--;
	ddF_y += 2;
	f += ddF_y;
      }
      x++;
      ddF_x += 2;
      f += ddF_x;    

      int tempx = cx + x;
      if (tempx >= 0 && tempx < m) {
	int tempy = cy + y;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
	tempy = cy - y;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
      }

      tempx = cx + y;
      if (tempx >= 0 && tempx < m) {
	int tempy = cy + x;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
	tempy = cy - x;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
      }

      tempx = cx - x;
      if (tempx >= 0 && tempx < m) {
	int tempy = cy + y;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
	tempy = cy - y;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
      }

      tempx = cx - y;
      if (tempx >= 0 && tempx < m) {
	int tempy = cy + x;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
	tempy = cy - x;
	if (tempy >= 0 && tempy < n)
	  img[tempy][tempx] = val;
      }
    }
  }


  /**
   * Draw a filled circle
   *
   * The appropriate elements of \p img are set to \p val.  The
   * midpoint circle algorithm (a variant of Bresenham's line
   * algorithm) is used.
   *
   * \param img the matrix to be modified
   * \param cx horizontal coordinate of the center
   * \param cy vertical coordinate of the center
   * \param radius the radius of the circle
   * \param val value used to draw the circle
   *
   * \pre radius >= 0
   */
  template <typename T>
  void fill_circle(Matrix<T>& img,
		   int cx,
		   int cy,
		   int radius,
		   const T& val)
  {
    assert(radius >= 0);
    
    int f = 1 - radius;
    int ddF_x = 1;
    int ddF_y = -2 * radius;
    int x = 0;
    int y = radius;
    int n = img.rows();
    int m = img.columns();
 
    if (cx >= 0 && cx < m) {
      int tempy = cy + radius;
      if (tempy >= 0 && tempy < n)
	img[tempy][cx] = val;
      tempy = cy - radius;
      if (tempy >= 0 && tempy < n)
	img[tempy][cx] = val;
    }
    if (cy >= 0 && cy < n) {
      int start = std::max(cx - radius, 0);
      int stop = std::min(cx + radius + 1, m);
      for (; start < stop; ++start)
	img[cy][start] = val;
    }
 
    while(x < y) {
      // ddF_x == 2 * x + 1;
      // ddF_y == -2 * y;
      // f == x*x + y*y - radius*radius + 2*x - y + 1;
      if(f >= 0) {
	y--;
	ddF_y += 2;
	f += ddF_y;
      }
      x++;
      ddF_x += 2;
      f += ddF_x;    

      int start = std::max(cx - x, 0);
      int stop = std::min(cx + x + 1, m);
      int tempy = cy - y;
      if (tempy >= 0 && tempy < n)
	for (int i = start; i != stop; i++)
	  img[tempy][i] = val;
      tempy = cy + y;
      if (tempy >= 0 && tempy < n)
	for (int i = start; i != stop; i++)
	  img[tempy][i] = val;
      
      start = std::max(cx - y, 0);
      stop = std::min(cx + y + 1, m);
      tempy = cy - x;
      if (tempy >= 0 && tempy < n)
	for (int i = start; i != stop; i++)
	  img[tempy][i] = val;
      tempy = cy + x;
      if (tempy >= 0 && tempy < n)
	for (int i = start; i != stop; i++)
	  img[tempy][i] = val;
    }
  }
  

  /**
   * Draw an arrow onto a matrix.
   *
   * Draw the line between the points <tt>(fromx,fromy)</tt> and
   * <tt>(tox,toy)</tt>.  At the end of the line draw an arrowhead of
   * size \a headsize.
   *
   * \pre headsize >= 0
   *
   * \param img image to be modified
   * \param fromx start column
   * \param fromy start row
   * \param tox end column
   * \param toy end row
   * \param headsize size of the arrowhead in pixels
   * \param val value used to draw the arrow
   */
  template <typename T>
  void draw_arrow(Matrix<T>& img,
		  int fromx,
		  int fromy,
		  int tox,
		  int toy,
		  int headsize,
		  const T& val)
  {
    assert(headsize >= 0);
    
    draw_line(img, fromx, fromy, tox, toy, val);

    double dx = tox - fromx;
    double dy = toy - fromy;
    
    double l = std::sqrt(dx * dx + dy * dy);
    
    if (l > 0) {
      dx *= headsize / l;
      dy *= headsize / l;
    } else {
      dx = 0;
      dy = -headsize;
    }
    
    const double cos30 = 0.86602540378443871;
    const double sin30 = 0.5;
    
    draw_line(img, tox, toy,
	      tox - cos30 * dx - sin30 * dy + 0.5,
	      toy + sin30 * dx - cos30 * dy + 0.5,
	      val);

    draw_line(img, tox, toy,
	      tox - cos30 * dx + sin30 * dy + 0.5,
	      toy - sin30 * dx - cos30 * dy + 0.5,
	      val);
  }
  

  /**
   * Scale the values of a matrix
   *
   * Elements of the input matrix are scaled
   * in the range \f$ [from,to] \f$ and the copied
   * into the destination matrix.
   *
   * The \p blend functor is used to compute the new values.
   *
   * The elements of the input matrix must be convertible to double
   * and must be comparable with \p operator< .
   * The blend functor must take two parameters of tpye \p V,
   * and a double between 0 and 1. The result must be assignable
   * to the elements of the destination matrix.
   *
   * \param in input matrix
   * \param from begin of the new range
   * \param to end of the new range
   * \param out output matrix
   * \param blend blending functor
   * 
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename V,typename BlendFun>
  void scale_range(const Matrix<T>& in,V from,V to,Matrix<U>& out,const BlendFun& blend)
  {
    Matrix<U> result(in.rows(),in.columns());
    if (in.rows() == 0 || in.columns() == 0) {
      out.swap(result);
      return;
    }

    T min = *std::min_element(in.begin(),in.end());
    T max = *std::max_element(in.begin(),in.end());

    std::transform(in.begin(),
		   in.end(),
		   result.begin(),
		   detail::RangeScaler<T,U,V,BlendFun>(min,max,from,to,blend));

    out.swap(result);
  }

  /**
   * Scale the values of a matrix
   *
   * The more general version of this function is
   * called using \p ivllib::Blend<V>() as blending
   * functor.
   */
  template <typename T,typename U,typename V>
  void scale_range(const Matrix<T>& in,V from,V to,Matrix<U>& out)
  {
    scale_range(in,from,to,out,Blend<V>());
  }

  /**
   * Draw a filled convex polygon setting the appropriate
   * elements of \p mat to \p val.
   *
   * The coordinates of the vertices of the polygon are passed
   * in the (forward) iterator ranges <tt>[y_from,y_to)</tt> and 
   * <tt>[x_from,std::advance(x_from,std::distance(y_from,y_to))) </tt>.
   * The two ranges must be valid and their elements must be convertible to
   * <tt>Matrix<T>::size_type</tt>. Each pair of coordinates must be inside
   * the matrix boundaries.
   *
   * \param mat the matrix to be modified
   * \param y_from begin of y coordinates
   * \param y_to iterator past the last y coordinate
   * \param x_from begin of y coordinates
   * \param val value used to fill the polygon
   */
  template <typename T,typename FwdIter1,typename FwdIter2>
  void fill_convex_polygon(Matrix<T>& mat,
			   FwdIter1 y_from,
			   FwdIter1 y_to,
			   FwdIter2 x_from,
			   const T& val)
  {
#ifndef NDEBUG
    typedef typename Matrix<T>::size_type size_type;
#endif

    if (y_from == y_to)
      return; // no points: exit
    
    int y_begin = static_cast<int>(*std::min_element(y_from,y_to));
    int y_end = static_cast<int>(*std::max_element(y_from,y_to));
    
    assert( y_begin >= 0 );
    assert( static_cast<size_type>(y_end) < mat.rows() );
    
    std::vector<int> x_begin(1 + y_end - y_begin,mat.columns());
    std::vector<int> x_end(1 + y_end - y_begin,0);

    FwdIter1 yit = y_from;
    FwdIter2 xit = x_from;
    
    while (yit != y_to) {
      int y1 = static_cast<int>(*yit);
      int x1 = static_cast<int>(*xit);
      ++yit;
      ++xit;

      int y2 = static_cast<int>(*y_from);
      int x2 = static_cast<int>(*x_from);

      assert( y1 >= 0 );
      assert( x1 >= 0 );

      assert( static_cast<size_type>(y2) < mat.rows() );
      assert( static_cast<size_type>(x2) < mat.columns() );

      if (yit != y_to) {
	y2 = static_cast<int>(*yit);
	x2 = static_cast<int>(*xit);
      }
	
      if (y1 == y2) {
	x_begin[y1 - y_begin] = std::min(x_begin[y1 - y_begin],std::min(x1,x2));
	x_end[y1 - y_begin] = std::max(x_end[y1 - y_begin],1 + std::max(x1,x2));
      } else {
	if (y1 > y2) {
	  std::swap(y1,y2);
	  std::swap(x1,x2);
	}

	for (int y = y1; y <= y2; y++) {
	  int x = x1 + ((y - y1) * (x2 - x1)) / (y2 - y1);
	  int off = y - y_begin;
	  if (x < x_begin[off])
	    x_begin[off] =  x;
	  if (x + 1> x_end[off])
	    x_end[off] = x + 1;
	}
      }
    } 

    for (int y = y_begin ; y < y_end; y++) {
      int off = y - y_begin;
      if (x_begin[off] > x_end[off+1]) {
	int middle = (x_begin[off] + x_end[off+1]) / 2;
	x_begin[off] = middle;
	x_end[off+1] = middle;
      }
      if (x_begin[off+1] > x_end[off]) {
	int middle = (x_begin[off+1] + x_end[off]) / 2;
	x_begin[off+1] = middle;
	x_end[off] = middle;
      }
    }
    
    for (int y = y_begin; y <= y_end; y++) {
      int off = y - y_begin;
      assert( x_begin[off] >= 0 );
      assert( static_cast<size_type>(x_end[off]) <= mat.columns() );

      std::fill(mat.row_begin(y) + x_begin[off],
		mat.row_begin(y) + x_end[off],
		val);
    }
  }


  /**
   * Draw a filled polygon setting the appropriate elements of \p mat
   * to \p val.
   *
   * The coordinates of the vertices of the polygon are passed in the
   * (forward) iterator ranges <tt>[y_from,y_to)</tt> and
   * <tt>[x_from,std::advance(x_from,std::distance(y_from,y_to)))
   * </tt>.  The two ranges must be valid and their elements must be
   * convertible to <tt>int</tt>. Only the region inside the matrix
   * boundaries is actually drawn.
   *
   * \param mat the matrix to be modified
   * \param y_from begin of y coordinates
   * \param y_to iterator past the last y coordinate
   * \param x_from begin of y coordinates
   * \param val value used to fill the polygon
   */
  template <typename T, typename FwdIter1, typename FwdIter2>
  void fill_polygon(Matrix<T>& mat,
		    FwdIter1 y_from,
		    FwdIter1 y_to,
		    FwdIter2 x_from,
		    const T &val)
  {
    if (y_from == y_to)
      return; // no points: exit

    std::vector<detail::poly_edge> edges;
    std::vector<ivllib::Vector2<int> > coords;
    
    while (y_from != y_to) {
      coords.push_back(ivllib::Vector2<int>(*x_from, *y_from));
      ++x_from;
      ++y_from;
    }
    
    detail::collect_poly_edges(mat, coords, edges, val);
    detail::fill_edges(mat, edges, val);
  }

  /*@}*/

} // ivllib

#endif
