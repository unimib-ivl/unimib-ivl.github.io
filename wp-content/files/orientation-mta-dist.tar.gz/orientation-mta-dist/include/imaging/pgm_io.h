/**
 * \file    pgm_io.h
 * \brief   io routines for the pgm graphic format
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef pgm_io_h
#define pgm_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/

  /**
   * Load a portable graymap file (pgm).
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_pgm(const std::string& filename,Matrix<Gray8>& out);

  /**
   * Load a portable graymap file (pgm).
   *
   * red, green and blue components of each pixel are
   * set at the same value.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_pgm(const std::string& filename,Matrix<RGB8>& out);

  /**
   * Load a portable graymap file (pgm).
   *
   * red, green and blue components of each pixel are
   * set at the same value. Alpha component is set to 255.
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   */ 
  void load_pgm(const std::string& filename,Matrix<RGBA8>& out);

  /**
   * Save a portable graymap file (pgm).
   *
   * if \p binary is false, pixels are encoded as text,
   * otherwise a binary representation is used.
   *
   * \param filename name of the file to save
   * \param in the image to save
   * \param binary binary/text flag
   *
   * \throw ImageFileError
   */ 
  void save_pgm(const std::string& filename,
		const Matrix<Gray8>& in,
		bool binary = true);

  /*@}*/

}

#endif
