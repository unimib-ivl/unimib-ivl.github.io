/**
 * \file    binarization.h
 * \brief   binarization and thresholding routines
 * \author  $LastChangedBy: cusano $
 * \date    $Date$
 * \version $Revision: 65 $
 */

#ifndef binarization_h
#define binarization_h

#include <ivl_matrix.h>
#include <mat_algorithm.h>
#include <functional>

namespace ivllib
{
  /** \addtogroup processing */
  /*@{*/

  template <typename T,typename U,typename Pred>
  void binarization(const Matrix<T>& in,
		    U false_value,
		    U true_value,
		    Matrix<U>& out,
		    Pred pred);

  template <typename T,typename V,typename U,typename Pred>
  void thresholding(const Matrix<T>& in,
		    V threshold,
		    U low_value,
		    U high_value,
		    Matrix<U>& out,
		    Pred pred);

  template <typename T,typename V,typename U>
  void thresholding(const Matrix<T>& in,
		    V threshold,
		    U low_value,
		    U high_value,
		    Matrix<U>& out);

  template <typename T,typename V,typename U>
  V adaptive_thresholding(const Matrix<T>& in,
			  V init_threshold,
			  U low_value,
			  U high_value,
			  Matrix<U>& out,
			  unsigned int max_iterations = 20);

  /** \cond detail */
  namespace detail
  {
    template <typename T,typename U,typename Pred>
    class BinarizationFun
    {
    public:
      BinarizationFun(Pred pred,U true_value,U false_value)
	: pred_(pred),
	  true_value_(true_value),
	  false_value_(false_value)
      {
      }

      U operator()(const T& t) const
      {
	return pred_(t) ? true_value_ : false_value_;
      }

    private:
      Pred pred_;
      U true_value_;
      U false_value_;
    };

    template <typename T,typename V,typename U,typename Pred>
    class ThresholdingFun
    {
    public:
      ThresholdingFun(Pred pred,V threshold,U low_value,U high_value)
	: pred_(pred),
	  threshold_(threshold),
	  low_value_(low_value),
	  high_value_(high_value)
      {
      }

      U operator()(const T& t) const
      {
	return pred_(t,threshold_) ? low_value_ : high_value_;
      }

    private:
      Pred pred_;
      V threshold_;
      U low_value_;
      U high_value_;
    };

    template <typename T,typename V,typename U>
    class DefaultThresholdingFun
    {
    public:
      DefaultThresholdingFun(V threshold,U low_value,U high_value)
	: threshold_(threshold),
	  low_value_(low_value),
	  high_value_(high_value)
      {
      }

      U operator()(const T& t) const
      {
	return (t < threshold_) ? low_value_ : high_value_;
      }

    private:
      V threshold_;
      U low_value_;
      U high_value_;
    };

  } // detail  
  /** \endcond */

  /** 
   * Matrix binarization.
   *
   * <tt> out[i][j] = pred(in[i][j]) ? true_value : false_value </tt>
   * \param in input matrix
   * \param false_value output values for elements which makes false the predicate
   * \param true_value output values for elements which makes true the predicate
   * \param out output matrix
   * \param pred binarization predicate
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename U,typename Pred>
  void binarization(const Matrix<T>& in,
		    U false_value,
		    U true_value,
		    Matrix<U>& out,
		    Pred pred)
  {
    mat_transform(in,
		  out,
		  detail::BinarizationFun<T,U,Pred>(pred,true_value,false_value));
  }

  /**
   * Matrix thresholding
   *
   * <tt> out[i][j] = pred(in[i][j],threshold) ? low_value : high_value </tt>
   *
   * \param in input matrix
   * \param threshold value of the threshold
   * \param low_value output values for elements below the threshold
   * \param high_value output values for elements above (or equal to) the threshold
   * \param out output matrix
   * \param pred comparison predicate
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename V,typename U,typename Pred>
  void thresholding(const Matrix<T>& in,
		    V threshold,
		    U low_value,
		    U high_value,
		    Matrix<U>& out,
		    Pred pred)
  {
    mat_transform(in,
		  out,
		  detail::ThresholdingFun<T,V,U,Pred>(pred,threshold,low_value,high_value));
  }

  /**
   * Matrix thresholding
   *
   * <tt> out[i][j] = (in[i][j] < threshold) ? low_value : high_value </tt>
   *
   * \param in input matrix
   * \param threshold value of the threshold
   * \param low_value output values for elements below the threshold
   * \param high_value output values for elements above (or equal to) the threshold
   * \param out output matrix
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename V,typename U>
  void thresholding(const Matrix<T>& in,
		    V threshold,
		    U low_value,
		    U high_value,
		    Matrix<U>& out)
  {
    mat_transform(in,
		  out,
		  detail::DefaultThresholdingFun<T,V,U>(threshold,low_value,high_value));
  }

  /**
   * Adaptive matrix thresholding
   *
   * Based on one-dimensional k-means
   * The method iteratively estimate a threshold until
   * the new estimate is equal to the previous estimate, or
   * \p max_iterations have been excuted.  
   *
   * If \p v is a variable of type \p V, \p t is
   * a variable of type \p T, and \p n is a variable of type \p int
   * the following expressions must be valid:
   * - <tt> v += t </tt>
   * - <tt> v /= n </tt> 
   * - <tt> (v + v) / n </tt>
   * - <tt> t < v </tt>
   *
   * \param in input matrix
   * \param init_threshold initial threshold estimate
   * \param low_value output values for elements below the threshold
   * \param high_value output values for elements above (or equal to) the threshold
   * \param out output matrix
   * \param max_iterations maximum number of iterations
   *
   * \return the final value of the threshold
   *
   * \post out.rows() == in.rows()
   * \post out.columns() == in.columns()
   */
  template <typename T,typename V,typename U>
  V adaptive_thresholding(const Matrix<T>& in,
			  V init_threshold,
			  U low_value,
			  U high_value,
			  Matrix<U>& out,
			  unsigned int max_iterations)
  {
    V thr = init_threshold;

    Matrix<U> bin;
    while (max_iterations-- != 0) {

      thresholding(in,thr,low_value,high_value,bin);
      V low_mean = V(0);
      V high_mean = V(0);
      int low_count = 0;
      int high_count = 0;
      typename Matrix<T>::const_iterator it1 = in.begin();
      typename Matrix<U>::iterator it2 = bin.begin();
      for (; it1 != in.end(); ++it1,++it2) {
	if (*it2 == low_value) {
	  low_mean += *it1;
	  ++low_count;
	} else {
	  high_mean += *it1;
	  ++high_count;
	}
      }
      if (low_count == 0 || high_count == 0) {
	out.swap(bin);
	return thr;
      }
      low_mean /= low_count;
      high_mean /= high_count;
      
      V new_thr = (low_mean + high_mean) / 2;
      if (thr == new_thr) {
	out.swap(bin);
	return thr;
      }
      thr = new_thr;
    }

    out.swap(bin);
    return thr;
  }

  /*@}*/

} // ivllib

#endif // binarization_h
