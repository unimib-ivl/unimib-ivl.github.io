/**
 * \file    image_io.h
 * \brief   io routines for loading and saving images
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef image_io_h
#define image_io_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <string>

namespace ivllib
{
  /** \addtogroup io */
  /*@{*/

  /**
   * Load an image.
   *
   * the graphic format is determined by the
   * extension of \p filename. If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown
   * 
   * The supported formats are:
   * - color and grayscale jpeg (extension jpg or jpeg)
   * - color and grayscale png (extension png)
   * - portable greyscle (extension pgm) 
   * - portable pixmap (extension ppm)
   * - windows bitmap (extension bmp or dib)
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void load_image(const std::string& filename,
		  Matrix<RGB8>& out);

  /**
   * Load an image.
   *
   * the graphic format is determined by the
   * extension of \p filename.
   * If the file does not encode an alpha channel, the value
   * 255 is used.
   * If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown.
   * 
   * The supported formats are:
   * - color and grayscale jpeg (extension jpg or jpeg)
   * - color,grayscale and color+alpha png (extension png)
   * - portable greyscle (extension pgm) 
   * - portable pixmap (extension ppm)
   * - windows bitmap (extension bmp or dib)
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void load_image(const std::string& filename,
		  Matrix<RGBA8>& out);
  
  /**
   * Load an image.
   *
   * the graphic format is determined by the
   * extension of \p filename. If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown
   *
   * The supported formats are:
   * - grayscale jpeg (extension jpg or jpeg)
   * - grayscale png (extension png)
   * - portable greyscle (extension pgm) 
   *
   * \param filename name of the file to load
   * \param out result
   *
   * \throw ImageFormatError
   * \throw ImageFileError
   * \throw ImageConversionError
   */
  void load_image(const std::string& filename,
		  Matrix<Gray8>& out);
  
  /**
   * Save an image
   *
   * the graphic format is determined by the
   * extension of \p filename.  If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown
   *
   * The supported formats are:
   * - jpeg (extension jpg or jpeg)
   * - png (extension png)
   * - portable pixmap (extension ppm) 
   *
   * \param filename name of the file to save
   * \param in the image to save
   *
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void save_image(const std::string& filename,
		  const Matrix<RGB8>& in);

  /**
   * Save an image
   *
   * the graphic format is determined by the
   * extension of \p filename.  If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown
   *
   * The supported formats are:
   * - png (extension png)
   *
   * \param filename name of the file to save
   * \param in the image to save
   *
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void save_image(const std::string& filename,
		  const Matrix<RGBA8>& in);
  
  /**
   * Save an image
   *
   * the graphic format is determined by the
   * extension of \p filename.  If the format is
   * unknown or is not supported, an \p ImageConversionError
   * exception is thrown
   *
   * The supported formats are:
   * - jpeg (extension jpg or jpeg)
   * - png (extension png)
   * - portable greyscle (extension pgm)
   * - portable pixmap (extension ppm) 
   *
   * \param filename name of the file to save
   * \param in the image to save
   *
   * \throw ImageFileError
   * \throw ImageConversionError
   */ 
  void save_image(const std::string& filename,
		  const Matrix<Gray8>& in);

  /*@}*/

}

#endif
