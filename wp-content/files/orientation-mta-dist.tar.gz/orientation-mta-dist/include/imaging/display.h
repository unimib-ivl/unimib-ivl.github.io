/**
 * \file    display.h
 * \brief   functions for displaying images
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef display_h
#define display_h

#include <ivl_matrix.h>
#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <imaging/utils.h>  // scale_range

#include <string>

namespace ivllib
{
  /** \addtogroup misc */
  /*@{*/

  /**
   * Open a window and show an image.
   *
   * The application is blocked until the user
   * closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   *
   * \throw std::runtime_error
   */
  void display_image(const Matrix<Gray8>& img,
		     const std::string& title);

  /**
   * Open a window and show an image.
   *
   * The application is blocked until the user
   * closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   *
   * \throw std::runtime_error
   */
  void display_image(const Matrix<RGB8>& img,
		     const std::string& title);

  /**
   * Open a window and show an image.
   *
   * The application is blocked until the user
   * closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   *
   * \throw std::runtime_error
   */
  void display_image(const Matrix<RGBA8>& img,
		     const std::string& title);


  /**
   * Let the user visually select points over an image.
   *
   * A window is opened showing the input image.
   * The user can select up to \p n points by left-clicking
   * on the picture.
   * The application is blocked until the user
   * selects \p n points or closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   * \param n maximum number of points to be selected (0 means illimited)
   * \param x array where the horizontal coordinate of the selected pixels are stored
   * \param y array where the vertical coordinate of the selected pixels are stored
   *
   * \return the number of points actually selected
   *
   * If \p x is null, the horizontal coordinates are not stored.
   * If \p y is null, the vertical coordinates are not stored.
   * If \p n is 0, \p x and \p y must be null.
   *
   * \pre n > 0 || (x == 0 && y == 0)
   *
   * \throw std::runtime_error
   */
  unsigned int select_points(const Matrix<Gray8>& img,
			     const std::string& title,
			     unsigned int n,
			     int* x,
			     int* y);

  /**
   * Let the user visually select points over an image.
   *
   * A window is opened showing the input image.
   * The user can select up to \p n points by left-clicking
   * on the picture.
   * The application is blocked until the user
   * selects \p n points or closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   * \param n maximum number of points to be selected (0 means illimited)
   * \param x array where the horizontal coordinate of the selected pixels are stored
   * \param y array where the vertical coordinate of the selected pixels are stored
   *
   * \return the number of points actually selected
   *
   * If \p x is null, the horizontal coordinates are not stored.
   * If \p y is null, the vertical coordinates are not stored.
   *
   * \throw std::runtime_error
   */
  unsigned int select_points(const Matrix<RGB8>& img,
			     const std::string& title,
			     unsigned int n,
			     int* x,
			     int* y);

  /**
   * Let the user visually select points over an image.
   *
   * A window is opened showing the input image.
   * The user can select up to \p n points by left-clicking
   * on the picture.
   * The application is blocked until the user
   * selects \p n points or closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.
   *
   * \param img the image to display
   * \param title the title of the window
   * \param n maximum number of points to be selected (0 means illimited)
   * \param x array where the horizontal coordinate of the selected pixels are stored
   * \param y array where the vertical coordinate of the selected pixels are stored
   *
   * \return the number of points actually selected
   *
   * If \p x is null, the horizontal coordinates are not stored.
   * If \p y is null, the vertical coordinates are not stored.
   *
   * \throw std::runtime_error
   */
  unsigned int select_points(const Matrix<RGBA8>& img,
			     const std::string& title,
			     unsigned int n,
			     int* x,
			     int* y);
  
  /**
   * Open a window and show an image.
   *
   * The application is blocked until the user
   * closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.  The image is first scaled by using
   * the \c scale_range function
   *
   * \param img the image to display
   * \param title the title of the window
   * \param from begin of the new range
   * \param to end of the new range
   * \param blend blending functor
   *
   * \throw std::runtime_error
   */
  template <typename T, typename U, typename Blend>
  void display_scaled_image(const Matrix<T>& img,
			    const std::string& title,
			    U from,
			    U to,
			    Blend blend);

  /**
   * Open a window and show an image.
   *
   * The application is blocked until the user
   * closes the window.
   * The user can close the window pressing the space bar.
   * The user can also save the displayed image
   * pressing the 's' key.  The image is first scaled by using
   * the \c scale_range function
   *
   * \param img the image to display
   * \param title the title of the window
   * \param from begin of the new range
   * \param to end of the new range
   *
   * \throw std::runtime_error
   */
  template <typename T, typename U>
  void display_scaled_image(const Matrix<T>& img,
			    const std::string& title,
			    U from,
			    U to);

  /*@}*/
}


template <typename T, typename U, typename Blend>
void ivllib::display_scaled_image(const ivllib::Matrix<T>& img,
				  const std::string& title,
				  U from,
				  U to,
				  Blend blend)
{
  Matrix<U> temp;
  scale_range(img, from, to, temp, blend);
  display_image(temp, title);
}


template <typename T, typename U>
void ivllib::display_scaled_image(const ivllib::Matrix<T>& img,
				  const std::string& title,
				  U from,
				  U to)
{
  Matrix<U> temp;
  scale_range(img, from, to, temp);
  display_image(temp, title);
}


#endif
