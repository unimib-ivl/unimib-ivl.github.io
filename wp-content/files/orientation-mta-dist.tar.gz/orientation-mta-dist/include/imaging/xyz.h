/**
 * \file    xyz.h
 * \brief   XYZ colorspace structures
 * \author  $LastChangedBy: ciocca $
 */

/*
NOTE: Only sRGB color space and D65 reference white conversion matrices are
	implemented. For other conversion matrices see: 
	
	http://www.brucelindbloom.com/index.html?Eqn_RGB_XYZ_Matrix.html

*/

#ifndef ivllib_xyz_h
#define ivllib_xyz_h

#include <imaging/pixel.h>
#include <imaging/rgb.h>
#include <cmath>

using namespace std;

namespace ivllib
{
  /** \cond detail */
	namespace details {
		inline Matrix<double> gm(
			double a00, double a01, double a02,
			double a10, double a11, double a12,
			double a20, double a21, double a22) {
				
			Matrix<double> tmp(3,3);
			tmp[0][0]=a00; tmp[0][1]=a01; tmp[0][2]=a02;
			tmp[1][0]=a10; tmp[1][1]=a11; tmp[1][2]=a12;
			tmp[2][0]=a20; tmp[2][1]=a21; tmp[2][2]=a22;
			
			return tmp;
		}
	};
  /** \endcond */

  static const Matrix<double> XYZ2sRGBD65=
  	details::gm( 3.2404542, -1.5371385, -0.4985314,
								-0.9692660,  1.8760108,  0.0415560,
 								 0.0556434, -0.2040259,  1.0572252);

  static const Matrix<double> sRGB2XYZD65 =
  	details::gm( 0.4124564,  0.3575761,  0.1804375,
								 0.2126729,  0.7151522,  0.0721750,
 								 0.0193339,  0.1191920,  0.9503041);

  /** \addtogroup color */
  /*@{*/

  /**
   * Pixels in the XYZ color space
   */
  template <typename T>
  struct xyz
  {
    typedef T channel_type; ///< type of the components

    channel_type x; ///< x component
    channel_type y; ///< y component
    channel_type z; ///< z component

    /// Black value in XYZ
    xyz()
      : x(0),y(0),z(0)
    {
    }

    /// Construction from the channels values
    xyz(channel_type ax,
		channel_type ay,
		channel_type az)
      : x(ax),y(ay),z(az){}
  };

  /**
   * XYZ pixels
   *
   */
  typedef xyz<double> XYZ;
  
  // pixel conversions
  

  /**
   * XYZ to RGB colorspace conversion
   *
   * Conversion of XYZ values to 8-bits RGB values.
   * Defaults are sRGB color space and D65 Reference White
   *
   */
  template <>
  struct PixelConversion<XYZ,RGB8>
    : public std::unary_function<XYZ,RGB8>
  {
  	
  	/**
  	 * Constructor
  	 * @param M color conversion matrix (default XYZ2sRGBD65)
  	 */  	 
  	PixelConversion(const Matrix<double> &M = XYZ2sRGBD65) : _m(M) {}
  	
    /// conversion
    RGB8 operator()(const XYZ& p) const
    {			
    	assert(_m.rows()==3);
    	assert(_m.columns()==3);

			double r = _m[0][0] * p.x + _m[0][1] * p.y + _m[0][2] * p.z;
			double g = _m[1][0] * p.x + _m[1][1] * p.y + _m[1][2] * p.z;
			double b = _m[2][0] * p.x + _m[2][1] * p.y + _m[2][2] * p.z;
			
			return RGB8(static_cast<unsigned char>(0.5+r*255),
									static_cast<unsigned char>(0.5+g*255),
									static_cast<unsigned char>(0.5+b*255));
    }
    
  	private:
    	Matrix<double> _m;
  };
    
  /**
   * RGB to XYZ colorspace conversion
   *
   * Conversion of 8-bits RGB pixels to XYZ values.
   * Defaults are sRGB color space and D65 Reference White.
   */
  template <>
  struct PixelConversion<Gray8,XYZ>
    : public std::unary_function<Gray8,XYZ>
  {
  	/**
  	 * Constructor
  	 * @param M color conversion matrix (default sRGB2XYZD65)
  	 */  	 
   	PixelConversion(const Matrix<double> &M = sRGB2XYZD65) : _m(M) {}

   /// conversion
    XYZ operator()(const Gray8& p) const
    {
    	assert(_m.rows()==3);
    	assert(_m.columns()==3);
    	
			double r = p/255.0;
			double g = r;
			double b = r;
			
			return XYZ(
				_m[0][0] * r + _m[0][1] * g + _m[0][2] * b,
				_m[1][0] * r + _m[1][1] * g + _m[1][2] * b,
				_m[2][0] * r + _m[2][1] * g + _m[2][2] * b
			);
 		}
 		
    private:
    	Matrix<double> _m;
  };
  
  /**
   * RGB to XYZ colorspace conversion
   *
   * Conversion of 8-bits RGB pixels to XYZ values.
   * Defaults are sRGB color space and D65 Reference White.
   */
  template <>
  struct PixelConversion<RGB8,XYZ>
    : public std::unary_function<RGB8,XYZ>
  {
  	/**
  	 * Constructor
  	 * @param M color conversion matrix (default sRGB to D65)
  	 */  	 
   	PixelConversion(const Matrix<double> &M = sRGB2XYZD65) : _m(M) {}

   /// conversion
    XYZ operator()(const RGB8& p) const
    {
    	assert(_m.rows()==3);
    	assert(_m.columns()==3);

			double r = p.red/255.0;
			double g = p.green/255.0;
			double b = p.blue/255.0;
			
			return XYZ(
				_m[0][0] * r + _m[0][1] * g + _m[0][2] * b,
				_m[1][0] * r + _m[1][1] * g + _m[1][2] * b,
				_m[2][0] * r + _m[2][1] * g + _m[2][2] * b
			);
 		}
 		
    private:
    	Matrix<double> _m;
  };

  // comparisons

  /// equality
  template <typename T>
  bool operator==(const xyz<T>& a,const xyz<T>& b)
  {
    return a.x == b.x &&
           a.y == b.y &&
           a.z == b.z;
  }

  /// inequality
  template <typename T>
  bool operator!=(const xyz<T>& a,const xyz<T>& b)
  {
    return !(a == b);
  }

  /*@}*/

} // namespace ivllib

#endif // ivllib_xyz_h
