/**
 * \file    pixel.h
 * \brief   definitions for grayscale and generic pixels
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef pixel_h
#define pixel_h

#include <functional> // unary_function
#include <ivl_matrix.h>


namespace ivllib
{
  /** \addtogroup color */
  /*@{*/

  /// Pixel type with 256 different graylevels
  typedef unsigned char Gray8;

  // Conversions between pixels

  /** \cond detail */
  namespace detail
  {
    template <typename From,typename To>
    class is_convertible
    {
    private:
      typedef char yes;
      struct no { yes unused[2]; };
      template <typename T> struct checker
      {
	static yes test(T);
	static no  test(...);
      };
      static From makeFrom();
    public:
      static const bool value = (sizeof(checker<To>::test(makeFrom())) == sizeof(yes));
    };

    template <typename From,typename To,bool b>
    struct DefaultPixelConversion
    {
      // conversion not defined
    };

    template <typename From,typename To>
    struct DefaultPixelConversion<From,To,true>
      : public std::unary_function<From,To>
    {
      To operator()(From p) const
      {
	return p;
      }
    };
  } // namespace detail
  /** \endcond */

  /**
   * Conversion of pixels
   *
   * The functor convert a pixel of type From
   * in a pixel of type to.
   * By default:
   * - if there is an implicit conversion from \p From to \p To
   *   that conversion is applied
   * - if there is not such a conversion, PixelConversion does not
   *   define the appropriate \p operator(). A compile-time error
   *   occurs if such a conversion is required.
   *
   * Specialized conversions can be supplied providing a specialization
   * of the template PixelConversion.
   */
  template <typename From,typename To>
  struct PixelConversion
    : detail::DefaultPixelConversion<From,To,detail::is_convertible<From,To>::value>
  {
  };

  /**
   * Conversion of a pixel
   *
   * Equivalent to <tt>PixelConversion<From,To>()(p)</tt>,
   * but the \p From template parameter may be
   * deduced from \p p.
   */
  template <typename To,typename From>
  To pixel_cast(From p)
  {
    return PixelConversion<From,To>()(p);
  }

  // specialized conversions:

  /**
   * Floating point to eight bits gray conversion
   *
   * Values are clamped in the range 0-255.
   */
  template <>
  struct PixelConversion<double,Gray8>
  {
    /// conversion
    Gray8 operator()(double x) const
    {
      return x >= 0.0 ? (x <= 255.0 ? static_cast<Gray8>(x) : 255) : 0;
    }
  };

  /**
   * Floating point to eight bits gray conversion
   *
   * Values are clamped in the range 0-255.
   */
  template <>
  struct PixelConversion<float,Gray8>
  {
    /// conversion
    Gray8 operator()(float x) const
    {
      return x >= 0.0f ? (x <= 255.0f ? static_cast<Gray8>(x) : 255) : 0;
    }
  };

  
  /**
   * Compute the luminance of a pixel.
   *
   * For <tt>Gray8</tt> this is the identity function.
   */
  inline Gray8 luminance(Gray8 x)
  {
    return x;
  }


  // blending

  /**
   * Blending functor
   *
   * The functor mix the values of two pixels
   * according to the parameter \p f in the range [0,1].
   *
   * <tt>Blend()(a,b,0.0) == b</tt> and <tt>Blend()(a,b,1.0) == a</tt>
   *
   * The functor is linear in \p f.
   */
  template <typename T>
  struct Blend
  {
    /// blend two pixels
    T operator()(const T& a,const T& b,double f) const
    {
      return pixel_cast<T>(f*a + (1-f)*b);
    }
  };


  // basic image operations

  /**
   * Convert an image.
   *
   * Convert \a src to \a dst according to <tt>PixelConversion<From,
   * To></tt>.  A suitable pixel conversion must have been declared.
   *
   * \param src input image
   * \param dst output image
   *
   * \post dst.rows() == src.rows()
   * \post dst.columns() == src.columns()
   */
  template <typename From, typename To>
  void convert_image(const Matrix<From>& src,
		     Matrix<To>& dst)
  {
    typedef typename Matrix<From>::size_type size_type;

    size_type n = src.rows();
    size_type m = src.columns();

    PixelConversion<From, To> convert;
    Matrix<To> temp(n, m);

    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
	temp[i][j] = convert(src[i][j]);

    dst.swap(temp);
  }
  
  
  /**
   * Compute the luminance image.
   *
   * Convert \a src to \a dst according to the overloaded
   * <tt>luminance</tt> function.
   *
   * \param src input image
   * \param dst output luminance image
   *
   * \post dst.rows() == src.rows()
   * \post dst.columns() == src.columns()
   */
  template <typename From, typename To>
  void luminance_image(const Matrix<From>& src,
		       Matrix<To>& dst)
  {
    typedef typename Matrix<From>::size_type size_type;

    size_type n = src.rows();
    size_type m = src.columns();

    Matrix<To> temp(n, m);

    for (size_type i = 0; i < n; i++)
      for (size_type j = 0; j < m; j++)
	temp[i][j] = luminance(src[i][j]);

    dst.swap(temp);
  }
  


  /*@{*/
  
} // namespace ivllib

#endif
