#ifndef feature_computer_h
#define feature_computer_h

#include <framework/basic_feature_computer.h>

#include <ivl_matrix.h>
#include <imaging/rgb.h>


class FeatureComputer
  : public BasicFeatureComputer
{
public:
  FeatureComputer();

protected:
  typedef ivllib::Matrix<ivllib::RGB8> RGBImage;

  virtual void do_setup_options(cc::OptionParser& parser);

  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images);
  
  void do_process_image(const std::string& filename,
			Features& features) const;

  virtual void do_preprocessing(const RGBImage& in,
				RGBImage& out) const;

  virtual void do_compute_feature(const RGBImage& in,
				  Features& features) const = 0;

private:

  bool parse_resampling_(const std::string& s);
  static void load_image_list_(const std::string fname,
			       ImageList& lst);


  bool ignore_errors_;
  RGBImage::size_type width_;
  RGBImage::size_type height_;
  enum {
    rt_none,
    rt_full,
    rt_width,
    rt_height,
    rt_longest,
    rt_shortest,
  } resample_type_;
  int nthreads_;

};  // class FeatureComputer

#endif  // feature_computer_h
