#ifndef box_feature_computer_h
#define box_feature_computer_h

#include <framework/feature_computer.h>

#include <ivl_box.h>
#include <vector>
#include <cassert>


class BasicBoxFeatureComputer
  : public FeatureComputer
{
public:
  BasicBoxFeatureComputer();

protected:

  virtual void do_setup_options(cc::OptionParser& parser);

  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images);

protected:

  RGBImage::size_type hblocks() const;
  RGBImage::size_type vblocks() const;

private:

  bool parse_blocks_(const std::string& s);

  RGBImage::size_type hblocks_;
  RGBImage::size_type vblocks_;
  bool allow_pyramid_;
  bool pyramid_;

};  // class BasicBoxFeatureComputer


template <typename T>
class BoxFeatureComputer
  : public BasicBoxFeatureComputer
{
protected:
  typedef ivllib::Matrix<T> PreImage;

  void do_compute_feature(const RGBImage& in,
			  Features& features) const;

  virtual void do_compute_preimage(const RGBImage& in,
				   PreImage& out) const = 0;

  virtual void do_compute_block_feature(PreImage& in,
					const ivllib::Box& box,
					Features& features) const = 0;
  
};  // class BoxFeatureComputer



template <typename T>
void
BoxFeatureComputer<T>::do_compute_feature(const RGBImage& in,
					  Features& features) const
{
  typedef typename PreImage::size_type size_type;
  PreImage img;
  this->do_compute_preimage(in, img);

  size_type n = img.rows();
  size_type m = img.columns();

  RGBImage::size_type h = hblocks();
  RGBImage::size_type v = vblocks();

  assert(h > 0);
  assert(v > 0);

  size_type bwidth = (m + h - 1) / h;
  size_type bheight = (n + v - 1) / v;

  std::vector<Features> bfeatures(h * v);
  std::vector<Features>::size_type k = 0;
  Features::size_type sz = 0;
  for (size_type i = 0; i < n; i += bheight) {
    for (size_type j = 0; j < m; j += bwidth) {
      size_type bottom = std::min(n, i + bheight);
      size_type right = std::min(m, j + bwidth);
      do_compute_block_feature(img,
			       ivllib::Box(i, j, bottom, right),
			       bfeatures[k]);
      sz += bfeatures[k].size();      
      ++k;
    }
  }

  
  Features temp(sz);
  Features::iterator it = temp.begin();
  for (k = 0; k < bfeatures.size(); k++)
    it = std::copy(bfeatures[k].begin(),
		   bfeatures[k].end(),
		   it);
  
  features.swap(temp);
}

#endif  // box_feature_computer_h
