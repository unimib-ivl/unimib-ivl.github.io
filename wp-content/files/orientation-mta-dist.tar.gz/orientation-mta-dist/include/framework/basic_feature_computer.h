#ifndef basic_feature_computer_h
#define basic_feature_computer_h

#include <string>
#include <vector>

#include <ivl_vector.h>
#include <options/option_parser.h>


/**
 * - No options
 * - No processing
 */
class BasicFeatureComputer
{
public:
  BasicFeatureComputer();
  virtual ~BasicFeatureComputer();

  void set_usage(const std::string& usage);

  void set_threads(int n);

  int run(int argc, char* argv[]);

protected:
  typedef ivllib::Vector<double> Features;
  typedef std::vector<std::string> ImageList;

  virtual void do_setup_options(cc::OptionParser& parser);
  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images);
  virtual void do_process_image(const std::string& filename,
				Features& features) const = 0;
  virtual void do_output(const Features& features);

private:
  /// Deny copy.
  BasicFeatureComputer(const BasicFeatureComputer&);

  /// Deny assignement.
  BasicFeatureComputer& operator=(const BasicFeatureComputer&);

  void run_(int argc, char* argv[]);

  void process_images_single_(const ImageList& images);
  void process_images_multi_(const ImageList& images);

  struct Processor;
  friend struct Processor;

  std::string usage_;
  int threads_;

};  // BasicFeatureComputer


#endif  //basic_feature_computer_h


// void FeatureComputer<T>::process_image_(const std::string& filename,
// 					Features& features) const
// {
//   load_image(filename, rgb);
//   do_preprocessing(rgb, rgb);
//   do_convert(rgb, img);
//   do_compute_feature(img, features);
// }



// // setup
// // for ... load image
