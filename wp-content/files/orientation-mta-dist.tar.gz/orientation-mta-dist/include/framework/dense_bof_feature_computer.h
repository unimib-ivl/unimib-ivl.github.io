#ifndef dense_bof_feature_computer_h
#define dense_bof_feature_computer_h

#include <framework/feature_computer.h>

#include <ivl_box.h>
#include <vector>
#include <cassert>


class DenseBofFeatureComputer
  : public FeatureComputer
{
public:
  DenseBofFeatureComputer();

protected:

  virtual void do_setup_options(cc::OptionParser& parser);

  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images);

protected:

  typedef ivllib::Vector<float> Descriptor;
  
  void do_compute_feature(const RGBImage& in,
			  Features& features) const;

  virtual void do_compute_descriptors(const RGBImage& in,
				      ivllib::Matrix<Descriptor>& out) const=0;

private:

  typedef std::vector<Descriptor> Codebook;

  static void load_codebook_(const std::string& filename, Codebook& codebook);
  unsigned short find_descriptor_(const Descriptor& desc) const;

  Codebook codebook_;
  unsigned int levels_;
  bool unnormalized_;

};  // class DenseBofFeatureComputer


#endif  // dense_bof_feature_computer_h
