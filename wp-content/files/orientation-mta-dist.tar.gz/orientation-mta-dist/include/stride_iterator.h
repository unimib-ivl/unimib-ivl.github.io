/**
 * \file    stride_iterator.h
 * \brief   definition of the stride_iterator class
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef stride_iterator_h
#define stride_iterator_h

/**
 * \example stride_iterators.cpp
 *
 * Example on how to use stride iterators
 */

//--- Headers --------------------------------------------------------
#include <iterator> // iterator_traits
#include <cassert>  // assert

//--- Classes --------------------------------------------------------

namespace ivllib
{
  /** \addtogroup basic */
  /*@{*/

  /**
   * Stride iterator class
   *
   * StrideIterator is na iterator adaptor which
   * traverses the elements pointed by a base iterator.
   *
   * An increment of the stride iterator corresponds to
   * an advancement of a fixed step in the underlying sequence
   * traversed by the base iterator.
   *
   * The RaIter type must be a random access iterator.
   */
  template <typename RaIter>
  class StrideIterator
  {
  public:
    //--- Type definitions ----

    /// type of the base iterator
    typedef RaIter base_iterator;

    /// traits of the base iterator
    typedef std::iterator_traits<RaIter> base_traits;

    /// must be std::random_access_iterator_tag
    typedef typename base_traits::iterator_category iterator_category;

    /// same value_type of the base iterator
    typedef typename base_traits::value_type value_type;

    /// same difference_type of the base iterator
    typedef typename base_traits::difference_type difference_type;

    /// same pointer type of the base iterator
    typedef typename base_traits::pointer pointer;

    /// same reference type of the base iterator
    typedef typename base_traits::reference reference;


    //--- Methods -------------
    StrideIterator(); ///< Default constructor

    /**
     * Creates a new StrideIterator.
     *
     * Creates a new StrideIterator starting from a given base
     * iterator and a using a given step.
     */
    StrideIterator(const base_iterator& abase, difference_type astep);

    /// Conversion between stride iterators
    template <typename RaIter2>
    StrideIterator(const StrideIterator<RaIter2>& other);

    /// Conversion between stride iterators
    template <typename RaIter2>
    StrideIterator& operator=(const StrideIterator<RaIter2>& other);

    // default copy, assignement, destructor

    /// Returns the pointed element
    reference operator*() const;

    /// Returns the equivalent base iterator
    base_iterator operator->() const;

    /// Access to an element of the underlying sequence
    reference operator[](difference_type n) const;

    StrideIterator& operator++();   ///< Pre-increment
    StrideIterator operator++(int); ///< Post-increment
    StrideIterator& operator--();   ///< Pre-decrement
    StrideIterator operator--(int); ///< Post-decrement

    /// Advances the iterator by <tt>n</tt>
    StrideIterator& operator+=(difference_type n);

    /// Advances the iterator by <tt>-n</tt>
    StrideIterator& operator-=(difference_type n);

    /// Difference of two StrideIterators
    difference_type operator-(const StrideIterator& iter) const;

    bool operator==(const StrideIterator& iter) const; ///< Equivalence test
    bool operator<(const StrideIterator& iter) const;  ///< Comparison

    // needed for conversion construction and assignement
    template <typename RaIter2> friend class StrideIterator;

  private:
    //--- Attributes ----------

    /// The base iterator
    base_iterator base_;

    /// Current offset with respect to the base iterator
    difference_type offset_;

    /// The step
    difference_type step_;
  };


  //--- StrideIterator - External operators and functions --------------

  /// Returns the advancement of <tt>iter</tt> by <tt>n</tt>
  template <typename RaIter>
  StrideIterator<RaIter>
  operator+(const StrideIterator<RaIter>& iter,
	    typename StrideIterator<RaIter>::difference_type n)
  {
    StrideIterator<RaIter> ret(iter);
    ret += n;
    return ret;
  }

  /// Returns the advancement of <tt>iter</tt> by <tt>n</tt>
  template <typename RaIter>
  StrideIterator<RaIter>
  operator+(typename StrideIterator<RaIter>::difference_type n,
	    const StrideIterator<RaIter>& iter)
  {
    return iter + n;
  }

  /// Returns the advancement of <tt>iter</tt> by <tt>-n</tt>
  template <typename RaIter>
  StrideIterator<RaIter>
  operator-(const StrideIterator<RaIter>& iter,
	    typename StrideIterator<RaIter>::difference_type n)
  {
    StrideIterator<RaIter> ret(iter);
    ret -= n;
    return ret;
  }

  /// Inequality test: <tt>a!=b</tt> iff <tt>!(a==b)</tt>.
  template <typename RaIter>
  bool
  operator!=(const StrideIterator<RaIter>& a,
	     const StrideIterator<RaIter>& b)
  {
    return !(a==b);
  }

  /// Comparison
  template <typename RaIter>
  bool operator>(const StrideIterator<RaIter>& a,
		 const StrideIterator<RaIter>& b)
  {
    return b < a;
  }

  /// Comparison
  template <typename RaIter>
  bool operator<=(const StrideIterator<RaIter>& a,
		 const StrideIterator<RaIter>& b)
  {
    return !(b < a);
  }

  /// Comparison
  template <typename RaIter>
  bool operator>=(const StrideIterator<RaIter>& a,
		 const StrideIterator<RaIter>& b)
  {
    return !(a < b);
  }
  
  /// Utility function used to create StrideIterators.
  template <typename RaIter>
  StrideIterator<RaIter> make_stride_iterator(const RaIter& abase,
					      typename StrideIterator<RaIter>::difference_type astep)
  {
    return StrideIterator<RaIter>(abase,astep);
  }

  //--- StrideIterator - public - methods ------------------------------
  template <typename RaIter>
  StrideIterator<RaIter>::StrideIterator()
    : base_(),
      offset_(),
      step_(1)
  {
  }

  /**
   * <tt>(StrideIterator<Iter>(base,n) + k)</tt> is equivalent to
   * <tt>StrideIterator<Iter>(base+k*n,n)</tt>, provided that
   * <tt>base+k*n</tt> is a valid iterator.  If <tt>iter</tt> is a
   * random access iterator of type <tt>Iter</tt> then
   * <tt>iter+k*n</tt> points to the same element of
   * <tt>StrideIterator<Iter>(iter)+n</tt>.
   * <tt>StrideIterator<Iter>(base,n) + k</tt> is a valid iterator
   * even when <tt>base+k*n</tt> is not valid.  However the
   * StrideIterator can be dereferenced only if the corresponding base
   * iterator is dereferenceable.
   *
   * Note that the step may be negative, in this case the order of
   * iteration is reversed.
   *
   * \param abase the base iterator
   * \param astep the step
   *
   * \pre <tt>astep != 0 </tt>
   */
 template <typename RaIter>
 StrideIterator<RaIter>::StrideIterator(const base_iterator& abase,
					difference_type astep)
   : base_(abase),
     offset_(0),
     step_(astep)
 {
   assert(astep != 0);
 }

  /**
   * RaIter2 must be convertible to RaIter (for example, RaIter =
   * const T* and RaIter2 = T*).
   */
  template <typename RaIter> template <typename RaIter2>
  StrideIterator<RaIter>::StrideIterator(const StrideIterator<RaIter2>& other)
    : base_(other.base_),
      offset_(other.offset_),
      step_(other.step_)
  {
  }

  /**
   * RaIter2 must be convertible to RaIter (for example, RaIter =
   * const T* and RaIter2 = T*).
   */
  template <typename RaIter> template <typename RaIter2>
  StrideIterator<RaIter>&
  StrideIterator<RaIter>::operator=(const StrideIterator<RaIter2>& other)
  {
    base_ = other.base_;
    offset_ = other.offset_;
    step_ = other.step_;
  }


  /**
   * \pre the underlying equivalent base iterator must be a valid
   * iterator
   */
  template <typename RaIter>
  typename StrideIterator<RaIter>::reference
  StrideIterator<RaIter>::operator*() const
  {
    return *(base_ + offset_);
  }

  /**
   * \pre the underlying equivalent base iterator must be a valid iterator
   */
  template <typename RaIter>
  typename StrideIterator<RaIter>::base_iterator
  StrideIterator<RaIter>::operator->() const
  {
    return base_ + offset_;
  }

  /**
   * if <tt>s</tt> is stride iterator then <tt>s[n]</tt> is equivalent
   * to <tt>*(base+n)</tt>.
   */
  template <typename RaIter>
  typename StrideIterator<RaIter>::reference
  StrideIterator<RaIter>::operator[](difference_type n) const
  {
    return *(base_ + (offset_ + (n * step_)));
  }

  template <typename RaIter>
  StrideIterator<RaIter>&
  StrideIterator<RaIter>::operator++()
  {
    offset_ += step_;
    return *this;
  }

  template <typename RaIter>
  StrideIterator<RaIter>
  StrideIterator<RaIter>::operator++(int)
  {
    StrideIterator<RaIter> ret(*this);
    ++(*this);
    return ret;
  }

  template <typename RaIter>
  StrideIterator<RaIter>&
  StrideIterator<RaIter>::operator--()
  {
    offset_ -= step_;
    return *this;
  }

  template <typename RaIter>
  StrideIterator<RaIter>
  StrideIterator<RaIter>::operator--(int)
  {
    StrideIterator<RaIter> ret(*this);
    --(*this);
    return ret;
  }

  template <typename RaIter>
  StrideIterator<RaIter>&
  StrideIterator<RaIter>::operator+=(difference_type n)
  {
    offset_ += step_*n;
    return *this;
  }

  template <typename RaIter>
  StrideIterator<RaIter>&
  StrideIterator<RaIter>::operator-=(difference_type n)
  {
    offset_ -= step_*n;
    return *this;
  }

  /**
   * \pre the two iterators must have the same step
   */
  template <typename RaIter>
  typename StrideIterator<RaIter>::difference_type
  StrideIterator<RaIter>::operator-(const StrideIterator& iter) const
  {
    assert(step_ == iter.step_);
    return ((base_ - iter.base_) + (offset_ - iter.offset_))/step_;
  }

  /**
   * Two StrideIterators are considered equals when are equals the
   * corresponding base iterators
   */
  template <typename RaIter>
  bool
  StrideIterator<RaIter>::operator==(const StrideIterator& iter) const
  {
    return (base_ - iter.base_) + (offset_ - iter.offset_) == 0;
  }

  template <typename RaIter>
  bool
  StrideIterator<RaIter>::operator<(const StrideIterator& iter) const
  {
    return (*this - iter) < 0;
  }

  /*@}*/

} // namespace ivllib

#endif
