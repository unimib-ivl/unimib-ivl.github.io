/**
 * \file    ivl_box.h
 * \brief   generic 2D/3D box
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#ifndef ivl_box_h
#define ivl_box_h

#include <cassert>
#include <cstddef>
#include "numerical/vector2.h"
#include "numerical/vector3.h"


//undef near and far defined in win32 headers for 16-bit applications.
#ifdef near
#undef near
#endif

#ifdef far
#undef far
#endif


namespace ivllib
{  
  /** \addtogroup basic */
  /*@{*/

  /**
   * A generic axis aligned rectangular box in 2 dimensions
   *
   * \invariant top() <= bottom()
   * \invariant left() <= right()
   */
  template<typename T>
  class GenericBox2D
  {
  public:

    /// type of the coordinates
    typedef T size_type;

    /// default constructor
    GenericBox2D()
      : top_(0),
	left_(0),
	bottom_(0),
	right_(0)
    {
    }
      
    /**
     * constructor
     *
     * \pre atop <= abottom
     * \pre aleft <= aright
     */
    GenericBox2D(size_type atop,
		 size_type aleft,
		 size_type abottom,
		 size_type aright)
      : top_(atop),
	left_(aleft),
	bottom_(abottom),
	right_(aright)
    {
      assert(atop <= abottom);
      assert(aleft <= aright);
    }

    // default copy, assignement, and destructor

    /**
     * Implicit conversion between different types of boxes.
     */
    template <typename U>
    GenericBox2D(const GenericBox2D<U>& other)
    {
      top_=static_cast<T>(other.top());
      left_=static_cast<T>(other.left());
      right_=static_cast<T>(other.right());
      bottom_=static_cast<T>(other.bottom());
    }

    /**
     * Assignement between different types of boxes.
     */
    template <typename U>
    GenericBox2D& operator=(const GenericBox2D<U>& other)
    {
      if (&other != this)
	{
	  top_=static_cast<T>(other.top());
	  left_=static_cast<T>(other.left());
	  right_=static_cast<T>(other.right());
	  bottom_=static_cast<T>(other.bottom());
	}
      return *this;
    }
    
    // accessors

    size_type top() const { return top_; } ///< first row of the box
    size_type left() const { return left_; }  ///< first column of the box
    size_type bottom() const { return bottom_; } ///< one past the last row of the box
    size_type right() const { return right_; }  ///< one past the last column of the box

    size_type width() const { return right_ - left_; }  ///< <tt>right() - left()</tt>
    size_type height() const { return bottom_ - top_; } ///< <tt>bottom() - top()</tt>

    size_type area() const { return width() * height(); } ///< <tt>width()*height()</tt>

    /// compute the centroid
    Vector2<T> centroid() const 
    { 
      return Vector2<T>((right_ + left_) / 2, 
			(bottom_ + top_) / 2);
    }

  private:
    size_type top_;    ///< top coordinate 
    size_type left_;   ///< left coordinate
    size_type bottom_; ///< bottom coordinate
    size_type right_;  ///< right coordinate
  };

  // comparisons

  /// equality
  template<typename T>
  inline bool operator==(const GenericBox2D<T>& a,const GenericBox2D<T>& b)
  {
    return a.top() == b.top() &&
      a.left() == b.left() &&
      a.bottom() == b.bottom() &&
      a.right() == b.right();
  }

  /// inequality
  template<typename T>
  inline bool operator!=(const GenericBox2D<T>& a,const GenericBox2D<T>& b)
  {
    return !(a == b);
  }

  /**
   * A rectangular box in 2D image space
   */
  typedef GenericBox2D<std::size_t> Box;

  /**
   * A generic axis aligned box in 3 dimensions
   *
   * \invariant top() <= bottom()
   * \invariant left() <= right()
   * \invariant near() <= far()   
   */
  template<typename T>
  class GenericBox3D
  {
  public:

    /// type of the coordinates
    typedef T size_type;

    /// default constructor
    GenericBox3D()
      : top_(0),
	left_(0),
	bottom_(0),
	right_(0),
	near_(0),
	far_(0)
    {
    }
      
    /**
     * constructor
     *
     * \pre atop <= abottom
     * \pre aleft <= aright
     * \pre anear <= afar
     */
    GenericBox3D(size_type atop,
		 size_type aleft,
		 size_type anear,
		 size_type abottom,
		 size_type aright,
		 size_type afar)
      : top_(atop),
	left_(aleft),
	bottom_(abottom),
	right_(aright),
	near_(anear),
	far_(afar)
    {
      assert(atop <= abottom);
      assert(aleft <= aright);
      assert(anear <= afar);
    }

    /**
     * Implicit conversion between different types of boxes.
     */
    template <typename U>
    GenericBox3D(const GenericBox3D<U>& other)
    {
      top_=static_cast<T>(other.top());
      left_=static_cast<T>(other.left());
      right_=static_cast<T>(other.right());
      bottom_=static_cast<T>(other.bottom());
      near_=static_cast<T>(other.near());
      far_=static_cast<T>(other.far());
    }

    /**
     * Assignement between different types of boxes.
     */
    template <typename U>
    GenericBox3D& operator=(const GenericBox3D<U>& other)
    {
      if (&other != this)
	{
	  top_=static_cast<T>(other.top());
	  left_=static_cast<T>(other.left());
	  right_=static_cast<T>(other.right());
	  bottom_=static_cast<T>(other.bottom());
	  near_=static_cast<T>(other.near());
	  far_=static_cast<T>(other.far());
	}
      return *this;
    }
        
    // accessors

    size_type top() const { return top_; } ///< first row of the box
    size_type left() const { return left_; } ///< first column of the box
    size_type bottom() const { return bottom_; } ///< one past the last row of the box
    size_type right() const { return right_; }  ///< one past the last column of the box
    size_type near() const { return near_; } ///< first plane of the box
    size_type far() const { return far_; }  ///< one past the last plane of the box

    size_type width() const { return right_ - left_; }  ///< <tt>right() - left()</tt>
    size_type height() const { return bottom_ - top_; } ///< <tt>bottom() - top()</tt>
    size_type depth() const { return far_ - near_; }    ///< <tt>far() - near()</tt>

    /// <tt> width()*height()*depth() </tt>
    size_type volume() const { return width() * height() * depth(); }

    /// compute the centroid of the box
    Vector3<T> centroid() const 
    { 
      return Vector3<T>((right_ + left_) / 2, 
			(bottom_ + top_) / 2,
			(far_ + near_) / 2);
    }

  private:
    size_type top_;    ///< top coordinate 
    size_type left_;   ///< left coordinate
    size_type bottom_; ///< bottom coordinate
    size_type right_;  ///< right coordinate
    size_type near_; ///< near coordinate
    size_type far_;  ///< far coordinate
  };

  // comparisons

  /// equality
  template<typename T>
  inline bool operator==(const GenericBox3D<T>& a,const GenericBox3D<T>& b)
  {
    return a.top() == b.top() &&
      a.left() == b.left() &&
      a.bottom() == b.bottom() &&
      a.right() == b.right() &&
      a.near() == b.near() &&
      a.far() == b.far();
  }

  /// inequality
  template<typename T>
  inline bool operator!=(const GenericBox3D<T>& a,const GenericBox3D<T>& b)
  {
    return !(a == b);
  }

  /*@}*/
} // ivllib

#endif

