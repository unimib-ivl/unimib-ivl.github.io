/**
 * \file    bmp_io.cpp
 * \brief   io routines for the bmp graphic format
 * \author  $LastChangedBy: cusano $
 * \date    $Date$
 * \version $Revision: 67 $
 */

#include <mat_algorithm.h>
#include <imaging/bmp_io.h>
#include <imaging/exception_io.h>
#include <imaging/basic_transform.h>

#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>

namespace ivllib {

  namespace
  {
    typedef std::vector<RGB8> bmp_palette;

    struct bmp_header
    {
      unsigned long type;             // 2 bytes
      unsigned long file_size;        // 4 bytes
      unsigned long reserved1;        // 2 bytes
      unsigned long reserved2;        // 2 bytes
      unsigned long offset;           // 4 bytes
      unsigned long header_size;      // 4 bytes
      unsigned long width;            // 4 bytes
      long height;                    // 4 bytes
      unsigned long planes;           // 2 bytes
      unsigned long bits_per_pixel;   // 2 bytes
      unsigned long compression;      // 4 bytes
      unsigned long image_size;       // 4 bytes
      unsigned long x_resolution;     // 4 bytes
      unsigned long y_resolution;     // 4 bytes
      unsigned long colors_used;      // 4 bytes
      unsigned long colors_important; // 4 bytes
    };

    unsigned long read1byte(std::istream& is);
    unsigned long read2bytes(std::istream& is);
    unsigned long read4bytes(std::istream& is);
    long read4signedbytes(std::istream& is);

    void read_header(std::istream& is,bmp_header& out);
    void read_palette(std::istream& is,
		      unsigned long bpp, // bits per pixel
		      bmp_palette& out);

    void bmp_read_pixels_24(std::istream& is,
			    const bmp_header& header,
			    Matrix<RGB8>& out);

    void bmp_read_pixels_N(std::istream& is,
			   const bmp_header& header,
			   const bmp_palette& palette,
			   Matrix<RGB8>& out);
  }

  void load_bmp(const std::string& filename,Matrix<RGB8>& out)
  {
    std::ifstream file(filename.c_str(),std::ios::binary);

    if (!file)
      throw ImageFileError("load_bmp: error opening the image file");
    
    bmp_header header;
    read_header(file,header);
    
    bmp_palette palette;
    read_palette(file,header.bits_per_pixel,palette);
    
    if (header.bits_per_pixel == 24)
      bmp_read_pixels_24(file,header,out);
    else
      bmp_read_pixels_N(file,header,palette,out); // 1,4, or 8 bits per pixel
  }

  void load_bmp(const std::string& filename,Matrix<RGBA8>& out)
  {
    Matrix<RGB8> tmp;
    load_bmp(filename,tmp);
    Matrix<RGBA8> res(tmp.rows(),tmp.columns());
    mat_transform(tmp,res,PixelConversion<RGB8,RGBA8>());
    out.swap(res);
  }

  namespace
  {
    unsigned long read1byte(std::istream& is)
    {
      unsigned char c = is.get();
      if (!is) {
	if (is.eof())
	  throw ImageFormatError("load_bmp: unexpected end of file");
	else
	  throw ImageFileError("load_bmp: error reading from file");
      }
      return c;
    }

    unsigned long read2bytes(std::istream& is)
    {
      unsigned long ret = read1byte(is);
      ret += 256 * read1byte(is);
      return ret;
    }

    unsigned long read4bytes(std::istream& is)
    {
      unsigned long ret = read1byte(is);
      ret += 256 * read1byte(is);
      ret += 256 * 256 * read1byte(is);
      ret += 256 * 256 * 256 * read1byte(is);
      return ret;
    }

    long read4signedbytes(std::istream& is)
    {
      unsigned long tmp = read4bytes(is);
      // recover the sign. it shoulf work for both 32 and 64 bit long.
      return ((tmp >> 31) == 0 
	      ? static_cast<long>(tmp)
	      : static_cast<long>(tmp - (1U << 31)) - (1U << 31));
    }

    void read_header(std::istream& is,bmp_header& out)
    {
      out.type = read2bytes(is);
      if (out.type != 0x4D42) // magic number
	throw ImageFormatError("load_bmp: not a bitmap");
      
      out.file_size = read4bytes(is);
      out.reserved1 = read2bytes(is);
      out.reserved2 = read2bytes(is);
      out.offset = read4bytes(is);
      out.header_size = read4bytes(is);
      out.width = read4bytes(is);
      out.height = read4signedbytes(is);
      out.planes = read2bytes(is);
      out.bits_per_pixel = read2bytes(is);
      if (out.bits_per_pixel != 1 &&
	  out.bits_per_pixel != 4 &&
	  out.bits_per_pixel != 8 &&
	  out.bits_per_pixel != 24)
	throw ImageFormatError("load_bmp: invalid number of bits per pixel");
      out.compression = read4bytes(is);
      if (out.compression != 0)
	throw ImageFormatError("load_bmp: unsupported compression type");
      out.image_size = read4bytes(is);
      out.x_resolution = read4bytes(is);
      out.y_resolution = read4bytes(is);
      out.colors_used = read4bytes(is);
      out.colors_important = read4bytes(is);
    }
  
    void read_palette(std::istream& is,unsigned long bpp,bmp_palette& out)
    {
      out.clear();
      
      int n = 0;
      if (bpp == 1)
	n = 2;
      else if (bpp == 4)
	n = 16;
      else if (bpp == 8)
	n = 256;
      while (n-- > 0) {
	unsigned char blue = static_cast<unsigned char>(read1byte(is));
	unsigned char green = static_cast<unsigned char>(read1byte(is));
	unsigned char red = static_cast<unsigned char>(read1byte(is));
	read1byte(is); // reserverd
	out.push_back(RGB8(red,green,blue));
      }
    }

    void bmp_read_pixels_24(std::istream& is,
			    const bmp_header& header,
			    Matrix<RGB8>& out)
    {
      unsigned long height = std::abs(header.height);
      Matrix<RGB8> res(height, header.width);
      unsigned long read_count = 0;

      for (unsigned long i = 0; i < height; i++) {
	for (unsigned long j = 0; j < header.width; j++) {
	  res[height - i - 1][j].blue = read1byte(is);
	  res[height - i - 1][j].green = read1byte(is);
	  res[height - i - 1][j].red = read1byte(is);
	  read_count += 3;
	}
	while ((read_count % 4) != 0) {
	  read1byte(is);
	  ++read_count;
	}
      }

      if (header.height < 0)
	flip_vertically(res, res);

      out.swap(res);
    }


    void bmp_read_pixels_N(std::istream& is,
			   const bmp_header& header,
			   const bmp_palette& palette,
			   Matrix<RGB8>& out)
    {
      unsigned long height = std::abs(header.height);
      unsigned long bpp = header.bits_per_pixel;
      unsigned long mask = (1 << bpp) - 1;

      unsigned long read_count = 0;
      Matrix<RGB8> res(height, header.width);

      for (unsigned long i = 0; i < height; i++) {
	unsigned long bits = 0;
	unsigned long nbits = 0;

	for (unsigned long j = 0; j < header.width; j++) {
	  if (nbits == 0) {
	    bits = read1byte(is);
	    ++read_count;
	    nbits = 8;
	  }
	  unsigned long index = (bits >> (nbits - bpp)) & mask;
	  nbits -= bpp;
	  res[height - i - 1][j] = palette[index];
	}
	while ((read_count % 4) != 0) {
	  read1byte(is);
	  ++read_count;
	}
      }

      if (header.height < 0)
	flip_vertically(res, res);

      out.swap(res);
    }

  }  
} // ivllib
