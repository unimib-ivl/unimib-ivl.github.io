#include <framework/feature_computer.h>

#include <iostream>
#include <fstream>
#include <istream>
#include <cctype>
#include <cassert>
#include <imaging/image_io.h>
#include <imaging/resampling.h>

#include <stringop.h>


FeatureComputer::FeatureComputer()
  : BasicFeatureComputer(),
    ignore_errors_(false),
    width_(0),
    height_(0),
    resample_type_(rt_none)
{
}


void
FeatureComputer::do_setup_options(cc::OptionParser& parser)
{
  BasicFeatureComputer::do_setup_options(parser);

  parser.add_option(cc::Option("help", 'h', cc::Option::noparam,
			       "GENERAL OPTIONS",
			       "Display this message and exit"));

  parser.add_option(cc::Option("list", 'l', "FILENAME",
			       "GENERAL OPTIONS",
			       "process images specified in FILENAME "
			       "(1 image per row) before processing "
			       "arguments. Use '-' to read from the "
			       "standard input."));
  
  parser.add_option(cc::Option("ignore-errors", 'i', cc::Option::noparam,
			       "GENERAL OPTIONS",
			       "ignore errors while loading images"));
  
  parser.add_option(cc::Option("threads", 't', "N",
			       "GENERAL OPTIONS",
			       "Uses up to N concurrent threads (default 1)"
#ifndef ENABLE_MULTITHREADING
			       " [Multithreading not supported]"
#endif
			       ));

  parser.add_option(cc::Option("resize", 'r', "SIZE",
			       "GENERAL OPTIONS",
			       "Resample the image according to SIZE. "
			       "SIZE can specify: "
			       "the final resolution (e.g. 320x200); "
			       "the width (e.g. 320 or 320x); "
			       "the height (e.g. x200); "
			       "the longest side (e.g. 320>); "
			       "the shortest side (e.g. 200<); "
			       "no resampling (e.g. x) which is the default. "
			       "When a single dimension is specified the other "
			       "is computed to preserve the aspect ratio of the "
			       "image."));
}


void
FeatureComputer::do_parse_options(cc::OptionParser& parser,
				  const cc::ParsedOptions& options,
				  FeatureComputer::ImageList& images)
{
  BasicFeatureComputer::do_parse_options(parser, options, images);

  if (options.contains_option("help")) {
    parser.print_help();
    exit(EXIT_SUCCESS);
  }

  long nthreads = cc::str::tolong(options.parameter_value("threads", "1"), 0);
  if (nthreads < 1)
    parser.error("Invalid value for option 'threads'");
  this->set_threads(nthreads);

  ignore_errors_ = options.contains_option("ignore-errors");

  if (!parse_resampling_(options.parameter_value("resize", "x")))
    parser.error("Invalid value for option 'resize'");

  ImageList lst;
  if (options.contains_option("list"))
    load_image_list_(options.parameter_value("list", "-"), lst);
  lst.insert(lst.end(), options.begin_args() + 1, options.end_args());

  lst.swap(images);
}


void
FeatureComputer::do_process_image(const std::string& filename,
				  FeatureComputer::Features& features) const
{
  RGBImage rgb;
  
  try {
    ivllib::load_image(filename, rgb);
  } catch (...) {
    if (!ignore_errors_)
      throw;
    std::cerr << "Warning: error loading '" << filename << "'\n";
    RGBImage(128, 128, ivllib::RGB8(0, 0, 0)).swap(rgb);
  }
  this->do_preprocessing(rgb, rgb);
  this->do_compute_feature(rgb, features);
}


void
FeatureComputer::do_preprocessing(const FeatureComputer::RGBImage& in,
				  FeatureComputer::RGBImage& out) const
{
  if (resample_type_ == rt_none) {
    out = in;
    return;
  }
  if (resample_type_ == rt_full) {
    ivllib::bilinear_resampling(in, height_, width_, out);
    return;
  }

  RGBImage::size_type dim;
  ivllib::scaling_dimension sd;

  if (resample_type_ == rt_width) {
    sd = ivllib::scaling_dimension_width;
    dim = width_;
  } else if (resample_type_ == rt_height) {
    sd = ivllib::scaling_dimension_height;
    dim = height_;
  } else if (resample_type_ == rt_longest) {
    sd = ivllib::scaling_dimension_longest;
    dim = width_;
  } else {
    assert(resample_type_ == rt_shortest);
    sd = ivllib::scaling_dimension_shortest;
    dim = width_;
  }

  ivllib::bilinear_scaling(in, dim, out, sd);
}


bool
FeatureComputer::parse_resampling_(const std::string& str)
{
  std::string s = cc::str::strip(str);

  // 1) empty
  if (s.size() == 0)
    return false;

  // 2) 100<
  if (s[s.size() - 1] == '<') {
    width_ = cc::str::tolong(s.substr(0, s.size() - 1), 0);
    resample_type_ = rt_shortest;
    return (width_ > 0);
  }

  // 3) 100>
  if (s[s.size() - 1] == '>') {
    width_ = cc::str::tolong(s.substr(0, s.size() - 1), 0);
    resample_type_ = rt_longest;
    return (width_ > 0);
  }
  
  // 4) x
  if (s == "x") {
    resample_type_ = rt_none;
    return true;
  }
  
  std::string a;
  std::string b;
  std::string c;
  std::tr1::tie(a, b, c) = cc::str::partition(str, "x");

  width_ = cc::str::tolong(a, 0);
  height_ = cc::str::tolong(c, 0);

  // 5) x100, 200x, 200, or  200x100
  if (a.size() == 0) {
    resample_type_ = rt_height;
    return (height_ > 0);
  }
  if (c.size() == 0) {
    resample_type_ = rt_width;
    return (width_ > 0);
  }

  resample_type_ = rt_full;
  
  return (width_ > 0 && height_ > 0);
}


void
FeatureComputer::load_image_list_(const std::string fname,
				  FeatureComputer::ImageList& lst)
{
  std::ifstream infile;
  if (fname != "-") {
    infile.open(fname.c_str());
    if (!infile) {
      std::string msg = "Error opening '";
      msg += fname;
      msg += "'";
      throw std::runtime_error(msg);
    }
  }

  std::istream& is = (fname == "-" ? std::cin : infile);
  
  ImageList result;

  std::string line;
  while (std::getline(is, line)) {
    line = cc::str::strip(line);
    if (line.size() > 0)
      result.push_back(line);
  }

  result.swap(lst);
}

