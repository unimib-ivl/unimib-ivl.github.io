#include <framework/box_feature_computer.h>

#include <stringop.h>


BasicBoxFeatureComputer::BasicBoxFeatureComputer()
  : FeatureComputer(),
    hblocks_(1),
    vblocks_(1)
{
}


void
BasicBoxFeatureComputer::do_setup_options(cc::OptionParser& parser)
{
  FeatureComputer::do_setup_options(parser);

  parser.add_option(cc::Option("blocks", 'b', "BLOCKS",
			       "GENERAL OPTIONS",
			       "Specify a regular subdivision of the image in "
			       "blocks. For each block a feature vector will be "
			       "computed. The final feature is the concatenation "
			       "of the features of the blocks (from left to right "
			       "and from top to bottom). BLOCKS specifies a "
			       "the number of horizontal and vertical blocks "
			       "(e.g. '7x5'). BLOCKS can also be a single number "
			       "which, in that case, indicates an equal number of "
			       "blocks in both the directions. By default "
			       "BLOCKS is '1x1')."));
}


void
BasicBoxFeatureComputer::do_parse_options(cc::OptionParser& parser,
					  const cc::ParsedOptions& options,
					  ImageList& images)
{
  ImageList result;
  FeatureComputer::do_parse_options(parser, options, result);
  
  if (!parse_blocks_(options.parameter_value("blocks", "1")))
    parser.error("Invalid value for option 'blocks'");
  
  images.swap(result);
}


BasicBoxFeatureComputer::RGBImage::size_type
BasicBoxFeatureComputer::hblocks() const
{
  return hblocks_;
}


BasicBoxFeatureComputer::RGBImage::size_type
BasicBoxFeatureComputer::vblocks() const
{
  return vblocks_;
}


bool
BasicBoxFeatureComputer::parse_blocks_(const std::string& s)
{
  std::string a;
  std::string b;
  std::string c;
  std::tr1::tie(a, b, c) = cc::str::partition(s, "x");


  hblocks_ = cc::str::tolong(a, 0);
  if (hblocks_ < 1)
    return false;
  
  if (b.size() == 0) {
    vblocks_ = hblocks_;
  } else {
    vblocks_ = cc::str::tolong(c, 0);
  }

  return (vblocks_ > 0);
}



