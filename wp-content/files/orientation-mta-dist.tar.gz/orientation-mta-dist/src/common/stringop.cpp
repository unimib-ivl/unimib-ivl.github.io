#include <stringop.h>

#include <cctype>
#include <sstream>
#include <stdexcept>


typedef std::string::size_type size_type;


std::string
cc::str::capitalize(std::string s)
{
  size_type n = s.size();
  if (n > 0) {
    s[0] = std::toupper(s[0]);
    for (size_type i = 1; i < n; i++)
      s[i] = std::tolower(s[i]);
  }
  return s;
}


std::string
cc::str::center(const std::string& s,
		std::string::size_type width,
		char fillchar)
{
  size_type n = s.size();
  if (width <= n)
    return s;
  size_type left = (1 + width - n) / 2;

  std::string ret(width, fillchar);
  ret.replace(left, n, s);

  return ret;
}


std::string::size_type
cc::str::count(const std::string& s,
	       const std::string& sub,
	       std::string::size_type start,
	       std::string::size_type end)
{
  size_type len = sub.size();
  if (len == 0)
    return (1 + s.size());
  size_type n = 0;
  while (start < end) {
    start = s.find(sub, start);
    if (start < end) {
      start += len;
      ++n;
    }
  }
  return n;
}


std::string::size_type
cc::str::count(const std::string& s,
	       char c,
	       std::string::size_type start,
	       std::string::size_type end)
{
  if (s.size() < end)
    end = s.size();

  size_type n = 0;
  for (;start != end; start++)
    if (s[start] == c)
      ++n;

  return n;
}


bool
cc::str::endswith(const std::string& s,
		  const std::string& suffix)
{
  size_type n = s.size();
  size_type m = suffix.size();
  if (n < m)
    return false;
  size_type offset = n - m;
  for (size_type i = 0; i != m; i++)
    if (s[i + offset] != suffix[i])
      return false;
  return true;
}


std::string
cc::str::expandtabs(const std::string& s,
		    std::string::size_type tabsize)
{
  if (tabsize < 1)
    tabsize = 1;
  size_type col = 0;
  std::ostringstream os;

  size_type n = s.size();
  for (size_type i = 0; i < n; i++) {
    char c = s[i];
    if (c == '\t') {
      do {
	++col;
	os.put(' ');
      } while (col % tabsize != 0);
    } else {
      os.put(c);
      if (c == '\n')
	col = 0;
      else
	++col;
    }
  }
  return os.str();
}


std::string
cc::str::fromdouble(double x)
{
  std::ostringstream os;
  os << x;
  return os.str();
}


std::string
cc::str::fromlong(long n)
{
  std::ostringstream os;
  os << n;
  return os.str();
}


std::string
cc::str::ljust(const std::string& s,
	       std::string::size_type width,
	       char fillchar)
{
  size_type n = s.size();
  if (width <= n)
    return s;

  std::string ret(width, fillchar);
  ret.replace(0, n, s);

  return ret;
}


std::string
cc::str::lower(std::string s)
{
  size_type n = s.size();
  for (size_type i = 0; i < n; i++)
    s[i] = std::tolower(s[i]);
  return s;
}


std::string
cc::str::lstrip(const std::string& s,
		const std::string& chars)
{
  size_type n = s.size();
  size_type i = 0;

  if (chars.size() == 0) {
    while (i < n && std::isspace(s[i]))
      ++i;
  } else {
    while (i < n && chars.find(s[i]) != std::string::npos)
      ++i;
  }
  return s.substr(i);
}


std::tr1::tuple<std::string, std::string, std::string>
cc::str::partition(const std::string& s,
		   const std::string& sep)
{
  size_type i = s.find(sep);
  if (i == std::string::npos) {
    std::string empty = "";
    return std::tr1::make_tuple(s, empty, empty);
  }

  size_type n = sep.size();
  return std::tr1::make_tuple(s.substr(0, i),
			      sep,
			      s.substr(i + n));
}


std::string
cc::str::replace(const std::string& s,
		 const std::string& old,
		 const std::string& news,
		 std::string::size_type count)
{
  size_type n = old.size();
  size_type m = s.size();

  if (m == 0)
    return s;

  if (n == news.size()) {
    // Simple case, just copy and change the characters.
    std::string ret = s;
    size_type n = old.size();
    size_type i = 0;
    while (count > 0) {
      i = ret.find(old, i);
      if (i == std::string::npos)
	break;
      ret.replace(i, n, news);
      --count;
    }
    return ret;
  }

  std::ostringstream os;
  size_type i = 0;
  if (n == 0) {
    // Replace each space between chars.
    std::ostringstream oss;
    while (i < m && count > 0) {
      os << news << s[i];
      --count;
      ++i;
    }
    os << s.substr(i);
    return os.str();
  }

  while (i < m && count > 0) {
    size_type j = s.find(old, i);
    if (j == std::string::npos)
      break;
    os << s.substr(i, j - i);
    i = j + n;
    os << news;
    --count;
  }
  os << s.substr(i);
  return os.str();
}


std::string
cc::str::replace(std::string s,
		 char old,
		 char news,
		 std::string::size_type count)
{
  size_type n = s.size();
  for (size_type i = 0; i < n && count > 0; i++) {
    if (s[i] == old) {
      --count;
      s[i] = news;
    }
  }
  return s;
}


std::string
cc::str::rjust(const std::string& s,
	       std::string::size_type width,
	       char fillchar)
{
  size_type n = s.size();
  if (width <= n)
    return s;

  std::string ret(width, fillchar);
  ret.replace(width - n, n, s);

  return ret;
}


std::tr1::tuple<std::string, std::string, std::string>
cc::str::rpartition(const std::string& s,
		    const std::string& sep)
{
  size_type i = s.rfind(sep);
  if (i == std::string::npos) {
    std::string empty = "";
    return std::tr1::make_tuple(empty, empty, s);
  }

  size_type n = sep.size();
  return std::tr1::make_tuple(s.substr(0, i),
			      sep,
			      s.substr(i + n));
}


std::string
cc::str::rstrip(const std::string& s,
		const std::string& chars)
{
  size_type n = s.size();
  size_type i = n;

  if (chars.size() == 0) {
    while (i > 0 && std::isspace(s[i - 1]))
      --i;
  } else {
    while (i > 0 && chars.find(s[i - 1]) != std::string::npos)
      --i;
  }
  return s.substr(0, i);
}


cc::str::split::split(const std::string& s,
					const std::string& sep)
  : current_(""),
    base_(s),
    sep_(sep),
    next_(0)
{
  operator++();
}


cc::str::split&
cc::str::split::operator++()
{
  size_type n = base_.size();
  if (sep_.size() == 0) {
    while (next_ < n && std::isspace(base_[next_]))
      ++next_;
    if (next_ == n) {
      // Make it a past-the-end iterator.
      current_ = "";
      base_ = "";
      sep_ = "";
      next_ = std::string::npos;
    } else {
      size_type i = next_;
      while (next_ < n && !std::isspace(base_[next_]))
	++next_;
      current_ = base_.substr(i, next_ - i);
    }
  } else {
    if (next_ == n) {
      // Make it a past-the-end iterator.
      current_ = "";
      base_ = "";
      sep_ = "";
      next_ = std::string::npos;
    } else {
      size_type i = next_;
      next_ = base_.find(sep_, i);
      if (next_ == std::string::npos) {
	current_ = base_.substr(i);
	next_ = n;
      } else {
	current_ = base_.substr(i, next_ - i);
	next_ += sep_.size();
      }
    }
  }
  return *this;
}


bool
cc::str::startswith(const std::string& s,
		    const std::string& prefix)
{
  size_type n = prefix.size();
  if (s.size() < n)
    return false;
  for (size_type i = 0; i < n; i++)
    if (s[i] != prefix[i])
      return false;
  return true;
}


std::string
cc::str::strip(const std::string& s,
	       const std::string& chars)
{
  size_type from = 0;
  size_type to = s.size();
  if (chars.size() == 0) {
    while (from != to && std::isspace(s[from]))
      ++from;
    while (from != to && std::isspace(s[to - 1]))
      --to;
  } else {
    while (from != to && chars.find(s[from]) != std::string::npos)
      ++from;
    while (from != to && chars.find(s[to - 1]) != std::string::npos)
      --to;
  }
  return s.substr(from, to - from);
}


std::string
cc::str::swapcase(std::string s)
{
  size_type n = s.size();
  for (size_type i = 0; i < n; i++) {
    char c = s[i];
    if (std::islower(c))
      s[i] = std::toupper(c);
    else if (std::isupper(c))
      s[i] = std::tolower(c);
  }
  return s;
}


std::string
cc::str::title(std::string s)
{
  bool first = true;
  size_type n = s.size();
  for (size_type i = 0; i < n; i++) {
    char c = s[i];
    if (std::isalpha(c)) {
      if (first) {
	s[i] = std::toupper(c);
	first = false;
      } else {
	s[i] = std::tolower(c);
      }
    } else {
      first = true;
    }
  }
  return s;
}


double
cc::str::todouble(const std::string& s)
{
  std::istringstream is(s);
  double ret;
  char c;
  if (!(is >> ret) || (is >> c)) {
    std::string msg = "Invalid conversion argument: '";
    msg += s;
    msg += "'";
    throw std::invalid_argument(msg);
  }
  return ret;
}


double
cc::str::todouble(const std::string& s,
		   double def)
{
  std::istringstream is(s);
  double ret;
  char c;
  if (!(is >> ret) || (is >> c))
    return def;
  return ret;
}


long
cc::str::tolong(const std::string& s)
{
  std::istringstream is(s);
  long ret;
  char c;
  if (!(is >> ret) || (is >> c)) {
    std::string msg = "Invalid conversion argument: '";
    msg += s;
    msg += "'";
    throw std::invalid_argument(msg);
  }
  return ret;
}


long
cc::str::tolong(const std::string& s,
		 long def)
{
  std::istringstream is(s);
  long ret;
  char c;
  if (!(is >> ret) || (is >> c))
    return def;
  return ret;
}


std::string
cc::str::upper(std::string s)
{
  size_type n = s.size();
  for (size_type i = 0; i < n; i++)
    s[i] = std::toupper(s[i]);
  return s;
}


std::string
cc::str::zfill(const std::string& s,
	       std::string::size_type width)
{
  size_type n = s.size();
  if (n >= width)
    return s;

  std::string ret(width, '0');
  ret.replace(width - n, n, s);
  if (s[0] == '+' || s[0] == '-') {
    ret[0] = s[0];
    ret[width - n] = '0';
  }

  return ret;
}

