/**
 * \file basic_features.cpp
 *
 * Common image features.
 */

#include <features/basic_features.h>

#include <mat_algorithm.h>
#include <imaging/recursive_filtering.h>
#include <numerical/matrix_op.h>
#include <numerical/vector_op.h>

#include <cmath>
#include <cassert>
#include <algorithm>
#include <functional>


void
make_histogram(const ivllib::Matrix<ivllib::label_type>& img,
	       ivllib::label_type nbins,
	       ivllib::Vector<std::size_t>& out)
{
  make_histogram(img,
		 nbins,
		 ivllib::Box(0, 0, img.rows(), img.columns()),
		 out);
}


void
make_histogram(const ivllib::Matrix<ivllib::label_type>& img,
	       ivllib::label_type nbins,
	       const ivllib::Box& box,
	       ivllib::Vector<std::size_t>& out)
{
  assert(box.bottom() <= img.rows());
  assert(box.right() <= img.columns());
  typedef ivllib::Box::size_type size_type;

  ivllib::Vector<std::size_t> ret(nbins, 0);
  for (size_type i = box.top(); i < box.bottom(); i++) {
    for (size_type j = box.left(); j < box.right(); j++) {
      assert(img[i][j] < nbins);
      ++ret[img[i][j]];
    }
  }
  out.swap(ret);
}


void
normalize_histogram(const ivllib::Vector<std::size_t>& in,
		    ivllib::Vector<double>& out)
{
  std::size_t tot = 0;
  tot = std::accumulate(in.begin(), in.end(), tot);
  double mul = (tot > 0 ? 1.0 / tot : 0.0);
  ivllib::mul(in, mul, out);
}


void
yuvmoments(const ivllib::Matrix<ivllib::RGB8>& img,
	   ivllib::Vector<double>& features,
	   bool normalized)
{
  ivllib::Matrix<ivllib::YUV8> yuv;
  ivllib::convert_image(img, yuv);
  yuvmoments(yuv,
	     ivllib::Box(0, 0, yuv.rows(), yuv.columns()),
	     features,
	     normalized);
}


void
yuvmoments(const ivllib::Matrix<ivllib::YUV8>& img,
	   const ivllib::Box& box,
	   ivllib::Vector<double>& features,
	   bool normalized)
{
  assert(box.bottom() <= img.rows());
  assert(box.right() <= img.columns());

  typedef ivllib::Box::size_type size_type;

  double toty = 0.0;
  double totu = 0.0;
  double totv = 0.0;

  double toty2 = 0.0;
  double totu2 = 0.0;
  double totv2 = 0.0;

  for (size_type i = box.top(); i != box.bottom(); i++) {
    for (size_type j = box.left(); j != box.right(); j++) {
      ivllib::YUV8 p = img[i][j]; 
      toty += p.y;
      totu += p.u;
      totv += p.v;
      toty2 += p.y * p.y;
      totu2 += p.u * p.u;
      totv2 += p.v * p.v;
    }
  }
  
  double norm = (box.area() > 0 ? 1.0 / box.area() : 0.0);
  
  double my = toty*norm;
  double mu = totu*norm;
  double mv = totv*norm;
  double dy = std::sqrt(std::fabs(toty2 * norm - my * my));
  double du = std::sqrt(std::fabs(totu2 * norm - mu * mu));
  double dv = std::sqrt(std::fabs(totv2 * norm - mv * mv));

  if (normalized) {
    my /= 255.0;
    mu /= 255.0;
    mv /= 255.0;
    dy /= 127.5;
    du /= 127.5;
    dv /= 127.5;
  }

  ivllib::Vector<double> ret(6, 0.0);
  ret[0] = my;
  ret[1] = mu;
  ret[2] = mv;
  ret[3] = dy;
  ret[4] = du;
  ret[5] = dv;

  ret.swap(features);
}


namespace
{
  struct RGBQuantizer
  {
    RGBQuantizer(int qred, int qgreen, int qblue)
      : qr(qred), qg(qgreen), qb(qblue)
    {
    }

    int qr, qg, qb;

    ivllib::label_type operator()(const ivllib::RGB8& rgb) const
    {
      ivllib::label_type ret = 0;
      ret = (rgb.red * qr) >> 8;
      ret *= qg;
      ret += (rgb.green * qg) >> 8;
      ret *= qb;
      ret += (rgb.blue * qb) >> 8;
      return ret;
    }
  };  // struct RGBQuantizer
}  // anonymous namespace


void
rgbquantization(const ivllib::Matrix<ivllib::RGB8>& img,
		int qred,
		int qgreen,
		int qblue,
		ivllib::Matrix<ivllib::label_type>& out)
{
  assert(qred > 0);
  assert(qgreen > 0);
  assert(qblue > 0);
  assert(qred <= 256);
  assert(qgreen <= 256);
  assert(qblue <= 256);

  ivllib::mat_transform(img, out, RGBQuantizer(qred, qgreen, qblue));
}


void
edgedirections(const ivllib::Matrix<ivllib::Gray8>& img,
	       int ndirs,
	       ivllib::Matrix<ivllib::label_type>& out,
	       double sigma,
	       double threshold)
{
  typedef ivllib::Matrix<ivllib::Gray8>::size_type size_type;
  const double pi = 3.141592653589793;

  size_type n = img.rows();
  size_type m = img.columns();
  
  ivllib::Matrix<double> gx;
  ivllib::recursive_gaussian(img, sigma, sigma, 1, 0, gx);
  ivllib::Matrix<double> gy;
  ivllib::recursive_gaussian(img, sigma, sigma, 0, 1, gy);

  ivllib::Matrix<double> tmp = gx;
  ivllib::elements_mul_to(tmp, tmp);
  ivllib::Matrix<double> mag2 = gy;
  ivllib::elements_mul_to(mag2, mag2);
  ivllib::add_to(mag2, tmp);
  tmp.clear();

  threshold *= threshold;

  ivllib::Matrix<ivllib::label_type> ret(n, m, ndirs);
  for (size_type i = 1; i + 1 < n; i++) {
    for (size_type j = 1; j + 1 < m; j++) {
      double val = mag2[i][j];
      if (val <= threshold)
	continue;
      double x = gx[i][j];
      double y = gy[i][j];
      
      if (x < 0) {
      	x = -x;
      	y = -y;
      }
      int ii = -1;
      int jj = 0;
      if (y < -2.4142135623730949 * x) { // tan(-3*pi/8)
      	;
      } else if (y < -0.41421356237309503 * x) { // tan(-pi/8)
      	jj = 1;
      } else if (y < 0.41421356237309503 * x) { // tan(pi/8)
      	ii = 0;
      	jj = 1;
      } else if (y < 2.4142135623730949 * x) { // tan(3*pi/8)
      	ii = 1;
      	jj = 1;
      }
      if (val < mag2[i + ii][j + jj] || val < mag2[i - ii][j - jj])
	continue;
      double angle = 0.5 + (x == 0 ? 0 : std::atan(y/x) / pi);
      int dir = 0.5 + (angle * ndirs);
      ret[i][j] = (dir < ndirs ? dir : 0);
    }
  }
  out.swap(ret);
}


namespace
{
  lbp_type rotate1_lbp(lbp_type p, int n)
  {
    return (p >> 1) | ((p & 1) << (n - 1));
  }


  lbp_type rotate_lbp(lbp_type p, int n)
  {
    typedef ivllib::Vector<lbp_type>::size_type size_type;
    size_type j = p;
    size_type k = p;
    do {
      j = rotate1_lbp(j, n);
      if (j < k)
	k = j;
    } while (j != p);
    return k;
  }
}  // anonymous namespace


ivllib::Vector<lbp_type>::size_type
make_lbp_lut(int n, bool rotinv, bool uniform, ivllib::Vector<lbp_type>& lut)
{
  assert(n > 0);
  assert(n <= 16);

  if (n < 3)
    uniform = false;
  if (n < 2)
    rotinv = false;

  typedef ivllib::Vector<lbp_type>::size_type size_type;

  size_type sz = (1 << n);
  ivllib::Vector<lbp_type> ret(sz);

  if (!rotinv && !uniform) {
    // The lut just maps i to i.
    for (size_type i = 0; i < sz; i++)
      ret[i] = i;
    lut.swap(ret);
    return sz;
  }

  if (rotinv && !uniform) {
    ret.assign(0);
    size_type used = 0;
    for (size_type i = 0; i < sz; i++) {
      size_type k = rotate_lbp(i, n);
      if (ret[k] > 0)
	ret[i] = ret[k];
      else
	ret[k] = ret[i] = used++;
    }
    lut.swap(ret);
    return used;
  }

  if (!rotinv && uniform) {
    // two 'flat' patterns + one code for non uniform patterns +
    // n patterns for each number of ones between 1 and n - 1
    size_type p = 3 + (n - 1) * n;

    ret.assign(p - 1);   // non uniform
    ret[0] = 0;  // all zeros
    ret[(1 << n) - 1] = p - 2;  // all ones
    for (int i = 1; i < n; i++) {
      size_type q = (1 << i) - 1;
      for (int j = 0; j < n; j++) {
	// 'i' ones rotated by j positions
	ret[q] = 1 + j + (i - 1) * n;
	q = rotate1_lbp(q, n);
      }
    }
    lut.swap(ret);
    return p;
  }

  // rotinv && uniform
  // one code for non uniform patterns +
  // 1 pattern for each number of ones between 0 and n
  size_type p = 2 + n;

  ret.assign(p - 1);   // non uniform
  ret[0] = 0;  // all zeros
  for (int i = 0; i <= n; i++) {
    size_type q = (1 << i) - 1;
    for (int j = 0; j < n; j++) {
      // 'i' ones rotated by j positions
      ret[q] = i;
      q = rotate1_lbp(q, n);
    }
  }
  lut.swap(ret);
  return p;
}


