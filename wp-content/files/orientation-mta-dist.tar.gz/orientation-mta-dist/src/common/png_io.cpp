/**
 * \file    png_io.cpp
 * \brief   io routines for the png graphic format (based on libpng)
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#include <ivl_config.h>
#include <imaging/png_io.h>
#include <imaging/exception_io.h>

#include <cstdio>
#include <cassert>
#include <sstream>

#ifndef IVL_DONT_USE_LIB_PNG
#  include <png.h>

#  ifndef png_jmpbuf
#    define png_jmpbuf(png_ptr) ((png_ptr)->jmpbuf)
#  endif

#  ifndef png_infopp_NULL
#    define png_infopp_NULL (png_infopp)NULL  // Mod. per versione 14
#  endif

#  ifndef int_p_NULL
#    define int_p_NULL (int*)NULL  // Mod. per versione 14
#  endif
#endif

namespace ivllib
{

#ifndef IVL_DONT_USE_LIB_PNG

  /* PNG I/O Routines ************************************************************/


  /* Check to see if a file is a PNG file using png_sig_cmp().  png_sig_cmp()
   * returns zero if the image is a PNG and nonzero if it isn't a PNG.
   *
   * The function check_if_png() shown here, but not used, returns nonzero (true)
   * if the file can be opened and is a PNG, 0 (false) otherwise.
   *
   * If this call is successful, and you are going to keep the file open,
   * you should call png_set_sig_bytes(png_ptr, PNG_BYTES_TO_CHECK); once
   * you have created the png_ptr, so that libpng knows your application
   * has read that many bytes from the start of the file.  Make sure you
   * don't call png_set_sig_bytes() with more than 8 bytes read or give it
   * an incorrect number of bytes read, or you will either have read too
   * many bytes (your fault), or you are telling libpng to read the wrong
   * number of magic bytes (also your fault).
   *
   * Many applications already read the first 2 or 4 bytes from the start
   * of the image to determine the file type, so it would be easiest just
   * to pass the bytes to png_sig_cmp() or even skip that if you know
   * you have a PNG file, and call png_set_sig_bytes().
   */
#define PNG_BYTES_TO_CHECK 4
  
  namespace
  {
    int check_if_png(char *file_name, FILE **fp)
    {
      png_byte buf[PNG_BYTES_TO_CHECK];
      
      /* Open the prospective PNG file. */
      if ((*fp = fopen(file_name, "rb")) == NULL)
	return 0;
      
      /* Read in some of the signature bytes */
      if (fread(buf, 1, PNG_BYTES_TO_CHECK, *fp) != PNG_BYTES_TO_CHECK)
	return 0;
      
      /* Compare the first PNG_BYTES_TO_CHECK bytes of the signature.
	 Return nonzero (true) if they match */
      
      return(!png_sig_cmp(buf, (png_size_t)0, PNG_BYTES_TO_CHECK));
    }

    template <typename T>
    struct PngPixelTraits {};

    template <>
    struct PngPixelTraits<Gray8>
    {
      static const int ncomponents = 1;

      static const png_byte color_type = PNG_COLOR_TYPE_GRAY;

      static png_bytep read_pixel(png_bytep src,Gray8& p)
      {
	p = *src;
	return ++src;
      }

      static png_bytep write_pixel(const Gray8& p,png_bytep dst)
      {
	*dst = p;
	return ++dst;
      }

      static bool accept_image(png_structp png_ptr,png_infop info_ptr,int depth,int color_type)
      {
	if (color_type != PNG_COLOR_TYPE_GRAY)
	  return false;

	if (depth == 16)
	  png_set_strip_16(png_ptr);

	if (depth < 8)
	  // png_set_gray_1_2_4_to_8(png_ptr);  Mod. versione 14
	  png_set_expand_gray_1_2_4_to_8(png_ptr);

	return true;
      }
    };

    template <>
    struct PngPixelTraits<RGB8>
    {
      static const int ncomponents = 3;

      static const png_byte color_type = PNG_COLOR_TYPE_RGB;

      static png_bytep read_pixel(png_bytep src,RGB8& p)
      {
	p.red = *src++;
	p.green = *src++;
	p.blue = *src++;
	return src;
      }

      static png_bytep write_pixel(const RGB8& p,png_bytep dst)
      {
	*dst++ = p.red;
	*dst++ = p.green;
	*dst++ = p.blue;
	return dst;
      }

      static bool accept_image(png_structp png_ptr,png_infop info_ptr,int depth,int color_type)
      {
      /* Set the image information here.  Width and height are up to 2^31,
       * bit_depth is one of 1, 2, 4, 8, or 16, but valid values also depend on
       * the color_type selected. color_type is one of PNG_COLOR_TYPE_GRAY,
       * PNG_COLOR_TYPE_GRAY_ALPHA, PNG_COLOR_TYPE_PALETTE, PNG_COLOR_TYPE_RGB,
       * or PNG_COLOR_TYPE_RGB_ALPHA.  interlace is either PNG_INTERLACE_NONE or
       * PNG_INTERLACE_ADAM7, and the compression_type and filter_type MUST
       * currently be PNG_COMPRESSION_TYPE_BASE and PNG_FILTER_TYPE_BASE. REQUIRED
       */
	if (color_type == PNG_COLOR_TYPE_GRAY)
	  png_set_gray_to_rgb(png_ptr);
	else if (color_type == PNG_COLOR_TYPE_PALETTE)
	  png_set_palette_to_rgb(png_ptr);
	else if (color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
	  return false;	
	else if (color_type == PNG_COLOR_TYPE_RGB_ALPHA)
	  return false;
	
	if (depth == 16)
	  png_set_strip_16(png_ptr);

	if (depth < 8) {
	  png_color_8p sig_bit;
   
	  if (png_get_sBIT(png_ptr, info_ptr, &sig_bit))
	    png_set_shift(png_ptr, sig_bit);
	}

	return true;
      }
    };

    template <>
    struct PngPixelTraits<RGBA8>
    {
      static const int ncomponents = 4;

      static const png_byte color_type = PNG_COLOR_TYPE_RGB_ALPHA;

      static png_bytep read_pixel(png_bytep src,RGBA8& p)
      {
	p.red = *src++;
	p.green = *src++;
	p.blue = *src++;
	p.alpha = *src++;
	return src;
      }

      static png_bytep write_pixel(const RGBA8& p,png_bytep dst)
      {
	*dst++ = p.red;
	*dst++ = p.green;
	*dst++ = p.blue;
	*dst++ = p.alpha;
	return dst;
      }

      static bool accept_image(png_structp png_ptr,png_infop info_ptr,int depth,int color_type)
      {
	if (color_type == PNG_COLOR_TYPE_GRAY) {
	  png_set_add_alpha(png_ptr, 255, PNG_FILLER_AFTER);
	  png_set_gray_to_rgb(png_ptr);
	} else if (color_type == PNG_COLOR_TYPE_PALETTE) {
	  png_set_palette_to_rgb(png_ptr);
	  png_set_add_alpha(png_ptr, 255, PNG_FILLER_AFTER);
	} else if (color_type == PNG_COLOR_TYPE_RGB)
	  png_set_add_alpha(png_ptr, 255, PNG_FILLER_AFTER);
	else if (color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
	  png_set_gray_to_rgb(png_ptr);
	
	if (depth == 16)
	  png_set_strip_16(png_ptr);

	if (depth < 8) {
	  png_color_8p sig_bit;
   
	  if (png_get_sBIT(png_ptr, info_ptr, &sig_bit))
	    png_set_shift(png_ptr, sig_bit);
	}
	
	return true;
      }
    };

    template <typename T>
    void save_png_aux(const std::string& filename,
		      const Matrix<T>& in,
		      unsigned int compression_level)
    {
      std::FILE *fp;
      png_structp png_ptr;
      png_infop info_ptr;

      /* open the file */
      fp = std::fopen(filename.c_str(), "wb");
      if (fp == 0) {
	std::string message = "save_png: error opening file '";
	message += filename;
	message += "'";
	throw ImageFileError(message);
      }

      /* Create and initialize the png_struct with the desired error handler
       * functions.  If you want to use the default stderr and longjump method,
       * you can supply NULL for the last three parameters.  We also check that
       * the library version is compatible with the one used at compile time,
       * in case we are using dynamically linked libraries.  REQUIRED.
       */
      png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,NULL, NULL, NULL);
      //      png_voidp user_error_ptr, user_error_fn, user_warning_fn);
      
      if (png_ptr == 0) {
	std::fclose(fp);
	throw ImageFormatError("save_png: an error occurred creating write struct");
      }

      /* Allocate/initialize the image information data.  REQUIRED */
      info_ptr = png_create_info_struct(png_ptr);
      if (info_ptr == 0) {
	std::fclose(fp);
	png_destroy_write_struct(&png_ptr,  png_infopp_NULL);
	throw ImageFormatError("save_png: an error occurred creating info struct");
      }

      png_byte *image = 0;
      png_bytep *row_pointers = 0;
      
      /* Set error handling.  REQUIRED if you aren't supplying your own
       * error handling functions in the png_create_write_struct() call.
       */
      if (setjmp(png_jmpbuf(png_ptr))) {
	/* If we get here, we had a problem reading the file */
	std::fclose(fp);
	png_destroy_write_struct(&png_ptr, &info_ptr);
	delete[] image;
	delete[] row_pointers;

	std::string msg = "save_png: an error occurred reading the file '";
	msg += filename;
	msg += "'";

	throw ImageFormatError(msg);
      }

      /* set up the output control if you are using standard C streams */
      png_init_io(png_ptr, fp);
      
      /* set the zlib compression level */
      png_set_compression_level(png_ptr,compression_level);

      
      /* Set the image information here.  Width and height are up to 2^31,
       * bit_depth is one of 1, 2, 4, 8, or 16, but valid values also depend on
       * the color_type selected. color_type is one of PNG_COLOR_TYPE_GRAY,
       * PNG_COLOR_TYPE_GRAY_ALPHA, PNG_COLOR_TYPE_PALETTE, PNG_COLOR_TYPE_RGB,
       * or PNG_COLOR_TYPE_RGB_ALPHA.  interlace is either PNG_INTERLACE_NONE or
       * PNG_INTERLACE_ADAM7, and the compression_type and filter_type MUST
       * currently be PNG_COMPRESSION_TYPE_BASE and PNG_FILTER_TYPE_BASE. REQUIRED
       */
      png_set_IHDR(png_ptr, info_ptr,
		   in.columns(), in.rows(), 8,
		   PngPixelTraits<T>::color_type,
		   PNG_INTERLACE_NONE,
		   PNG_COMPRESSION_TYPE_DEFAULT,
		   PNG_FILTER_TYPE_DEFAULT);
    
      /* Write the file header information.  REQUIRED */
      png_write_info(png_ptr, info_ptr);
      
      int ncomp = PngPixelTraits<T>::ncomponents;

      /* The easiest way to write the image (you may have a different memory
       * layout, however, so choose what fits your needs best).  You need to
       * use the first method if you aren't handling interlacing yourself.
       */      
      png_uint_32 k, height=in.rows(), width=in.columns();
      row_pointers = new png_bytep[height];
      
      if (height > PNG_UINT_32_MAX/png_sizeof(png_bytep))
	png_error (png_ptr, "Image is too tall to process in memory");
      
      /* allocate a temporary buffer for the image data to be written */
      image = new png_byte[height*width*ncomp];
      
      for (k = 0; k < height; k++)
	row_pointers[k] = image + k*width*ncomp;

      /* copy the in image into the buffer*/
      typedef typename Matrix<T>::size_type size_type;
      for (size_type row = 0; row < static_cast<size_type>(height); row++) {
	png_bytep row_ptr = row_pointers[row];
	for (size_type col = 0; col < static_cast<size_type>(width); col++) {
	  row_ptr = PngPixelTraits<T>::write_pixel(in[row][col],row_ptr);
	}
      }

      png_write_image(png_ptr, row_pointers);
      
      /* It is REQUIRED to call this to finish writing the rest of the file */
      png_write_end(png_ptr, info_ptr);
      
      /* clean up after the write, and free any memory allocated */
      png_destroy_write_struct(&png_ptr, &info_ptr);
      
      /* deallocate the temporary buffer */
      delete [] image;
      delete [] row_pointers;
      
      /* close the file */
      fclose(fp);
      
      /* that's it */
    }

    template <typename T>
    void load_png_aux(const std::string& filename,
		      Matrix<T>& out)
    {
      Matrix<T> localOut;

      png_structp png_ptr;
      png_infop info_ptr;
      unsigned int sig_read = 0;
      png_uint_32 width, height;
      int bit_depth, color_type, interlace_type;
      std::FILE *fp = std::fopen(filename.c_str(), "rb");

      if (fp == 0) {
	std::string msg = "load_png: error opening '";
	msg += filename;
	msg += "'";
	throw ivllib::ImageFileError(msg);
      }
    
      /* Create and initialize the png_struct with the desired error handler
       * functions.  If you want to use the default stderr and longjump method,
       * you can supply NULL for the last three parameters.  We also supply the
       * the compiler header file version, so that we know if the application
       * was compiled with a compatible version of the library.  REQUIRED
       */
      png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
      // png_voidp user_error_ptr, user_error_fn, user_warning_fn);

      if (png_ptr == 0) {
	std::fclose(fp);
	std::string msg = "load_png: error occurred creating read struct for file '";
	msg += filename;
	msg += "'";
	throw ivllib::ImageFormatError(msg);
      }

      /* Allocate/initialize the memory for image information.  REQUIRED. */
      info_ptr = png_create_info_struct(png_ptr);
      if (info_ptr == 0) {
	std::fclose(fp);
	std::string msg = "load_png: error occurred creating info struct for file '";
	msg += filename;
	msg += "'";
	throw ivllib::ImageFormatError(msg);
      }
  
      /* Set error handling if you are using the setjmp/longjmp method (this is
       * the normal method of doing things with libpng).  REQUIRED unless you
       * set up your own error handlers in the png_create_read_struct() earlier.
       */

      png_bytep *row_pointers = 0;

      if (setjmp(png_jmpbuf(png_ptr))) {
	/* Free all of the memory associated with the png_ptr and info_ptr */
	if (row_pointers) {
	  png_bytep *rowi = row_pointers;
	  while(*rowi) {
	    png_free(png_ptr,*rowi);
	    ++rowi;
	  }
	  delete[] row_pointers;
	}
	png_destroy_read_struct(&png_ptr, &info_ptr, png_infopp_NULL);
	std::fclose(fp);
	/* If we get here, we had a problem reading the file */
	std::string msg = "load_png: error occurred loading file '";
	msg += filename;
	msg += "'";
	throw ivllib::ImageFormatError(msg);
      }
      /* Set up the input control if you are using standard C streams */
      png_init_io(png_ptr, fp);

      /* If we have already read some of the signature */
      png_set_sig_bytes(png_ptr, sig_read);
    
      /* The call to png_read_info() gives us all of the information from the
       * PNG file before the first IDAT (image data chunk).  REQUIRED
       */
      png_read_info(png_ptr, info_ptr);

      png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type,
		   &interlace_type, int_p_NULL, int_p_NULL);
    
      /* Set up the data transformations you want.  Note that these are all
       * optional.  Only call them if you want/need them.  Many of the
       * transformations only work on specific types of images, and many
       * are mutually exclusive.
       */
    
      if (!PngPixelTraits<T>::accept_image(png_ptr,info_ptr,bit_depth,color_type)) {
	png_destroy_read_struct(&png_ptr, &info_ptr, png_infopp_NULL);
	std::fclose(fp);
	throw ivllib::ImageConversionError("load png: invalid image conversion required");
      }
      
      png_read_update_info(png_ptr, info_ptr);

      /* Allocate the memory to hold the image using the fields of info_ptr. */

      /* The easiest way to read the image: */
      row_pointers = new png_bytep[height+1];

      for (int row = 0; row < int(height); row++) {
	row_pointers[row] = reinterpret_cast<png_byte*>( png_malloc(png_ptr, png_get_rowbytes(png_ptr,
											      info_ptr)) );
      }
      row_pointers[height] = 0;

      /* Read the entire image in one go */
      png_read_image(png_ptr, row_pointers);
    
      /* read rest of file, and get additional chunks in info_ptr - REQUIRED */
      png_read_end(png_ptr, info_ptr);

      /* At this point you have read the entire image */
      /* copy the raw buffer into the out image.*/
      localOut.resize(height, width); 
  
      
      for (int row=0; row < int(height); row++) {
	png_bytep rowp = row_pointers[row];
	for (int col=0; col < int(width); col++) {
	  rowp = PngPixelTraits<T>::read_pixel(rowp,localOut[row][col]);
	}
      }
      
      /* clean up after the read, and free any memory allocated - REQUIRED */
      //png_destroy_read_struct(&png_ptr, &info_ptr, png_infopp_NULL);

      // cleanup

      /* Free all of the memory associated with the png_ptr and info_ptr */
      if (row_pointers) {
	png_bytep *rowi = row_pointers;
	while(*rowi) {
	  png_free(png_ptr,*rowi);
	  ++rowi;
	}
	delete[] row_pointers;
      }
      png_destroy_read_struct(&png_ptr, &info_ptr, png_infopp_NULL);

      /* close the file */
      fclose(fp);

      /* that's it */
      out.swap(localOut);
    }

  } // anonymous namespace

#else
// do not use libpng

  namespace
  {
    template <typename T>
    void save_png_aux(const std::string& filename,
		      const Matrix<T>& in,
		      unsigned int compression_level)
    {
      throw ivllib::ImageConversionError("save_png: png format is not supported");
    }

    template <typename T>
    void load_png_aux(const std::string& filename,
		      ivllib::Matrix<T>& out)
    {
      throw ivllib::ImageConversionError("load_png: png format is not supported");
    }
  }

#endif

  void load_png(const std::string& filename,
		Matrix<RGB8>& out)
  {
    load_png_aux(filename,out);
  }
  
  void load_png(const std::string& filename,
		Matrix<RGBA8>& out)
  {
    load_png_aux(filename,out);
  }

  void load_png(const std::string& filename,
		Matrix<Gray8>& out)
  {
    load_png_aux(filename,out);
  }
  
  void save_png(const std::string& filename,
		const Matrix<RGB8>& in,
		unsigned int compression_level)
  {
    assert(compression_level <= 9);
    save_png_aux(filename,in,compression_level);
  }

  void save_png(const std::string& filename,
		const Matrix<RGBA8>& in,
		unsigned int compression_level)
  {
    assert(compression_level <= 9);
    save_png_aux(filename,in,compression_level);
  }

  void save_png(const std::string& filename,
		const Matrix<Gray8>& in,
		unsigned int compression_level)
  {
    assert(compression_level <= 9);
    save_png_aux(filename,in,compression_level);
  }

} // namespace ivllib
