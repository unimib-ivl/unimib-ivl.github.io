/**
 * \file option_parser.cpp
 * Implementation of the command line parser.
 * \author Claudio Cusano
 */
#include <options/option_parser.h>
#include <map>
#include <vector>
#include <cassert>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <stdexcept>

//----------------------------------------------------------------------

namespace cc
{
  namespace
  {
    /*
     * validate the (long) name of an option:
     *
     * - an empty name is not allowed
     * - a name beginning with '-' is not allowed
     * - a name containing spaces, '=' or non-printable characters is not allowed
     */
    bool is_valid(const std::string& name)
    {
      if (name.size() == 0)
	return false;

      if (name[0] == '-')
	return false;

      for(std::string::size_type i = 0; i < name.size(); i++) {
	if (std::isspace(name[i]))
	  return false;
	if (name[i] == '=')
	  return false;
	if (!std::isprint(name[i]))
	  return false;
      }
      return true;
    }

    /*
     * validate the short name of an option:
     *
     * - the value Option::noshort is allowed
     * - the character '-' is not allowed
     * - spaces are not allowed
     * - non-printable characters are not allowed
     */
    bool is_valid(char short_name)
    {
      if (short_name == Option::noshort)
	return true;

      if (short_name == '-')
	return false;

      if (std::isspace(short_name))
	return false;
      if (!std::isprint(short_name))
	return false;

      return true;
    }

    // Helper predicate used to find an option by short name
    struct is_named_short
    {
      char c_;

      is_named_short(char c)
	: c_(c)
      {
      }

      bool operator()(const Option& opt) const
      {
	return opt.short_name() == c_;
      }

      bool operator()(const Option* opt) const
      {
	return opt->short_name() == c_;
      }
    };

    // Helper predicate used to find an option by name
    struct is_named_long
    {
      std::string s_;

      is_named_long(const std::string& s)
	: s_(s)
      {
      }

      bool operator()(const Option& opt) const
      {
	return opt.name() == s_;
      }

      bool operator()(const Option* opt) const
      {
	return opt->name() == s_;
      }
    };

    // Helper predicate used to manage option grouping
    struct is_in_group
    {
      std::string s_;

      is_in_group(const std::string& s)
	: s_(s)
      {
      }

      bool operator()(const Option& opt) const
      {
	return opt.group() == s_;
      }

      bool operator()(const Option* opt) const
      {
	return opt->group() == s_;
      }
    };


    // Helper predicate which returns the address of an option
    const Option* get_opt_address(const Option& opt)
    {
      return &opt;
    }
  } // anonymous namespace

  // constant which means "no parameter"
  const Option::noparam_t Option::noparam = Option::noparam_t();

  // constructors

  Option::Option(const std::string& name,
		 char short_name)
    : name_(name),
      short_name_(short_name),
      require_param_(false),
      metavar_(""),
      group_(""),
      description_("")
  {
    assert( is_valid(name) );
    assert( is_valid(short_name) );
  }

  Option::Option(const std::string& name,
		 char short_name,
		 noparam_t,
		 const std::string& group,
		 const std::string& description)
    : name_(name),
      short_name_(short_name),
      require_param_(false),
      metavar_(""),
      group_(group),
      description_(description)
  {
    assert( is_valid(name) );
    assert( is_valid(short_name) );
  }

  Option::Option(const std::string& name,
		 char short_name,
		 const std::string& metavar,
		 const std::string& group,
		 const std::string& description)
    : name_(name),
      short_name_(short_name),
      require_param_(true),
      metavar_(metavar),
      group_(group),
      description_(description)
  {
    assert( is_valid(name) );
    assert( is_valid(short_name) );
  }

  // observers

  std::string Option::name() const
  {
    return name_;
  }

  char Option::short_name() const
  {
    return short_name_;
  }

  bool Option::require_parameter() const
  {
    return require_param_;
  }

  std::string Option::metavar() const
  {
    return metavar_;
  }

  std::string Option::group() const
  {
    return group_;
  }

  std::string Option::description() const
  {
    return description_;
  }

  // modifiers

  void Option::set_name(const std::string& name)
  {
    assert( is_valid(name) );
    name_ = name;
  }

  void Option::set_short_name(char short_name)
  {
    assert( is_valid(short_name) );
    short_name_ = short_name;
  }

  void Option::set_metavar(noparam_t)
  {
    metavar_ = "";
    require_param_ = false;
  }

  void Option::set_metavar(const std::string& metavar)
  {
    metavar_ = metavar;
    require_param_ = true;
  }

  void Option::set_group(const std::string& group)
  {
    group_ = group;
  }

  void Option::set_description(const std::string& description)
  {
    description_ = description;
  }

  //------------------------------------------------------------

  // pimpl
  struct ParsedOptions::impl
  {
    typedef std::map<std::string,std::string> Values;
    typedef std::vector<std::string> Args;

    Args args_;
    Values values_;

    impl()
      : args_(),values_()
    {
    }
  };

  // constructors

  ParsedOptions::ParsedOptions()
    : pimpl_(new impl)
  {
  }

  ParsedOptions::ParsedOptions(const ParsedOptions& other)
    : pimpl_(new impl(*other.pimpl_))
  {
  }

  ParsedOptions::~ParsedOptions()
  {
    delete pimpl_;
  }

  // assignement

  ParsedOptions& ParsedOptions::operator=(const ParsedOptions& other)
  {
    ParsedOptions temp(other);
    swap(temp);
    return *this;
  }

  // observers

  int ParsedOptions::argc() const
  {
    return pimpl_->args_.size();
  }

  std::string ParsedOptions::argv(int i) const
  {
    assert( i >= 0 );
    assert( i < argc() );
    return pimpl_->args_[i];
  }

  bool ParsedOptions::contains_option(const std::string& name) const
  {
    return pimpl_->values_.find(name) != pimpl_->values_.end();
  }

  std::string ParsedOptions::parameter_value(const std::string& name,
					     const std::string& default_value) const
  {
    impl::Values::const_iterator it = pimpl_->values_.find(name);

    return it != pimpl_->values_.end()
      ? it->second
      : default_value;
  }


  long ParsedOptions::int_parameter_value(const std::string& name,
					  long default_value) const
  {
    impl::Values::const_iterator it = pimpl_->values_.find(name);

    if (it == pimpl_->values_.end())
      return default_value;

    long val;
    char dummy;
    std::istringstream is(it->second);
    
    if (!(is >> val) || (is >> dummy)) {
      std::string msg = "Invalid value for option '";
      msg += name;
      msg += "'  (";
      msg += it->second;
      msg += ").";
      throw std::runtime_error(msg);
    }
    
    return val;
  }

  
  double ParsedOptions::double_parameter_value(const std::string& name,
					       double default_value) const
  {
    impl::Values::const_iterator it = pimpl_->values_.find(name);

    if (it == pimpl_->values_.end())
      return default_value;

    double val;
    char dummy;
    std::istringstream is(it->second);
    
    if (!(is >> val) || (is >> dummy)) {
      std::string msg = "Invalid value for option '";
      msg += name;
      msg += "'  (";
      msg += it->second;
      msg += ").";
      throw std::runtime_error(msg);
    }
    
    return val;
  }

  ParsedOptions::args_iterator ParsedOptions::begin_args() const
  {
    return &(pimpl_->args_[0]);
  }

  ParsedOptions::args_iterator ParsedOptions::end_args() const
  {
    return begin_args() + argc();
  }

  // modifiers

  void ParsedOptions::swap(ParsedOptions& other)
  {
    impl* tmp = pimpl_;
    pimpl_ = other.pimpl_;
    other.pimpl_ = tmp;
  }

  //------------------------------------------------------------

  // pimpl
  struct OptionParser::impl
  {
    typedef std::vector<Option> Options;

    Options options_;
    std::string usage_;

    explicit impl(const std::string& usage = "")
      : options_(),
	usage_(usage)
    {
    }
  };

  // constructors

  OptionParser::OptionParser(const std::string& usage)
    : pimpl_(new impl(usage))
  {
  }

  OptionParser::OptionParser(const OptionParser& other)
    : pimpl_(new impl(*other.pimpl_))
  {
  }

  // destructor

  OptionParser::~OptionParser()
  {
    delete pimpl_;
  }

  // assignement

  OptionParser& OptionParser::operator=(const OptionParser& other)
  {
    OptionParser temp(other);
    swap(temp);
    return *this;
  }

  // observers

  std::string OptionParser::usage() const
  {
    return pimpl_->usage_;
  }

  // modifiers


  void OptionParser::set_usage(const std::string& usage)
  {
    pimpl_->usage_ = usage;
  }

  void OptionParser::swap(OptionParser& other)
  {
    impl* tmp = other.pimpl_;
    other.pimpl_ = pimpl_;
    pimpl_ = tmp;
  }

  void OptionParser::add_option(const Option& opt)
  {
    assert( std::find_if(pimpl_->options_.begin(),
			 pimpl_->options_.end(),
			 is_named_long(opt.name())) == pimpl_->options_.end() );
    pimpl_->options_.push_back(opt);
  }

  ParsedOptions OptionParser::parse_cmd_line(int argc,char* argv[]) const
  {
    using std::string;
    using std::find_if;

    assert( argc >= 0 );

    typedef std::vector<const Option*>::iterator iter;

    ParsedOptions result;

    std::vector<const Option*> opts(pimpl_->options_.size());
    std::transform(pimpl_->options_.begin(),
		   pimpl_->options_.end(),
		   opts.begin(),
		   &get_opt_address);

    int i = 0;
    while (i < argc) {
      assert( argv[i] != 0 );
      assert( argv[i][0] != Option::noshort );

      string arg = argv[i];

      if (arg == "") {
	// do nothing
      } else if (arg == "-" || arg == "--") {
	// special dash arguments
	result.pimpl_->args_.push_back(arg);
      } else if (arg.size() > 2 && arg[0] == '-' && arg[1] == '-') {
	// long option
	std::string name(arg,2,arg.size() - 2);
	std::string par;

	string::size_type j = arg.find('=');

	if (j != string::npos) {
	  // parameter not set with '='
	  name = string(arg,2,j - 2);
	  par = string(arg,j+1);
	}

	iter it = find_if(opts.begin(),
			  opts.end(),
			  is_named_long(name));

	if (it == opts.end()) {
	  if (std::find_if(pimpl_->options_.begin(),
			   pimpl_->options_.end(),
			   is_named_long(name)) == pimpl_->options_.end()) {
	    string msg = "unknown option '";
	    msg += name;
	    msg += "'";
	    error(msg);
	  } else {
	    // duplication
	    string msg = "duplicated option '";
	    msg += name;
	    msg += "'";
	    error(msg);
	  }
	}

	if ((*it)->require_parameter()) {
	  if (j == string::npos) {
	    if (i == argc - 1) {
	      string msg = "option '";
	      msg += name;
	      msg += "' requires a parameter";
	      error(msg);
	    } else {
	      ++i;
	      par = argv[i];
	    }
	  }
	} else {
	  if (j != string::npos) {
	    string msg = "option '";
	    msg += name;
	    msg += "' does not require a parameter";
	    error(msg);
	  }
	}
	opts.erase(it);
	result.pimpl_->values_.insert(std::make_pair(name,par));

      } else if (arg[0] == '-') {
	// short options
	string::size_type j = 1;
	while (j < arg.size()) {
	  iter it = find_if(opts.begin(),
			    opts.end(),
			    is_named_short(arg[j]));

	  if (it == opts.end()) {
	    if (std::find_if(pimpl_->options_.begin(),
			     pimpl_->options_.end(),
			     is_named_short(arg[j])) == pimpl_->options_.end()) {
	      string msg = "unknown option '";
	      msg += arg[j];
	      msg += "'";
	      error(msg);
	    } else {
	      // duplication
	      string msg = "duplicated option '";
	      msg += arg[j];
	      msg += "'";
	      error(msg);
	    }
	  }

	  if ((*it)->require_parameter()) {
	    if (j == arg.size() - 1) {
	      ++i;
	      if (i == argc) {
		string msg = "option '";
		msg += arg[j];
		msg += "' requires a parameter";
		error(msg);
	      }
	      result.pimpl_->values_.insert(std::make_pair((*it)->name(),
							   std::string(argv[i])));
	      ++j;
	    } else {
	      result.pimpl_->values_.insert(std::make_pair((*it)->name(),
							   std::string(arg,j+1)));
	      j = arg.size();
	    }
	  } else {
	    result.pimpl_->values_.insert(std::make_pair((*it)->name(),
							 ""));

	    ++j;
	  }
	  opts.erase(it);
	}
      } else {
	// not an option
	result.pimpl_->args_.push_back(arg);
      }
      ++i;
    }
    return result;
  }

  // actions

  void OptionParser::print_help(const std::string& comment) const
  {
    using std::cout;
    using std::setw;
    using std::left;
    using std::string;

    cout << usage() << '\n';

    std::size_t left_len = 29;
    std::size_t line_len = 79;

    std::vector<const Option*> opts(pimpl_->options_.size());
    std::transform(pimpl_->options_.begin(),
		   pimpl_->options_.end(),
		   opts.begin(),
		   &get_opt_address);

    typedef std::vector<const Option*>::iterator iter;

    iter it = opts.begin();
    iter stop = opts.end();

    // aggregate options in the same group
    while (it != stop)
      it = std::stable_partition(it,stop,is_in_group((*it)->group()));

    it = opts.begin();
    while (it != stop) {
      const Option& opt = **it;

      if (it == opts.begin() || opt.group() != (*(it-1))->group()) {
	if (opt.group() != "")
	  cout << '\n' << opt.group() << "\n\n";
	else
	  cout << '\n';
      }

      string left_column;

      if (opt.short_name() == Option::noshort) {
	left_column += "  --";
      } else {
	left_column += "  -";
	left_column += opt.short_name();
	left_column += ", --";
      }
      left_column += opt.name();
      if (opt.require_parameter()) {
	left_column += "=";
	left_column += opt.metavar();
      }
      left_column += " ";

      cout << left << setw(left_len) << left_column;

      std::size_t pos = std::max(left_len,left_column.size());
      std::istringstream is(opt.description());
      string word;

      while (is >> word) {
	if (pos != left_len && word.size() >= line_len - pos) {
	  cout << '\n';
	  cout << setw(left_len) << " ";
	  pos = left_len;
	}
	if (pos != left_len)
	  cout << ' ';
	cout << word;
	pos += (1 + word.size());
      }
      cout << '\n';
      ++it;
    }

    cout << '\n';
    if (comment.size() > 0)
      cout << comment << '\n';
  }

  void OptionParser::error(const std::string& msg) const
  {
    std::cout << msg << std::endl;
    std::exit(EXIT_FAILURE);
  }
} // namespace cc
