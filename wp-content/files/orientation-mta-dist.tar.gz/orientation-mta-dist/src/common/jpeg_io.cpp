/**
 * \file    jpeg_io.cpp
 * \brief   io routines for the jpeg graphic format (based on libjpeg)
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#include <ivl_config.h>
#include <imaging/jpeg_io.h>
#include <imaging/exception_io.h>
#include <algorithm>

#ifndef IVL_DONT_USE_LIB_JPEG
#  include <stdio.h>   // jpeglib seems to require c-style headers
#  include <jpeglib.h>
#  include <setjmp.h>  // jpeglib seems to require c-style headers
#  include <vector>
#  include <string>
#  include <sstream>


// jpeglib (almost) requires the use of setjmp/longjmp
// for custom error management.
struct my_error_mgr
{
  jpeg_error_mgr pub;	 // jpeglib fields
  jmp_buf setjmp_buffer; // for return to caller
  std::string message;   // error message
};

char err_buffer[256]; // I hope the buffer is big enough

METHODDEF(void) my_error_exit (j_common_ptr cinfo)
{
  my_error_mgr* myerr = (my_error_mgr*) cinfo->err;
  (*cinfo->err->format_message)(cinfo,err_buffer);
  myerr->message = err_buffer;

  // Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}

//------------------------------------------------------------

// class used to cleanup C-style data structures
class ScopeGuard
{
public:

  template <typename Fun,typename Arg>
  ScopeGuard(const Fun& fun,const Arg& arg)
    : functor_(new functor<Fun,Arg>(fun,arg)) { ; } 

  ~ScopeGuard() { delete functor_; }

private:
  // deny copy and assignement
  ScopeGuard(const ScopeGuard&);
  ScopeGuard& operator=(const ScopeGuard&);

  struct functor_base { virtual ~functor_base() { ; } };

  template <typename Fun,typename Arg>
  struct functor : public functor_base
  {
    functor(const Fun& fun,const Arg& arg) : fun_(fun),arg_(arg) { ; }

    ~functor()
    {
      // real work is done here
      try { fun_(arg_); } catch (...) { ; }
      // all exceptions are swallowed:
      // cleanup functions should not emit exceptions
    }

    Fun fun_;
    Arg arg_;
  };

  functor_base* functor_;
}; // ScopeGuard

//------------------------------------------------------------

namespace {
  template <typename T> 
  struct PixelTraits {};

  template <>
  struct PixelTraits<ivllib::Gray8>
  {
    static const int n_components = 1;

    static const J_COLOR_SPACE color_space = JCS_GRAYSCALE;

    static bool accept_components(int n)
    {
      return (n == 1);
    }

    template <typename Iter>
    static Iter assign_pixel(Iter data,
			     ivllib::Gray8& out,
			     int /*components*/)
    {
      out = *data;
      ++data;
      return data;
    }

    template <typename Iter>
    static Iter assign_buffer(Iter it,const ivllib::Gray8& p)
    {
      *it = p;
      ++it;
      return it;
    }

  };

  template <>
  struct PixelTraits<ivllib::RGB8>
  {
    static const int n_components = 3;

    static const J_COLOR_SPACE color_space = JCS_RGB;

    static bool accept_components(int n)
    {
      return (n == 1) || (n == 3);
    }

    template <typename Iter>
    static Iter assign_pixel(Iter data,
			     ivllib::RGB8& out,
			     int components)
    {
      assert(components == 1 || components == 3);

      if (components == 3) {
	out.red = *data;
	++data;
	out.green = *data;
	++data;
	out.blue = *data;
	++data;
      } else {
	out.red = *data;
	out.green = *data;
	out.blue = *data;
	++data;
      } 

      return data;
    }

    template <typename Iter>
    static Iter assign_buffer(Iter it,const ivllib::RGB8& p)
    {
      *it = p.red;
      ++it;
      *it = p.green;
      ++it;
      *it = p.blue;
      ++it;

      return it;
    }

  };

  template <typename T>
  void load_jpeg_aux(const std::string& filename,ivllib::Matrix<T>& out)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    std::vector<JSAMPLE> buffer;

    // open the input file
    FILE* infile = fopen(filename.c_str(), "rb");
    if (infile == 0) {
      std::string msg = "load_jpeg: error opening '";
      msg += filename;
      msg += "'";
      throw ivllib::ImageFileError(msg);
    }
    ScopeGuard file_guard(&fclose,infile);
  
    // create the decompression structure
    jpeg_decompress_struct cinfo;
    my_error_mgr jerr;
    cinfo.err = jpeg_std_error(&jerr.pub);// override error_exit
    jerr.pub.error_exit = my_error_exit;

    // From Pete Becker on comp.lang.c++.moderated:
    // " The behavior of a program that uses longjmp to jump past destructors is
    //   undefined. The language definition does not require that it not destruct
    //   objects. Some implementations do invoke destructors, and they are
    //   completely conforming in this regard. "
  
    // All c++ objects will be declared before setjmp,
    // I hope all the destructor will be correctly called
  
    ScopeGuard jpeg_guard(&jpeg_destroy_decompress,&cinfo);

    // Establish the setjmp return context for my_error_exit to use. */
    if (setjmp(jerr.setjmp_buffer) != 0) {
      // the JPEG code has signaled an error.
      std::string msg = "load_jpeg: ";
      msg += jerr.message;
      throw ivllib::ImageFormatError(msg);
    }

    jpeg_create_decompress(&cinfo);
  
    // assign the source to the decompressor
    jpeg_stdio_src(&cinfo, infile);

    jpeg_read_header(&cinfo, TRUE);
  
    // set custom decompression parameters ? (maybe for greyscale/color management)

    jpeg_start_decompress(&cinfo);

    size_type w = cinfo.output_width;
    size_type h = cinfo.output_height;
  
    int components = cinfo.out_color_components;
    // int n components = cinfo.output_components
    // colormap:the selected colormap, if any
    // actual_number_of_colors: number of entries in colormap
	
    if (!PixelTraits<T>::accept_components(components)) {
      std::ostringstream os;
      os << "load_jpeg: unsupported number of components (" << components << ')';
      throw ivllib::ImageConversionError(os.str());
    }

    buffer.resize(components*w);
    ivllib::Matrix<T> result(h,w);
  
    size_type current_row = 0;
  
    while (cinfo.output_scanline < cinfo.output_height) {
      JSAMPROW row_pointer = &buffer[0];
      int k = jpeg_read_scanlines(&cinfo,&row_pointer,1);
    
      if (k == 0)	
	throw ivllib::ImageFormatError("load_jpeg: error reading a scanline");
      
      
      for (std::size_t i = 0 ; i < w; i++)
	row_pointer = PixelTraits<T>::assign_pixel(row_pointer,
						   result[current_row][i],
						   components);
      ++current_row;
    }
  
    jpeg_finish_decompress(&cinfo);
  
    out.swap(result);
  }
}

//------------------------------------------------------------

namespace {
  template <typename T>
  void save_jpeg_aux(const std::string& filename,
		     const ivllib::Matrix<T>& img,
		     int quality)
  {
    typedef typename ivllib::Matrix<T>::size_type size_type;

    assert( quality >= 0 );
    assert( quality <= 100 );

    std::vector<JSAMPLE> buffer;

    // Specify the destination for the compressed data (i.e., the file)
    FILE* outfile = fopen(filename.c_str(),"wb");
    if (!outfile) {
      std::string message = "save_jpeg: error opening file '";
      message += filename;
      message += "'";
      throw ivllib::ImageFileError(message);
    }
    ScopeGuard file_guard(&fclose,outfile);
    
    // Allocate and initialize a JPEG compression object
    jpeg_compress_struct cinfo;
    my_error_mgr jerr;
  
    cinfo.err = jpeg_std_error(&jerr.pub); // override error_exit
    jerr.pub.error_exit = my_error_exit;

    // From Pete Becker on comp.lang.c++.moderated:
    // " The behavior of a program that uses longjmp to jump past destructors is
    //   undefined. The language definition does not require that it not destruct
    //   objects. Some implementations do invoke destructors, and they are
    //   completely conforming in this regard. "

    // All c++ objects will be declared before setjmp,
    // I hope all the destructor will be correctly called

    ScopeGuard jpeg_guard(&jpeg_destroy_compress,&cinfo);
    jpeg_create_compress(&cinfo);

    // Establish the setjmp return context for my_error_exit to use. */
    if (setjmp(jerr.setjmp_buffer) != 0) {
      // the JPEG code has signaled an error.
      std::string msg = "save_jpeg: ";
      msg += jerr.message;
      throw ivllib::ImageFormatError(msg);
    }

    jpeg_stdio_dest(&cinfo, outfile);

    // Set parameters for compression, including image size & colorspace
    size_type h = img.rows();
    size_type w = img.columns();

    cinfo.image_width = static_cast<JDIMENSION>(w);
    cinfo.image_height = static_cast<JDIMENSION>(h);
    cinfo.input_components = PixelTraits<T>::n_components;
    cinfo.in_color_space = PixelTraits<T>::color_space;
  
    jpeg_set_defaults(&cinfo);

    jpeg_set_quality(&cinfo, quality, TRUE);
  
    // Compression
    jpeg_start_compress(&cinfo, TRUE);

    buffer.resize(w*cinfo.input_components);
  
    while (cinfo.next_scanline < cinfo.image_height) {
      std::vector<JSAMPLE>::iterator it = buffer.begin();
      for (std::size_t i = 0; i < w; i++)
	it = PixelTraits<T>::assign_buffer(it,
					   img[cinfo.next_scanline][i]);
      
      // jpeglib requires a pointer to a row (not to its first element)
      JSAMPROW row_pointer = &buffer[0];
      jpeg_write_scanlines(&cinfo, &row_pointer, 1);
    }
    
    jpeg_finish_compress(&cinfo); // to be put in a guard ?
  }
}

#else
// do not use libjpeg

namespace
{
  
  template <typename T>
  void load_jpeg_aux(const std::string& filename,
		     ivllib::Matrix<T>& out)
  {
    throw ivllib::ImageConversionError("load_jpeg: jpeg format is not supported");
  }

  template <typename T>
  void save_jpeg_aux(const std::string& filename,
		     const ivllib::Matrix<T>& img,
		     int quality)
  {
    throw ivllib::ImageConversionError("save_jpeg: jpeg format is not supported");
  }
}

#endif

//------------------------------------------------------------


void ivllib::load_jpeg(const std::string& filename,
		       ivllib::Matrix<ivllib::RGB8>& out)
{
  load_jpeg_aux(filename,out);
}

void ivllib::load_jpeg(const std::string& filename,
		       ivllib::Matrix<ivllib::RGBA8>& out)
{
  ivllib::Matrix<ivllib::RGB8> rgb;
  load_jpeg(filename,rgb);

  Matrix<RGBA8> tmp(rgb.rows(),rgb.columns());
  std::transform(rgb.begin(),rgb.end(),
		 tmp.begin(),
		 PixelConversion<RGB8,RGBA8>());
  out.swap(tmp);
}

void ivllib::load_jpeg(const std::string& filename,
		       ivllib::Matrix<Gray8>& out)
{
  load_jpeg_aux(filename,out);
}

void ivllib::save_jpeg(const std::string& filename,
		       const ivllib::Matrix<ivllib::RGB8>& img,
		       int quality)
{
  save_jpeg_aux(filename,img,quality);
}

void ivllib::save_jpeg(const std::string& filename,
		       const ivllib::Matrix<Gray8>& img,
		       int quality)
{
  save_jpeg_aux(filename,img,quality);
}
