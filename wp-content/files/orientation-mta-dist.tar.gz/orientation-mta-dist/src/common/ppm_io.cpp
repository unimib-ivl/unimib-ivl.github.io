/**
 * \file    ppm_io.cpp
 * \brief   io routines for the ppm graphic format
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#include <imaging/ppm_io.h>
#include <imaging/exception_io.h>

#include <iostream>
#include <fstream>
#include <iterator>
#include <cassert>
#include <algorithm>

namespace ivllib {

  namespace
  {
    struct pxm_header {
      enum {pbm,pgm,ppm} format;
      std::size_t width;
      std::size_t height;
      unsigned int max_value;
      bool binary;
    };

    void read_header(std::istream& is,pxm_header& out);
    
    void write_header(std::ostream& os,const pxm_header& in);
  }
  
  void load_ppm(const std::string& filename,Matrix<RGB8>& out)
  {
	std::ifstream is(filename.c_str(),std::ios::in | std::ios::binary);
    if (!is) {
      std::string message = "load_ppm: error opening'";
      message += filename;
      message += "'";
      throw ImageFileError(message);
    }

    pxm_header h;
    
    read_header(is,h);

    if (h.format != pxm_header::ppm)
      throw ImageFormatError("load_ppm: wrong magic number");

    typedef Matrix<RGB8> mat_type;
    mat_type result(h.height,h.width);

    for (mat_type::size_type i = 0; i<h.height; i++) {
      for (mat_type::size_type j = 0; j<h.width; j++) {
	if (h.binary) {
	  unsigned char col[3];
	  
	  is.read(reinterpret_cast<char*>(col),1);
	  if (h.max_value > 255)
	    is.get();
	  is.read(reinterpret_cast<char*>(col+1),1);
	  if (h.max_value > 255)
	    is.get();
	  is.read(reinterpret_cast<char*>(col+2),1);
	  if (h.max_value > 255)
	    is.get();

	  if (!is)
	    throw ImageFormatError("load_ppm: error reading from the file"); 
	  
	  result[i][j] = RGB8(col[0],col[1],col[2]);
	} else {
	  unsigned int red;
	  unsigned int green;
	  unsigned int blue;
	  if (!(is >> red >> green >> blue) || 
	      red > h.max_value ||
	      green > h.max_value ||
	      blue > h.max_value)
	    throw ImageFormatError("ppm_load: invalid value");
	  
	  result[i][j] = RGB8( (red * 255)/h.max_value,
					     (green * 255)/h.max_value,
					     (blue * 255)/h.max_value);
	}
      }
    }

    out.swap(result);
  }

  void load_ppm(const std::string& filename,Matrix<RGBA8>& out)
  {
    Matrix<RGB8> rgb;
    load_ppm(filename,rgb);

    Matrix<RGBA8> tmp(rgb.rows(),rgb.columns());
    std::transform(rgb.begin(),rgb.end(),
		   tmp.begin(),
		   PixelConversion<RGB8,RGBA8>());
    out.swap(tmp);
  }

  void save_ppm(const std::string& filename,
		const Matrix<RGB8>& in,
		bool binary)
  {
    std::ofstream os(filename.c_str(),std::ios::binary);
    if (!os) {
      std::string message = "save_ppm: error opening'";
      message += filename;
      message += "'";
      throw ImageFileError(message);
    }

    pxm_header h;

    h.format = pxm_header::ppm;
    h.binary = binary;
    h.width = in.columns();
    h.height = in.rows();
    h.max_value = 255;
    
    write_header(os,h);

    typedef Matrix<Gray8> mat_type;
    mat_type result(h.height,h.width);
    
    for (mat_type::size_type i = 0; i<h.height; i++) {
      for (mat_type::size_type j = 0; j<h.width; j++) {
	if (h.binary) {
	  unsigned char c[3];
	  c[0] = in[i][j].red;
	  c[1] = in[i][j].green;
	  c[2] = in[i][j].blue;
	  os.write(reinterpret_cast<char*>(c),3);
	} else {
	  os << static_cast<unsigned int>(in[i][j].red) << ' '
	     << static_cast<unsigned int>(in[i][j].green) << ' '
	     << static_cast<unsigned int>(in[i][j].blue);
	  if ((i>0 || j>0) && (i*h.height + j) % 6 == 0)
	    os << '\n';
	  else
	    os << ' ';
	}
      }
    }     
    if (!h.binary)
      os << '\n';

    if (!os)
      throw ImageFileError("save_ppm: error writing to the file");    
  }

  void save_ppm(const std::string& filename,
		const Matrix<Gray8>& in,
		bool binary)
  {
    Matrix<RGB8> tmp(in.rows(),in.columns());
    std::transform(in.begin(),
		   in.end(),
		   tmp.begin(),
		   PixelConversion<Gray8,RGB8>());
    
    save_ppm(filename,tmp,binary);
  }

  namespace {

    void skip_comments(std::istream& is)
    {
	  std::streamsize MAX_COMMENT_LENGTH = 1024;

      char c;
      while (is >> c && c == '#') {
	std::streamsize last = MAX_COMMENT_LENGTH;
	while (last == MAX_COMMENT_LENGTH) {
	  is.ignore(MAX_COMMENT_LENGTH,'\n');
	  last = is.gcount();
	}
      }
    
      if (is)
	is.putback(c);
    }

    void read_header(std::istream& is,pxm_header& out)
    {
      char c;
  
      skip_comments(is);
      if (!(is >> c) || c!='P')
	throw ImageFormatError("read_header: invalid header");

      skip_comments(is);
      if (!(is >> c))
	throw ImageFormatError("read_header: unexpected end of file");
  
      out.max_value = 0;

      switch(c) {
      case '1':
	// binary pbm 
	out.binary = false;
	out.format = pxm_header::pbm;
	out.max_value = 1;
	break;
      case '2':
	// binary pgm 
	out.binary = false;
	out.format = pxm_header::pgm;
	break;
      case '3':
	// binary ppm 
	out.binary = false;
	out.format = pxm_header::ppm;
	break;
      case '4':
	// text pbm 
	out.binary = true;
	out.format = pxm_header::pbm;
	out.max_value = 1;
	break;
      case '5':
	// text pgm 
	out.binary = true;
	out.format = pxm_header::pgm;
	break;
      case '6':
	// text ppm 
	out.binary = true;
	out.format = pxm_header::ppm;
	break;
      default:
	throw ImageFormatError("read_header: invalid header");
      }

      skip_comments(is);
      is >> out.width;

      skip_comments(is);
      is >> out.height;

      if (!is || out.width < 0 || out.height < 0)
	throw ImageFormatError("read_header: invalid image dimension");
    
      if (out.format != pxm_header::pbm) {
	skip_comments(is);
	is >> out.max_value;

	if (!is || out.max_value < 1 || out.max_value > 65535)
	  throw ImageFormatError("read_header: unsupported maximum value");
      }
  
      if (!is.get(c))
	throw ImageFormatError("read_header: unexpected end of file");
    }

    void write_header(std::ostream& os,const pxm_header& in)
    {
      os << "P";
      const char* codes = "0123456";
      int fmt = 0;
      switch (in.format) {
      case pxm_header::pbm:
	fmt = 1;
	break;
      case pxm_header::pgm:
	fmt = 2;
	break;
      case pxm_header::ppm:
	fmt = 3;
	break;
      default:
	assert(false);
      }
      if (in.binary)
	fmt += 3;
    
      os << codes[fmt] << '\n';
      os << "# created by the ivllib library\n";
      os << in.width << ' ' << in.height << '\n';
      if (in.format != pxm_header::pbm)
	os << in.max_value << '\n';
    }
  }
} // ivllib
