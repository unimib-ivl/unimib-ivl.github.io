#include <threading/threading.h>


#include <pthread.h>
#include <errno.h>
#include <sys/time.h>
#include <cassert>
#include <stdexcept>
#include <cstring>  // strerror
#include <cmath>  // modf
#include <string>
#include <memory>  // auto_ptr


namespace
{
  // just provide an non-null address, used to report that an
  // exception occurred.
  int thread_error;
};


struct cc::Thread::impl
{
  pthread_t pt;
  bool joinable;  
};


cc::Thread::Thread()
  : impl_(new impl)
{
  impl_->joinable = false;
}


cc::Thread::~Thread()
{
  if (impl_->joinable)
    detach();
  delete impl_;
}


void cc::Thread::join()
{
  // Join the thread and retrieve the return value.
  void* retcode;
  int ret = pthread_join(impl_->pt, &retcode);

  if (ret != 0)
    throw std::runtime_error(strerror(ret));

  impl_->joinable = false;

  if (retcode != 0) {
    // If the function returned a non null pointer, then the thread
    // ended beacause of an exception.
    
    std::string msg = "The thread has been terminated by an exception.";
    throw std::runtime_error(msg);
  }
}


void cc::Thread::detach()
{
  int ret = pthread_detach(impl_->pt);

  if (ret != 0)
    throw std::runtime_error(strerror(ret));

  impl_->joinable = false;
}


bool cc::Thread::joinable() const
{
  return impl_->joinable;
}


void cc::Thread::start(const std::tr1::function<void()>& f)
{
  // make a copy of f so that it can be passed to the thread body
  std::tr1::function<void()>* fun = new std::tr1::function<void()>(f);

  int ret = pthread_create(&(impl_->pt), 0, &thread_run_, fun);

  if (ret != 0) {
    delete fun;
    throw std::runtime_error(strerror(ret));
  }
  
  impl_->joinable = true;
}



void* cc::Thread::thread_run_(void* arg)
{
  // Execute the functor passed in arg.  The functor has been
  // dynamically allocated and need to be deallocated when its
  // execution is finished. In case of an exception, a non-null
  // pointer is returned.  In this case, an exception will be thrown
  // by the join method.  For detached threads, exceptions are just
  // ignored.

  assert( arg != 0 );
  
  typedef std::tr1::function<void()> callback_t;
  
  std::auto_ptr<callback_t> fun(static_cast<callback_t*>(arg));
  try {
    (*fun)();
  } catch (...) {
    return (void*)(&thread_error);
  }

  return 0;
}


struct cc::Mutex::impl
{
  pthread_mutex_t pm;
};


cc::Mutex::Mutex()
  : impl_(new impl)
{
  int ret = pthread_mutex_init(&(impl_->pm), 0);

  if (ret != 0) {
    delete impl_;
    throw std::runtime_error(strerror(ret));
  }
}


cc::Mutex::~Mutex()
{
  pthread_mutex_destroy(&(impl_->pm));
  delete impl_;
}


void cc::Mutex::lock()
{
  int ret = pthread_mutex_lock(&(impl_->pm));
  if (ret != 0)
    throw std::runtime_error(strerror(ret));
}


bool cc::Mutex::trylock()
{
  int ret = pthread_mutex_trylock(&(impl_->pm));
  if (ret == EBUSY)
    return false;
  if (ret != 0)
    throw std::runtime_error(strerror(ret));
  return true;
}


void cc::Mutex::unlock()
{
  int ret = pthread_mutex_unlock(&(impl_->pm));
  if (ret != 0)
    throw std::runtime_error(strerror(ret));
}


cc::Lock::Lock()
  : mutex_(0)
{
}


cc::Lock::Lock(Mutex& m)
  : mutex_(0)
{
  lock(m);
}


cc::Lock::~Lock()
{
  unlock();
}


void cc::Lock::lock(Mutex& m)
{
  // After locking m, the previous mutex is unlocked (if any).
  m.lock();
  unlock();
  mutex_ = &m;
}


bool cc::Lock::trylock(Mutex& m)
{
  // If locking of m succeds, the previous mutex is unlocked (if any).
  bool ret = m.trylock();
  if (!ret)
    return false;
  unlock();
  mutex_ = &m;
  return true;
}


void cc::Lock::unlock()
{
  if (locked()) {
    mutex_->unlock();
    mutex_ = 0;
  }
}


bool cc::Lock::locked() const
{
  return mutex_ != 0;
}


struct cc::Condition::impl
{
  pthread_cond_t pc;
};


cc::Condition::Condition()
  : impl_(new impl)
{
  int ret = pthread_cond_init(&(impl_->pc), 0);
  if (ret != 0) {
    delete impl_;
    throw std::runtime_error(strerror(ret));
  }
}


cc::Condition::~Condition()
{
  pthread_cond_destroy(&(impl_->pc));
  delete impl_;
}


void cc::Condition::wait(Lock& l)
{
  if (!l.locked())
    throw std::runtime_error("Lock has not been acquired");

  assert( l.mutex_ != 0 );
  assert( l.mutex_->impl_ != 0 );
  pthread_mutex_t* mutex = &(l.mutex_->impl_->pm);
  int ret = pthread_cond_wait(&(impl_->pc), mutex);

  if (ret != 0)
    throw std::runtime_error(strerror(ret));
}


bool cc::Condition::wait(Lock& l, double timeout)
{
  assert(timeout >= 0.0);

  if (!l.locked())
    throw std::runtime_error("Lock has not been acquired");

  // The timeout must be converted into a timespec structure.  This is
  // done by retrieving the current time and updating the appropriate
  // fields.
  struct timeval time;
  gettimeofday(&time, NULL);

  // Update timeout to be absolute, as required by
  // pthread_cond_timedwait.
  timeout += time.tv_sec;
  timeout += 1.0e-6 * time.tv_usec;

  // Convert the updated timeout into an istance of timespec.
  double intpart = 0.0;
  double fracpart = std::modf(timeout, &intpart);

  struct timespec ts;
  ts.tv_sec = static_cast<long>(intpart);
  ts.tv_nsec =  static_cast<long>(1.0e9 * fracpart);

  // retrieve the mutex from the lock object and call the pthread
  // function.
  assert( l.mutex_ != 0 );
  assert( l.mutex_->impl_ != 0 );
  pthread_mutex_t* mutex = &(l.mutex_->impl_->pm);
  int ret = pthread_cond_timedwait(&(impl_->pc), mutex, &ts);

  if (ret == ETIMEDOUT)
    return false;

  if (ret != 0)
    throw std::runtime_error(strerror(ret));
  return true;
}


void cc::Condition::notify()
{
  int ret = pthread_cond_signal(&(impl_->pc));
  if (ret != 0)
    throw std::runtime_error(strerror(ret));
}


void cc::Condition::notify_all()
{
  int ret = pthread_cond_broadcast(&(impl_->pc));
  if (ret != 0)
    throw std::runtime_error(strerror(ret));
}
