#include <framework/basic_feature_computer.h>

#include <iostream>
#include <iomanip>
#include <exception>
#include <cstdlib>

#ifdef ENABLE_MULTITHREADING
#include <queue>
#include <threading/threading.h>
#include <threading/queue.h>
#endif


// -- public -----------------------------------------------------------

BasicFeatureComputer::BasicFeatureComputer()
  : usage_(""),
    threads_(1)
{
}


BasicFeatureComputer::~BasicFeatureComputer()
{
}


int
BasicFeatureComputer::run(int argc, char* argv[])
{
  try {
    run_(argc, argv);
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
    return EXIT_FAILURE;
  } catch (...) {
    std::cerr << "Unknown exception" << std::endl;
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}


void
BasicFeatureComputer::set_usage(const std::string& usage)
{
  usage_ = usage;
}


void
BasicFeatureComputer::set_threads(int n)
{
  assert(n > 0);
#ifndef ENABLE_MULTITHREADING
  if (n > 1)
    throw std::runtime_error("Multithreading not supported");
#endif
  threads_ = n;
}


// -- protected --------------------------------------------------------

void
BasicFeatureComputer::do_setup_options(cc::OptionParser& parser)
{
}


void
BasicFeatureComputer::do_parse_options(cc::OptionParser& parser,
				       const cc::ParsedOptions& options,
				       BasicFeatureComputer::ImageList& images)
{
  images.clear();
}


void
BasicFeatureComputer::do_output(const BasicFeatureComputer::Features& features)
{
  Features::size_type n = features.size();
  for (Features::size_type i = 0; i < n; i++)
    std::cout << features[i]
	      << (i + 1 < n ? '\t' : '\n');
}


// -- private ----------------------------------------------------------

void
BasicFeatureComputer::run_(int argc, char* argv[])
{
  cc::OptionParser parser(usage_);

  this->do_setup_options(parser);
  cc::ParsedOptions opts = parser.parse_cmd_line(argc, argv);
  ImageList images;
  this->do_parse_options(parser, opts, images);
  if (threads_ > 1)
    process_images_multi_(images);
  else
    process_images_single_(images);
}


#ifdef ENABLE_MULTITHREADING
struct BasicFeatureComputer::Processor
{
  struct Job
  {
    ImageList::size_type id;
    std::string fname;
    Features features;
    std::string error;
    
    // reverse order, used by the priority queue
    bool operator<(const Job& j) const { return id > j.id; }
  };

  explicit Processor(const BasicFeatureComputer* acomputer,
		     cc::Queue<Job>* aqin,
		     cc::Queue<Job>* aqout)
    : computer(acomputer),
      qin(aqin),
      qout(aqout)
  {
    assert(computer != 0);
    assert(qin != 0);
    assert(qout != 0);
  }
  
  void operator()()
  {
    Job job;
    while (qin->pop(job)) {
      job.error = "";
      try {
	computer->do_process_image(job.fname, job.features);
      } catch (std::exception& e) {
	job.error = e.what();
      } catch (...) {
	job.error = "unknwon error";
      }	
      qout->push(job);
    }
  }
  
  const BasicFeatureComputer* computer;
  cc::Queue<Job>* qin;
  cc::Queue<Job>* qout;
};

#endif  // ENABLE_MULTITHREADING

void
BasicFeatureComputer::process_images_single_(const ImageList& images)
{
  Features features;
  for (ImageList::size_type i = 0; i < images.size(); i++) {
    this->do_process_image(images[i], features);
    this->do_output(features);
  }
}

#ifdef ENABLE_MULTITHREADING
void
BasicFeatureComputer::process_images_multi_(const ImageList& images)
{
  ImageList::size_type n = images.size();
  ImageList::size_type qsize = 4 * threads_;

  cc::Queue<Processor::Job> imgqueue(qsize);
  cc::Queue<Processor::Job> resqueue(qsize);
  std::priority_queue<Processor::Job> buffer;

  Processor::Job job;

  cc::Thread* processors = new cc::Thread[threads_];
  for (int i = 0; i < threads_; i++)
    processors[i].start(Processor(this, &imgqueue, &resqueue));

  ImageList::size_type nextimg = 0;
  ImageList::size_type expected = 0;
  ImageList::size_type pending = 0;
  while (expected != n) {
    while (pending < qsize && nextimg != n) {
      job.id = nextimg;
      job.fname = images[nextimg];      
      job.features.clear();
      imgqueue.push(job);
      ++nextimg;
      ++pending;
      if (nextimg == n)
	imgqueue.close();
    }
    resqueue.pop(job);
    buffer.push(job);
    while (!buffer.empty() && buffer.top().id == expected) {
      const Processor::Job& top = buffer.top();
      if (top.error == "")
	do_output(top.features);
      else
	std::cerr << top.fname << " skipped (" << top.error << ").\n";
      buffer.pop();
      --pending;
      ++expected;
    }
  }
  for (int i = 0; i < threads_; i++)
    processors[i].join();
}

#else

void
BasicFeatureComputer::process_images_multi_(const ImageList&)
{
  throw std::runtime_error("Multithreading not supported");
}

#endif  // ENABLE_MULTITHREADING
