/**
 * \file    pgm_io.cpp
 * \brief   io routines for the pgm graphic format
 * \author  $LastChangedBy$
 * \date    $Date$
 * \version $Revision$
 */

#include <imaging/pgm_io.h>
#include <imaging/exception_io.h>

#include <iostream>
#include <fstream>
#include <iterator>
#include <cassert>
#include <algorithm>

namespace ivllib {

  namespace
  {
    struct pxm_header {
      enum {pbm,pgm,ppm} format;
      std::size_t width;
      std::size_t height;
      unsigned int max_value;
      bool binary;
    };

    void read_header(std::istream& is,pxm_header& out);
    
    void write_header(std::ostream& os,const pxm_header& in);
  }
  
  void load_pgm(const std::string& filename,Matrix<Gray8>& out)
  {
    std::ifstream is(filename.c_str(),std::ios::binary);
    if (!is) {
      std::string message = "load_pgm: error opening'";
      message += filename;
      message += "'";
      throw ImageFileError(message);
    }
    
    pxm_header h;
    
    read_header(is,h);

    if (h.format != pxm_header::pgm)
      throw ImageFormatError("load_pgm: wrong magic number");

    typedef Matrix<Gray8> mat_type;
    mat_type result(h.height,h.width);

    for (mat_type::size_type i = 0; i<h.height; i++) {
      for (mat_type::size_type j = 0; j<h.width; j++) {
	if (h.binary) {
	  char c;
	  is.read(&c,1);
	  if (h.max_value > 255)
	    is.get();
	  if (!is) 
	    throw ImageFormatError("load_pgm: error reading from the file");

	  result[i][j] = c;
	} else {
	  unsigned int x;
	  if (!(is >> x) || x > h.max_value)
	    throw ImageFormatError("load_pgm: invalid pixel value");
	  
	  result[i][j] = (x * 255)/h.max_value;
	}
      }
    }

    out.swap(result);
  }

  void load_pgm(const std::string& filename,Matrix<RGB8>& out)
  {
    Matrix<Gray8> m;
    load_pgm(filename,m);
    Matrix<RGB8> tmp(m.rows(),m.columns());
    std::transform(m.begin(),
		   m.end(),
		   tmp.begin(),
		   PixelConversion<Gray8,RGB8>());

    out.swap(tmp);
  }

  void load_pgm(const std::string& filename,Matrix<RGBA8>& out)
  {
    Matrix<Gray8> m;
    load_pgm(filename,m);
    Matrix<RGBA8> tmp(m.rows(),m.columns());
    std::transform(m.begin(),
		   m.end(),
		   tmp.begin(),
		   PixelConversion<Gray8,RGBA8>());

    out.swap(tmp);
  }

  void save_pgm(const std::string& filename,
		const Matrix<Gray8>& in,
		bool binary)
  {
    std::ofstream os(filename.c_str(),std::ios::binary);
    if (!os) {
      std::string message = "save_pgm: error opening'";
      message += filename;
      message += "'";
      throw ImageFileError(message);
    }

    pxm_header h;

    h.format = pxm_header::pgm;
    h.binary = binary;
    h.width = in.columns();
    h.height = in.rows();
    h.max_value = 255;
    
    write_header(os,h);

    typedef Matrix<Gray8> mat_type;
    mat_type result(h.height,h.width);
    
    for (mat_type::size_type i = 0; i<h.height; i++) {
      for (mat_type::size_type j = 0; j<h.width; j++) {
	if (h.binary) {
	  unsigned char c = in[i][j];
	  os.write(reinterpret_cast<char*>(&c),1);
	} else {
	  os << static_cast<unsigned int>(in[i][j]);
	  if ((i>0 || j>0) && (i*h.height + j) % 16 == 0)
	    os << '\n';
	  else
	    os << ' ';
	}
      }
    }     
    if (!h.binary)
      os << '\n';

    if (!os)
      throw ImageFileError("save_pgm: error writing to the file");    
  }

  namespace {

    void skip_comments(std::istream& is)
    {
      std::streamsize MAX_COMMENT_LENGTH = 1024;

      char c;
      while (is >> c && c == '#') {
	std::streamsize last = MAX_COMMENT_LENGTH;
	while (last == MAX_COMMENT_LENGTH) {
	  is.ignore(MAX_COMMENT_LENGTH,'\n');
	  last = is.gcount();
	}
      }
    
      if (is)
	is.putback(c);
    }

    void read_header(std::istream& is,pxm_header& out)
    {
      char c;
  
      skip_comments(is);
      if (!(is >> c) || c!='P')
	throw ImageFormatError("read_header: invalid header");

      skip_comments(is);
      if (!(is >> c))
	throw ImageFormatError("read_header: unexpected end of file");
  
      out.max_value = 0;

      switch(c) {
      case '1':
	// binary pbm 
	out.binary = false;
	out.format = pxm_header::pbm;
	out.max_value = 1;
	break;
      case '2':
	// binary pgm 
	out.binary = false;
	out.format = pxm_header::pgm;
	break;
      case '3':
	// binary ppm 
	out.binary = false;
	out.format = pxm_header::ppm;
	break;
      case '4':
	// text pbm 
	out.binary = true;
	out.format = pxm_header::pbm;
	out.max_value = 1;
	break;
      case '5':
	// text pgm 
	out.binary = true;
	out.format = pxm_header::pgm;
	break;
      case '6':
	// text ppm 
	out.binary = true;
	out.format = pxm_header::ppm;
	break;
      default:
	throw ImageFormatError("read_header: invalid header");
      }

      skip_comments(is);
      is >> out.width;

      skip_comments(is);
      is >> out.height;

      if (!is || out.width < 0 || out.height < 0)
	throw ImageFormatError("read_header: invalid image dimension");
    
      if (out.format != pxm_header::pbm) {
	skip_comments(is);
	is >> out.max_value;

	if (!is || out.max_value < 1 || out.max_value > 65535)
	  throw ImageFormatError("read_header: unsupported maximum value");
      }
  
      if (!is.get(c))
	throw ImageFormatError("read_header: unexpected end of file");
    }

    void write_header(std::ostream& os,const pxm_header& in)
    {
      os << "P";
      const char* codes = "0123456";
      int fmt = 0;
      switch (in.format) {
      case pxm_header::pbm:
	fmt = 1;
	break;
      case pxm_header::pgm:
	fmt = 2;
	break;
      case pxm_header::ppm:
	fmt = 3;
	break;
      default:
	assert(false);
      }
      if (in.binary)
	fmt += 3;
    
      os << codes[fmt] << '\n';
      os << "# created by the ivllib library\n";
      os << in.width << ' ' << in.height << '\n';
      if (in.format != pxm_header::pbm)
	os << in.max_value << '\n';
    }
  }
} // ivllib
