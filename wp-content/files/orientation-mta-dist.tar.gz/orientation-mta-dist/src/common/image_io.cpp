/**
 * \file    image_io.cpp
 * \brief   io routines for loading and saving images
 */
#include <imaging/pgm_io.h>
#include <imaging/ppm_io.h>
#include <imaging/jpeg_io.h>
#include <imaging/png_io.h>
#include <imaging/bmp_io.h>
#include <imaging/exception_io.h>

#include <cctype>

namespace
{
  /* extract the lowercase extension from the filename str
   * for example: extension("pippo.Jpg") == "jpg"
   * return the empty string if the filename does not contain a dot
   */
  std::string extension(const std::string& str)
  {
    std::string::size_type i = str.rfind('.');
    
    if (i == std::string::npos)
      return "";
    
    std::string ret = str.substr(i + 1);

    for (std::string::size_type i = 0; i < ret.size(); i++)
      ret[i] = std::tolower(ret[i]);

    return ret;
  }
}

namespace ivllib
{

  void load_image(const std::string& filename,Matrix<RGB8>& out)
  {
    std::string ext = extension(filename);

    if (ext == "jpg" || ext == "jpeg")
      load_jpeg(filename,out);
    else if (ext == "png")
      load_png(filename,out);
    else if (ext == "pgm")
      load_pgm(filename,out);
    else if (ext == "ppm")
      load_ppm(filename,out);
    else if (ext == "bmp" || ext == "dib")
      load_bmp(filename,out);
    else {
      std::string message = "load_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }

  void load_image(const std::string& filename,Matrix<RGBA8>& out)
  {
    std::string ext = extension(filename);

    if (ext == "jpg" || ext == "jpeg")
      load_jpeg(filename,out);
    else if (ext == "png")
      load_png(filename,out);
    else if (ext == "pgm")
      load_pgm(filename,out);
    else if (ext == "ppm")
      load_ppm(filename,out);
    else if (ext == "bmp" || ext == "dib")
      load_bmp(filename,out);
    else {
      std::string message = "load_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }

  void load_image(const std::string& filename,Matrix<Gray8>& out)
  {
    std::string ext = extension(filename);

    if (ext == "jpg" || ext == "jpeg")
      load_jpeg(filename,out);
    else if (ext == "png")
      load_png(filename,out);
    else if (ext == "pgm")
      load_pgm(filename,out);
    else {
      std::string message = "load_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }
  
  void save_image(const std::string& filename,const Matrix<RGB8>& in)
  {
    std::string ext = extension(filename);

    if (ext == "jpg" || ext == "jpeg")
      save_jpeg(filename,in);
    else if (ext == "png")
      save_png(filename,in);
    else if (ext == "ppm")
      save_ppm(filename,in);
    else {
      std::string message = "save_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }

  void save_image(const std::string& filename,const Matrix<RGBA8>& in)
  {
    std::string ext = extension(filename);

    if (ext == "png")
      save_png(filename,in);
    else {
      std::string message = "save_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }

  void save_image(const std::string& filename,const Matrix<Gray8>& in)
  {
    std::string ext = extension(filename);

    if (ext == "jpg" || ext == "jpeg")
      save_jpeg(filename,in);
    else if (ext == "png")
      save_png(filename,in);
    else if (ext == "pgm")
      save_pgm(filename,in);
    else if (ext == "ppm")
      save_ppm(filename,in);
    else {
      std::string message = "save_image: unsupported format";
      if (ext != "") {
	message += " '";
	message += ext;
	message += "'";
      }
      throw ImageConversionError(message);
    }
  }

} // namespace ivllib
