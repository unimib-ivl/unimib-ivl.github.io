#include <features/utils.h>
#include <sstream>
#include <stdexcept>
#include <cmath>


namespace
{
  std::istream& skip_blank(std::istream& is)
  {
    char c;
    while (is >> c) {
      if (c == '#') {
	if (!is.ignore((1 << 15), '\n'))
	  break;
      } else {
	is.putback(c);
	break;
      }
    }
    return is;
  }


  void parse_line(const std::string& line,
		  ivllib::Vector<double>& v)
  {
    std::istringstream is(line);
    std::vector<double> tmp;
    double x;
    while (is >> x)
      tmp.push_back(x);
    if (!is.eof())
      throw std::runtime_error("Error reading the feature vector (invalid value)");
    ivllib::Vector<double>(tmp.begin(), tmp.end()).swap(v);
  }


  void parse_sparse_line(const std::string& line,
			 std::vector<std::pair<long, double> >& v)
  {
    std::istringstream is(line);
    std::vector<std::pair<long, double> > tmp;
    double x;
    long i;
    char c;
    while (is >> i >> c >> x) {
      if (c != ':')
	throw std::runtime_error("Error reading the feature vector (invalid format)");
      tmp.push_back(std::make_pair(i, x));
    }
    if (!is.eof())
      throw std::runtime_error("Error reading the feature vector");
    std::vector<std::pair<long, double> >(tmp.begin(), tmp.end()).swap(v);
  }
  
}  // anonymous namespace


std::istream&
read_features(std::istream& is, ivllib::Vector<double>& v)
{
  if (!skip_blank(is)) {
    v.clear();
    return is;
  }
  
  std::string line;
  if (!std::getline(is, line)) {
    v.clear();
    return is;
  }

  parse_line(line, v);
  return is;
}


std::istream&
read_features(std::istream& is, std::string& label, ivllib::Vector<double>& v)
{
  if (!skip_blank(is)) {
    v.clear();
    return is;
  }
  
  if (!(is >> label)) {
    v.clear();
    return is;
  }

  std::string line;
  if (!std::getline(is, line)) {
    v.clear();
    return is;
  }

  parse_line(line, v);
  return is;
}


std::ostream&
write_features(std::ostream& os, const ivllib::Vector<double>& v)
{
  typedef ivllib::Vector<double>::size_type size_type;
  size_type n = v.size();
  for (size_type i = 0; i < n; i++) {
    if (i != 0)
      os << ' ';
    if (!(os << v[i]))
      break;
  }
  return os;
}


std::ostream&
write_features(std::ostream& os,
	       const std::string& label,
	       const ivllib::Vector<double>& v)
{
  if (os << label << ' ')
    write_features(os, v);
  return os;
}


void
sparsify(const ivllib::Vector<double>& dense,
	 std::vector<std::pair<long, double> >& sparse,
	 double toll)
{
  std::vector<std::pair<long, double> > ret;
  typedef ivllib::Vector<double>::size_type size_type;

  size_type n = dense.size();
  for (size_type i = 0; i < n; i++) {
    double val = dense[i];
    if (std::fabs(val) > toll)
      ret.push_back(std::make_pair(static_cast<long>(i + 1), val));
  }
  sparse.swap(ret);
}


void
unsparsify(const std::vector<std::pair<long, double> >& sparse,
	   ivllib::Vector<double>& dense,
	   ivllib::Vector<double>::size_type minsize)
{
  typedef ivllib::Vector<double>::size_type size_type;
  
  size_type k = sparse.size();
  size_type sz = minsize;
  for (size_type i = 0; i < k; i++) {
    assert(sparse[i].first > 0);
    size_type u = sparse[i].first - 1;
    if (u >= sz)
      sz = u + 1;
  }

  ivllib::Vector<double> ret(sz, 0.0);
  for (size_type i = 0; i < k; i++)
    ret[sparse[i].first - 1] = sparse[i].second;

  dense.swap(ret);
}


std::istream&
read_sparse_features(std::istream& is,
		     std::vector<std::pair<long, double> >& v)
{
  if (!skip_blank(is)) {
    v.clear();
    return is;
  }
  
  std::string line;
  if (!std::getline(is, line)) {
    v.clear();
    return is;
  }

  parse_sparse_line(line, v);
  return is;
}


std::istream&
read_sparse_features(std::istream& is,
		     std::string& label,
		     std::vector<std::pair<long, double> >& v)
{
  if (!skip_blank(is)) {
    v.clear();
    return is;
  }
  
  if (!(is >> label)) {
    v.clear();
    return is;
  }

  std::string line;
  if (!std::getline(is, line)) {
    v.clear();
    return is;
  }

  parse_sparse_line(line, v);
  return is;
}




std::ostream&
write_sparse_features(std::ostream& os,
		      const std::vector<std::pair<long, double> >& sparse)
{
  typedef std::vector<std::pair<long, double> >::size_type size_type;
  
  size_type n = sparse.size();
  for (size_type i = 0; i < n; i++) {
    if (i != 0)
      os << ' ';
    os << sparse[i].first << ':' << sparse[i].second;
  }
  return os;
}


std::ostream&
write_sparse_features(std::ostream& os,
		      const std::string& label,
		      const std::vector<std::pair<long, double> >& sparse,
		      long start_index)
{
  typedef std::vector<std::pair<long, double> >::size_type size_type;

  --start_index;  // sparse[i].first already starts at 1.
  size_type n = sparse.size();
  os << label;
  for (size_type i = 0; i < n; i++)
    os << ' ' << (sparse[i].first + start_index) << ':' << sparse[i].second;
  return os;
}
