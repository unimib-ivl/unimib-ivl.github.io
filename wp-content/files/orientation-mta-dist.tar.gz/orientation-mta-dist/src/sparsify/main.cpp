#include <features/utils.h>

#include <iostream>
#include <fstream>
#include <exception>
#include <options/option_parser.h>



const char* USAGE= "Usage: sparsify [OPTIONS] [INFILE] [OUTFILE]\n"
  "\n"
  "Convert data to the sparse format used by LIBSVM.\n\n\n";



int dowork(int argc, char* argv[])
{
  std::string usage = argv[0];
  usage += " [OPTIONS...] INFILE OUTFILE";

  cc::OptionParser parser(usage);

  parser.add_option(cc::Option("threshold", 't', "T",
			       "GENERAL OPTIONS",
			       "Threshold used to decide if a value is zero "
			       "(default 1e-15)."));

  parser.add_option(cc::Option("class", 'c', "LABEL",
			       "GENERAL OPTIONS",
			       "Assign LABEL to each vector. If omitted, "
			       "the first element of each vector is used."));

  parser.add_option(cc::Option("start-index", 's', "INDEX",
			       "GENERAL OPTIONS",
			       "Index of the first feature (default 1)."));

  parser.add_option(cc::Option("help", 'h', cc::Option::noparam,
			       "GENERAL OPTIONS",
			       "print this message and exit."));

  cc::ParsedOptions options = parser.parse_cmd_line(argc, argv);

  if (options.contains_option("help")) {
    std::string msg =
      "Read data vectors from INFILE and rewrite them to OUTFILE in\n"
      "the LIBSVM format.  When INFILE and OUTFILE are omitted (or when\n"
      "they are '-') standard input and/or output is used.\n";
      
    parser.print_help(msg);
    return 0;
  }

  double threshold = options.double_parameter_value("threshold", 1e-15);
  int start_index = options.int_parameter_value("start-index", 1);
  bool haslabel = options.contains_option("class");
  std::string label = "";
  if (haslabel)
    label = options.parameter_value("class", "");
    
  if (options.argc() > 3)
    parser.error("Too many arguments");

  std::string infile = "-";
  std::string outfile = "-";

  if (options.argc() > 1)
    infile = options.argv(1);
  if (options.argc() > 2)
    outfile = options.argv(2);
  
  std::istream* input = &std::cin;
  std::ostream* output = &std::cout;

  std::ifstream input_f;
  std::ofstream output_f;

  if (infile != "-") {
    input_f.open(infile.c_str());
    if (!input_f)
      throw std::runtime_error("Error opening the input file");
    input = &input_f;
  }

  if (outfile != "-") {
    output_f.open(outfile.c_str());
    if (!output_f)
      throw std::runtime_error("Error opening the output file");
    output = &output_f;
  }
  
    ivllib::Vector<double> dense;
  std::vector<std::pair<long, double> > sparse;

  while (haslabel
	 ? read_features(*input, dense)
	 : read_features(*input, label, dense)) {

    sparsify(dense, sparse, threshold);
    if (!write_sparse_features(*output, label, sparse, start_index) || !((*output) << '\n'))
      throw std::runtime_error("Error writing the data");
  }

  if (!input->eof())
    throw std::runtime_error("Error reading the data");
  
  return 0;
}


int main(int argc, char* argv[])
{
  try {
    return dowork(argc, argv);
  } catch (std::exception& e) {
    std::cerr << e.what() << std::endl;
  } catch (...) {
    std::cerr << "Unknown error" << std::endl;
  }
  return 2;
}
