#include <framework/box_feature_computer.h>
#include <features/basic_features.h>

#include <numerical/vector_op.h>
#include <iostream>
#include <stringop.h>


const char* USAGE= "Usage: rgbhistogram [OPTIONS] [IMAGES...]\n"
  "\n"
  "Compute the histogram of the quantized RGB color space.\n";


class RGBHistogramComputer
  : public BoxFeatureComputer<ivllib::label_type>
{
public:
  typedef BoxFeatureComputer<ivllib::label_type> Super;

  RGBHistogramComputer()
    : Super(),
      qred_(4),
      qgreen_(4),
      qblue_(4),
      normalized_(false),
      marginal_(false)
  {
  }
  
protected: 

  virtual void do_setup_options(cc::OptionParser& parser)
  {
    Super::do_setup_options(parser);
    parser.add_option(cc::Option("marginal", 'M', cc::Option::noparam,
				 "FEATURES",
				 "Compute three marginal histograms instead "
				 "of a single joint histogram."));
    parser.add_option(cc::Option("normalized", 'N', cc::Option::noparam,
				 "FEATURES",
				 "Normalize the histogram to have unitary "
				 "sum."));
    parser.add_option(cc::Option("quantization", 'Q', "BINS",
				 "FEATURES",
				 "Indicate the number of bins for each "
				 "channel. A single number indicates the "
				 "same quantization over the three channels. "
				 "A triplet NxMxK indicates N, M, K bins "
				 "for the red, green, and blue channels, "
				 "respectively. The number of bins must be "
				 "in the range [1,256] (default 4)."));
  }

  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images)
  {
    Super::do_parse_options(parser, options, images);
    normalized_ = options.contains_option("normalized");
    marginal_ = options.contains_option("marginal");
    std::string q = options.parameter_value("quantization", "4");
    std::string a, b, c;
    std::tr1::tie(a, b, c) = cc::str::partition(q, "x");
    if (b.size() == 0) {
      qred_ = qgreen_ = qblue_ = cc::str::tolong(a, 0);
    } else {
      qred_ = cc::str::tolong(a, 0);
      std::tr1::tie(a, b, c) = cc::str::partition(c, "x");
      if (b.size() == 0) {
	qgreen_ = qblue_ = 0;
      } else {
	qgreen_ = cc::str::tolong(a, 0);
	qblue_ = cc::str::tolong(c, 0);
      }
    }
    if (qred_ < 1 || qred_ > 256 ||
	qgreen_ < 1 || qgreen_ > 256 ||
	qblue_ < 1 || qblue_ > 256)
      parser.error("Invalid value for the 'quantization' option.");
  }

  virtual void do_compute_preimage(const RGBImage& in,
				   PreImage& out) const
  {
    // For marginal histograms, leave the channels unmangled so that
    // they will be easier to process later on.
    if (marginal_)
      rgbquantization(in, 256, 256, 256, out);
    else
      rgbquantization(in, qred_, qgreen_, qblue_, out);
  }

  virtual void do_compute_block_feature(PreImage& in,
					const ivllib::Box& box,
					Features& features) const
  {
    if (marginal_) {
      this->compute_marginal_(in, box, features);
    } else {
      ivllib::Vector<ivllib::label_type> h;
      make_histogram(in, qred_ * qgreen_ * qblue_, box, h);
      if (normalized_)
	normalize_histogram(h, features);
      else
	Features(h.begin(), h.end()).swap(features);
    }
  }

private:

  void compute_marginal_(const PreImage& in,
			 const ivllib::Box& box,
			 Features& features) const
  {
    assert(box.bottom() <= in.rows());
    assert(box.right() <= in.columns());
    typedef ivllib::Box::size_type size_type;

    ivllib::Vector<double> ret(qred_ + qgreen_ + qblue_, 0);
    for (size_type i = box.top(); i < box.bottom(); i++) {
      for (size_type j = box.left(); j < box.right(); j++) {
	assert(in[i][j] < (1 << 24));
	unsigned int val = in[i][j];
	unsigned int r = (val >> 16);
	unsigned int g = ((val >> 8) & 255);
	unsigned int b = (val & 255);
	r = (r * qred_) >> 8;
	g = (g * qgreen_) >> 8;
	b = (b * qblue_) >> 8;
	++ret[r];
	++ret[qred_ + g];
	++ret[qred_ + qgreen_ + b];
      }
    }

    if (normalized_) {
      double tot = box.area();
      ivllib::mul(ret, tot > 0 ? 1.0 / tot : 1, features);
    } else {
      features.swap(ret);
    }
  }


  int qred_;
  int qgreen_;
  int qblue_;
  bool normalized_;
  bool marginal_;
};


int main(int argc, char* argv[])
{
  RGBHistogramComputer computer;
  computer.set_usage(USAGE);
  return computer.run(argc, argv);
}
