#include <framework/box_feature_computer.h>
#include <features/basic_features.h>

#include <iostream>
#include <stringop.h>


const char* USAGE= "Usage: lbphistogram [OPTIONS] [IMAGES...]\n"
  "\n"
  "Compute the histogram of the quantized RGB color space.\n";


class LBPHistogramComputer
  : public BoxFeatureComputer<ivllib::label_type>
{
public:
  typedef BoxFeatureComputer<ivllib::label_type> Super;

  LBPHistogramComputer()
    : Super(),
      n_(8),
      r_(1),
      rotinv_(false),
      uniform_(false),
      normalized_(false),
      lut_(),
      np_(0)
  {
    np_ = make_lbp_lut(n_, rotinv_, uniform_, lut_);
  }
  
protected: 

  virtual void do_setup_options(cc::OptionParser& parser)
  {
    Super::do_setup_options(parser);
    parser.add_option(cc::Option("normalized", 'N', cc::Option::noparam,
				 "FEATURES",
				 "Normalize the histogram to have unitary "
				 "sum."));
    parser.add_option(cc::Option("uniform", 'U', cc::Option::noparam,
				 "FEATURES",
				 "Uniform patterns."));
    parser.add_option(cc::Option("rotation-invariant", 'I', cc::Option::noparam,
				 "FEATURES",
				 "Rotation invariant patterns."));
    parser.add_option(cc::Option("neighbors", 'M', "N",
				 "FEATURES",
				 "Indicate the number of neighbors "
				 "(max 16, default 8)."));
    parser.add_option(cc::Option("radius", 'R', "R",
				 "FEATURES",
				 "Radius of the neighborhood "
				 "(default 1)."));
  }

  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images)
  {
    Super::do_parse_options(parser, options, images);
    normalized_ = options.contains_option("normalized");
    uniform_ = options.contains_option("uniform");
    rotinv_ = options.contains_option("rotation-invariant");
    n_ = options.int_parameter_value("neighbors", 8);
    if (n_ < 1 || n_ > 16)
      parser.error("Invalid value for the 'neighbors' option.");
    r_ = options.double_parameter_value("radius", 1.0);
    if (r_ <= 0.0)
      parser.error("Invalid value for the 'radius' option.");

    np_ = make_lbp_lut(n_, rotinv_, uniform_, lut_);
  }

  virtual void do_compute_preimage(const RGBImage& in,
				   PreImage& out) const
  {
    ivllib::Matrix<ivllib::Gray8> gray;
    ivllib::luminance_image(in, gray);
    lbpimage(gray, n_, r_, lut_, out);
  }

  virtual void do_compute_block_feature(PreImage& in,
					const ivllib::Box& box,
					Features& features) const
  {
    ivllib::Vector<ivllib::label_type> h;
    make_histogram(in, np_, box, h);
    if (normalized_)
      normalize_histogram(h, features);
    else
      Features(h.begin(), h.end()).swap(features);
  }

private:

  int n_;
  double r_;
  bool rotinv_;
  bool uniform_;
  bool normalized_;
  ivllib::Vector<lbp_type> lut_;
  ivllib::Vector<lbp_type>::size_type np_;
};


int main(int argc, char* argv[])
{
  LBPHistogramComputer computer;
  computer.set_usage(USAGE);
  return computer.run(argc, argv);
}
