#include <framework/box_feature_computer.h>
#include <features/basic_features.h>

#include <iostream>


const char* USAGE= "Usage: yuvmoments [OPTIONS] [IMAGES...]\n"
"\n"
"Compute the mean and the standard deviation of the three channels of\n"
"the YUV color space.\n";


class YUVMomentsComputer
  : public BoxFeatureComputer<ivllib::YUV8>
{
public:
  typedef BoxFeatureComputer<ivllib::YUV8> Super;

  YUVMomentsComputer()
    : Super(),
      normalized_(false),
      Y_(false),
      U_(false),
      V_(false),
      mean_(true),
      dev_(true)
  {
  }
  
protected: 

  virtual void do_setup_options(cc::OptionParser& parser)
  {
    Super::do_setup_options(parser);
    parser.add_option(cc::Option("normalized", 'N', cc::Option::noparam,
				 "FEATURES",
				 "Normalize the feature values in the range "
				 "[0, 1]."));
    
    parser.add_option(cc::Option("include-y", 'Y', cc::Option::noparam,
				 "FEATURES",
				 "Include the Y component."));

    parser.add_option(cc::Option("include-u", 'U', cc::Option::noparam,
				 "FEATURES",
				 "Include the U component."));

    parser.add_option(cc::Option("include-v", 'V', cc::Option::noparam,
				 "FEATURES",
				 "Include the V component."));

    parser.add_option(cc::Option("include-mean", 'M', cc::Option::noparam,
				 "FEATURES",
				 "Include the mean."));

    parser.add_option(cc::Option("include-stddev", 'D', cc::Option::noparam,
				 "FEATURES",
				 "Include the standard deviation."));
    
  }


  virtual void do_parse_options(cc::OptionParser& parser,
				const cc::ParsedOptions& options,
				ImageList& images)
  {
    Super::do_parse_options(parser, options, images);
    normalized_ = options.contains_option("normalized");
    Y_ = options.contains_option("include-y");
    U_ = options.contains_option("include-u");
    V_ = options.contains_option("include-v");
    if (!Y_ && !U_ && !V_) {
      Y_ = true;
      U_ = true;
      V_ = true;
    }
    mean_ = options.contains_option("include-mean");
    dev_ = options.contains_option("include-stddev");
    if (!mean_ && !dev_) {
      mean_ = true;
      dev_ = true;
    }
  }

  virtual void do_compute_preimage(const RGBImage& in,
				   PreImage& out) const
  {
    ivllib::convert_image(in, out);
  }

  virtual void do_compute_block_feature(PreImage& in,
					const ivllib::Box& box,
					Features& features) const
  {
    yuvmoments(in, box, features, normalized_);
    if (Y_ && U_ && V_ && mean_ && dev_)
      return;

    int sel[6];
    int nc = 0;
    if (Y_ && mean_)
      sel[nc++] = 0;
    if (U_ && mean_)
      sel[nc++] = 1;
    if (V_ && mean_)
      sel[nc++] = 2;
    if (Y_ && dev_)
      sel[nc++] = 3;
    if (U_ && dev_)
      sel[nc++] = 4;
    if (V_ && dev_)
      sel[nc++] = 5;
    
    assert(nc > 0);
    assert(features.size() % 6 == 0);
    Features::size_type n = features.size() / 6;
    Features f(n * nc);
    for (Features::size_type i = 0; i < n; i++)
      for (int k = 0; k < nc; k++)
	f[i*nc + k] = features[i*6 + sel[k]];

    features.swap(f);
  }

private:
  bool normalized_;
  bool Y_;
  bool U_;
  bool V_;
  bool mean_;
  bool dev_;
};


int main(int argc, char* argv[])
{
  YUVMomentsComputer computer;
  computer.set_usage(USAGE);
  return computer.run(argc, argv);
}
