#!/bin/sh


for ANGLE in 90 180 270; do
    OUTDIR=$(printf "%03d" $ANGLE)
    cat all.images.txt | while read i; do
	dest=$OUTDIR/$(basename $i)
	convert -resize 300x300 -rotate $ANGLE $i $dest
    done
done
