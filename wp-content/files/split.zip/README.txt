The files correspond to:

- final_food_list.mat: List of 65 food categories used in the experimentation presented in the paper
- original_food_list.mat: List of 73 food categories used in the experimentation presented in the paper
- statistics_cell.mat: List of 65 food categories used in the experimentation presented in the paper
- TestSet.mat: List of trays used as test set
- TrainingSet.mat: List of trays used as training set
- statistics_cell.mat: food-trays categories association 
- trays_statistics.mat: trays-food categories association 