function immLab=XYZ2Lab(immXYZ,white)

if nargin==1                 
    white=[0.9505;1.00;1.0888]; %D65
end
X0=white(1);
Y0=white(2);
Z0=white(3);

% immXYZ=double(immXYZ);
X=immXYZ(:,1);
Y=immXYZ(:,2);
Z=immXYZ(:,3);

q=Y/Y0;
q1=7.787*q+16/116;
[in]=(q>0.008856);
q1([in])=q([in]).^(1/3);

p=X/X0;
p1=7.787*p+16/116;
[in]=(p>0.008856);
p1([in])=p([in]).^(1/3);

r=Z/Z0;
r1=7.787*r+16/116;
[in]=(r>0.008856);
r1([in])=r([in]).^(1/3);

immLab=zeros(size(immXYZ));
immLab(:,1)=116*q1-16;
immLab(:,2)=500*(p1-q1);
immLab(:,3)=200*(q1-r1);



