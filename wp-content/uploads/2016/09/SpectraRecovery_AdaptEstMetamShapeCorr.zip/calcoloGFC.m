function GFC=calcoloGFC(refl1,refl2)

GFCn= sum(refl1.*refl2);
GFCd= sqrt(sum(refl1.^2)) .* sqrt(sum(refl2.^2));
GFC=GFCn./GFCd;