function im = ieClip(im,lowerBound, upperBound)
%Clip data to range specified arguments.
%
%    im = ieClip(im,[lowerBound], [upperBound])
%

% Set up various
if nargin == 1
    lowerBound = 0;
    upperBound = 1;
    disp('ieClip:  Setting range to 0 1');
elseif nargin == 2
    lowerBound = -abs(lowerBound);
    upperBound = abs(lowerBound);
    s = sprintf('ieClip:  Setting range to [%.3e,%.3e]',lowerBound,upperBound);
    disp(s);
end

if ~(~exist('lowerBound','var') | isempty(lowerBound))
    im(im<lowerBound) = lowerBound;
end

if ~(~exist('upperBound') | isempty(upperBound))
    im(im>upperBound) = upperBound;
end

return;


