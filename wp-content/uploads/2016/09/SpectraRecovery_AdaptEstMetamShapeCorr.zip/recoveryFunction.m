function f=recoveryFunction(x,base1,base2,ill_,observer,reflORIG,target,XYZtarget)

XYZ=observer;

refl_est=base1*x(1:3);
refl_est=refl_est*(ill_(:,2)'*XYZ(:,3));

refl_est=refl_est+base2*x(4:6);


up=sum(refl_est(refl_est>1));
down=-sum(refl_est(refl_est<0));
    
% refl_est=ieClip(refl_est',0,1);
refl_est=refl_est';
refl_est(refl_est<0)=0;
refl_est(refl_est>1)=1;
XYZrefl=(refl_est*diag(ill_(:,2))*XYZ(:,2:4))./(ill_(:,2)'*XYZ(:,3));
if ~isempty(target)
    XYZtarget=(target'*diag(ill_(:,2))*XYZ(:,2:4))./(ill_(:,2)'*XYZ(:,3));
end
DE94_D65=deltaE94(xyz2Lab(XYZtarget),xyz2Lab(XYZrefl));

refl=refl_est;
GFCn= (sum((repmat(refl,size(reflORIG,2),1).*reflORIG'),2));
GFCd= repmat(sqrt(sum(refl.^2)),size(reflORIG,2),1) .* sqrt(sum(reflORIG.^2)');
GFC=GFCn./GFCd;

f = DE94_D65 + 100*up + 100*down + 1*(1-max(GFC));

% figure(1)
% plot(target,'b')
% hold on
% plot(refl_est,'r')
% hold off
% ylim([0 1])
% drawnow