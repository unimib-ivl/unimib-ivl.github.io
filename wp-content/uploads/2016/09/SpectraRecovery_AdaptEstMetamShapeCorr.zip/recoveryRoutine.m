function [errors,recovered]=recoveryRoutine(XYZREFLtr,REFLtr,Basi,ill,obs,illA,illF2,reflORIG,BasiICA)

%%% reflORIG  : training reflectances
%%% XYZREFLtr : XYZ values of the reflectances that we want to recover
%%% REFLtr    : ground truth of the reflectances to be recovered, if not available []
%%% Basi      : error base
%%% BasiICA   : base of the whole training set

ill_=ill;

XYZ=obs;
S=diag(ill(:,2))*XYZ(:,2:4);
refls=BasiICA*inv(S'*BasiICA)*XYZREFLtr';
refls=refls*(ill(:,2)'*XYZ(:,3));
Refls=ieClip(refls,0,1); % specta recovered with the baseICA

errors=[];
recovered=[];
for ii=1:size(XYZREFLtr,1)
    refl=Refls(:,ii)'; % refltectance ii recovered with the baseICA
    if ~isempty(REFLtr)
        target=REFLtr(:,ii); % reflectance ii GT
    else
        target=[];
    end
    XYZtarget=XYZREFLtr(ii,:);
    
    % GFC among the reflectance recovered and the whole training set
    GFCn= (sum((repmat(refl,size(reflORIG,2),1).*reflORIG'),2));
    GFCd= repmat(sqrt(sum(refl.^2)),size(reflORIG,2),1) .* sqrt(sum(reflORIG.^2)');
    GFC=GFCn./GFCd;
    GFCmax=max(GFC);
    u=find(GFC>=0.95*GFCmax);
    if length(u)>10 % if there are enough similar spectra in the trainin set --> adaptive base
        adaptiveTRAIN=reflORIG(:,u); 
        [U,~,~]=svd(adaptiveTRAIN); 
        BasiICA2=U(:,1:3); % adaptive base
    else
        BasiICA2=BasiICA;
    end
    refls=BasiICA2*inv(S'*BasiICA2)*XYZREFLtr';
    refls=refls*(ill(:,2)'*XYZ(:,3));
    refls=ieClip(refls,0,1); % spectra recovered with the new baseICA2
    
    base1=BasiICA2; % adaptive base
    base2=Basi; % error base
    optionsFMinSearch = optimset('Display','off','TolFun',1e-13,'TolX',1e-13,'MaxIter',1e5,'MaxFunEvals',1e5);
    startW=[inv(S'*BasiICA2)*XYZREFLtr(ii,:)'; zeros(3,1)]; % initialization
    for jj=1:5
        if jj~=1
            startW=T;
        end
        [T,~,~,~]=fminsearch(@(x)recoveryFunction(x,base1,base2,ill_,obs,reflORIG,target,XYZtarget),startW,optionsFMinSearch);
    end
    refls=base1*T(1:3);
    refls=refls*(ill(:,2)'*XYZ(:,3));
    refls=refls+base2*T(4:6);
    refls=ieClip(refls,0,1);
    refl=refls; % final reflectance
  
    refl=refl';
    XYZrefl=(refl*diag(ill(:,2))*XYZ(:,2:4))./(ill(:,2)'*XYZ(:,3));
    DE94_D65=deltaE94(xyz2Lab(XYZREFLtr(ii,:)),xyz2Lab(XYZrefl));
    if ~isempty(REFLtr)
        DE94_A=DEunderIlluminant(XYZ(:,2:4),REFLtr(:,ii),refl',illA(:,2));
        DE94_F2=DEunderIlluminant(XYZ(:,2:4),REFLtr(:,ii),refl',illF2(:,2));
        RMSE=sqrt(sum(((refl-REFLtr(:,ii)').^2)/length(refl)));
        MAE=mean(abs(refl-REFLtr(:,ii)'));
        errors=[errors; DE94_D65 DE94_A DE94_F2 RMSE MAE calcoloGFC(refl,REFLtr(:,ii)')];
    else
        errors=[errors; DE94_D65];
    end
    recovered=[recovered; refl];
end
recovered=recovered';