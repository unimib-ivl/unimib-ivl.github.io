function DE=DEunderIlluminant(obs,sp1,sp2,ill)

% obs = observer [nx3]
% sp1 = spectra1 [nx1]
% sp2 = spectra2 [nx1]
% ill = illuminant SPD [nx1]

T1=(sp1'*diag(ill)*obs)./(ill'*obs(:,2));
T2=(sp2'*diag(ill)*obs)./(ill'*obs(:,2));

DE=deltaE94(xyz2Lab(T1),xyz2Lab(T2));

