% ReflRecoverAEMSR: recovers the reflectance spectra from tristimulus values. 

% INPUT:
%  SPECTRAtrain   : [31 n] training reflectances
%  XYZ_train      : [n 3] XYZ values of the training reflectances
%  XYZ_to_recover : [m 3] XYZ values of the reflectances that we want to recover
%  spectraGT      : [31 m] ground truth reflectances to be recovered, if not
%                   available, this variable can be set to =[]
%  XYZ            : standard observer CMF
%  D65            : illuminant SPD under which to perform the recovery. It
%                   is the same used to calculate XYZ_train and XYZ_to_recover
%  illA           : further illuminant SPD used to calculate the accuracy
%                   of the recovery (if spectraGT is available)
%  illF2          : further illuminant SPD used to calculate the accuracy
%                   of the recovery (if spectraGT is available)

% OUTPUT:
%  errors           : colorimetric errors between given and recovered reflectances.
%                     if spectraGT is available, the colorimetric error is
%                     computed also under different illuminants, and
%                     spectral error measures are also computed
%  recoveredSpectra : [31 m] recovered spectra

% ---------------------------------------------------------
% LITERATURE :
%
%  S. Bianco
%  "Reflectance Spectra Recovery from Tristimulus Values
%  by Adaptive Estimation with Metameric Shape Correction"
%  J. Opt. Soc. Am. A, Vol. 27, No. 8, pp. 1868-1877, 2010.
%
%-----------------------------------------------------------


% the weigths in the optimization function i.e. [alpha,beta,gamma,delta] in
% equation (18) in the paper can be set in line 26 of the function
% recoveryFunction.m
% the suggested values are [alpha,beta,gamma,delta]=[1,100,100,1]

% The number of cycles in the optimization can be set in line 49 of
% recoveryRoutine.m; the value used is 5.
% The maximum number of iterations in the optimization can be set in line 47 of
% recoveryRoutine.m; the value used is 1e5.
% Both these values can be lowered if a higher speed is required.


%% recovery
Ms=SPECTRAtrain*pinv(XYZ_train'); % pseudo-inverse matrix for recovery
FUND=Ms*XYZ_train'; % pseudo-inverse recovery
refls=FUND; 
XXX=SPECTRAtrain-refls; % error spectra
[U,~,~]=svd(XXX); 
Basi=U(:,1:3); % error base
[U,~,~]=svd(SPECTRAtrain(:,2:end)); 
BasiICA=U(:,1:3); % specra base

[errors,recoveredSpectra]=recoveryRoutine(XYZ_to_recover,spectraGT,Basi,D65,XYZ,illA,illF2,SPECTRAtrain,BasiICA);
